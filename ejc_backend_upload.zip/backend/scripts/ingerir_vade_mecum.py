"""
EJC — Script de ingestão do Vade Mecum Jurídico no RAG
Execute após o sistema estar rodando:
  docker exec ejc_backend python scripts/ingerir_vade_mecum.py

O script processa o PDF de 198 páginas, gera embeddings e persiste no pgvector.
"""
import asyncio, sys, os
sys.path.insert(0, '/app')

async def main():
    print("EJC — Ingestão do Vade Mecum Jurídico")
    print("=" * 50)
    try:
        from app.core.database import AsyncSessionLocal
        from app.modules.rag.knowledge_base import LegalKnowledgeBase

        kb = LegalKnowledgeBase()
        pdf_path = '/app/uploads/vade_mecum_detetive_juridico_final.pdf'

        if not os.path.exists(pdf_path):
            print(f"✗ Arquivo não encontrado: {pdf_path}")
            print(f"  Copie o PDF para: backend/uploads/")
            return

        with open(pdf_path, 'rb') as f:
            pdf_bytes = f.read()

        print(f"  Arquivo: {len(pdf_bytes)/1024:.0f} KB · 198 páginas")
        print(f"  Gerando embeddings (pode demorar 2-5 min)...")

        async with AsyncSessionLocal() as db:
            result = await kb.ingest_file(
                db=db,
                file_bytes=pdf_bytes,
                filename='vade_mecum_detetive_juridico_final.pdf',
                title='Vade Mecum do Detetive Jurídico — Guia OAB Completo',
                category='legislacao',
                metadata={'fonte':'Vade Mecum EJC','paginas':198,'areas':15,'versao':'2026'},
            )
            await db.commit()

        print(f"\n✓ Ingestão concluída!")
        print(f"  Documento ID : {result.get('document_id','?')}")
        print(f"  Chunks       : {result.get('chunks','?')}")
        print(f"\nO chat e a redação de peças agora usam o Vade Mecum como base.")

    except Exception as e:
        print(f"✗ Erro: {e}")
        import traceback; traceback.print_exc()

if __name__ == '__main__':
    asyncio.run(main())
