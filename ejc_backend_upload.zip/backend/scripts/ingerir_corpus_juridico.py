"""
EJC — Ingestão do Corpus Jurídico Completo
Execute após o sistema subir:
  docker exec ejc_backend python scripts/ingerir_corpus_juridico.py

Documentos:
  1. Vade Mecum Detetive Jurídico (198 págs)
  2. Súmulas STF 1-736 (427 págs)
  3. Súmulas STJ Penal (11 págs, 39 súmulas)
  4. Súmulas TST + OJs (579 págs)
  5. CTN 5ª edição (71 págs, 218 artigos)
  6. CTN Atualização 2026.1 (7 págs)

Total estimado: ~3.500 chunks | ~14.000 embeddings
"""
import asyncio, sys, os
sys.path.insert(0, '/app')

DOCUMENTOS = [
    {
        "path":     "/app/uploads/vade_mecum_detetive_juridico_final.pdf",
        "title":    "Vade Mecum do Detetive Jurídico — Guia OAB Completo",
        "category": "legislacao",
        "area":     "geral",
    },
    {
        "path":     "/app/uploads/Enunciados_Sumulas_STF_1_a_736_Completo.pdf",
        "title":    "Súmulas do STF — 1 a 736",
        "category": "jurisprudencia",
        "area":     "constitucional",
    },
    {
        "path":     "/app/uploads/stj_sumulasdostj_penal.pdf",
        "title":    "Súmulas do STJ — Área Penal",
        "category": "jurisprudencia",
        "area":     "penal",
    },
    {
        "path":     "/app/uploads/livrointernet-12-pdf.pdf",
        "title":    "Súmulas TST + Orientações Jurisprudenciais (SDI-I, SDI-II, SDC)",
        "category": "jurisprudencia",
        "area":     "trabalhista",
    },
    {
        "path":     "/app/uploads/Codigo_tributario_nacional_5ed.pdf",
        "title":    "Código Tributário Nacional — 5ª Edição (Senado Federal, 2024)",
        "category": "legislacao",
        "area":     "tributario",
    },
    {
        "path":     "/app/uploads/atualizacao-ctn-legislacao-tributaria-2026_1.pdf",
        "title":    "CTN + Legislação Tributária — Atualização 2026.1 (IBS, CBS, IS, EC 132/23)",
        "category": "legislacao",
        "area":     "tributario",
    },
]


async def main():
    print("=" * 60)
    print("EJC — Ingestão do Corpus Jurídico Completo")
    print("=" * 60)

    try:
        from app.core.database import AsyncSessionLocal
        from app.modules.rag.knowledge_base import LegalKnowledgeBase
        kb = LegalKnowledgeBase()

        total_chunks = 0
        for i, doc in enumerate(DOCUMENTOS, 1):
            path = doc["path"]
            if not os.path.exists(path):
                print(f"\n[{i}/{len(DOCUMENTOS)}] ✗ Não encontrado: {path}")
                print(f"      Copie o arquivo para backend/uploads/")
                continue

            print(f"\n[{i}/{len(DOCUMENTOS)}] {doc['title']}")
            print(f"      Arquivo: {os.path.getsize(path)/1024:.0f} KB")

            with open(path, 'rb') as f:
                pdf_bytes = f.read()

            async with AsyncSessionLocal() as db:
                result = await kb.ingest_file(
                    db=db,
                    file_bytes=pdf_bytes,
                    filename=os.path.basename(path),
                    title=doc["title"],
                    category=doc["category"],
                    metadata={"area": doc["area"], "fonte": "Corpus EJC 2026"},
                )
                await db.commit()

            chunks = result.get('chunks', '?')
            total_chunks += int(chunks) if str(chunks).isdigit() else 0
            print(f"      ✓ {chunks} chunks gerados")

        print(f"\n{'='*60}")
        print(f"✓ Corpus jurídico completo ingerido!")
        print(f"  Total chunks: ~{total_chunks}")
        print(f"\nO EJC agora possui conhecimento de:")
        print(f"  • Súmulas STF (1-736) — Direito Constitucional")
        print(f"  • Súmulas STJ Penal (39 súmulas recentes)")
        print(f"  • Súmulas TST + OJs SDI-I, SDI-II, SDC — Trabalhista")
        print(f"  • CTN completo (218 artigos) + Atualização 2026.1")
        print(f"  • IBS, CBS, IS (Reforma Tributária EC 132/23)")
        print(f"  • Vade Mecum OAB (17 manuais, todas disciplinas)")

    except Exception as e:
        print(f"\n✗ Erro: {e}")
        import traceback; traceback.print_exc()

if __name__ == '__main__':
    asyncio.run(main())
