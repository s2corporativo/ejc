-- ============================================================
-- EJC — Migration: integrações externas
-- Executa após init.sql
-- ============================================================

-- Processos monitorados via DataJud
CREATE TABLE IF NOT EXISTS processos_monitorados (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_processo     TEXT NOT NULL UNIQUE,
    tribunal            TEXT NOT NULL,
    classe              TEXT,
    ativo               BOOLEAN NOT NULL DEFAULT TRUE,
    ultima_sync         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    movimentos_count    INTEGER NOT NULL DEFAULT 0,
    document_id         UUID REFERENCES documents(id) ON DELETE SET NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_processos_monitorados_ativo
    ON processos_monitorados(ativo, ultima_sync);

-- Log de consultas a APIs externas
CREATE TABLE IF NOT EXISTS integracao_log (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fonte       TEXT NOT NULL,   -- 'datajud' | 'lexml' | 'stj' | 'receita'
    operacao    TEXT NOT NULL,
    parametros  JSONB NOT NULL DEFAULT '{}',
    status      TEXT NOT NULL,   -- 'sucesso' | 'erro'
    latencia_ms INTEGER,
    erro_msg    TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_integracao_log_fonte_data
    ON integracao_log(fonte, created_at DESC);
