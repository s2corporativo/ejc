-- EJC — Seed: Súmulas STF + STJ Penal + TST
-- Inseridas na tabela jurisprudencias_salvas para acesso imediato
-- Também disponíveis via RAG (embeddings) após execução do script de ingestão
BEGIN;

INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 1, 'É vedada a expulsão de estrangeiro casado com Brasileira, ou que tenha filho Brasileiro,
dependente da economia paterna.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 3, 'A imunidade concedida a deputados estaduais é restrita à Justiça do Estado. (Superada)', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 5, 'A sanção do projeto supre a falta de iniciativa do Poder Executivo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 7, 'Sem prejuízo de recurso para o Congresso, não é exeqüível contrato administrativo a
que o Tribunal de Contas houver negado registro.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 9, 'Para o acesso de auditores ao Superior Tribunal Militar, só concorrem os de segunda
entrância.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 11, 'A vitaliciedade não impede a extinção do cargo, ficando o funcionário em
disponibilidade, com todos os vencimentos.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 13, 'A equiparação de extranumerário a funcionário efetivo, determinada pela L. 2.284, de
9.8.54, não envolve reestruturação, não compreendendo, portanto, os vencimentos.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 15, 'Dentro do prazo de validade do concurso, o candidato aprovado tem o direito à
nomeação, quando o cargo fôr preenchido sem observância da classificação.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 17, 'A nomeação de funcionário sem concurso pode ser desfeita antes da posse.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 19, 'É inadmissível segunda punição de servidor público, baseada no mesmo processo em
que se fundou a primeira.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 21, 'Funcionário em estágio probatório não pode ser exonerado nem demitido sem inquérito
ou sem as formalidades legais de apuração de sua capacidade.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 23, 'Verificados os pressupostos legais para o licenciamento da obra, não o impede a
declaração de utilidade pública para desapropriação do imóvel, mas o valor da obra não
se incluirá na indenização, quando a desapropriação fôr efetivada.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 25, 'A nomeação a têrmo não impede a livre demissão pelo Presidente da República, de
ocupante de cargo dirigente de autarquia.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 27, 'Os servidores públicos não têm vencimentos irredutíveis, prerrogativa dos membros do
Poder Judiciário e dos que lhes são equiparados.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 29, 'Gratificação devida a servidores do "sistema fazendário" não se estende aos dos
Tribunais de Contas.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 31, 'Para aplicação da L. 1741, de 22.11.52, soma-se o tempo de serviço ininterrupto em mais
de um cargo em comissão.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 32, 'Para aplicação da L. 1741, de 22.11.52, soma-se o tempo de serviço ininterrupto em cargo
em comissão e em função gratificada.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 34, 'No Estado de São Paulo, funcionário eleito vereador fica licenciado por tôda a duração
do mandato.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 36, 'Servidor vitalício está sujeito à aposentadoria compulsória, em razão da idade.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 38, 'Reclassificação posterior à aposentadoria não aproveita ao servidor aposentado.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 40, 'A elevação da entrância da comarca não promove automaticamente o juiz, mas não
interrompe o exercício de suas funções na mesma comarca.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 42, 'É legítima a equiparação de juízes do Tribunal de Contas, em direitos e garantias, aos
membros do Poder Judiciário.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 45, 'A estabilidade dos substitutos do Ministério Público Militar não confere direito aos
vencimentos da atividade fora dos períodos de exercício.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 47, 'Reitor de universidade não é livremente demissível pelo Presidente da República
durante o prazo de sua investidura.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 49, 'A cláusula de inalienabilidade inclui a incomunicabilidade dos bens.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 51, 'Militar não tem direito a mais de duas promoções na passagem para a inatividade, ainda
que por motivos diversos.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 53, 'A promoção de professor militar, vinculada à sua reforma, pode ser feita, quando
couber, a pôsto inexistente no quadro.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 54, 'A reserva ativa do magistério militar não confere vantagens vinculadas à efetiva
passagem para a inatividade.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 56, 'Militar reformado não está sujeito à pena disciplinar.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 58, 'É válida a exigência de média superior a quatro para aprovação em estabelecimento de
ensino superior, consoante o respectivo regimento.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 60, 'Não pode o estrangeiro trazer automóvel quando não comprovada a transferência
definitiva de sua residência para o Brasil.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 62, 'Não basta a simples estada no estrangeiro por mais de seis meses, para dar direito à
trazida de automóvel com fundamento em transferência de residência.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 64, 'É permitido trazer do estrangeiro, como bagagem, objetos de uso pessoal e doméstico,
desde que, por sua quantidade e natureza, não induzam finalidade comercial.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 66, 'É legítima a cobrança do tributo que houver sido aumentado após o orçamento, mas
antes do início do respectivo exercício financeiro.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 68, 'É legítima a cobrança, pelos Municípios, no exercício de 1961, de tributo estadual,
regularmente criado ou aumentado, e que lhes foi transferido pela Emenda
Constitucional nº 5, de 21.11.61.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 70, 'É inadmissível a interdição de estabelecimento como meio coercitivo para cobrança de
tributo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 71, 'Embora pago indevidamente, não cabe restituição de tributo indireto.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 73, 'A imunidade das autarquias, implicitamente contida no art. 31, V, a, da Constituição
Federal, abrange tributos estaduais e municipais.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 75, 'Sendo vendedora uma autarquia, a sua imunidade fiscal não compreende o impôsto de
transmissão inter vivos, que é encargo do comprador.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 77, 'Está isenta de impostos federais a aquisição de bens pela Rêde Ferroviária Federal.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 79, 'O Banco do Brasil não tem isenção de tributos locais.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 81, 'As cooperativas não gozam de isenção de impostos locais, com fundamento na
Constituição e nas leis federais.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 83, 'Os ágios de importação incluem-se no valor dos artigos importados para incidência do
impôsto de consumo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 85, 'Não estão sujeitos ao impôsto de consumo os bens de uso pessoal e doméstico trazidos,
como bagagem, do exterior.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 87, 'Somente no que não colidirem com a L. 3.244, de 14.8.57, são aplicáveis acordos
tarifários anteriores.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 88, 'É válida a majoração da tarifa alfandegária, resultante da L. 3.244, de 14.8.57, que
modificou o Acordo Geral sôbre Tarifas Aduaneiras e Comércio (GATT), aprovado pela
L. 313, de 30.7.48.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 90, 'É legítima a lei local que faça incidir o impôsto de indústrias e profissões com base no
movimento econômico do contribuinte.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 92, 'É constitucional o art. 100, nº II, da L. 4.563, de 20.2.57, do Município de Recife, que faz
variar o impôsto de licença em função do aumento do capital do contribuinte.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 94, 'É competente a autoridade alfandegária para o desconto, na fonte, do impôsto de renda
correspondente às comissões dos despachantes aduaneiros.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 96, 'O impôsto de lucro imobiliário incide sôbre a venda de imóvel da meação do cônjuge
sobrevivente, ainda que aberta a sucessão antes da vigência da L. 3.470, de 28.11.58.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 98, 'Sendo o imóvel alienado na vigência da L. 3.470, de 28.11.58, ainda que adquirido por
herança, usucapião ou a título gratuito, é devido o impôsto de lucro imobiliário.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 100, 'Não é devido o impôsto de lucro imobiliário, quando a alienação de imóvel, adquirido
por usucapião, tiver sido anterior à vigência da L. 3.470, de 28.11.58.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 102, 'É devido o impôsto federal do selo pela incorporação de reservas, em reavaliação de
ativo, ainda que realizada antes da vigência da L. 3.519, de 30.12.58.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 104, 'Não é devido o impôsto federal do selo na simples reavaliação de ativo anterior à
vigência da L. 3.519, de 30.12.58.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 106, 'É legítima a cobrança de sêlo sôbre registro de automóveis, na conformidade da
legislação estadual.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 108, 'É legítima a incidência do impôsto de transmissão inter vivos sôbre o valor do imóvel ao
tempo da alienação e não da promessa, na conformidade da legislação local.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 110, 'O impôsto de transmissão inter vivos não incide sôbre a construção, ou parte dela,
realizada pelo adquirente, mas sôbre o que tiver sido construído ao tempo da alienação
do terreno.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 112, 'O impôsto de transmissão causa mortis é devido pela alíquota vigente ao tempo da
abertura da sucessão.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 114, 'O impôsto de transmissão causa mortis não é exigível antes da homologação do cálculo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 116, 'Em desquite ou inventário, é legítima a cobrança do chamado impôsto de reposição,
quando houver desigualdade nos valôres partilhados.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 119, 'É devido o impôsto de vendas e consignações sôbre a venda de cafés ao Instituto
Brasileiro do Café, embora o lote, originariamente, se destinasse à exportação.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 120, 'Parede de tijolos de vidro translúcido pode ser levantada a menos de metro e meio do
prédio vizinho, não importando servidão sôbre êle.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 122, 'O enfiteuta pode purgar a mora enquanto não decretado o comisso por sentença.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 124, 'É inconstitucional o adicional do impôsto de vendas e consignações cobrado pelo
Estado do Espírito Santo sôbre cafés da cota de expurgo entregues ao Instituto Brasileiro
do Café.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 125, 'Não é devido o impôsto de vendas e consignações sôbre a parcela do impôsto de
consumo que onera a primeira venda realizada pelo produtor.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 127, 'É indevida a taxa de armazenagem, posteriormente aos primeiros trinta dias, quando
não exigível o impôsto de consumo, cuja cobrança tenha motivado a retenção da
mercadoria.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 129, 'Na conformidade da legislação local, é legítima a cobrança de taxa de calçamento.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 131, 'A taxa de despacho aduaneiro (art. 66 da L. 3.244, de 14.8.57) continua a ser exigível após
o Dec. Legisl. 14, de 25.8.60, mesmo para as mercadorias incluídas na vigente lista III do
Acordo Geral sôbre Tarifas Aduaneiras e Comércio (GATT).', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 132, 'Não é devida a taxa de previdência social na importação de amianto bruto ou em fibra.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 133, 'Não é devida a taxa de despacho aduaneiro na importação de fertilizantes e inseticidas.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 135, 'É inconstitucional a taxa de eletrificação de Pernambuco.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 136, 'É constitucional a taxa de estatística da Bahia.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 138, 'É inconstitucional a taxa contra fogo, do estado de Minas Gerais, incidente sôbre prêmio
de seguro contra fogo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 140, 'Na importação de lubrificantes é devida a taxa de previdência social.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 141, 'Não incide a taxa de previdência social sôbre combustíveis.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 143, 'Na forma da lei estadual, é devido o impôsto de vendas e consignações na exportação de
café pelo Estado da Guanabara, embora proveniente de outro Estado.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 145, 'Não há crime, quando a preparação do flagrante pela polícia torna impossível a sua
consumação.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 146, 'A prescrição da ação penal regula-se pela pena concretizada na sentença, quando não há
recurso da acusação.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 148, 'É legítimo o aumento de tarifas portuárias por ato do Ministro da Viação e Obras
Públicas.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 150, 'Prescreve a execução no mesmo prazo de prescrição da ação.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 152, 'A ação para anular venda de ascendente a descendente, sem consentimento dos demais,
prescreve em quatro anos a contar da abertura da sucessão. (Revogada)', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 153, 'Simples protesto cambiário não interrompe a prescrição.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 155, 'É relativa a nulidade do processo criminal por falta de intimação da expedição de
precatória para inquirição de testemunha.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 157, 'É necessária prévia autorização do Presidente da República para desapropriação, pelos
Estados, de emprêsa de energia elétrica.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 159, 'Cobrança excessiva, mas de boa-fé, não dá lugar às sanções do art. 1.531 do Código Civil.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 161, 'Em contrato de transporte, é inoperante a cláusula de não indenizar.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 163, 'Salvo contra a Fazenda Pública, sendo a obrigação ilíquida, contam-se os juros
moratórios desde a citação inicial para a ação.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 165, 'A venda realizada diretamente pelo mandante ao mandatário não é atingida pela
nulidade do art. 1.133, II, do Código Civil.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 167, 'Não se aplica o regime do Dl. 58, de 10.12.37, ao compromisso de compra e venda não
inscrito no registro imobiliário, salvo se o promitente vendedor se obrigou a efetuar o
registro.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 169, 'Depende de sentença a aplicação da pena de comisso.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 170, 'É resgatável a enfiteuse instituída anteriormente à vigência do Código Civil.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 172, 'Não se admite, na locação em curso, de prazo determinado, o reajustamento de aluguel a
que se refere a L. 3.085, de 29.12.56.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 174, 'Para a retomada do imóvel alugado, não é necessária a comprovação dos requisitos
legais na notificação prévia.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 177, 'O cessionário do promitente comprador, nas mesmas condições dêste, pode retomar o
imóvel locado.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 178, 'Não excederá de cinco anos a renovação judicial de contrato de locação, fundada no D.
24.150, de 20.4.34.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 180, 'Na ação revisional do art. 31 do D. 24.150, de 20.4.34, o aluguel arbitrado vigora a partir
do laudo pericial.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 182, 'Não impede o reajustamento do débito pecuário, nos termos da L. 1.002, de 24.12.49, a
falta de cancelamento da renúncia à moratória da L. 209, de 2.1.48.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 184, 'Não se incluem no reajustamento pecuário dívidas contraídas posteriormente a 19.12.46.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 186, 'Não infringe a lei a tolerância da quebra de 1% no transporte por estrada de ferro,
prevista no regulamento de transportes.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 188, 'O segurador tem ação regressiva contra o causador do dano, pelo que efetivamente
pagou, até ao limite previsto no contrato de seguro.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 190, 'O não pagamento de título vencido há mais de trinta dias, sem protesto, não impede a
concordata preventiva.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 192, 'Não se inclui no crédito habilitado em falência a multa fiscal com efeito de pena
administrativa.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 194, 'É competente o Ministro do Trabalho para a especificação das atividades insalubres.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 196, 'Ainda que exerça atividade rural, o empregado de emprêsa industrial ou comercial é
classificado de acôrdo com a categoria do empregador.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 198, 'As ausências motivadas por acidente do trabalho não são descontáveis do período
aquisitivo das férias.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 199, 'O salário das férias do empregado horista corresponde à média do período aquisitivo,
não podendo ser inferior ao mínimo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 201, 'O vendedor pracista, remunerado mediante comissão, não tem direito ao repouso
semanal remunerado.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 202, 'Na equiparação de salário, em caso de trabalho igual, toma-se em conta o tempo de
serviço na função, e não no emprêgo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 204, 'Tem direito o trabalhador substituto, ou de reserva, ao salário mínimo no dia em que
fica à disposição do empregador sem ser aproveitado na função específica; se
aproveitado, recebe o salário contratual.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 206, 'É nulo o julgamento ulterior pelo júri com a participação de jurado que funcionou em
julgamento anterior do mesmo processo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 208, 'O assistente do Ministério Público não pode recorrer, extraordinariamente, de decisão
concessiva de habeas corpus.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 210, 'O assistente do Ministério Público pode recorrer, inclusive extraordinariamente, na ação
penal, nos casos dos arts. 584, § 1º, e 598 do Cód. de Proc. Penal.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 211, 'Contra a decisão proferida sôbre o agravo no auto do processo, por ocasião do
julgamento da apelação, não se admitem embargos infringentes ou de nulidade.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 213, 'É devido o adicional de serviço noturno, ainda que sujeito o empregado ao regime de
revezamento.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 215, 'Conta-se a favor de empregado readmitido o tempo de serviço anterior, salvo se houver
sido despedido por falta grave ou tiver recebido a indenização legal.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 217, 'Tem direito de retornar ao emprego, ou ser indenizado em caso de recusa do
empregador, o aposentado que recupera a capacidade de trabalho dentro de cinco anos,
a contar da aposentadoria, que se torna definitiva após êsse prazo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 219, 'Para a indenização devida a empregado que tinha direito a ser readmitido, e não foi,
levam-se em conta as vantagens advindas à sua categoria no período do afastamento.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 221, 'A transferência de estabelecimento, ou a sua extinção parcial, por motivo que não seja
de fôrça maior, não justifica a transferência de empregado estável.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 223, 'Concedida isenção de custas ao empregado, por elas não responde o sindicato que o
representa em juízo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 225, 'Não é absoluto o valor probatório das anotações da carteira profissional.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 227, 'A concordata do empregador não impede a execução de crédito nem a reclamação de
empregado na Justiça do Trabalho.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 229, 'A indenização acidentária não exclui a do direito comum, em caso de dolo ou culpa
grave do empregador.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 230, 'A prescrição da ação de acidente do trabalho conta-se do exame pericial que comprovar
a enfermidade ou verificar a natureza da incapacidade.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 232, 'Em caso de acidente do trabalho, são devidas diárias até doze meses, as quais não se
confundem com a indenização acidentária nem com o auxílio-enfermidade.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 234, 'São devidos honorários de advogado em ação de acidente do trabalho julgada
procedente.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 236, 'Em ação de acidente do trabalho, a autarquia seguradora não tem isenção de custas.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 238, 'Em caso de acidente do trabalho, a multa pelo retardamento da liquidação é exigível do
segurador sub-rogado, ainda que autarquia.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 239, 'Decisão que declara indevida a cobrança do impôsto em determinado exercício não faz
coisa julgada em relação aos posteriores.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 241, 'A contribuição previdenciária incide sôbre o abono incorporado ao salário.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 243, 'Em caso de dupla aposentadoria, os proventos a cargo do IAPFESP não são equiparáveis
aos pagos pelo Tesouro Nacional, mas calculados à base da média salarial nos últimos
doze meses de serviço.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 245, 'A imunidade parlamentar não se estende ao co-réu sem essa prerrogativa.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 247, 'O relator não admitirá os embargos da L. 623, de 19.2.49, nem deles conhecerá o
Supremo Tribunal Federal, quando houver jurisprudência firme do Plenário no mesmo
sentido da decisão embargada.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 249, 'É competente o Supremo Tribunal Federal para a ação rescisória, quando, embora não
tendo conhecido do recurso extraordinário, ou havendo negado provimento ao agravo,
tiver apreciado a questão federal controvertida.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 251, 'Responde a Rêde Ferroviária Federal S.A. perante o fôro comum e não perante o juízo
especial da Fazenda Nacional, a menos que a União intervenha na causa.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 253, 'Nos embargos da L. 623, de 19.2.49, no Supremo Tribunal Federal, a divergência
somente será acolhida, se tiver sido indicada na petição de recurso extraordinário.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 255, 'Sendo ilíquida a obrigação, os juros moratórios, contra a Fazenda Pública, incluídas as
autarquias, são contados do trânsito em julgado da sentença de liquidação.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 257, 'São cabíveis honorários de advogado na ação regressiva do segurador contra o causador
do dano.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 259, 'Para produzir efeito em juízo não é necessária a inscrição, no registro público, de
documentos de procedência estrangeira, autenticados por via consular.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 261, 'Para a ação de indenização, em caso de avaria, é dispensável que a vistoria se faça
judicialmente.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 263, 'O possuidor deve ser citado pessoalmente para a ação de usucapião.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 265, 'Na apuração de haveres não prevalece o balanço não aprovado pelo sócio falecido,
excluído ou que se retirou.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 267, 'Não cabe mandado de segurança contra ato judicial passível de recurso ou correição.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 269, 'O mandado de segurança não é substitutivo de ação de cobrança.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 271, 'Concessão de mandado de segurança não produz efeitos patrimoniais em relação a
período pretérito, os quais devem ser reclamados administrativamente ou pela via
judicial própria.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 273, 'Nos embargos da L. 623, de 19.2.49, a divergência sôbre questão prejudicial ou
preliminar, suscitada após a interposição do recurso extraordinário, ou do agravo,
somente será acolhida se o acórdão-padrão fôr anterior à decisão embargada.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 274, 'É inconstitucional a taxa de serviço contra fogo cobrada pelo Estado de Pernambuco.
(Revogada)', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 276, 'Não cabe recurso de revista em ação executiva fiscal.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 278, 'São cabíveis embargos em ação executiva fiscal contra decisão reformatória da de
primeira instância, ainda que unânime.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 280, 'Por ofensa a direito local não cabe recurso extraordinário.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 282, 'É inadmissível o recurso extraordinário, quando não ventilada, na decisão recorrida, a
questão federal suscitada.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 283, 'É inadmissível o recurso extraordinário, quando a decisão recorrida assenta em mais de
um fundamento suficiente e o recurso não abrange todos êles.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 285, 'Não sendo razoável a argüição de inconstitucionalidade, não se conhece do recurso
extraordinário fundado na letra c do art. 101, III, da Constituição Federal.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 287, 'Nega-se provimento ao agravo, quando a deficiência na sua fundamentação, ou na do
recurso extraordinário, não permitir a exata compreensão da controvérsia.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 289, 'O provimento do agravo por uma das Turmas do Supremo Tribunal Federal ainda que
sem ressalva, não prejudica a questão do cabimento do recurso extraordinário.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 291, 'No recurso extraordinário pela letra d do art. 101, n. III, da Constituição, a prova do
dissídio jurisprudencial far-se-á por certidão, ou mediante indicação do Diário da
Justiça ou de repertório de jurisprudência autorizado, com a transcrição do trecho que
configure a divergência, mencionadas as circunstâncias que identifiquem ou
assemelhem os casos confrontados.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 292, 'Interposto o recurso extraordinário por mais de um dos fundamentos indicados no art.
101, n. III, da Constituição, a admissão apenas por um dêles não prejudica o seu
conhecimento por qualquer dos outros.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 294, 'São inadmissíveis embargos infringentes contra decisão do Supremo Tribunal Federal
em mandado de segurança.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 295, 'São inadmissíveis embargos infringentes contra decisão unânime do Supremo Tribunal
Federal em ação rescisória.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 297, 'Oficiais e praças das milícias dos Estados, no exercício de função policial civil, não são
considerados militares para efeitos penais, sendo competente a Justiça comum para
julgar os crimes cometidos por ou contra êles.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 298, 'O legislador ordinário só pode sujeitar civis à Justiça Militar, em tempo de paz, nos
crimes contra a segurança externa do país ou as instituições militares.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 300, 'São incabíveis os embargos da L. 623, de 19.2.49, contra provimento de agravo para
subida de recurso extraordinário.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 302, 'Está isenta da taxa de previdência social a importação de petróleo bruto.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 304, 'Decisão denegatória de mandado de segurança, não fazendo coisa julgada contra o
impetrante, não impede o uso da ação própria.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 305, 'Acordo de desquite ratificado por ambos os cônjuges não é retratável unilateralmente.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 307, 'É devido o adicional de serviço insalubre, calculado à base do salário mínimo da região,
ainda que a remuneração contratual seja superior ao salário mínimo acrescido da taxa de
insalubridade.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 309, 'A taxa de despacho aduaneiro, sendo adicional do impôsto de importação, não está
compreendida na isenção do impôsto de consumo para automóvel usado trazido do
exterior pelo proprietário.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 311, 'No típico acidente do trabalho, a existência de ação judicial não exclui a multa pelo
retardamento da liquidação.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 313, 'Provada a identidade entre o trabalho diurno e o noturno, é devido o adicional, quanto a
este, sem a limitação do art. 73, § 3º, da C.L.T., independentemente da natureza da
atividade do empregador.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 315, 'Indispensável o traslado das razões da revista, para julgamento, pelo Tribunal Superior
do Trabalho, do agravo para sua admissão.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 316, 'A simples adesão a greve não constitui falta grave.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 318, 'É legítima a cobrança, em 1962, pela municipalidade de São Paulo, do impôsto de
indústrias e profissões, consoante as leis 5.917 e 5.919, de 1961 (aumento anterior à
vigência do orçamento e incidência do tributo sôbre o movimento econômico do
contribuinte).', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 320, 'A apelação despachada pelo juiz no prazo legal não fica prejudicada pela demora da
juntada, por culpa do cartório.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 321, 'A constituição estadual pode estabelecer a irredutibilidade dos vencimentos do
Ministério Público.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 323, 'É inadmissível a apreensão de mercadorias como meio coercitivo para pagamento de
tributos.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 325, 'As emendas ao regimento do Supremo Tribunal Federal, sôbre julgamento de questão
constitucional, aplicam-se aos pedidos ajuizados e aos recursos interpostos
anteriormente a sua aprovação.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 327, 'O direito trabalhista admite a prescrição intercorrente.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 329, 'O impôsto de transmissão inter vivos não incide sôbre a transferência de ações de
sociedade imobiliária.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 331, 'É legítima a incidência do impôsto de transmissão causa mortis no inventário por morte
presumida.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 333, 'Está sujeita ao impôsto de vendas e consignações a venda realizada por invernista não
qualificado como pequeno produtor.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 335, 'É válida a cláusula de eleição do fôro para os processos oriundos do contrato.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 337, 'A controvérsia entre o empregador e o segurador não suspende o pagamento devido ao
empregado por acidente do trabalho.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 339, 'Não cabe ao Poder Judiciário, que não tem função legislativa, aumentar vencimentos de
servidores públicos sob fundamento de isonomia.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 341, 'É presumida a culpa do patrão ou comitente pelo ato culposo do empregado ou
preposto.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 342, 'Cabe agravo no auto do processo, e não agravo de petição, do despacho que não admite
a reconvenção.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 344, 'Sentença de primeira instância concessiva de habeas corpus, em caso de crime praticado
em detrimento de bens, serviços ou interesses da União, está sujeita a recurso ex officio.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 345, 'Na chamada desapropriação indireta, os juros compensatórios são devidos a partir da
perícia, desde que tenha atribuído valor atual ao imóvel.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 347, 'O Tribunal de Contas, no exercício de suas atribuições, pode apreciar a
constitucionalidade das leis e dos atos do poder público.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 348, 'É constitucional a criação de taxa de construção, conservação e melhoramento de
estradas.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 350, 'O impôsto de indústrias e profissões não é exigível de empregado, por falta de
autonomia na sua atividade profissional.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 352, 'Não é nulo o processo penal por falta de nomeação de curador ao réu menor que teve a
assistência de defensor dativo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 354, 'Em caso de embargos infringentes parciais, é definitiva a parte da decisão embargada
em que não houve divergência na votação.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 356, 'O ponto omisso da decisão, sôbre o qual não foram opostos embargos declaratórios, não
pode ser objeto de recurso extraordinário, por faltar o requisito do prequestionamento.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 358, 'O servidor público em disponibilidade tem direito aos vencimentos integrais do cargo.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 360, 'Não há prazo de decadência para a representação de inconstitucionalidade prevista no
art. 8º, parágrafo único, da Constituição Federal.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 362, 'A condição de ter o clube sede própria para a prática de jôgo lícito não o obriga a ser
proprietário do imóvel em que tem sede.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 364, 'Enquanto o Estado da Guanabara não tiver Tribunal Militar de segunda instância, o
Tribunal de Justiça é competente para julgar os recursos das decisões da auditoria da
Polícia Militar.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 365, 'Pessoa jurídica não tem legitimidade para propor ação popular.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 367, 'Concede-se liberdade ao extraditando que não fôr retirado do país no prazo do art. 16 do
Decreto-lei. 394, de 28.4.38.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 370, 'Julgada improcedente a ação renovatória da locação, terá o locatário, para desocupar o
imóvel, o prazo de seis meses, acrescido de tantos meses quantos forem os anos da
ocupação, até o limite total de dezoito meses.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STF', 372, 'A L. 2.752, de 10.4.56, sôbre dupla aposentadoria, aproveita, quando couber, a servidores
aposentados antes de sua publicação.', 'constitucional', 3, 'Súmulas STF 1-736')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 668, 'Não é hediondo o delito de porte ou posse de arma de fogo de uso permitido, ainda que com numeração, marca ou qualquer outro sinal de identificação raspado, suprimido ou adulterado.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 664, 'É inaplicável a consunção entre o delito de embriaguez ao volante e o de condução de veículo automotor sem habilitação.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 662, 'Para a prorrogação do prazo de permanência no sistema penitenciário federal, é prescindível a ocorrência de fato novo; basta constar, em decisão fundamentada, a persistência dos motivos que ensejaram a transferência inicial do preso.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 661, 'A falta grave prescinde da perícia do celular apreendido ou de seus componentes essenciais.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 660, 'A posse, pelo apenado, de aparelho celular ou de seus componentes essenciais constitui falta grave.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 659, 'A fração de aumento em razão da prática de crime continuado deve ser fixada de acordo com o número de delitos cometidos, aplicando-se 1/6 pela prática de duas infrações, 1/5 para três, 1/4 para quatro, 1/3 para cinco, 1/2 para seis e 2/3 para sete ou mais infrações.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 658, 'O crime de apropriação indébita tributária pode ocorrer tanto em operações próprias, como em razão de substituição tributária.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 645, 'O crime de fraude à licitação é formal, e sua consumação prescinde da comprovação do prejuízo ou da obtenção de vantagem.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 643, 'A execução da pena restritiva de direitos depende do trânsito em julgado da condenação.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 636, 'A folha de antecedentes criminais é documento suficiente a comprovar os maus antecedentes e a reincidência.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 631, 'O indulto extingue os efeitos primários da condenação (pretensão executória), mas não atinge os efeitos secundários, penais ou extrapenais.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 630, 'A incidência da atenuante da confissão espontânea no crime de tráfico ilícito de entorpecentes exige o reconhecimento da traficância pelo acusado, não bastando a mera admissão da posse ou propriedade para uso próprio.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 617, 'A ausência de suspensão ou revogação do livramento condicional antes do término do período de prova enseja a extinção da punibilidade pelo integral cumprimento da pena.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 607, 'A majorante do tráfico transnacional de drogas (art. 40, I, da Lei n. 11.343/2006) configura-se com a prova da destinação internacional das drogas, ainda que não consumada a transposição de fronteiras.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 606, 'Não se aplica o princípio da insignificância a casos de transmissão clandestina de sinal de internet via radiofrequência.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 600, 'Para a configuração da violência doméstica e familiar prevista no artigo 5º da Lei n. 11.340/2006 (Lei Maria da Penha) não se exige a coabitação entre autor e vítima.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 599, 'O princípio da insignificância é inaplicável aos crimes contra a administração pública.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 593, 'O crime de estupro de vulnerável se configura com a conjunção carnal ou prática de ato libidinoso com menor de 14 anos, sendo irrelevante eventual consentimento da vítima.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 589, 'É inaplicável o princípio da insignificância nos crimes ou contravenções penais praticados contra a mulher no âmbito das relações domésticas.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 588, 'A prática de crime ou contravenção penal contra a mulher com violência ou grave ameaça no ambiente doméstico impossibilita a substituição da pena privativa de liberdade por restritiva de direitos.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 582, 'Consuma-se o crime de roubo com a inversão da posse do bem mediante emprego de violência ou grave ameaça, ainda que por breve tempo.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 567, 'Sistema de vigilância realizado por monitoramento eletrônico ou por existência de segurança no interior de estabelecimento comercial, por si só, não torna impossível a configuração do crime de furto.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 562, 'É possível a remição de parte do tempo de execução da pena quando o condenado, em regime fechado ou semiaberto, desempenha atividade laborativa, ainda que extramuros.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 545, 'Quando a confissão for utilizada para a formação do convencimento do julgador, o réu fará jus à atenuante prevista no art. 65, III, d, do Código Penal.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 542, 'A ação penal relativa ao crime de lesão corporal resultante de violência doméstica contra a mulher é pública incondicionada.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 536, 'A suspensão condicional do processo e a transação penal não se aplicam na hipótese de delitos sujeitos ao rito da Lei Maria da Penha.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 534, 'A prática de falta grave interrompe a contagem do prazo para a progressão de regime de cumprimento de pena.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 533, 'Para o reconhecimento da prática de falta disciplinar no âmbito da execução penal, é imprescindível a instauração de procedimento administrativo pelo diretor do estabelecimento prisional.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 522, 'A conduta de atribuir-se falsa identidade perante autoridade policial é típica, ainda que em situação de alegada autodefesa.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 511, 'É possível o reconhecimento do privilégio previsto no § 2º do art. 155 do CP nos casos de crime de furto qualificado.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 500, 'A configuração do crime do art. 244-B do ECA independe da prova da efetiva corrupção do menor, por se tratar de delito formal.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 444, 'É vedada a utilização de inquéritos policiais e ações penais em curso para agravar a pena-base.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 443, 'O aumento na terceira fase de aplicação da pena no crime de roubo circunstanciado exige fundamentação concreta.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 440, 'Fixada a pena-base no mínimo legal, é vedado o estabelecimento de regime prisional mais gravoso com base apenas na gravidade abstrata do delito.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 438, 'É inadmissível a extinção da punibilidade pela prescrição da pretensão punitiva com fundamento em pena hipotética.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 231, 'A incidência da circunstância atenuante não pode conduzir à redução da pena abaixo do mínimo legal.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 220, 'A reincidência não influi no prazo da prescrição da pretensão punitiva.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 96, 'O crime de extorsão consuma-se independentemente da obtenção da vantagem indevida.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('STJ', 18, 'A sentença concessiva do perdão judicial é declaratória da extinção da punibilidade, não subsistindo qualquer efeito condenatório.', 'penal', 5, 'Súmulas STJ Penal')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 46, 'SUM-86      Empresa em liquidação extrajudicial. Massa falida. Depósi-
                to recursal e custas processuais. Deserção.
    OJ-SDI1-408 Juros de mora. Empresa em liquidação extrajudicial. Suces-
                são trabalhista.
    OJ-SDI2-53 Mandado de segurança. Cooperativa em liquidação extraju-
                dicial. Execução. Suspensão. Lei nº 5.764/71, art. 76.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 51, 'Ação rescisória. Súm. 83.
    PN-86       Representantes dos trabalhadores.
    PN-80       Serviço militar.
    PN-26       (cancelado)
    PN-51       (cancelado)
    SUM-222     (cancelada)', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 55, 'SUM-191     Cálculo. Salário-base. Eletricitários. Cálculo. Parcelas de
                            natureza salarial.
                OJ-SDI1-172 Condenação. Inclusão em folha de pagamento.
                OJ-SDI1T-12 CSN. Salário complessivo. Prevalência do acordo coletivo.
                OJ-SDI1-279 (cancelada)
                SUM-361     Eletricitários. Exposição intermitente.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 59, 'SUM-367, I Vantagens "in natura". Habitação. Energia elétrica. Veículo.
                            Indispensáveis para a realização do trabalho. Natureza in-
                            denizatória.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 61, 'OJ-SDI1-296 Equiparação salarial. Atendente e auxiliar de enfermagem.
                            Impossibilidade.
                OJ-SDI1-319 Representação regular. Estagiário. Habilitação posterior.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 62, 'OJ-SDI2-5       Banco do Brasil. Adicionais AP e ADI ou AFR. Horas ex-
                            tras. Ação rescisória. Decisão rescindenda anterior à OJ 17.
                            Súm. 83 do TST. Súm. 343 do STF.
            OJ-SDI1-17 Banco do Brasil. Adicionais AP, ADI ou AFR. Somatório.
                            Cargo de confiança. CLT, art. 224, § 2º.
            OJ-SDI2-4       Banco do Brasil. Adicional de caráter pessoal. Ação resci-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 63, 'OJ-SDI1T-32 Complementação de aposentadoria. Sucumbência. Inversão.
    OJ-SDI1-18, II     Complementação de aposentadoria. Teto. Adicionais
                  AP e ADI.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 65, 'OJ-SDI1-402 Portuário. Terminal privativo. Arts. 14 e 19 da Lei nº 4.860,
                  de 26.11.1965. Indevido.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 69, 'SUM-387, III Fac-símile. Juntada de originais. Ato que não depende de
             notificação. "Dies a quo". CPC, art. 184. Inaplicável.
SUM-385      Feriado local. Ausência de expediente forense. Prazo recur-
             sal. Prorrogação. Comprovação. Necessidade. Ato adminis-
             trativo do juízo “a quo”.
OJ-SDI1-344 FGTS. Multa de 40%. Diferenças decorrentes dos expurgos', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 70, 'SUM-303, I Decisão contrária à Fazenda Pública. Duplo grau de jurisdi-
                 ção. Exceções.
    OJ-SDI1-73 Mandado de segurança. Decisões proferidas pelo TRT favo-
                 ráveis a ente público. Lei nº 1.533/51, art. 12.
    SUM-303, III Mandado de segurança. Fazenda Pública prejudicada pela
                 concessão da ordem.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 71, 'SUM-269     Suspensão do contrato de trabalho. Tempo de serviço.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 72, 'RECEPCIONADA PELA CF/1988 (cancelada em decorrência
     da sua conversão na Súmula nº 391) -', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 76, 'A supressão, pelo empregador, do serviço suplementar prestado com habitualidade,
                  durante pelo menos um ano, assegura ao empregado o direito à indenização corres-
                  pondente ao valor de um mês das horas suprimidas para cada ano ou fração igual ou
                  superior a seis meses de prestação de serviço acima da jornada normal. O cálculo ob-
                  servará a média das horas suplementares efetivamente trabalhadas nos últimos 12 me-
                  ses, multiplicada pelo valor da hora extra do dia da supressão.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 79, 'OJ-SDI1T-6 Adicional de produtividade. Limitação. Vigência. DC-TST
                         6/79.
            OJ-SDI1-413 Ajuda-alimentação. Alteração da natureza jurídica. Norma
                         coletiva ou adesão ao PAT.
            OJ-SDI1T-61 Ajuda-alimentação. CEF. Previsão em norma coletiva. Na-
                         tureza indenizatória. Extensão aos aposentados e pensionis-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 82, 'OJ-SDI1-148 Art. 31 da Lei nº 8.880/94. Dispensa sem justa causa. Inde-
                nização.
    SUM-378, I Art. 118 da Lei nº 8.213/91. Estabilidade provisória. Aci-
                dente do trabalho.
    SUM-435     Art. 557 do CPC. Aplicação subsidiária ao processo do tra-
                balho.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 83, 'SUM-339, I CIPA. Suplente. Estabilidade provisória. Garantia de em-
                         prego a partir da CF/88.
            SUM-339, II CIPA. Suplente. Extinção do estabelecimento.
            SUM-371      Concessão de auxílio-doença no curso do aviso prévio in-
                         denizado. Efeitos da dispensa.
            OJ-SDI1-268 Contagem do prazo do aviso prévio. Projeção. Indenização', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 84, 'SUM-73        Falta grave. Decurso do prazo do aviso prévio. Verbas res-
                              cisórias indenizatórias.
                OJ-SDI1-42, II      FGTS. Multa de 40%. Aviso prévio indenizado. Cálcu-
                              lo.
                SUM-69        Lei n° 10.272/01. Verbas rescisórias não quitadas na pri-
                              meira audiência. Acréscimo de 50%. Pagamento em dobro', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 85, 'SUM-358       Radiologista. Técnico. Lei nº 7.394/85.
    OJ-SDC-26     Salário normativo. Salário mínimo profissional. Menor em-
                  pregado. CF/88, art. 7º, XXX.
    SUM-17        (cancelada)', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 87, 'OJ-SDI2-2     Adicional de insalubridade. Salário mínimo. CLT, art. 192.
                              Ação rescisória. Cabimento.
                SUM-228       (cancelada)
                SUM-191       Adicional de periculosidade. Cálculo. Salário-base. Eletrici-
                              tários. Cálculo. Parcelas de natureza salarial.
                OJ-SDI1-279 (cancelada)', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 88, 'OJ-SDI1-321 Contratação por empresa interposta. Vínculo empregatício.
                              Período anterior à CF/88.
                SUM-331, IV Contrato de prestação de serviços. Inadimplemento das
                              obrigações trabalhistas. Responsabilidade subsidiária.
                SUM-331, II Contrato de prestação de serviços. Irregularidade. Vínculo
                              de emprego. Órgãos da administração pública direta, indire-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 89, 'OJ-TP/OE-1 Precatório. Crédito trabalhista. Pequeno valor. Emenda
                            Constitucional nº 37/2002.
                OJ-TP/OE-6 Precatório. Limitação da condenação imposta pelo título ju-
                            dicial exeqüendo à data do advento da Lei nº 8.112, de
                            11.12.1990.
                OJ-TP/OE-9 Precatório. Pequeno valor. Individualização do crédito apu-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 90, 'OJ-SDI1-43       CONVERSÃO DE SÁLARIOS DE CRUZEIROS
     PARA CRUZADOS. DECRETO-LEI Nº 2.284/86 (nova reda-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 91, 'V - Para o labor realizado a partir de 5.3.2009, considera-se fato gera-
dor das contribuições previdenciárias decorrentes de créditos traba-
lhistas reconhecidos ou homologados em juízo a data da efetiva pres-
tação dos serviços. Sobre as contribuições previdenciárias não reco-
lhidas a partir da prestação dos serviços incidem juros de mora e, uma
vez apurados os créditos previdenciários, aplica-se multa a partir do', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 93, 'SUM-331, VI Contrato de prestação de serviços. Legalidade. Responsabi-
                 lidade subsidiária. Verbas decorrentes da condenação.
    SUM-331, IV Contrato de prestação de serviços. Inadimplemento das
                 obrigações trabalhistas. Responsabilidade subsidiária.
    OJ-SDI1-185 Contrato de trabalho. Associação de Pais e Mestres - APM.
                 Responsabilidade solidária ou subsidiária do Estado. Inexis-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 94, 'SUM-319     Gatilhos. Decretos-Leis nºs 2.284/86 e 2.302/86. Servidores
                            públicos celetistas.
                SUM-315     IPC de mar/90. Plano Collor. Lei nº 8.030/90. Inexistência
                            de direito adquirido.
                OJ-SDI1T-55 IPC de mar/90. Servidores celetistas da Administração Di-
                            reta, Fundações e Autarquias do GDF. Legislação federal.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 95, 'A partir da vigência da Medida Provisória nº 542/94, convalidada pela Lei nº
       9.069/95, o critério de reajuste da complementação de aposentadoria passou a
       ser anual e não semestral, aplicando-se o princípio "rebus sic stantibus" diante
       da nova ordem econômica.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 96, 'OJ-SDI1-33 Custas processuais. Comprovação do recolhimento. Carim-
                bo do banco.
    OJ-SDI1-134 Documento. Pessoa jurídica de direito público. Validade.
                Medida Provisória nº 1.360/96 e suas reedições. Dispensa
                de autenticação.
    OJ-SDI1-36 Documento comum às partes. Instrumento normativo. Có-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 97, 'A regra ampliativa do prazo decadencial para a propositura de ação rescisória,
                   em favor de pessoa jurídica de direito público, não se aplica se, ao tempo em
                   que sobreveio a Medida Provisória nº 1577/97, já se exaurira o biênio do art.
                   495 do CPC. Preservação do direito adquirido da parte à decadência já consu-
                   mada sob a égide da lei velha.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 98, 'OJ-SDI1T-17 Agravo de instrumento. Traslado. Certidão de publicação do
                         acórdão dos embargos declaratórios. Comprovação de tem-
                         pestividade da revista. Lei nº 9.756/98.
            OJ-SDI1-335 Ausência de concurso público. Contrato nulo. Administra-
                         ção pública. Efeitos. Conhecimento do recurso por violação
                         do art. 37, II e § 2º, da CF/88.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 99, 'Documento dirigido diretamente ao órgão jurisdicional.
                 Transmissão entre particulares. Não aplicação.
    SUM-387, III Juntada de originais. Ato que não depende de notificação.
                 "Dies a quo". CPC, art. 184. Inaplicável.
    SUM-387, II Lei nº 9.800/99, art. 2º. Prazo. Apresentação dos originais.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 100, 'OJ-SDI1T-48 Petromisa. Petrobras. Legitimidade.
    OJ-SDI1-411 Sucessão trabalhista. Aquisição de empresa pertencente a
                 grupo econômico. Responsabilidade solidária do sucessor
                 por débitos trabalhistas de empresa não adquirida. Inexis-
                 tência.
    OJ-SDI1T-28 Sucessão trabalhista. CONESP. CDHU.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 110, 'SUM-68 PROVA (cancelada em decorrência da sua incorporação à nova
               redação da Súmula nº 6) -', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 114, 'SUM-419      Execução por carta. Competência do juízo deprecante. Em-
             bargos de terceiro.
OJ-SDI1-300 Execução trabalhista. Aplicação da TRD cumulada com ju-
             ros de mora. Constitucionalidade. Lei nº 8.177/91, art. 39 e
             Lei nº 10.192/01, art. 15.
OJ-SDI2-53 Mandado de segurança. Cooperativa em liquidação extraju-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 118, 'SUM-378     Estabilidade provisória. Art. 118 da Lei nº 8.213/91.
                OJ-SDI1-41 Estabilidade provisória. Preenchimento dos pressupostos na
                            vigência do instrumento normativo.
                OJ-SDI1-421 Honorários Advocatícios. Ação de indenização por danos
                            morais e materiais decorrentes de acidente de trabalho ou de
                            doença profissional. Ajuizamento perante a Justiça Comum', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 125, 'OJ-SDI2-30, "a" Art. 920 do Código Civil de 1916. Art. 412 do Código
                          Civil de 2002. Limitação. Ação rescisória. Decisão rescin-
                          denda anterior à OJ 54. Súm. 83. Improcedência.
            SUM-388       Arts. 467 e 477 da CLT. Massa falida.
            SUM-432       Contribuição sindical rural. Ação de cobrança. Penalidade
                          por atraso no recolhimento. Inaplicabilidade do art. 600 da', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 146, '(cancelada em decorrência da redação da Súmula nº 146 confe-
                rida pela Res. 121/2003, DJ 21.11.2003) – Res. 129/2005, DJ 20,
                22 e 25.04.2005
                O trabalho prestado em domingos e feriados não compensados deve
                ser pago em dobro sem prejuízo da remuneração relativa ao repouso
                semanal.
                 Histórico:
                 Redação original - Inserida em 30.05.1997', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 166, 'JORNADA DE TRABALHO
                OJ-SDI1-323 Acordo de compensação. "Semana espanhola".
                SUM-85, IV Acordo de compensação. Horas extras habituais.
                OJ-SDI1-403 Advogado empregado. Contratação anterior a Lei nº 8.906,
                            de 04.07.1994. Jornada de trabalho mantida com o advento
                            da lei. Dedicação exclusiva. Caracterização.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 188, 'A União é responsável pelo pagamento dos honorários de perito
               quando a parte sucumbente no objeto da perícia for beneficiária da
               assistência judiciária gratuita, observado o procedimento disposto nos
               arts. 1º, 2º e 5º da Resolução n.º 66/2010 do Conselho Superior da
               Justiça do Trabalho – CSJT.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 192, 'SUM-365     Alçada. Ação rescisória e mandado de segurança. Inaplicá-
                            vel.
                OJ-SDI2-124 Argüição de incompetência absoluta. CPC, art. 485, II. Pre-
                            questionamento inexigível.
                SUM-403, II Art. 485, III, do CPC. Sentença homologatória de acordo.
                            Dolo da parte vencedora em detrimento da vencida. Causa', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 195, 'SUM-453       Adicional de periculosidade. Pagamento espontâneo. Carac-
                  terização de fato incontroverso. Desnecessária a perícia de
                  que trata o Art. 195 da CLT.
    SUM-448, I Não basta a constatação da insalubridade por meio de laudo
                  pericial para que o empregado tenha direito ao respectivo
                  adicional, sendo necessária a classificação da atividade in-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 216, 'Tendo em vista que as Leis nº 3.999/1961 e 4.950-A/1966 não
               estipulam a jornada reduzida, mas apenas estabelecem o salário
               mínimo da categoria para uma jornada de 4 horas para os médicos e
               de 6 horas para os engenheiros, não há que se falar em horas extras,
               salvo as excedentes à oitava, desde que seja respeitado o salário
               mínimo/horário das categorias.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 218, 'A transferência do regime jurídico de celetista para estatutário implica
               extinção do contrato de trabalho, fluindo o prazo da prescrição bienal
               a partir da mudança de regime. (ex-OJ nº 128 da SBDI-I - inserida em
               20.04.1998)
                 IRR-218 MUDANÇA DE REGIME CELETISTA PARA ES-
                 TATUTÁRIO. EXTINÇÃO DO CONTRATO. PRESCRIÇÃO', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 219, 'É dispensável o trânsito em julgado da sentença normativa para a
               propositura da ação de cumprimento.
                 IRR-219 AÇÃO DE CUMPRIMENTO. TRÂNSITO EM JUL-
                 GADO DA SENTENÇA NORMATIVA. (RR-0000097-
                 89.2024.5.07.0017, Tribunal Pleno, publicado em 02.09.2025, rel.
                 Min. Aloysio Silva Corrêa da Veiga)', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 220, 'Assegura-se o direito à manutenção de plano de saúde ou de assistên-
               cia médica oferecido pela empresa ao empregado, não obstante sus-
               penso o contrato de trabalho em virtude de auxílio-doença acidentário
               ou de aposentadoria por invalidez.
                 IRR-220 AUXÍLIO-DOENÇA ACIDENTÁRIO. APOSENTA-
                 DORIA POR INVALIDEZ. SUSPENSÃO DO CONTRATO DE', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 221, 'Membro de conselho fiscal de sindicato não tem direito à estabilida-
     de prevista nos arts. 543, § 3º, da CLT e 8º, VIII, da CF/1988, por-
     quanto não representa ou atua na defesa de direitos da categoria res-
     pectiva, tendo sua competência limitada à fiscalização da gestão fi-
     nanceira do sindicato (art. 522, § 2º, da CLT).
       IRR-221 ESTABILIDADE PROVISÓRIA. MEMBRO DE', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 224, 'OJ-SDI1-379 Empregado de cooperativa de crédito. Bancário. Equipara-
                             ção. Impossibilidade.
                SUM-119      Empregados de distribuidoras e corretoras de títulos de va-
                             lores mobiliários. Jornada especial dos bancários. Equipara-
                             ção.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 226, 'Presume-se o abandono de emprego se o trabalhador não retornar ao
               serviço no prazo de 30 (trinta) dias após a cessação do benefício
               previdenciário nem justificar o motivo de não o fazer.
                 IRR-226 CESSAÇÃO DE BENEFÍCIO PREVIDENCIÁRIO.
                 ABANDONO DE EMPREGO. PRESUNÇÃO. CRITÉRIOS.
                 PRAZO        PARA       RETORNO.          APRESENTAÇÃO        DE', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 227, 'O direito ao aviso prévio é irrenunciável pelo empregado. O pedido
     de dispensa de cumprimento não exime o empregador de pagar o res-
     pectivo valor, salvo comprovação de haver o prestador dos serviços
     obtido novo emprego.
       IRR-227 AVISO-PRÉVIO. RENÚNCIA PELO EMPREGADO.
       (RR-0000280-61.2024.5.09.0322, Tribunal Pleno, publicado em', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 229, 'Compete à Justiça do Trabalho a execução, de ofício, da contribuição
     referente ao Seguro de Acidente de Trabalho (SAT), que tem natureza
     de contribuição para a seguridade social (arts. 114, VIII, e 195, I, “a”,
     da CF), pois se destina ao financiamento de benefícios relativos à in-
     capacidade do empregado decorrente de infortúnio no trabalho (arts.
     11 e 22 da Lei nº 8.212/1991).', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 231, 'A realização de perícia é obrigatória para a verificação de
                insalubridade. Quando não for possível sua realização, como em
                caso de fechamento da empresa, poderá o julgador utilizar-se de
                outros meios de prova.
                  IRR-231 ADICIONAL              DE          INSALUBRIDADE.
                  NECESSIDADE DE PERÍCIA. (RR-0000516-48.2023.5.05.0002,', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 233, 'A contratação de servidor público, após a CF/1988, sem prévia apro-
               vação em concurso público, encontra óbice no respectivo art. 37, II e
               § 2º, somente lhe conferindo direito ao pagamento da contraprestação
               pactuada, em relação ao número de horas trabalhadas, respeitado o
               valor da hora do salário mínimo, e dos valores referentes aos depósi-
               tos do FGTS.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 234, 'As gorjetas, cobradas pelo empregador na nota de serviço ou
     oferecidas espontaneamente pelos clientes, integram a remuneração
     do empregado, não servindo de base de cálculo para as parcelas de
     aviso-prévio, adicional noturno, horas extras e repouso semanal
     remunerado.
       IRR-234 GORJETAS.               NATUREZA              JURÍDICA.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 236, 'O empregado que se demite antes de complementar 12 (doze) meses
               de serviço tem direito a férias proporcionais.
                 IRR-236 FÉRIAS PROPORCIONAIS. PEDIDO DE DEMIS-
                 SÃO. (RR-0001221-90.2024.5.13.0001, Tribunal Pleno, publicado
                 em 02.09.2025, rel. Min. Aloysio Silva Corrêa da Veiga)
                 O empregado que se demite antes de complementar 12 (doze) meses', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 239, 'A decisão que defere horas extras com base em prova oral ou docu-
     mental não ficará limitada ao tempo por ela abrangido, desde que o
     julgador fique convencido de que o procedimento questionado supe-
     rou aquele período.
       IRR-239 HORAS EXTRAORDINÁRIAS. COMPROVAÇÃO
       DE PARTE DO PERÍODO ALEGADO. (RR-0010136-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 241, 'A compensação, na Justiça do Trabalho, está restrita a dívidas de na-
     tureza trabalhista.
       IRR-241 COMPENSAÇÃO DE DÍVIDAS. (RR-0010239-
       59.2021.5.15.0107, Tribunal Pleno, publicado em 02.09.2025, rel.
       Min. Aloysio Silva Corrêa da Veiga)
       A compensação, no processo do trabalho, está restrita a dívidas de na-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 243, 'A transferência para o período diurno de trabalho implica a perda do
               direito ao adicional noturno.
                 IRR-243 ADICIONAL NOTURNO. ALTERAÇÃO DE TURNO
                 DE TRABALHO. POSSIBILIDADE DE SUPRESSÃO. (RR-
                 0010348-50.2023.5.03.0006, Tribunal Pleno, publicado em
                 02.09.2025, rel. Min. Aloysio Silva Corrêa da Veiga)', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 247, 'A redução da carga horária do professor, em virtude da diminuição
SBDI - I', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 249, 'O valor da multa estipulada em cláusula penal, ainda que diária, não
     poderá ser superior à obrigação principal corrigida, em virtude da
     aplicação do artigo 412 do Código Civil de 2002 (art. 920 do Código
     Civil de 1916).
        IRR-249 MULTA. CLÁUSULA PENAL. VALOR SUPERIOR
        AO PRINCIPAL. (RR-0010547-54.2024.5.03.0033, Tribunal', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 251, 'A prescrição da pretensão relativa às parcelas remuneratórias alcança o
       respectivo recolhimento da contribuição para o FGTS.
       IRR-251 FGTS.         INCIDÊNCIA           SOBRE       PARCELAS
       PRESCRITAS. (RR-0010826-76.2024.5.03.0021, Tribunal Pleno,
       publicado em 02.09.2025, rel. Min. Aloysio Silva Corrêa da Veiga)
       A prescrição da pretensão relativa às parcelas remuneratórias alcança', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 252, 'A dedução das horas extras comprovadamente pagas daquelas
     reconhecidas em juízo não pode ser limitada ao mês de apuração,
     devendo ser integral e aferida pelo total das horas extraordinárias
     quitadas durante o período imprescrito do contrato de trabalho.
        IRR-252 HORAS EXTRAORDINÁRIAS. RECONHECI-
        MENTO         EM       JUÍZO.       CRITÉRIO         DE      DEDU-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 253, 'A jornada de trabalho do empregado de banco gerente de agência é
               regida pelo art. 224, § 2º, da CLT. Quanto ao gerente-geral de agência
               bancária, presume-se o exercício de encargo de gestão, aplicando-se-
               lhe o art. 62 da CLT.
                 IRR-253 - BANCÁRIO. JORNADA DE TRABALHO. GEREN-
                 TE GERAL. (RR-0011312-53.2023.5.15.0024, Tribunal Pleno,', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 254, 'Presume-se discriminatória a despedida de empregado portador do ví-
     rus HIV ou de outra doença grave que suscite estigma ou preconceito.
     Inválido o ato, o empregado tem direito à reintegração no emprego.
       IRR-254 DISPENSA DISCRIMINATÓRIA. PRESUNÇÃO.
       EMPREGADO PORTADOR DE DOENÇA GRAVE. ESTIGMA
       OU PRECONCEITO. DIREITO À REINTEGRAÇÃO. (RR-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 255, 'IRR-255 FGTS,         MULTA         DE      40%. (RR-0011516-
                  07.2023.5.03.0065, Tribunal Pleno, publicado em 29.08.2025, rel.
                  Min. Aloysio Silva Corrêa da Veiga)', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 256, 'Computam-se no cálculo do repouso remunerado as horas extras
               habitualmente prestadas (ex-Prejulgado nº 52).
                 IRR-256 HORAS            EXTRAORDINÁRIAS             HABITUAIS.
                 INCIDÊNCIA NO CÁLCULO DO REPOUSO REMUNERADO.
                 (RR-0020154-89.2022.5.04.0015, Tribunal Pleno, publicado em
                 02.09.2025, rel. Min. Aloysio Silva Corrêa da Veiga)', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 258, 'Empregado integrante de categoria profissional diferenciada não tem
     o direito de haver de seu empregador vantagens previstas em
     instrumento coletivo no qual a empresa não foi representada por
     órgão de classe de sua categoria.
       IRR-258 NORMA                  COLETIVA.             CATEGORIA
       DIFERENCIADA.            ABRANGÊNCIA.           (RR-       0020184-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 259, 'O termo inicial do direito ao salário-família coincide com a prova da
               filiação. Se feita em juízo, corresponde à data de ajuizamento do
               pedido, salvo se comprovado que anteriormente o empregador se
               recusara a receber a respectiva certidão.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 260, 'Para os empregados a que alude o art. 58, caput, da CLT, quando
     sujeitos a 40 horas semanais de trabalho, aplica-se o divisor 200
     (duzentos) para o cálculo do valor do salário-hora.
       IRR-260 SALÁRIO-HORA. EMPREGADO SUJEITO AO
       REGIME GERAL DE TRABALHO (ART. 58, CAPUT, DA
       CLT). 40 HORAS SEMANAIS. CÁLCULO. APLICAÇÃO DO', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 261, 'As empresas de crédito, financiamento ou investimento, também
     denominadas financeiras, equiparam-se aos estabelecimentos
     bancários para os efeitos do art. 224 da CLT.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 262, 'É inválida a concessão do aviso prévio na fluência da garantia de
               emprego, ante a incompatibilidade dos dois institutos.
                 IRR-262 AVISO-PRÉVIO. CONCESSÃO NA FLUÊNCIA DA
                 GARANTIA DE EMPREGO. INVALIDADE. (RR-0020279-
                 36.2023.5.04.0334, Tribunal Pleno, publicado em 29.08.2025, rel.
                 Min. Aloysio Silva Corrêa da Veiga)', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 264, 'É assegurado o adicional de periculosidade apenas aos empregados
     que trabalham em sistema elétrico de potência em condições de
     risco, ou que o façam com equipamentos e instalações elétricas
     similares, que ofereçam risco equivalente, ainda que em unidade
     consumidora de energia elétrica.
       IRR-264 ADICIONAL DE PERICULOSIDADE. SISTEMA', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 265, 'Viola o art. 7º, XV, da CF a concessão de repouso semanal
     remunerado após o sétimo dia consecutivo de trabalho, importando
     no seu pagamento em dobro.
                                      C-103', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 266, 'O pagamento de adicional de periculosidade efetuado por mera libe-
               ralidade da empresa, ainda que de forma proporcional ao tempo de
               exposição ao risco ou em percentual inferior ao máximo legalmente
               previsto, dispensa a realização da prova técnica exigida pelo art. 195
               da CLT, pois torna incontroversa a existência do trabalho em condi-
               ções perigosas.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 267, 'O bancário sujeito à jornada de oito horas (art. 224, § 2º, da CLT), após a
        Constituição da República de 1988, tem salário-hora calculado com base no di-
        visor 220, não mais 240.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 273, 'É do empregador o ônus da prova em relação à regularidade dos de-
               pósitos do FGTS, pois o pagamento é fato extintivo do direito do au-
               tor (art. 373, II, do CPC de 2015).
                 IRR-273 FGTS. DIFERENÇAS. RECOLHIMENTO. (RR-
                 1001992-22.2023.5.02.0606, Tribunal Pleno, publicado em
                 02.09.2025, rel. Min. Aloysio Silva Corrêa da Veiga)', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 278, 'O ônus de provar o término do contrato de trabalho, quando negados
     a prestação de serviço e o despedimento, é do empregador, pois o
     princípio da continuidade da relação de emprego constitui presunção
     favorável ao empregado.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 280, 'A remuneração do serviço suplementar é composta do valor da hora
     normal, integrado por parcelas de natureza salarial e acrescido do adi-
     cional previsto em lei, contrato, acordo, convenção coletiva ou sen-
     tença normativa.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 282, 'IRR-282 MULTA CONVENCIONAL. DESCUMPRIMENTO
       DE OBRIGAÇÃO TAMBÉM PREVISTA EM LEI. (RR-
       0000341-87.2024.5.12.0046, Tribunal Pleno, publicado em
       03.09.2025, rel. Min. Aloysio Silva Corrêa da Veiga)
       É aplicável multa prevista em instrumento normativo (sentença nor-
       mativa, convenção ou acordo coletivo) em caso de descumprimento', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 284, 'SUM-405, I Pedido liminar formulado na petição inicial de ação rescisó-
                           ria ou na fase recursal. Suspensão de execução. Cabimento.
                           CPC, art. 273, § 7º.
               OJ-SDI1-120 Recurso sem assinatura. Assinatura da petição ou das razões
                           recursais.
               OJ-SDI1-120 Recurso sem assinatura. Assinatura da petição ou das razões', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 286, 'A juntada de documentos na fase recursal só se justifica quando
                provado o justo impedimento para sua oportuna apresentação ou se
                referir a fato posterior à sentença.
                 IRR-286 JUNTADA               DE     DOCUMENTO      NA     FASE
                 RECURSAL. (RR-0010013-87.2024.5.03.0073, Tribunal Pleno,
                 publicado em 03.09.2025, rel. Min. Aloysio Silva Corrêa da Veiga)', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 287, 'Da extinção do último contrato começa a fluir o prazo prescricional
               do direito de ação em que se objetiva a soma de períodos
               descontínuos de trabalho (ex-Prejulgado nº 31).
                 IRR-287 PRESCRIÇÃO.                 PRAZO.          (RR-0010046-
                 29.2017.5.15.0028, Tribunal Pleno, publicado em 03.09.2025, rel.
                 Min. Aloysio Silva Corrêa da Veiga)', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 288, 'CARÊNCIA DE AÇÃO
    SUM-299, IV Ação rescisória. Vício de intimação da decisão rescindenda.
                Ausência da formação da coisa julgada material.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 289, 'OJ-SDI1T-32 Banco do Brasil. Complementação de aposentadoria. Inver-
                  são. Sucumbência. Exame de postulação aduzida em contes-
                  tação e/ou em contrarrazões.
      OJ-SDI1-115 (cancelada)
      SUM-459     Recurso de revista. Nulidade por negativa de prestação ju-
                  risdicional.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 294, 'OJ-SDI1-322 Cláusula de termo aditivo. Acordo coletivo de trabalho.
                          Prorrogação do acordo para prazo indeterminado.
            OJ-SDI1-268 Contagem do prazo do aviso prévio. Projeção. Indenização
                          adicional. Leis nºs 6.708/79 e 7.238/84.
            SUM-308, I Contagem. Prescrição qüinqüenal.
            OJ-SDI1-204 Contagem. Prescrição qüinqüenal.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 297, 'OJ-SDI1-151 Prequestionamento. Decisão regional que adota a sentença.
                         Súm. 297.
            SUM-297      Prequestionamento. Oportunidade. Configuração.
            OJ-SDI1-62 Prequestionamento. Pressuposto de recorribilidade em apelo
                         de natureza extraordinária.
            OJ-SDI1-118 Prequestionamento. Tese explícita. Indicação expressa do', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 305, 'Havendo pedido expresso de que as intimações e publicações sejam
     realizadas exclusivamente em nome de determinado advogado, a
     comunicação em nome de outro profissional constituído nos autos é
     nula, salvo se constatada a inexistência de prejuízo.
       IRR-305 INTIMAÇÃO. PLURALIDADE DE ADVOGADOS.
       PUBLICAÇÃO EM NOME DE ADVOGADO DIVERSO', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 318, 'CF/88, art. 7º, XVI.
                PN-31       Horário vago (janelas).
                OJ-SDI1-393 Jornada de trabalho especial. Art. 318 da CLT. Salário mí-
                            nimo. Proporcionalidade.
                OJ-SDI1-65 Professor adjunto. Ingresso no cargo de professor titular.
                            CF/88, arts. 37, II e 206, V.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 320, 'SUM-225     Repercussão. Gratificações por tempo de serviço e produti-
                            vidade.
                SUM-172     Repouso semanal remunerado. Incidência das horas extras
                            habituais.
                OJ-SDI1T-5 Servita. Bonificação de assiduidade e produtividade pagas
                            semanalmente. Repercussão no repouso semanal remunera-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 459, 'SUM-101     Diárias de viagem excedentes a 50% do salário. Integração
            temporária no salário.
PN-82       Dissídio coletivo. Garantia de salários e consectários. De-
            missão sem justa causa.
SUM-396, I Estabilidade provisória. Período estabilitário exaurido.
            Reintegração. Efeitos financeiros.', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 481, 'SUM-125     Contrato por prazo determinado. Indenização. Dispensa sem
                        justa causa. Opção. FGTS. CLT, art. 479. Decreto nº
                        59.820/66, art. 30, § 3º.
            SUM-14      Culpa recíproca. Aviso prévio, décimo terceiro e férias pro-
                        porcionais.
            SUM-73      Falta grave. Decurso do prazo do aviso prévio. Verbas res-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 494, 'FATO MODIFICATIVO, IMPEDITIVO OU EXTINTIVO DO DIREITO
                SUM-6, VIII É do empregador o ônus da prova do fato impeditivo, modi-
                            ficativo ou extintivo da equiparação salarial. (', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;
INSERT INTO jurisprudencias_salvas (tribunal, numero_sumula, ementa, area, relevancia, fonte)
VALUES ('TST', 495, 'OJ-SDI1-100 Celetista. Reajuste salarial previsto em legislação federal.
                            Incidência sobre as relações contratuais trabalhistas do esta-
                            do-membro, autarquias e fundações públicas.
                SUM-331, IV Contrato de prestação de serviços. Inadimplemento das
                            obrigações trabalhistas. Responsabilidade subsidiária.
                SUM-331, V Contrato de prestação de serviços. Legalidade. Responsabi-', 'trabalhista', 5, 'Súmulas TST/OJs')
ON CONFLICT DO NOTHING;

COMMIT;
-- Sumário:
--   STF: 200 súmulas
--   STJ Penal: 39 súmulas
--   TST: 91 súmulas