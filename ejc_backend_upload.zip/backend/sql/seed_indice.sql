-- =====================================================================
-- EJC — Seed: Índice Remissivo + Índice de Teses Jurídicas
-- Execute: psql -U ejc_user -d ejc_db -f /app/sql/seed_indice.sql
-- =====================================================================

-- ── SÚMULAS STJ ───────────────────────────────────────────────────────

INSERT INTO indice_sumulas (id,tribunal,numero,tipo,enunciado,area_juridica,temas,status,leis_relacionadas,palavras_chave)
VALUES
-- Consumidor
(uuid_generate_v4(),'STJ',297,'sumula','O contrato de abertura de crédito em conta corrente, acompanhado do demonstrativo de débito, constitui documento hábil para o requerimento da ação monitória.','bancario',ARRAY['conta corrente','ação monitória'],'vigente',ARRAY['CPC Art. 700'],ARRAY['banco','conta','monitória']),
(uuid_generate_v4(),'STJ',385,'sumula','Da anotação irregular em cadastro de proteção ao crédito, não cabe indenização por dano moral quando preexistente legítima inscrição, ressalvado o direito ao cancelamento.','consumidor',ARRAY['negativação indevida','dano moral','SPC/Serasa'],'vigente',ARRAY['CC Art. 186','CDC Art. 42'],ARRAY['SPC','Serasa','negativação','dano moral']),
(uuid_generate_v4(),'STJ',388,'sumula','A simples devolução indevida de cheque caracteriza dano moral.','consumidor',ARRAY['dano moral','cheque'],'vigente',ARRAY['CC Art. 186'],ARRAY['cheque','devolução','dano moral']),
(uuid_generate_v4(),'STJ',479,'sumula','As instituições financeiras respondem objetivamente pelos danos gerados por fortuito interno relativo a fraudes e delitos praticados por terceiros no âmbito de operações bancárias.','bancario',ARRAY['fraude bancária','responsabilidade objetiva','fortuito interno'],'vigente',ARRAY['CDC Art. 14'],ARRAY['fraude','banco','responsabilidade objetiva']),
(uuid_generate_v4(),'STJ',530,'sumula','Nos contratos bancários, na impossibilidade de comprovar a taxa de juros efetivamente contratada, incide a taxa média de mercado apurada pelo Bacen, limitada ao percentual contratado.','bancario',ARRAY['juros','taxa média','contratos bancários'],'vigente',NULL,ARRAY['juros','banco','Bacen']),
(uuid_generate_v4(),'STJ',54,'sumula','Os juros moratórios fluem a partir do evento danoso, em caso de responsabilidade extracontratual.','civel',ARRAY['juros moratórios','responsabilidade civil'],'vigente',ARRAY['CC Art. 398'],ARRAY['juros','responsabilidade civil','danos']),
-- Trabalhista
(uuid_generate_v4(),'STJ',382,'sumula','A estipulação de juros remuneratórios superiores a 12% ao ano, por si só, não indica abusividade.','bancario',ARRAY['juros remuneratórios','abusividade'],'vigente',NULL,ARRAY['juros','12%','banco']),
-- Família
(uuid_generate_v4(),'STJ',309,'sumula','O débito alimentar que autoriza a prisão civil do alimentante é o que compreende as três prestações anteriores ao ajuizamento da execução e as que se vencerem no curso do processo.','familia',ARRAY['alimentos','prisão civil','alimentante'],'vigente',ARRAY['CPC Art. 528'],ARRAY['alimentos','prisão','alimentante']),
(uuid_generate_v4(),'STJ',621,'sumula','Os efeitos da sentença que declara a usucapião retroagem à data do início da posse.','civel',ARRAY['usucapião','efeitos da sentença'],'vigente',ARRAY['CC Art. 1228'],ARRAY['usucapião','posse','retroatividade'])
ON CONFLICT (tribunal, numero, tipo) DO NOTHING;

-- ── SÚMULAS STF ───────────────────────────────────────────────────────

INSERT INTO indice_sumulas (id,tribunal,numero,tipo,enunciado,area_juridica,temas,status,leis_relacionadas,palavras_chave)
VALUES
(uuid_generate_v4(),'STF',37,'sumula','É inadmissível o recurso extraordinário, quando a deficiência na sua fundamentação não permitir a exata compreensão da controvérsia.','constitucional',ARRAY['recurso extraordinário','admissibilidade'],'vigente',ARRAY['CF Art. 102'],ARRAY['RE','recurso extraordinário','admissibilidade']),
(uuid_generate_v4(),'STF',736,'sumula','Compete à Justiça do Trabalho julgar as ações que tenham como causa de pedir o descumprimento de normas trabalhistas relativas à segurança, higiene e saúde dos trabalhadores.','trabalhista',ARRAY['competência','justiça do trabalho','saúde do trabalhador'],'vigente',ARRAY['CF Art. 114'],ARRAY['competência','trabalhista','saúde','segurança']),
(uuid_generate_v4(),'STF',670,'sumula_vinculante','Compete à Justiça Eleitoral processar e julgar os crimes eleitorais e os comuns que lhe forem conexos, bem como os não eleitorais que lhes sejam conexos.','constitucional',ARRAY['competência','crimes eleitorais'],'vigente',ARRAY['CF Art. 121'],ARRAY['eleitoral','competência','crimes']),
(uuid_generate_v4(),'STF',11,'sumula_vinculante','A prisão civil por dívida alimentar deve recair somente sobre o responsável pelo inadimplemento voluntário e inescusável de obrigação alimentícia.','familia',ARRAY['prisão civil','alimentos','inadimplemento'],'vigente',ARRAY['CF Art. 5º LXVII'],ARRAY['prisão civil','alimentos','inadimplemento'])
ON CONFLICT (tribunal, numero, tipo) DO NOTHING;

-- ── SÚMULAS TST ───────────────────────────────────────────────────────

INSERT INTO indice_sumulas (id,tribunal,numero,tipo,enunciado,area_juridica,temas,status,leis_relacionadas,palavras_chave)
VALUES
(uuid_generate_v4(),'TST',85,'sumula','A prestação de serviços a mais de uma empresa do mesmo grupo econômico, durante a mesma jornada de trabalho, não caracteriza a coexistência de mais de um contrato de trabalho, salvo ajuste em contrário.','trabalhista',ARRAY['grupo econômico','jornada','contrato de trabalho'],'vigente',ARRAY['CLT Art. 2º'],ARRAY['grupo econômico','jornada','contrato']),
(uuid_generate_v4(),'TST',129,'sumula','A prestação de serviços a mais de uma empresa do grupo econômico, durante a mesma jornada de trabalho, não caracteriza mais de um vínculo.','trabalhista',ARRAY['grupo econômico','vínculo empregatício'],'vigente',ARRAY['CLT Art. 2º'],ARRAY['grupo econômico','vínculo']),
(uuid_generate_v4(),'TST',331,'sumula','Contrato de prestação de serviços. Legalidade. A contratação de trabalhadores por empresa interposta é ilegal, formando-se o vínculo diretamente com o tomador dos serviços.','trabalhista',ARRAY['terceirização','vínculo empregatício'],'vigente',ARRAY['CLT Art. 9º'],ARRAY['terceirização','vínculo','tomador']),
(uuid_generate_v4(),'TST',277,'sumula','As cláusulas normativas dos acordos coletivos ou convenções coletivas integram os contratos individuais de trabalho e somente poderão ser modificadas ou suprimidas mediante negociação coletiva de trabalho.','trabalhista',ARRAY['convenção coletiva','contrato individual'],'vigente',ARRAY['CLT Art. 114'],ARRAY['convenção coletiva','ACT','negociação'])
ON CONFLICT (tribunal, numero, tipo) DO NOTHING;

-- ── ÍNDICE DE LEIS — dispositivos mais usados ─────────────────────────

INSERT INTO indice_leis (id,diploma,numero_lei,artigo,texto,area_juridica,tema,palavras_chave,fonte_oficial)
VALUES
-- CDC
(uuid_generate_v4(),'CDC','8.078/1990','Art. 6º, III','São direitos básicos do consumidor: a informação adequada e clara sobre os diferentes produtos e serviços.','consumidor','informação ao consumidor',ARRAY['CDC','direito do consumidor','informação'],'https://www.planalto.gov.br/ccivil_03/leis/l8078compilado.htm'),
(uuid_generate_v4(),'CDC','8.078/1990','Art. 42','Na cobrança de débitos, o consumidor inadimplente não será exposto a ridículo, nem será submetido a qualquer tipo de constrangimento ou ameaça.','consumidor','cobrança abusiva',ARRAY['CDC','cobrança','constrangimento'],'https://www.planalto.gov.br/ccivil_03/leis/l8078compilado.htm'),
(uuid_generate_v4(),'CDC','8.078/1990','Art. 42, Parágrafo Único','O consumidor cobrado em quantia indevida tem direito à repetição do indébito, por valor igual ao dobro do que pagou em excesso.','consumidor','repetição do indébito dobrado',ARRAY['CDC','dobro','repetição do indébito'],'https://www.planalto.gov.br/ccivil_03/leis/l8078compilado.htm'),
(uuid_generate_v4(),'CDC','8.078/1990','Art. 51','São nulas de pleno direito, entre outras, as cláusulas contratuais relativas ao fornecimento de produtos e serviços que limitem o direito do consumidor.','consumidor','cláusulas abusivas',ARRAY['CDC','cláusula abusiva','nulidade'],'https://www.planalto.gov.br/ccivil_03/leis/l8078compilado.htm'),
-- CC
(uuid_generate_v4(),'Código Civil','10.406/2002','Art. 186','Aquele que, por ação ou omissão voluntária, negligência ou imprudência, violar direito e causar dano a outrem, ainda que exclusivamente moral, comete ato ilícito.','civel','responsabilidade civil',ARRAY['CC','ato ilícito','dano moral','responsabilidade'],'https://www.planalto.gov.br/ccivil_03/leis/2002/l10406compilada.htm'),
(uuid_generate_v4(),'Código Civil','10.406/2002','Art. 927','Aquele que, por ato ilícito (arts. 186 e 187), causar dano a outrem, fica obrigado a repará-lo.','civel','dever de indenizar',ARRAY['CC','indenização','dano'],'https://www.planalto.gov.br/ccivil_03/leis/2002/l10406compilada.htm'),
(uuid_generate_v4(),'Código Civil','10.406/2002','Art. 206, § 3º, V','Prescreve em três anos a pretensão de reparação civil.','civel','prescrição',ARRAY['CC','prescrição','3 anos','reparação civil'],'https://www.planalto.gov.br/ccivil_03/leis/2002/l10406compilada.htm'),
-- CLT
(uuid_generate_v4(),'CLT','DL 5.452/1943','Art. 7º','São direitos dos trabalhadores urbanos e rurais, além de outros que visem à melhoria de sua condição social.','trabalhista','direitos trabalhistas',ARRAY['CLT','direitos','trabalhador'],'https://www.planalto.gov.br/ccivil_03/decreto-lei/del5452.htm'),
(uuid_generate_v4(),'CLT','DL 5.452/1943','Art. 9º','Serão nulos de pleno direito os atos praticados com o objetivo de desvirtuar, impedir ou fraudar a aplicação dos preceitos contidos na presente Consolidação.','trabalhista','fraude trabalhista',ARRAY['CLT','nulidade','fraude','terceirização'],'https://www.planalto.gov.br/ccivil_03/decreto-lei/del5452.htm'),
(uuid_generate_v4(),'CLT','DL 5.452/1943','Art. 483','O empregado poderá considerar rescindido o contrato e pleitear a devida indenização quando o empregador exigir serviços superiores às suas forças.','trabalhista','rescisão indireta',ARRAY['CLT','rescisão indireta','justa causa patronal'],'https://www.planalto.gov.br/ccivil_03/decreto-lei/del5452.htm')
ON CONFLICT DO NOTHING;

-- ── ÍNDICE DE TESES — banco estratégico completo ─────────────────────

INSERT INTO indice_teses (id,titulo,area_juridica,subarea,tese,fundamentos,contra_argumento,jurisprudencias,sumulas,leis,viabilidade,tipo_acao,tags)
VALUES

-- CONSUMIDOR
(uuid_generate_v4(),'Repetição do Indébito em Dobro — Cobrança Indevida','consumidor','cobrança indevida',
 'O consumidor tem direito à repetição do valor cobrado indevidamente em dobro, independentemente de dolo, bastando a comprovação da cobrança indevida e o efetivo pagamento.',
 'CDC Art. 42, Parágrafo Único. STJ Súmula 388. O STJ firmou o Tema 929 (REsp 1.648.005) que distingue: cobrança de dívida inexistente = dobro; cobrança de dívida existente com valor errado = simples. Aplicável a toda relação de consumo.',
 'Banco argumenta que o erro foi não intencional (mero engano) e que não há má-fé, afastando o dobro. STJ já pacificou que a boa-fé do fornecedor é irrelevante para o dobro.',
 ARRAY['STJ REsp 1.648.005 (Tema 929)','STJ AgInt no AREsp 1.418.891'],
 ARRAY['Súmula 388 STJ'],
 ARRAY['CDC Art. 42, Parágrafo Único'],
 'alta',ARRAY['JEC','vara consumidor'],ARRAY['CDC','dobro','cobrança indevida']),

(uuid_generate_v4(),'Dano Moral por Negativação Indevida','consumidor','negativação indevida',
 'A inscrição indevida em cadastros de inadimplentes (SPC/Serasa) gera dano moral in re ipsa (presumido), sem necessidade de prova do abalo sofrido.',
 'STJ Súmula 385 (quando há negativação anterior legítima, afasta indenização). CC Art. 186. CDC Art. 14. O dano é in re ipsa — decorre da própria situação de fato. Basta provar que a inscrição era indevida.',
 'Se houver outra inscrição legítima pré-existente, a Súmula 385 STJ impede a indenização. Fornecedor pode alegar exercício regular de direito (dívida existia, mas estava prescrita, por exemplo).',
 ARRAY['STJ AgRg no AREsp 142.562','STJ REsp 1.586.178'],
 ARRAY['Súmula 385 STJ'],
 ARRAY['CC Art. 186','CDC Art. 14'],
 'alta',ARRAY['JEC','vara consumidor'],ARRAY['SPC','Serasa','negativação','dano moral']),

-- TRABALHISTA
(uuid_generate_v4(),'Rescisão Indireta por Assédio Moral','trabalhista','assédio moral / rescisão indireta',
 'O empregado vítima de assédio moral reiterado pode pleitear a rescisão indireta do contrato com fundamento no Art. 483 da CLT, recebendo todas as verbas rescisórias como se demitido sem justa causa fosse.',
 'CLT Art. 483, alíneas a, b e d. TST tem jurisprudência consolidada reconhecendo que humilhações reiteradas, metas abusivas, exposição vexatória e perseguições configuram justa causa do empregador.',
 'Empregador argui que episódios foram isolados e não sistemáticos. Necessário provar sistematicidade. Testemunhas são essenciais.',
 ARRAY['TST RR-796-22.2012.5.04.0000','TST-AIRR-12-16.2015.5.10.0010'],
 ARRAY['Súmula 331 TST'],
 ARRAY['CLT Art. 483'],
 'media',ARRAY['JT','VT'],ARRAY['CLT','assédio moral','rescisão indireta','verbas rescisórias']),

(uuid_generate_v4(),'Horas Extras — Controle de Ponto Irregular','trabalhista','jornada de trabalho',
 'Quando os cartões de ponto apresentam horários uniformes ("britânicos"), há presunção relativa de jornada extraordinária, invertendo-se o ônus da prova para o empregador.',
 'CLT Art. 74 §2º. TST OJ 306 SDI-1. Súmula 338 TST. Cartões de ponto com horários sempre idênticos são considerados inválidos como prova, gerando presunção favorável ao empregado.',
 'Empregador pode apresentar testemunhas para desmentir jornada alegada. Se a empresa tem menos de 10 empregados, não é obrigada a manter controle de ponto.',
 ARRAY['TST RR-140400-13.2006.5.02.0002'],
 ARRAY['Súmula 338 TST'],
 ARRAY['CLT Art. 74'],
 'media',ARRAY['JT','VT'],ARRAY['horas extras','ponto','jornada','presunção']),

-- PREVIDENCIÁRIO
(uuid_generate_v4(),'Reconhecimento de Tempo de Serviço Especial — Atividade de Risco','previdenciario','aposentadoria especial',
 'O trabalhador exposto a agentes nocivos (ruído, calor, químicos) tem direito ao reconhecimento do tempo especial mediante apresentação de PPP e LTCAT, mesmo após 1998.',
 'Lei 8.213/91 Arts. 57 e 58. Dec. 3.048/99. STJ Tema 1.016. Conversão do tempo especial em comum é possível mesmo após Lei 9.711/98. A exigência de PPP retroage aos vínculos anteriores.',
 'INSS argumenta que após 1997 é necessário EPI eliminar a insalubridade. STJ e TRF já decidiram que uso de EPI não descaracteriza o especial se o agente nocivo ainda é presente.',
 ARRAY['STJ REsp 1.398.260 (Tema 534)','TRF4 5002233-73.2019.4.04.7108'],
 NULL,
 ARRAY['Lei 8.213/91 Art. 57','Dec. 3.048/99 Anexo IV'],
 'alta',ARRAY['JEF','vara federal','TRF'],ARRAY['INSS','aposentadoria especial','PPP','tempo especial']),

-- TRIBUTÁRIO
(uuid_generate_v4(),'Exclusão do ICMS da Base de Cálculo do PIS/COFINS — Tese do Século','tributario','PIS/COFINS',
 'O ICMS não integra a base de cálculo do PIS e COFINS, pois não constitui faturamento ou receita da empresa, mas mero ingresso de caixa que transita pelo patrimônio sem a ele pertencer.',
 'STF RE 574.706 (Tema 69 — Repercussão Geral). Tese vinculante: o ICMS destacado na nota fiscal não compõe a base de PIS/COFINS. Modulação dos efeitos a partir de 15/03/2017.',
 'Fazenda argumenta que o valor do ICMS integra o preço do produto. STF encerrou esta discussão no RE 574.706 com efeito vinculante. Atenção à modulação: créditos antes de 15/03/2017 só com ação ajuizada.',
 ARRAY['STF RE 574.706 (Tema 69)'],
 NULL,
 ARRAY['CF Art. 195','Lei 9.718/98'],
 'alta',ARRAY['JF','TRF','STJ'],ARRAY['ICMS','PIS','COFINS','tese do século','exclusão']),

-- CÍVEL
(uuid_generate_v4(),'Dano Moral — Quantum Indenizatório — Parâmetros STJ','civel','dano moral',
 'O valor do dano moral deve observar os critérios de proporcionalidade e razoabilidade, considerando: extensão do dano, capacidade econômica do ofensor e da vítima, caráter pedagógico e compensatório.',
 'STJ REsp 1.152.541 (Recurso Repetitivo). CC Art. 927. O STJ admite revisão do quantum em REsp quando irrisório ou exorbitante. Parâmetro médio para JEC: 5–20 salários mínimos para danos comuns.',
 'Empresa argumenta que o valor é exagerado e pede redução. STJ pode reduzir se desproporcionalmente elevado.',
 ARRAY['STJ REsp 1.152.541','STJ AgInt no REsp 1.789.456'],
 NULL,
 ARRAY['CC Art. 927','CC Art. 944'],
 'media',ARRAY['JEC','vara cível'],ARRAY['dano moral','quantum','indenização','proporcionalidade']),

-- FAMÍLIA
(uuid_generate_v4(),'Alimentos — Revisão de Quantum com Base em Mudança de Fortuna','familia','alimentos',
 'É possível a revisão do quantum alimentar quando demonstrada alteração na situação financeira do alimentante (redução de renda) ou do alimentado (aumento de necessidades), sem necessidade de aguardar prazo mínimo.',
 'CC Art. 1.699. CPC Arts. 531-534. A cláusula rebus sic stantibus é inerente às obrigações alimentares. Não existe prazo mínimo para revisão — basta demonstrar mudança de circunstâncias.',
 'Alimentado argumenta que as necessidades cresceram proporcionalmente e que a redução prejudica o menor. Juiz tem ampla discricionariedade no quantum.',
 ARRAY['STJ REsp 1.205.148','STJ AgRg no AREsp 408.218'],
 NULL,
 ARRAY['CC Art. 1.699','CPC Art. 531'],
 'media',ARRAY['vara família','JEC-família'],ARRAY['alimentos','revisão','quantum','rebus sic stantibus'])

ON CONFLICT DO NOTHING;

SELECT 'Seed concluído' AS status,
       (SELECT COUNT(*) FROM indice_sumulas) AS sumulas,
       (SELECT COUNT(*) FROM indice_leis) AS leis,
       (SELECT COUNT(*) FROM indice_teses) AS teses;
