-- ============================================================
-- EJC — Migration: funcionalidades inspiradas no Jus.ia
-- Executa após init.sql e migration_integracao.sql
-- ============================================================

-- ── Espaços de trabalho (por cliente / processo) ──────────
-- Agrupa conversas e documentos de um mesmo caso/cliente.
-- Cada novo chat dentro do espaço herda o contexto do espaço.
CREATE TABLE IF NOT EXISTS espacos (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    titulo      TEXT NOT NULL,
    tipo        TEXT NOT NULL CHECK (tipo IN ('cliente','processo','tema','audiencia')),
    referencia  TEXT,           -- número OAB, número processo, CPF/CNPJ etc.
    descricao   TEXT,
    contexto    TEXT,           -- contexto acumulado do espaço (resume conversas)
    cor         TEXT DEFAULT '#c9960a',
    ativo       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Conversas dentro de um espaço
CREATE TABLE IF NOT EXISTS conversas (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    espaco_id   UUID REFERENCES espacos(id) ON DELETE CASCADE,
    titulo      TEXT,
    mensagens   JSONB NOT NULL DEFAULT '[]',  -- [{role, content, ts}]
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_conversas_espaco ON conversas(espaco_id, created_at DESC);

-- ── Prazos processuais ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS prazos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    espaco_id       UUID REFERENCES espacos(id) ON DELETE SET NULL,
    titulo          TEXT NOT NULL,
    descricao       TEXT,
    numero_processo TEXT,
    tribunal        TEXT,
    tipo_prazo      TEXT NOT NULL CHECK (tipo_prazo IN
                      ('contestacao','recurso','contrarrazoes','manifestacao',
                       'audiencia','pericia','diligencia','outros')),
    data_intimacao  DATE,
    data_vencimento DATE NOT NULL,
    dias_uteis      BOOLEAN DEFAULT TRUE,
    alertas_dias    INTEGER[] DEFAULT '{5,2,1}',  -- alertar N dias antes
    status          TEXT NOT NULL DEFAULT 'pendente'
                    CHECK (status IN ('pendente','cumprido','cancelado','vencido')),
    prioridade      TEXT NOT NULL DEFAULT 'media'
                    CHECK (prioridade IN ('baixa','media','alta','critica')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_prazos_vencimento ON prazos(data_vencimento, status);
CREATE INDEX IF NOT EXISTS idx_prazos_espaco ON prazos(espaco_id);

-- ── Análises de documentos ────────────────────────────────
CREATE TABLE IF NOT EXISTS analises_documentos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    espaco_id       UUID REFERENCES espacos(id) ON DELETE SET NULL,
    filename        TEXT NOT NULL,
    tipo_analise    TEXT NOT NULL CHECK (tipo_analise IN
                      ('resumo','referencias','estrategia','riscos',
                       'clausulas','simplificacao','checklist')),
    conteudo_original TEXT,
    resultado_md    TEXT NOT NULL,
    insights        JSONB NOT NULL DEFAULT '[]',
    score_confianca FLOAT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Jurimetria — histórico de análises preditivas ─────────
CREATE TABLE IF NOT EXISTS analises_jurimetria (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    espaco_id       UUID REFERENCES espacos(id) ON DELETE SET NULL,
    tipo_acao       TEXT NOT NULL,
    tribunal        TEXT,
    probabilidade_sucesso FLOAT,
    tempo_medio_dias INTEGER,
    valor_medio_condenacao TEXT,
    fatores_positivos JSONB DEFAULT '[]',
    fatores_negativos JSONB DEFAULT '[]',
    precedentes     JSONB DEFAULT '[]',
    metodologia     TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Trigger updated_at para espaços
CREATE TRIGGER trg_espacos_updated_at
    BEFORE UPDATE ON espacos
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
