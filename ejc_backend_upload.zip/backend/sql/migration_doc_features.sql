-- ============================================================
-- EJC — Migration: funcionalidades do documento de especificação
-- Gestão de casos, chat especializado, auditoria LGPD,
-- jurisprudências favoritas, templates, visual law
-- ============================================================

-- ── Gestão de Casos ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS casos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_caso     TEXT UNIQUE NOT NULL DEFAULT 'CASO-' || LPAD(FLOOR(RANDOM()*99999)::TEXT, 5, '0'),
    titulo          TEXT NOT NULL,
    area_juridica   TEXT NOT NULL CHECK (area_juridica IN (
                      'trabalhista','civil','consumidor','previdenciario',
                      'tributario','criminal','administrativo','familia','outros')),
    status          TEXT NOT NULL DEFAULT 'ativo' CHECK (status IN (
                      'prospeccao','ativo','aguardando','encerrado','arquivado')),
    prioridade      TEXT NOT NULL DEFAULT 'media' CHECK (prioridade IN ('baixa','media','alta','urgente')),
    cliente_nome    TEXT,
    cliente_cpf_cnpj TEXT,
    parte_contraria TEXT,
    numero_processo TEXT,
    tribunal        TEXT,
    valor_causa     NUMERIC(15,2),
    honorarios_pct  NUMERIC(5,2),
    descricao       TEXT,
    observacoes     TEXT,
    espaco_id       UUID REFERENCES espacos(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_casos_status ON casos(status, prioridade);
CREATE INDEX IF NOT EXISTS idx_casos_cliente ON casos(cliente_cpf_cnpj);

-- Movimentações do caso
CREATE TABLE IF NOT EXISTS caso_movimentacoes (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    caso_id     UUID NOT NULL REFERENCES casos(id) ON DELETE CASCADE,
    tipo        TEXT NOT NULL CHECK (tipo IN ('peticao','audiencia','decisao','recurso','acordo','outros')),
    descricao   TEXT NOT NULL,
    data_evento DATE,
    documento_id UUID REFERENCES legal_documents(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_caso_mov_caso ON caso_movimentacoes(caso_id, created_at DESC);

-- ── Chat Especializado (estilo ChatAdv) ───────────────────
CREATE TABLE IF NOT EXISTS chat_sessions (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    titulo      TEXT,
    caso_id     UUID REFERENCES casos(id) ON DELETE SET NULL,
    espaco_id   UUID REFERENCES espacos(id) ON DELETE SET NULL,
    prompt_tipo TEXT DEFAULT 'geral',  -- geral | trabalhista | civil | penal | tributario
    mensagens   JSONB NOT NULL DEFAULT '[]',
    documentos_contexto JSONB DEFAULT '[]',  -- PDFs analisados
    jurisprudencias_salvas JSONB DEFAULT '[]',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_caso ON chat_sessions(caso_id);

-- ── Jurisprudências Favoritas ─────────────────────────────
CREATE TABLE IF NOT EXISTS jurisprudencias_salvas (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tribunal    TEXT NOT NULL,
    numero      TEXT,
    classe      TEXT,
    assunto     TEXT,
    ementa      TEXT NOT NULL,
    data_decisao DATE,
    relator     TEXT,
    link_original TEXT,
    tags        TEXT[],
    caso_id     UUID REFERENCES casos(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_jurisp_tribunal ON jurisprudencias_salvas(tribunal);
CREATE INDEX IF NOT EXISTS idx_jurisp_caso ON jurisprudencias_salvas(caso_id);

-- ── Templates Profissionais ───────────────────────────────
CREATE TABLE IF NOT EXISTS templates (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome            TEXT NOT NULL,
    tipo_documento  TEXT NOT NULL,
    area_juridica   TEXT,
    conteudo_md     TEXT NOT NULL,
    variaveis       JSONB DEFAULT '[]',  -- [{nome, descricao, obrigatorio}]
    ativo           BOOLEAN DEFAULT TRUE,
    uso_count       INTEGER DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Auditoria LGPD ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    acao        TEXT NOT NULL,
    recurso     TEXT NOT NULL,
    recurso_id  TEXT,
    usuario     TEXT DEFAULT 'sistema',
    ip_origem   TEXT,
    dados_antes JSONB,
    dados_depois JSONB,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_acao ON audit_log(acao, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_recurso ON audit_log(recurso, recurso_id);

-- ── Visual Law — QR Codes gerados ────────────────────────
CREATE TABLE IF NOT EXISTS qrcodes_gerados (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id    UUID REFERENCES legal_documents(id) ON DELETE CASCADE,
    tipo            TEXT NOT NULL CHECK (tipo IN ('processo','validacao','documento','url')),
    conteudo        TEXT NOT NULL,
    qr_base64       TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Trigger updated_at
CREATE TRIGGER trg_casos_updated_at
    BEFORE UPDATE ON casos
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_chat_updated_at
    BEFORE UPDATE ON chat_sessions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
