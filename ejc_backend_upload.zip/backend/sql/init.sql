-- ============================================================
-- EJC — Inicialização do banco PostgreSQL + pgvector
-- ============================================================

CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Documentos jurídicos ingeridos na base de conhecimento
CREATE TABLE IF NOT EXISTS documents (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    filename    TEXT NOT NULL,
    source_type TEXT NOT NULL CHECK (source_type IN ('pdf','docx','txt','url')),
    category    TEXT NOT NULL DEFAULT 'geral',  -- ex: 'jurisprudencia','legislacao','edital'
    metadata    JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Chunks vetorizados dos documentos
CREATE TABLE IF NOT EXISTS document_chunks (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    chunk_index INTEGER NOT NULL,
    content     TEXT NOT NULL,
    embedding   VECTOR(768),          -- dimensão do paraphrase-multilingual-mpnet-base-v2
    metadata    JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índice HNSW para busca vetorial de alta performance
CREATE INDEX IF NOT EXISTS idx_chunks_embedding
    ON document_chunks USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);

-- Peças jurídicas geradas
CREATE TABLE IF NOT EXISTS legal_documents (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title           TEXT NOT NULL,
    document_type   TEXT NOT NULL,   -- ex: 'peticao_inicial','recurso','contrato'
    input_facts     TEXT NOT NULL,
    input_objective TEXT NOT NULL,
    content_md      TEXT NOT NULL,
    validation_log  JSONB NOT NULL DEFAULT '{}',
    status          TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','validated','final')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Log de cálculos jurídicos
CREATE TABLE IF NOT EXISTS calculation_log (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    calc_type       TEXT NOT NULL,   -- 'fgts_revisional','pis_cofins_monofasico'
    input_data      JSONB NOT NULL,
    result_data     JSONB NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Trigger: atualiza updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_documents_updated_at
    BEFORE UPDATE ON documents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_legal_documents_updated_at
    BEFORE UPDATE ON legal_documents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- Integrações — Processos monitorados via DataJud/CNJ
-- ============================================================

CREATE TABLE IF NOT EXISTS processos_monitorados (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_processo     TEXT NOT NULL UNIQUE,
    tribunal            TEXT NOT NULL,
    classe              TEXT,
    ativo               BOOLEAN NOT NULL DEFAULT TRUE,
    ultima_sync         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    movimentos_count    INTEGER NOT NULL DEFAULT 0,
    document_id         UUID REFERENCES documents(id) ON DELETE SET NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_processos_monitorados_ativo
    ON processos_monitorados(ativo, ultima_sync);

-- Log de consultas a APIs externas
CREATE TABLE IF NOT EXISTS integracao_log (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fonte       TEXT NOT NULL,
    operacao    TEXT NOT NULL,
    parametros  JSONB NOT NULL DEFAULT '{}',
    status      TEXT NOT NULL,
    latencia_ms INTEGER,
    erro_msg    TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_integracao_log_fonte_data
    ON integracao_log(fonte, created_at DESC);
-- ============================================================
-- EJC — Migration: integrações externas
-- Executa após init.sql
-- ============================================================

-- Processos monitorados via DataJud
CREATE TABLE IF NOT EXISTS espacos (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    titulo      TEXT NOT NULL,
    tipo        TEXT NOT NULL CHECK (tipo IN ('cliente','processo','tema','audiencia')),
    referencia  TEXT,           -- número OAB, número processo, CPF/CNPJ etc.
    descricao   TEXT,
    contexto    TEXT,           -- contexto acumulado do espaço (resume conversas)
    cor         TEXT DEFAULT '#c9960a',
    ativo       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Conversas dentro de um espaço
CREATE TABLE IF NOT EXISTS conversas (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    espaco_id   UUID REFERENCES espacos(id) ON DELETE CASCADE,
    titulo      TEXT,
    mensagens   JSONB NOT NULL DEFAULT '[]',  -- [{role, content, ts}]
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_conversas_espaco ON conversas(espaco_id, created_at DESC);

-- ── Prazos processuais ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS prazos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    espaco_id       UUID REFERENCES espacos(id) ON DELETE SET NULL,
    titulo          TEXT NOT NULL,
    descricao       TEXT,
    numero_processo TEXT,
    tribunal        TEXT,
    tipo_prazo      TEXT NOT NULL CHECK (tipo_prazo IN
                      ('contestacao','recurso','contrarrazoes','manifestacao',
                       'audiencia','pericia','diligencia','outros')),
    data_intimacao  DATE,
    data_vencimento DATE NOT NULL,
    dias_uteis      BOOLEAN DEFAULT TRUE,
    alertas_dias    INTEGER[] DEFAULT '{5,2,1}',  -- alertar N dias antes
    status          TEXT NOT NULL DEFAULT 'pendente'
                    CHECK (status IN ('pendente','cumprido','cancelado','vencido')),
    prioridade      TEXT NOT NULL DEFAULT 'media'
                    CHECK (prioridade IN ('baixa','media','alta','critica')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_prazos_vencimento ON prazos(data_vencimento, status);
CREATE INDEX IF NOT EXISTS idx_prazos_espaco ON prazos(espaco_id);

-- ── Análises de documentos ────────────────────────────────
CREATE TABLE IF NOT EXISTS analises_documentos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    espaco_id       UUID REFERENCES espacos(id) ON DELETE SET NULL,
    filename        TEXT NOT NULL,
    tipo_analise    TEXT NOT NULL CHECK (tipo_analise IN
                      ('resumo','referencias','estrategia','riscos',
                       'clausulas','simplificacao','checklist')),
    conteudo_original TEXT,
    resultado_md    TEXT NOT NULL,
    insights        JSONB NOT NULL DEFAULT '[]',
    score_confianca FLOAT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Jurimetria — histórico de análises preditivas ─────────
CREATE TABLE IF NOT EXISTS analises_jurimetria (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    espaco_id       UUID REFERENCES espacos(id) ON DELETE SET NULL,
    tipo_acao       TEXT NOT NULL,
    tribunal        TEXT,
    probabilidade_sucesso FLOAT,
    tempo_medio_dias INTEGER,
    valor_medio_condenacao TEXT,
    fatores_positivos JSONB DEFAULT '[]',
    fatores_negativos JSONB DEFAULT '[]',
    precedentes     JSONB DEFAULT '[]',
    metodologia     TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Trigger updated_at para espaços
CREATE TRIGGER trg_espacos_updated_at
    BEFORE UPDATE ON espacos
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
-- ============================================================
-- EJC — Migration: funcionalidades do documento de especificação
-- Gestão de casos, chat especializado, auditoria LGPD,
-- jurisprudências favoritas, templates, visual law
-- ============================================================

-- ── Gestão de Casos ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS casos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_caso     TEXT UNIQUE NOT NULL DEFAULT 'CASO-' || LPAD(FLOOR(RANDOM()*99999)::TEXT, 5, '0'),
    titulo          TEXT NOT NULL,
    area_juridica   TEXT NOT NULL CHECK (area_juridica IN (
                      'trabalhista','civil','consumidor','previdenciario',
                      'tributario','criminal','administrativo','familia','outros')),
    status          TEXT NOT NULL DEFAULT 'ativo' CHECK (status IN (
                      'prospeccao','ativo','aguardando','encerrado','arquivado')),
    prioridade      TEXT NOT NULL DEFAULT 'media' CHECK (prioridade IN ('baixa','media','alta','urgente')),
    cliente_nome    TEXT,
    cliente_cpf_cnpj TEXT,
    parte_contraria TEXT,
    numero_processo TEXT,
    tribunal        TEXT,
    valor_causa     NUMERIC(15,2),
    honorarios_pct  NUMERIC(5,2),
    descricao       TEXT,
    observacoes     TEXT,
    espaco_id       UUID REFERENCES espacos(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_casos_status ON casos(status, prioridade);
CREATE INDEX IF NOT EXISTS idx_casos_cliente ON casos(cliente_cpf_cnpj);

-- Movimentações do caso
CREATE TABLE IF NOT EXISTS caso_movimentacoes (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    caso_id     UUID NOT NULL REFERENCES casos(id) ON DELETE CASCADE,
    tipo        TEXT NOT NULL CHECK (tipo IN ('peticao','audiencia','decisao','recurso','acordo','outros')),
    descricao   TEXT NOT NULL,
    data_evento DATE,
    documento_id UUID REFERENCES legal_documents(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_caso_mov_caso ON caso_movimentacoes(caso_id, created_at DESC);

-- ── Chat Especializado (estilo ChatAdv) ───────────────────
CREATE TABLE IF NOT EXISTS chat_sessions (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    titulo      TEXT,
    caso_id     UUID REFERENCES casos(id) ON DELETE SET NULL,
    espaco_id   UUID REFERENCES espacos(id) ON DELETE SET NULL,
    prompt_tipo TEXT DEFAULT 'geral',  -- geral | trabalhista | civil | penal | tributario
    mensagens   JSONB NOT NULL DEFAULT '[]',
    documentos_contexto JSONB DEFAULT '[]',  -- PDFs analisados
    jurisprudencias_salvas JSONB DEFAULT '[]',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_caso ON chat_sessions(caso_id);

-- ── Jurisprudências Favoritas ─────────────────────────────
CREATE TABLE IF NOT EXISTS jurisprudencias_salvas (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tribunal    TEXT NOT NULL,
    numero      TEXT,
    classe      TEXT,
    assunto     TEXT,
    ementa      TEXT NOT NULL,
    data_decisao DATE,
    relator     TEXT,
    link_original TEXT,
    tags        TEXT[],
    caso_id     UUID REFERENCES casos(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_jurisp_tribunal ON jurisprudencias_salvas(tribunal);
CREATE INDEX IF NOT EXISTS idx_jurisp_caso ON jurisprudencias_salvas(caso_id);

-- ── Templates Profissionais ───────────────────────────────
CREATE TABLE IF NOT EXISTS templates (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome            TEXT NOT NULL,
    tipo_documento  TEXT NOT NULL,
    area_juridica   TEXT,
    conteudo_md     TEXT NOT NULL,
    variaveis       JSONB DEFAULT '[]',  -- [{nome, descricao, obrigatorio}]
    ativo           BOOLEAN DEFAULT TRUE,
    uso_count       INTEGER DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Auditoria LGPD ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    acao        TEXT NOT NULL,
    recurso     TEXT NOT NULL,
    recurso_id  TEXT,
    usuario     TEXT DEFAULT 'sistema',
    ip_origem   TEXT,
    dados_antes JSONB,
    dados_depois JSONB,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_acao ON audit_log(acao, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_recurso ON audit_log(recurso, recurso_id);

-- ── Visual Law — QR Codes gerados ────────────────────────
CREATE TABLE IF NOT EXISTS qrcodes_gerados (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_id    UUID REFERENCES legal_documents(id) ON DELETE CASCADE,
    tipo            TEXT NOT NULL CHECK (tipo IN ('processo','validacao','documento','url')),
    conteudo        TEXT NOT NULL,
    qr_base64       TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Trigger updated_at
CREATE TRIGGER trg_casos_updated_at
    BEFORE UPDATE ON casos
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_chat_updated_at
    BEFORE UPDATE ON chat_sessions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- Módulos novos: Auth, Portal, Teses, Financeiro
-- ============================================================

-- Usuários com roles
CREATE TABLE IF NOT EXISTS usuarios (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome        TEXT NOT NULL,
    email       TEXT NOT NULL UNIQUE,
    senha_hash  TEXT NOT NULL,
    role        TEXT NOT NULL DEFAULT 'advogado'
                CHECK (role IN ('admin','socio','advogado','estagiario','cliente')),
    oab_numero  TEXT,
    oab_estado  TEXT,
    ativo       BOOLEAN NOT NULL DEFAULT TRUE,
    ultimo_acesso TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email);

-- Tokens do portal do cliente
CREATE TABLE IF NOT EXISTS portal_tokens (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    caso_id     UUID UNIQUE NOT NULL REFERENCES casos(id) ON DELETE CASCADE,
    cliente_nome TEXT NOT NULL,
    token       TEXT,
    expira_em   TIMESTAMPTZ,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Teses customizadas do escritório
CREATE TABLE IF NOT EXISTS teses_customizadas (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    titulo          TEXT NOT NULL,
    area            TEXT NOT NULL,
    tema            TEXT NOT NULL,
    argumentacao_md TEXT NOT NULL,
    tribunal_ref    TEXT,
    tags            TEXT[],
    probabilidade_exito FLOAT,
    uso_count       INTEGER NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_teses_area ON teses_customizadas(area, tema);

-- Honorários
CREATE TABLE IF NOT EXISTS honorarios (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    caso_id             UUID NOT NULL REFERENCES casos(id) ON DELETE CASCADE,
    tipo                TEXT NOT NULL CHECK (tipo IN ('fixo','exito','misto')),
    valor_fixo          NUMERIC(15,2) DEFAULT 0,
    percentual_exito    NUMERIC(5,2) DEFAULT 0,
    valor_sinal         NUMERIC(15,2) DEFAULT 0,
    numero_parcelas     INTEGER NOT NULL DEFAULT 1,
    valor_parcela       NUMERIC(15,2),
    data_primeira_parcela DATE,
    status              TEXT NOT NULL DEFAULT 'ativo',
    observacoes         TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Parcelas de honorários
CREATE TABLE IF NOT EXISTS parcelas_honorarios (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    honorario_id    UUID NOT NULL REFERENCES honorarios(id) ON DELETE CASCADE,
    numero          INTEGER NOT NULL,
    valor           NUMERIC(15,2) NOT NULL,
    valor_pago      NUMERIC(15,2),
    data_vencimento DATE NOT NULL,
    data_pagamento  DATE,
    status          TEXT NOT NULL DEFAULT 'pendente'
                    CHECK (status IN ('pendente','pago','atrasado','cancelado')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_parcelas_venc ON parcelas_honorarios(data_vencimento, status);

-- Pagamentos de honorários
CREATE TABLE IF NOT EXISTS pagamentos_honorarios (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    honorario_id    UUID NOT NULL REFERENCES honorarios(id) ON DELETE CASCADE,
    valor_pago      NUMERIC(15,2) NOT NULL,
    data_pagamento  DATE NOT NULL,
    forma_pagamento TEXT NOT NULL DEFAULT 'pix',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Despesas do escritório
CREATE TABLE IF NOT EXISTS despesas (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    caso_id     UUID REFERENCES casos(id) ON DELETE SET NULL,
    descricao   TEXT NOT NULL,
    valor       NUMERIC(15,2) NOT NULL,
    data        DATE NOT NULL,
    tipo        TEXT NOT NULL DEFAULT 'custo_processual',
    reembolsavel BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_despesas_data ON despesas(data);

-- Inserir usuário admin padrão (senha: Admin@EJC2025 — alterar imediatamente)
INSERT INTO usuarios (id, nome, email, senha_hash, role)
VALUES (
    uuid_generate_v4(),
    'Administrador EJC',
    'admin@escritorio.com.br',
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGniYE6Oc3RleP.5nE/Q1nmyJrK',
    'admin'
) ON CONFLICT (email) DO NOTHING;

-- ── Monitor de Publicações ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS monitor_palavras_chave (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    termo               TEXT NOT NULL,
    tipo                TEXT NOT NULL DEFAULT 'cliente'
                        CHECK (tipo IN ('cliente','processo','advogado','assunto')),
    caso_id             UUID REFERENCES casos(id) ON DELETE SET NULL,
    fontes              TEXT[] NOT NULL DEFAULT '{dou}',
    ativo               BOOLEAN NOT NULL DEFAULT TRUE,
    notificar_telegram  BOOLEAN NOT NULL DEFAULT TRUE,
    notificar_email     BOOLEAN NOT NULL DEFAULT FALSE,
    email_destino       TEXT,
    ultima_verificacao  TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_monitor_ativo ON monitor_palavras_chave(ativo);

CREATE TABLE IF NOT EXISTS monitor_publicacoes (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    palavra_chave_id    UUID NOT NULL REFERENCES monitor_palavras_chave(id) ON DELETE CASCADE,
    caso_id             UUID REFERENCES casos(id) ON DELETE SET NULL,
    fonte               TEXT NOT NULL,
    titulo              TEXT NOT NULL,
    resumo              TEXT,
    url                 TEXT,
    data_publicacao     DATE,
    lida                BOOLEAN NOT NULL DEFAULT FALSE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (palavra_chave_id, url)   -- evita duplicatas
);
CREATE INDEX IF NOT EXISTS idx_monitor_pub_pkid ON monitor_publicacoes(palavra_chave_id, created_at DESC);

-- ============================================================
-- Módulo Público — Serviço de petições online
-- ============================================================

-- Planos disponíveis
CREATE TABLE IF NOT EXISTS planos (
    id          TEXT PRIMARY KEY,  -- 'peticao' | 'peticao_instrucoes'
    nome        TEXT NOT NULL,
    descricao   TEXT NOT NULL,
    preco       NUMERIC(10,2) NOT NULL,
    ativo       BOOLEAN NOT NULL DEFAULT TRUE
);

INSERT INTO planos VALUES
  ('peticao',            'Petição Automatizada',
   'Petição completa gerada por IA, pronta para protocolar', 19.90, true),
  ('peticao_instrucoes', 'Petição + Instruções Completas',
   'Petição + guia passo a passo para entrar com a ação no Juizado Especial do seu estado', 99.90, true)
ON CONFLICT (id) DO NOTHING;

-- Pedidos públicos (clientes do site)
CREATE TABLE IF NOT EXISTS pedidos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero          TEXT UNIQUE NOT NULL DEFAULT 'PED-' || LPAD(FLOOR(RANDOM()*999999)::TEXT,6,'0'),
    plano_id        TEXT NOT NULL REFERENCES planos(id),
    status          TEXT NOT NULL DEFAULT 'aguardando_pagamento'
                    CHECK (status IN ('aguardando_pagamento','pago','gerando','pronto','entregue','cancelado','reembolsado')),
    -- Dados do cliente
    cliente_nome    TEXT NOT NULL,
    cliente_email   TEXT NOT NULL,
    cliente_cpf     TEXT,
    cliente_telefone TEXT,
    cliente_estado  TEXT NOT NULL,  -- UF para o guia do JE correto
    -- Dados da petição
    area_juridica   TEXT NOT NULL,
    tipo_documento  TEXT NOT NULL DEFAULT 'peticao_inicial',
    fatos           TEXT NOT NULL,
    objetivo        TEXT NOT NULL,
    parte_contraria TEXT,
    valor_causa     NUMERIC(15,2),
    -- Resultado
    peticao_md      TEXT,           -- Markdown gerado
    peticao_pdf_url TEXT,           -- URL para download
    instrucoes_md   TEXT,           -- Guia JE (plano premium)
    -- Pagamento
    mp_payment_id   TEXT,           -- ID do pagamento no Mercado Pago
    mp_preference_id TEXT,          -- ID da preferência (checkout)
    valor_pago      NUMERIC(10,2),
    metodo_pagamento TEXT,          -- pix | credit_card | debit_card
    pago_em         TIMESTAMPTZ,
    -- Controle
    entregue_em     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pedidos_email  ON pedidos(cliente_email);
CREATE INDEX IF NOT EXISTS idx_pedidos_status ON pedidos(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_pedidos_mp     ON pedidos(mp_payment_id);

CREATE TRIGGER trg_pedidos_updated_at
    BEFORE UPDATE ON pedidos
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ── Melhorias competitivas v8 ─────────────────────────────

-- Novos planos: Impugnação + Só paga se ganhar
INSERT INTO planos VALUES
  ('impugnacao',   'Impugnação / Contestação',
   'Resposta jurídica quando a empresa contesta sua ação no JE', 29.90, true),
  ('so_se_ganhar', 'Só Paga Se Ganhar',
   'Advogado parceiro entra em contato gratuitamente — honorários só se vencer', 0.00, true)
ON CONFLICT (id) DO NOTHING;

-- Depoimentos de clientes (alimentados pelo painel admin)
CREATE TABLE IF NOT EXISTS depoimentos (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome        TEXT NOT NULL,
    estado      TEXT NOT NULL,
    area        TEXT NOT NULL,
    texto       TEXT NOT NULL,
    resultado   TEXT NOT NULL DEFAULT 'venceu',
    foto_url    TEXT,
    ativo       BOOLEAN NOT NULL DEFAULT TRUE,
    ordem       INTEGER NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Insere depoimentos exemplo
INSERT INTO depoimentos (nome, estado, area, texto, resultado, ordem) VALUES
  ('Marcos Andrade',  'SP', 'consumidor',
   'Fiz a petição em 10 minutos e ganhei na primeira audiência! A empresa foi condenada a me pagar R$ 5.000 de dano moral. Recomendo muito.',
   'Ganhou R$ 5.000', 1),
  ('Cláudia Ferreira', 'MG', 'consumidor',
   'Meu nome estava no SPC indevidamente. Em menos de 3 meses resolvi tudo com a petição daqui. Recebi indenização e tive o nome limpo.',
   'Ganhou + nome limpo', 2),
  ('Roberto Lima',   'RJ', 'trabalhista',
   'Não recebi minhas verbas rescisórias. Com a petição gerada aqui entrei no Juizado e recebi tudo que me deviam: FGTS, 13º e aviso prévio.',
   'Recebeu tudo', 3),
  ('Ana Paula Costa', 'PR', 'consumidor',
   'Produto com defeito e a empresa não queria trocar. Gerei a petição, protocolei sozinha e venci. O processo durou 2 meses.',
   'Ganhou a troca', 4),
  ('Fernanda Souza',  'RS', 'previdenciario',
   'INSS negou meu benefício. Com o guia do estado entendi exatamente o que fazer. Entrei no JEF e o benefício foi concedido.',
   'Benefício concedido', 5)
ON CONFLICT DO NOTHING;

-- Leads "só paga se ganhar" (encaminhados para advogados parceiros)
CREATE TABLE IF NOT EXISTS leads_advogado (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome        TEXT NOT NULL,
    email       TEXT NOT NULL,
    telefone    TEXT,
    estado      TEXT NOT NULL,
    area        TEXT NOT NULL,
    descricao   TEXT NOT NULL,
    valor_estimado NUMERIC(15,2),
    status      TEXT NOT NULL DEFAULT 'novo'
                CHECK (status IN ('novo','contatado','aceito','recusado','encerrado')),
    advogado_responsavel TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads_advogado(status, created_at DESC);
-- EJC — Teses jurídicas extraídas do Vade Mecum
-- Insere na tabela teses_customizadas para o Banco de Teses
BEGIN;

INSERT INTO teses_customizadas (titulo, area, argumentacao_md, fonte, ativo)
VALUES (
  'Rescisão Indireta — Art. 483 CLT',
  'trabalhista',
  'FUNDAMENTO: Art. 483, d, da CLT — O empregado pode rescisão indireta quando o empregador não cumpre obrigações contratuais.
REQUISITOS: Atraso reiterado de salários (3+ meses — Súmula 13 TST), falta grave do empregador, imediatidade.
VERBAS: Saldo de salário, aviso prévio, 13º proporcional, férias + 1/3, multa 40% FGTS.
JURISPRUDÊNCIA: Súmula 13 TST — atraso reiterado como falta grave do empregador.',
  'Vade Mecum do Detetive Jurídico EJC',
  true
) ON CONFLICT DO NOTHING;

INSERT INTO teses_customizadas (titulo, area, argumentacao_md, fonte, ativo)
VALUES (
  'Horas Extras — Art. 7º XIII CF + Art. 58 CLT',
  'trabalhista',
  'FUNDAMENTO: Art. 7º, XIII, CF + Art. 58/59 CLT — Jornada de 8h/dia e 44h/semana.
ADICIONAL: Mínimo 50% sobre hora normal (acordo coletivo pode elevar).
QUEM NÃO TEM DIREITO (Art. 62 CLT): Gerente com fidúcia especial + gratificação ≥ 40%. Trabalhador externo. Teletrabalho (se regime de sobreaviso).
SÚMULA 291 TST: Horas extras habituais extintas — indenização pelo período.',
  'Vade Mecum do Detetive Jurídico EJC',
  true
) ON CONFLICT DO NOTHING;

INSERT INTO teses_customizadas (titulo, area, argumentacao_md, fonte, ativo)
VALUES (
  'Responsabilidade Objetiva do Fornecedor — Art. 12 CDC',
  'consumidor',
  'FUNDAMENTO: Art. 12 CDC — Responsabilidade objetiva pelo fato do produto/serviço.
REQUISITOS PARA INDENIZAÇÃO: Defeito + dano + nexo causal (sem necessidade de culpa).
EXCLUDENTES (Art. 12, §3º): Não colocou o produto no mercado; não há defeito; culpa exclusiva do consumidor/terceiro.
PRAZO: 5 anos da data do dano ou ciência (Art. 27 CDC).
DISTINÇÃO: Vício (produto inadequado — Art. 18/20) ≠ Fato (acidente de consumo — Art. 12).',
  'Vade Mecum do Detetive Jurídico EJC',
  true
) ON CONFLICT DO NOTHING;

INSERT INTO teses_customizadas (titulo, area, argumentacao_md, fonte, ativo)
VALUES (
  'Inscrição Indevida em Cadastros de Proteção ao Crédito',
  'consumidor',
  'FUNDAMENTO: Art. 43 CDC + Súmula 323 STJ.
DANO MORAL: Presumido (in re ipsa) pela simples inscrição indevida.
VALOR MÉDIO EM JE: R$ 5.000 a R$ 15.000.
ATENÇÃO: Inscrito que já tem outros apontamentos legítimos — Súmula 385 STJ: NÃO há dano moral presumido.
PRAZO PRESCRIONAL: 3 anos (Art. 206, §3º, V, CC).',
  'Vade Mecum do Detetive Jurídico EJC',
  true
) ON CONFLICT DO NOTHING;

INSERT INTO teses_customizadas (titulo, area, argumentacao_md, fonte, ativo)
VALUES (
  'Auxílio-Doença — Lei 8.213/91',
  'previdenciario',
  'FUNDAMENTO: Arts. 59-63 Lei 8.213/91.
REQUISITOS: Incapacidade laborativa temporária + 12 contribuições (carência) + qualidade de segurado.
PRAZO: Carência de 12 meses (exceto acidente de trabalho e doenças especificadas na lista do INSS).
CARÊNCIA ZERO: Acidente de qualquer natureza, gravidez, TB ativa, neoplasia maligna, cegueira, HIV, doença mental grave.
CESSAÇÃO: Alta programada — direito ao TRCT se demitido durante afastamento (Súmula 440 TST).',
  'Vade Mecum do Detetive Jurídico EJC',
  true
) ON CONFLICT DO NOTHING;

INSERT INTO teses_customizadas (titulo, area, argumentacao_md, fonte, ativo)
VALUES (
  'Mandado de Segurança — Art. 5º LXIX CF + Lei 12.016/09',
  'constitucional',
  'FUNDAMENTO: Art. 5º, LXIX, CF + Lei 12.016/2009.
CABIMENTO: Direito líquido e certo; ato ilegal ou abusivo de autoridade pública.
PRAZO: 120 dias do ato coator (Art. 23 Lei 12.016).
NÃO CABE MS: Quando couber HC ou HD; ato de gestão de empresa pública; lei em tese.
LIMINAR: Possível se presentes fumus boni iuris e periculum in mora (Art. 7º, III).
SUSPENSÃO: Pode ser suspensa por decisão fundamentada do Presidente do Tribunal.',
  'Vade Mecum do Detetive Jurídico EJC',
  true
) ON CONFLICT DO NOTHING;

INSERT INTO teses_customizadas (titulo, area, argumentacao_md, fonte, ativo)
VALUES (
  'Legítima Defesa — Art. 25 CP',
  'penal',
  'FUNDAMENTO: Art. 25 CP — Excludente de ilicitude.
REQUISITOS CUMULATIVOS: Agressão injusta + atual ou iminente + direito próprio ou alheio + meios necessários + uso moderado.
EXCESSO: Punível (doloso ou culposo) — Art. 23, §único, CP.
LEGÍTIMA DEFESA PUTATIVA: Erro sobre existência de agressão — erro de tipo permissivo (Art. 20, §1º CP).
PROIBIDA: Legítima defesa real vs. legítima defesa real (não é possível, pois uma das condutas será ilícita).',
  'Vade Mecum do Detetive Jurídico EJC',
  true
) ON CONFLICT DO NOTHING;

INSERT INTO teses_customizadas (titulo, area, argumentacao_md, fonte, ativo)
VALUES (
  'Responsabilidade Civil — Arts. 186, 187 e 927 CC',
  'civil',
  'FUNDAMENTO: Arts. 186/187/927 CC.
SUBJETIVA (regra): Ação/omissão + dano + nexo causal + culpa (dolo ou negligência/imprudência/imperícia).
OBJETIVA (exceção — Art. 927, §único CC): Atividade de risco; casos previstos em lei (CDC, transportes, meio ambiente).
EXCLUDENTES: Caso fortuito/força maior; culpa exclusiva da vítima; fato de terceiro.
PRESCRIÇÃO: 3 anos (Art. 206, §3º, V, CC) para reparação civil.',
  'Vade Mecum do Detetive Jurídico EJC',
  true
) ON CONFLICT DO NOTHING;

COMMIT;

-- Total: 8 teses inseridas de 6 áreas
-- ============================================================
-- MÓDULO TRIBUTÁRIO — Inteligência Fiscal e Planejamento
-- ============================================================

CREATE TABLE IF NOT EXISTS empresas_consultadas (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cnpj            TEXT NOT NULL,
    razao_social    TEXT,
    nome_fantasia   TEXT,
    situacao        TEXT,
    cnae_principal  TEXT,
    cnaes_secundarios JSONB DEFAULT '[]',
    natureza_juridica TEXT,
    endereco        JSONB DEFAULT '{}',
    porte           TEXT,
    data_abertura   DATE,
    regime_atual    TEXT CHECK (regime_atual IN ('simples','presumido','real','arbitrado','mei','isento','nao_informado')),
    socios          JSONB DEFAULT '[]',
    fonte_dados     TEXT DEFAULT 'receita_federal',
    usuario_id      UUID,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(cnpj)
);
CREATE INDEX IF NOT EXISTS idx_empresa_cnpj ON empresas_consultadas(cnpj);
CREATE TRIGGER trg_empresa_updated_at BEFORE UPDATE ON empresas_consultadas
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TABLE IF NOT EXISTS simulacoes_tributarias (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    empresa_id      UUID REFERENCES empresas_consultadas(id) ON DELETE CASCADE,
    cnpj            TEXT NOT NULL,
    -- Dados financeiros informados
    faturamento_mensal      NUMERIC(15,2),
    faturamento_anual       NUMERIC(15,2),
    faturamento_12m         NUMERIC(15,2),
    folha_pagamento         NUMERIC(15,2),
    prolabore               NUMERIC(15,2),
    num_funcionarios        INTEGER,
    despesas_fixas          NUMERIC(15,2),
    despesas_variaveis      NUMERIC(15,2),
    compras_mercadorias     NUMERIC(15,2),
    creditos_tributarios    NUMERIC(15,2),
    margem_lucro            NUMERIC(5,2),
    regime_simulado         TEXT,
    municipio_iss           TEXT,
    uf_icms                 TEXT,
    -- Resultados por regime
    resultado_simples       JSONB DEFAULT '{}',
    resultado_presumido     JSONB DEFAULT '{}',
    resultado_real          JSONB DEFAULT '{}',
    regime_recomendado      TEXT,
    economia_mensal_estimada NUMERIC(15,2),
    economia_anual_estimada  NUMERIC(15,2),
    nivel_confiabilidade    TEXT DEFAULT 'preliminar',
    -- Metadados
    premissas               JSONB DEFAULT '{}',
    dados_faltantes         JSONB DEFAULT '[]',
    status                  TEXT DEFAULT 'concluida',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sim_empresa ON simulacoes_tributarias(empresa_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sim_cnpj ON simulacoes_tributarias(cnpj);

CREATE TABLE IF NOT EXISTS oportunidades_tributarias (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    empresa_id      UUID REFERENCES empresas_consultadas(id) ON DELETE CASCADE,
    simulacao_id    UUID REFERENCES simulacoes_tributarias(id) ON DELETE CASCADE,
    tipo            TEXT NOT NULL,
    titulo          TEXT NOT NULL,
    descricao       TEXT NOT NULL,
    economia_estimada NUMERIC(15,2),
    base_legal      TEXT,
    tributo         TEXT,
    risco           TEXT DEFAULT 'baixo' CHECK (risco IN ('baixo','medio','alto')),
    documentos_necessarios JSONB DEFAULT '[]',
    observacao      TEXT,
    prazo_prescricional TEXT,
    ativo           BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS alertas_fiscais (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    empresa_id      UUID REFERENCES empresas_consultadas(id) ON DELETE CASCADE,
    simulacao_id    UUID REFERENCES simulacoes_tributarias(id) ON DELETE CASCADE,
    tipo            TEXT NOT NULL,
    titulo          TEXT NOT NULL,
    descricao       TEXT NOT NULL,
    severidade      TEXT DEFAULT 'medio' CHECK (severidade IN ('baixo','medio','alto','critico')),
    acao_recomendada TEXT,
    resolvido       BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS fundamentos_legais (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tema            TEXT NOT NULL,
    tributo         TEXT NOT NULL,
    regime          TEXT,
    titulo          TEXT NOT NULL,
    fundamento      TEXT NOT NULL,
    base_legal      TEXT NOT NULL,
    jurisprudencia  TEXT,
    sumulas         JSONB DEFAULT '[]',
    risco           TEXT,
    aplicabilidade  TEXT,
    documentos      JSONB DEFAULT '[]',
    observacao      TEXT,
    ativo           BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS relatorios_tributarios (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    empresa_id      UUID REFERENCES empresas_consultadas(id) ON DELETE CASCADE,
    simulacao_id    UUID REFERENCES simulacoes_tributarias(id) ON DELETE CASCADE,
    tipo            TEXT NOT NULL CHECK (tipo IN ('diagnostico','comparativo','planejamento','checklist')),
    titulo          TEXT NOT NULL,
    conteudo_md     TEXT,
    arquivo_url     TEXT,
    formato         TEXT DEFAULT 'pdf',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS historico_analises (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cnpj            TEXT NOT NULL,
    usuario_id      UUID,
    tipo_acao       TEXT NOT NULL,
    resumo          TEXT,
    dados           JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_historico_cnpj ON historico_analises(cnpj, created_at DESC);

CREATE TABLE IF NOT EXISTS regimes_tributarios (
    id              TEXT PRIMARY KEY,
    nome            TEXT NOT NULL,
    descricao       TEXT,
    limite_faturamento NUMERIC(15,2),
    tributos        JSONB DEFAULT '[]',
    percentuais     JSONB DEFAULT '{}',
    ativo           BOOLEAN DEFAULT TRUE
);
INSERT INTO regimes_tributarios VALUES
  ('simples',   'Simples Nacional',    'Regime simplificado para ME e EPP', 4800000.00, '["IRPJ","CSLL","PIS","COFINS","CPP","ICMS","ISS","IPI"]', '{}', true),
  ('presumido', 'Lucro Presumido',     'Apuração por percentual de presunção', 78000000.00, '["IRPJ","CSLL","PIS","COFINS"]', '{"irpj_servico":0.32,"irpj_comercio":0.08,"csll_servico":0.32,"csll_comercio":0.12}', true),
  ('real',      'Lucro Real',          'Apuração pelo lucro contábil efetivo', NULL, '["IRPJ","CSLL","PIS","COFINS"]', '{"pis":0.0165,"cofins":0.076,"irpj":0.15,"csll":0.09}', true)
ON CONFLICT DO NOTHING;

-- Fundamentos legais seed
INSERT INTO fundamentos_legais (tema, tributo, regime, titulo, fundamento, base_legal, jurisprudencia, sumulas, risco, aplicabilidade) VALUES
  ('Fator R Simples Nacional', 'CPP', 'simples',
   'Enquadramento pelo Fator R — Redução de alíquota em serviços',
   'O Fator R é calculado pela relação Folha de Pagamento/Receita Bruta dos últimos 12 meses. Se ≥ 28%, determinadas atividades migram do Anexo V para o Anexo III do Simples Nacional, com alíquotas menores.',
   'LC 123/2006, Anexos III e V; Resolução CGSN 140/2018',
   'Solução de Consulta COSIT 21/2019',
   '[]', 'baixo', 'Serviços do Anexo V com folha elevada'),
  ('Créditos PIS/COFINS', 'PIS/COFINS', 'real',
   'Aproveitamento de créditos não cumulativos de PIS e COFINS',
   'No regime não cumulativo (Lucro Real), é possível tomar créditos de PIS (1,65%) e COFINS (7,6%) sobre insumos, depreciação, aluguéis e outros itens permitidos em lei, reduzindo a carga tributária.',
   'Lei 10.637/2002 e Lei 10.833/2003',
   'STJ REsp 1.221.170/PR (Repetitivo); Súmula 636 STJ',
   '[]', 'baixo', 'Empresas no Lucro Real com insumos relevantes'),
  ('Exclusão ICMS da base PIS/COFINS', 'PIS/COFINS', NULL,
   'Exclusão do ICMS da base de cálculo do PIS e COFINS',
   'O STF fixou que o ICMS destacado na nota fiscal não integra a base de cálculo do PIS e COFINS, gerando crédito para os últimos 5 anos (tese do Século — Tema 69).',
   'CF/88, art. 195, I; CTN art. 110',
   'STF RE 574.706 (Tema 69 — Tese do Século, julgado em 15/03/2017)',
   '[{"tribunal":"STF","numero":"Tema 69"}]', 'baixo', 'Empresas tributadas pelo Lucro Real ou Presumido'),
  ('IRPJ Lucro Presumido Serviços', 'IRPJ', 'presumido',
   'Presunção de lucro para serviços — 32% da receita bruta',
   'Para atividades de prestação de serviços em geral, a presunção de lucro para IRPJ é de 32% da receita bruta. Sobre o lucro presumido aplica-se 15% de IRPJ + 10% de adicional sobre excedente de R$20.000/mês.',
   'Lei 9.249/1995, art. 15; RIR/2018 arts. 587-620',
   NULL, '[]', 'baixo', 'Prestadores de serviços no Lucro Presumido'),
  ('Simples Nacional — Limite Sublimite', 'ICMS/ISS', 'simples',
   'Sublimite estadual para ICMS e ISS no Simples Nacional',
   'Estados com PIB menor que 1% do nacional podem adotar sublimite de R$1,8 mi ou R$3,6 mi. Ultrapassado, o contribuinte recolhe ICMS/ISS separadamente do DAS.',
   'LC 123/2006, art. 19 e 20',
   NULL, '[]', 'medio', 'Empresas do Simples com faturamento entre R$1,8M e R$4,8M')
ON CONFLICT DO NOTHING;

-- ── Item 2: Alertas de movimentação processual ────────────────────────────
CREATE TABLE IF NOT EXISTS alertas_processuais (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_processo     TEXT NOT NULL,
    tribunal            TEXT NOT NULL,
    tipo_alerta         TEXT NOT NULL DEFAULT 'nova_movimentacao',
    titulo              TEXT NOT NULL,
    descricao           TEXT NOT NULL,
    data_movimentacao   TIMESTAMPTZ,
    movimentos_novos    INTEGER DEFAULT 0,
    lido                BOOLEAN DEFAULT FALSE,
    enviado_telegram    BOOLEAN DEFAULT FALSE,
    enviado_email       BOOLEAN DEFAULT FALSE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_alertas_proc_lido  ON alertas_processuais(lido, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_alertas_proc_num   ON alertas_processuais(numero_processo);

-- Adiciona colunas de rastreamento ao processos_monitorados
ALTER TABLE processos_monitorados
    ADD COLUMN IF NOT EXISTS movimentos_count_anterior INTEGER DEFAULT 0,
    ADD COLUMN IF NOT EXISTS ultimo_movimento_data      TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS ultimo_movimento_titulo    TEXT,
    ADD COLUMN IF NOT EXISTS apelido                    TEXT,
    ADD COLUMN IF NOT EXISTS parte_cliente              TEXT,
    ADD COLUMN IF NOT EXISTS notificar_telegram         BOOLEAN DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS notificar_email            BOOLEAN DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS email_notificacao          TEXT;

-- ============================================================
-- Expansão v9: Monitoramento DataJud + Calculadoras Expandidas
-- ============================================================

-- Monitoramento avançado de processos
ALTER TABLE processos_monitorados
  ADD COLUMN IF NOT EXISTS cliente_nome      TEXT,
  ADD COLUMN IF NOT EXISTS cliente_cpf_cnpj  TEXT,
  ADD COLUMN IF NOT EXISTS polo              TEXT DEFAULT 'autor',
  ADD COLUMN IF NOT EXISTS assunto           TEXT,
  ADD COLUMN IF NOT EXISTS valor_causa       NUMERIC(15,2),
  ADD COLUMN IF NOT EXISTS ultima_movimentacao TEXT,
  ADD COLUMN IF NOT EXISTS data_ultima_mov   TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS alertas_pendentes INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS webhook_url       TEXT,
  ADD COLUMN IF NOT EXISTS dados_completos   JSONB DEFAULT '{}';

CREATE TABLE IF NOT EXISTS movimentacoes_processo (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    processo_id     UUID REFERENCES processos_monitorados(id) ON DELETE CASCADE,
    numero_processo TEXT NOT NULL,
    codigo_movimento INTEGER,
    nome_movimento  TEXT NOT NULL,
    data_movimento  TIMESTAMPTZ NOT NULL,
    complemento     TEXT,
    orgao_julgador  TEXT,
    notificado      BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_mov_processo ON movimentacoes_processo(processo_id, data_movimento DESC);
CREATE INDEX IF NOT EXISTS idx_mov_notif ON movimentacoes_processo(notificado, created_at DESC);

CREATE TABLE IF NOT EXISTS alertas_processo (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    processo_id     UUID REFERENCES processos_monitorados(id) ON DELETE CASCADE,
    numero_processo TEXT NOT NULL,
    tipo            TEXT NOT NULL,
    titulo          TEXT NOT NULL,
    descricao       TEXT,
    lido            BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_alerta_lido ON alertas_processo(lido, created_at DESC);

-- Histórico de cálculos expandidos
CREATE TABLE IF NOT EXISTS calculos_realizados (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo        TEXT NOT NULL,
    subtipo     TEXT,
    inputs      JSONB NOT NULL DEFAULT '{}',
    resultado   JSONB NOT NULL DEFAULT '{}',
    peticao_md  TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_calc_tipo ON calculos_realizados(tipo, created_at DESC);

-- ============================================================
-- v10: Painel cliente + Fila webhook + Rate limit + Onboarding
-- ============================================================

-- 1. Tokens de acesso do cliente (link mágico)
CREATE TABLE IF NOT EXISTS tokens_cliente (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email       TEXT NOT NULL,
    token       TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex'),
    usado       BOOLEAN DEFAULT FALSE,
    expira_em   TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '7 days',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_token_cliente_email ON tokens_cliente(email);
CREATE INDEX IF NOT EXISTS idx_token_cliente_token ON tokens_cliente(token);

-- 2. Fila de processamento de webhooks (idempotência)
CREATE TABLE IF NOT EXISTS webhook_queue (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    payment_id      TEXT NOT NULL UNIQUE,     -- idempotência por payment_id
    pedido_id       TEXT,
    action          TEXT NOT NULL,
    payload         JSONB NOT NULL DEFAULT '{}',
    status          TEXT NOT NULL DEFAULT 'pendente'
                    CHECK (status IN ('pendente','processando','concluido','erro','ignorado')),
    tentativas      INTEGER NOT NULL DEFAULT 0,
    max_tentativas  INTEGER NOT NULL DEFAULT 5,
    proximo_retry   TIMESTAMPTZ DEFAULT NOW(),
    erro_msg        TEXT,
    processado_em   TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_wq_status   ON webhook_queue(status, proximo_retry);
CREATE INDEX IF NOT EXISTS idx_wq_payment  ON webhook_queue(payment_id);

-- 3. Rate limiting por IP/chave
CREATE TABLE IF NOT EXISTS rate_limit_log (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chave       TEXT NOT NULL,    -- IP ou api_key
    endpoint    TEXT NOT NULL,
    janela      TIMESTAMPTZ NOT NULL DEFAULT DATE_TRUNC('minute', NOW()),
    contador    INTEGER NOT NULL DEFAULT 1,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (chave, endpoint, janela)
);
CREATE INDEX IF NOT EXISTS idx_rl_chave ON rate_limit_log(chave, janela DESC);

-- 4. Onboarding de usuários
CREATE TABLE IF NOT EXISTS onboarding_usuarios (
    usuario_id      UUID PRIMARY KEY,
    step_atual      INTEGER NOT NULL DEFAULT 1,
    steps_completos JSONB NOT NULL DEFAULT '[]',
    concluido       BOOLEAN DEFAULT FALSE,
    ignorado        BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TRIGGER trg_onboarding_upd BEFORE UPDATE ON onboarding_usuarios
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Adiciona token_acesso ao pedido para rastreio do painel cliente
ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS token_acesso TEXT;
CREATE INDEX IF NOT EXISTS idx_pedidos_token ON pedidos(token_acesso);

-- ============================================================
-- v10: Painel cliente + Fila webhook + Rate limit + Onboarding
-- ============================================================

-- 1. Tokens de acesso do cliente (link mágico)

-- 2. Fila de webhook com idempotência por payment_id

-- 3. Rate limiting por IP (em memória + Postgres como fallback)

-- 4. Onboarding de usuários (wizard 3 steps)

ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS token_acesso TEXT;

-- ============================================================
-- v11: Fila de revisão manual + Funil do escritório
-- ============================================================

-- Novos status adicionados ao fluxo de pedidos:
--   aguardando_pagamento → pago → gerando → em_revisao (NOVO)
--   → aprovado → entregue
--   → indicado_advogado (NOVO) — escritório ofereceu serviço
--   → solicitando_info (NOVO) — admin pediu mais dados ao cliente
--   → reembolsado (NOVO)

ALTER TABLE pedidos DROP CONSTRAINT IF EXISTS pedidos_status_check;
ALTER TABLE pedidos ADD CONSTRAINT pedidos_status_check
    CHECK (status IN (
        'aguardando_pagamento','pago','gerando','em_revisao',
        'aprovado','entregue','cancelado','reembolsado',
        'indicado_advogado','solicitando_info'
    ));

-- Log de revisões do admin
CREATE TABLE IF NOT EXISTS revisoes_pedido (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pedido_id       UUID NOT NULL,
    acao            TEXT NOT NULL
                    CHECK (acao IN ('aprovar','editar','indicar_advogado','solicitar_info','rejeitar','reembolsar')),
    nota_interna    TEXT,
    mensagem_cliente TEXT,
    peticao_editada TEXT,
    revisor         TEXT DEFAULT 'admin',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_rev_pedido ON revisoes_pedido(pedido_id, created_at DESC);

-- Solicitações de mais informações ao cliente
CREATE TABLE IF NOT EXISTS solicitacoes_info (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pedido_id       UUID NOT NULL,
    pergunta        TEXT NOT NULL,
    resposta        TEXT,
    respondido_em   TIMESTAMPTZ,
    token_resposta  TEXT UNIQUE DEFAULT encode(gen_random_bytes(16), 'hex'),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Leads do escritório (captados via indicação)
CREATE TABLE IF NOT EXISTS leads_escritorio (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pedido_id       UUID,
    nome            TEXT NOT NULL,
    email           TEXT NOT NULL,
    telefone        TEXT,
    area_juridica   TEXT,
    resumo_caso     TEXT,
    origem          TEXT DEFAULT 'indicacao_peticao',
    status_lead     TEXT DEFAULT 'novo'
                    CHECK (status_lead IN ('novo','contato_feito','proposta_enviada','convertido','perdido')),
    observacao      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- v12: Motor de Jurisprudência em Tempo Real
-- ============================================================

-- Cache de jurisprudências buscadas externamente
CREATE TABLE IF NOT EXISTS jurisprudencia_cache (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    hash_query      TEXT NOT NULL,          -- SHA256(query+tribunal+filtros)
    tribunal        TEXT NOT NULL,
    query_original  TEXT NOT NULL,
    resultados      JSONB NOT NULL DEFAULT '[]',
    total_encontrado INTEGER DEFAULT 0,
    fonte           TEXT NOT NULL,          -- datajud|stj|stf|tst|tjsp|local
    valido_ate      TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '6 hours',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_jcache_hash ON jurisprudencia_cache(hash_query, valido_ate DESC);
CREATE INDEX IF NOT EXISTS idx_jcache_tribunal ON jurisprudencia_cache(tribunal, created_at DESC);

-- Histórico de buscas por usuário (analytics + melhoria contínua)
CREATE TABLE IF NOT EXISTS jurisprudencia_historico (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    query           TEXT NOT NULL,
    tribunal        TEXT,
    area_juridica   TEXT,
    total_resultados INTEGER DEFAULT 0,
    tempo_ms        INTEGER,
    fontes_usadas   TEXT[],
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_jhist_query ON jurisprudencia_historico(created_at DESC);

-- Citações validadas embutidas em petições
CREATE TABLE IF NOT EXISTS citacoes_validadas (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pedido_id       UUID,
    tribunal        TEXT NOT NULL,
    numero_decisao  TEXT,
    tipo            TEXT NOT NULL,   -- acordao|sumula|oj|lei
    ementa          TEXT NOT NULL,
    link_fonte      TEXT,
    validado        BOOLEAN DEFAULT FALSE,
    valido          BOOLEAN,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- v12: Upload, Triagem, Agente extrajudicial
-- ============================================================

CREATE TABLE IF NOT EXISTS documentos_pedido (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pedido_id       UUID NOT NULL,
    nome_original   TEXT NOT NULL,
    nome_arquivo    TEXT NOT NULL,
    caminho         TEXT NOT NULL,
    tipo_mime       TEXT,
    tamanho_bytes   INTEGER,
    descricao       TEXT,
    texto_extraido  TEXT,
    ativo           BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_docs_pedido ON documentos_pedido(pedido_id, ativo);

CREATE TABLE IF NOT EXISTS tentativas_extrajudiciais (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pedido_id   UUID NOT NULL,
    email_empresa TEXT,
    email_texto TEXT,
    status      TEXT DEFAULT 'enviado',
    resposta    TEXT,
    respondido_em TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_tent_pedido ON tentativas_extrajudiciais(pedido_id);

-- Expande status do pedido para suportar notificacao_extrajudicial
ALTER TABLE pedidos DROP CONSTRAINT IF EXISTS pedidos_status_check;
ALTER TABLE pedidos ADD CONSTRAINT pedidos_status_check
    CHECK (status IN (
        'aguardando_pagamento','pago','gerando','em_revisao',
        'aprovado','entregue','cancelado','reembolsado',
        'indicado_advogado','solicitando_info','extrajudicial_em_andamento'
    ));

-- ============================================================
-- v12: Upload docs + Viabilidade + Notif. extrajudicial + WhatsApp + Gov.br + Agente
-- ============================================================

-- Documentos enviados pelo cliente

-- Análise de viabilidade pré-pagamento
CREATE TABLE IF NOT EXISTS analises_viabilidade (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id      TEXT,
    area_juridica   TEXT NOT NULL,
    fatos           TEXT NOT NULL,
    score           NUMERIC(3,2),  -- 0-1
    elegivel_jec    BOOLEAN,
    prescrito       BOOLEAN,
    valor_estimado  NUMERIC(12,2),
    problemas       JSONB DEFAULT '[]',
    recomendacao    TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Notificações extrajudiciais (produto R$ 9,90)
CREATE TABLE IF NOT EXISTS notificacoes_extrajudiciais (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pedido_id       UUID REFERENCES pedidos(id),
    remetente_nome  TEXT NOT NULL,
    remetente_email TEXT NOT NULL,
    destinatario    TEXT NOT NULL,  -- empresa ou pessoa
    assunto         TEXT NOT NULL,
    corpo_notif     TEXT NOT NULL,
    enviada_em      TIMESTAMPTZ,
    status          TEXT DEFAULT 'pendente'
                    CHECK (status IN ('pendente','enviada','entregue','sem_resposta')),
    resposta        TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- WhatsApp Business tokens (para notificação de advogados)
CREATE TABLE IF NOT EXISTS whatsapp_config (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id      UUID NOT NULL UNIQUE,
    numero_tel      TEXT NOT NULL,
    provider        TEXT DEFAULT 'evolution_api',  -- evolution_api | baileys | wapi
    api_url         TEXT,
    api_token       TEXT,
    ativo           BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Log de mensagens WhatsApp enviadas
CREATE TABLE IF NOT EXISTS whatsapp_log (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id  UUID,
    numero_dest TEXT NOT NULL,
    mensagem    TEXT NOT NULL,
    tipo        TEXT DEFAULT 'notificacao',
    status      TEXT DEFAULT 'enviada',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Documentos jurídicos analisados com IA (extração estruturada)
CREATE TABLE IF NOT EXISTS documentos_analisados (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pedido_id           UUID REFERENCES pedidos(id) ON DELETE SET NULL,
    nome_arquivo        TEXT NOT NULL,
    paginas             INTEGER DEFAULT 0,
    texto_extraido      TEXT,
    dados_estruturados  JSONB DEFAULT '{}',
    confianca           INTEGER DEFAULT 0,    -- 0-100
    tipo_documento      TEXT,
    criado_por          TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_docs_analisados_tipo ON documentos_analisados(tipo_documento);
CREATE INDEX IF NOT EXISTS idx_docs_analisados_conf ON documentos_analisados(confianca DESC);

-- Tarefas internas
CREATE TABLE IF NOT EXISTS tarefas (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    titulo          TEXT NOT NULL,
    descricao       TEXT,
    tipo            TEXT DEFAULT 'revisao',   -- revisao | pesquisa | contato | protocolo | outro
    status          TEXT DEFAULT 'pendente'
                    CHECK (status IN ('pendente','em_andamento','concluida','cancelada')),
    prioridade      TEXT DEFAULT 'media'
                    CHECK (prioridade IN ('baixa','media','alta','urgente')),
    atribuido_para  TEXT,
    caso_id         UUID,
    pedido_id       UUID REFERENCES pedidos(id) ON DELETE SET NULL,
    data_vencimento DATE,
    concluida_em    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_tarefas_status ON tarefas(status, prioridade);
CREATE INDEX IF NOT EXISTS idx_tarefas_atrib  ON tarefas(atribuido_para);
CREATE INDEX IF NOT EXISTS idx_tarefas_venc   ON tarefas(data_vencimento) WHERE data_vencimento IS NOT NULL;

-- Dossiês (agrupamentos temáticos de casos)
CREATE TABLE IF NOT EXISTS dossies (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    titulo          TEXT NOT NULL,
    descricao       TEXT,
    area_juridica   TEXT,
    cliente_nome    TEXT,
    tags            JSONB DEFAULT '[]',
    status          TEXT DEFAULT 'ativo' CHECK (status IN ('ativo','arquivado')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Relação dossiê → casos/pedidos
CREATE TABLE IF NOT EXISTS dossie_casos (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    dossie_id   UUID REFERENCES dossies(id) ON DELETE CASCADE,
    caso_id     UUID,
    nota        TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(dossie_id, caso_id)
);
CREATE INDEX IF NOT EXISTS idx_dossie_casos ON dossie_casos(dossie_id);

-- ============================================================
-- v14: Auditoria Completa — Módulos Fase 1
-- ============================================================

-- 1. CLIENTES (tabela própria — estava embutida em casos)
CREATE TABLE IF NOT EXISTS clientes (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tipo            TEXT NOT NULL DEFAULT 'pf' CHECK (tipo IN ('pf','pj')),
    -- Pessoa física
    nome            TEXT,
    cpf             TEXT UNIQUE,
    rg              TEXT,
    data_nascimento DATE,
    -- Pessoa jurídica
    razao_social    TEXT,
    cnpj            TEXT UNIQUE,
    nome_fantasia   TEXT,
    -- Contato
    email           TEXT,
    telefone        TEXT,
    whatsapp        TEXT,
    -- Endereço
    cep             TEXT,
    logradouro      TEXT,
    numero          TEXT,
    complemento     TEXT,
    bairro          TEXT,
    cidade          TEXT,
    estado          TEXT,
    -- Classificação
    origem          TEXT DEFAULT 'indicacao'
                    CHECK (origem IN ('indicacao','site','whatsapp','instagram','oab','parceiro','outro')),
    area_interesse  TEXT,
    tipo_cliente    TEXT DEFAULT 'comum'
                    CHECK (tipo_cliente IN ('comum','recorrente','empresarial','pro_bono','indicado')),
    -- Controle
    responsavel_id  UUID REFERENCES usuarios(id) ON DELETE SET NULL,
    status          TEXT DEFAULT 'ativo' CHECK (status IN ('ativo','inativo','arquivado')),
    observacoes     TEXT,
    sigilo          BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_clientes_cpf    ON clientes(cpf);
CREATE INDEX IF NOT EXISTS idx_clientes_cnpj   ON clientes(cnpj);
CREATE INDEX IF NOT EXISTS idx_clientes_email  ON clientes(email);
CREATE INDEX IF NOT EXISTS idx_clientes_status ON clientes(status, created_at DESC);

-- 2. PROPOSTA E CONTRATO DE HONORÁRIOS
CREATE TABLE IF NOT EXISTS propostas (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero          TEXT UNIQUE NOT NULL DEFAULT 'PROP-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(FLOOR(RANDOM()*9999)::TEXT,4,'0'),
    cliente_id      UUID REFERENCES clientes(id) ON DELETE SET NULL,
    caso_id         UUID REFERENCES casos(id) ON DELETE SET NULL,
    -- Conteúdo
    titulo          TEXT NOT NULL,
    escopo          TEXT NOT NULL,
    exclusoes       TEXT,
    -- Valores
    tipo_honorario  TEXT NOT NULL DEFAULT 'fixo'
                    CHECK (tipo_honorario IN ('fixo','exito','misto','mensalidade','hora')),
    valor_fixo      NUMERIC(12,2),
    valor_exito_pct NUMERIC(5,2),
    valor_total     NUMERIC(12,2),
    forma_pagamento TEXT,
    condicoes       TEXT,
    validade_dias   INTEGER DEFAULT 15,
    -- Status
    status          TEXT NOT NULL DEFAULT 'rascunho'
                    CHECK (status IN ('rascunho','enviada','em_negociacao','aceita','recusada','expirada','convertida')),
    -- Controle
    criado_por_id   UUID REFERENCES usuarios(id) ON DELETE SET NULL,
    aceito_em       TIMESTAMPTZ,
    aceito_por      TEXT,
    notas_internas  TEXT,
    versao          INTEGER DEFAULT 1,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_propostas_status ON propostas(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_propostas_cliente ON propostas(cliente_id);

-- 3. CONTRATOS DE HONORÁRIOS
CREATE TABLE IF NOT EXISTS contratos_honorarios (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero          TEXT UNIQUE NOT NULL DEFAULT 'CONT-' || TO_CHAR(NOW(),'YYYY') || '-' || LPAD(FLOOR(RANDOM()*9999)::TEXT,4,'0'),
    proposta_id     UUID REFERENCES propostas(id) ON DELETE SET NULL,
    cliente_id      UUID REFERENCES clientes(id) ON DELETE SET NULL,
    caso_id         UUID REFERENCES casos(id) ON DELETE SET NULL,
    conteudo_md     TEXT NOT NULL,
    valor_total     NUMERIC(12,2),
    status          TEXT NOT NULL DEFAULT 'ativo'
                    CHECK (status IN ('ativo','suspenso','encerrado','rescindido')),
    assinado_cliente BOOLEAN DEFAULT FALSE,
    assinado_adv     BOOLEAN DEFAULT FALSE,
    assinado_em      TIMESTAMPTZ,
    criado_por_id    UUID REFERENCES usuarios(id) ON DELETE SET NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. CRM JURÍDICO (pipeline de leads)
CREATE TABLE IF NOT EXISTS crm_leads (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    -- Dados do lead
    nome            TEXT NOT NULL,
    email           TEXT,
    telefone        TEXT,
    whatsapp        TEXT,
    area_interesse  TEXT,
    descricao       TEXT,
    -- Pipeline
    status          TEXT NOT NULL DEFAULT 'novo'
                    CHECK (status IN ('novo','contato_feito','aguardando_docs','em_analise',
                                      'proposta_enviada','follow_up','contratado','recusado','arquivado')),
    origem          TEXT DEFAULT 'site',
    prioridade      TEXT DEFAULT 'media' CHECK (prioridade IN ('baixa','media','alta','urgente')),
    -- Controle
    responsavel_id  UUID REFERENCES usuarios(id) ON DELETE SET NULL,
    cliente_id      UUID REFERENCES clientes(id) ON DELETE SET NULL,
    caso_id         UUID REFERENCES casos(id) ON DELETE SET NULL,
    proposta_id     UUID REFERENCES propostas(id) ON DELETE SET NULL,
    proxima_acao    TEXT,
    proxima_data    DATE,
    notas           TEXT,
    perdido_motivo  TEXT,
    converted_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_crm_status ON crm_leads(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_crm_resp   ON crm_leads(responsavel_id);

-- Histórico de interações CRM
CREATE TABLE IF NOT EXISTS crm_interacoes (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id     UUID NOT NULL REFERENCES crm_leads(id) ON DELETE CASCADE,
    tipo        TEXT NOT NULL CHECK (tipo IN ('ligacao','email','whatsapp','reuniao','nota','status_change')),
    descricao   TEXT NOT NULL,
    usuario_id  UUID REFERENCES usuarios(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_crm_int_lead ON crm_interacoes(lead_id, created_at DESC);

-- 5. CHECKLIST JURÍDICO POR TIPO DE DEMANDA
CREATE TABLE IF NOT EXISTS checklists (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome            TEXT NOT NULL,
    area_juridica   TEXT NOT NULL,
    tipo_demanda    TEXT NOT NULL,
    descricao       TEXT,
    itens           JSONB NOT NULL DEFAULT '[]',
    -- item: {id, categoria, descricao, obrigatorio, dica, ordem}
    ativo           BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Instâncias de checklist por caso
CREATE TABLE IF NOT EXISTS caso_checklists (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    caso_id         UUID NOT NULL REFERENCES casos(id) ON DELETE CASCADE,
    checklist_id    UUID NOT NULL REFERENCES checklists(id),
    itens_status    JSONB NOT NULL DEFAULT '{}',
    -- {item_id: {concluido: bool, nota: str, data: str}}
    concluido       BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. USUÁRIOS — expansão de roles e campos faltantes
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS assistente_de UUID REFERENCES usuarios(id);
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS telefone TEXT;
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS cargo TEXT;
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS departamento TEXT;
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS avatar_url TEXT;
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS notif_email BOOLEAN DEFAULT TRUE;
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS notif_whatsapp BOOLEAN DEFAULT FALSE;
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS preferencias JSONB DEFAULT '{}';
ALTER TABLE roles_permissoes ADD COLUMN IF NOT EXISTS descricao TEXT;

-- Atualiza constraint de roles para incluir novos perfis
-- (Postgres não tem ALTER CHECK sem recriar, usamos trigger de validação)
CREATE OR REPLACE FUNCTION validar_role() RETURNS TRIGGER AS $$
BEGIN
  IF NEW.role NOT IN ('superadmin','admin','socio','advogado','assistente','financeiro','atendimento','estagiario','cliente') THEN
    RAISE EXCEPTION 'Role inválido: %', NEW.role;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_validar_role ON usuarios;
CREATE TRIGGER trg_validar_role BEFORE INSERT OR UPDATE ON usuarios
  FOR EACH ROW EXECUTE FUNCTION validar_role();

-- 7. CASOS — expansão de status e campos
ALTER TABLE casos ADD COLUMN IF NOT EXISTS cliente_id UUID REFERENCES clientes(id) ON DELETE SET NULL;
ALTER TABLE casos ADD COLUMN IF NOT EXISTS responsavel_id UUID REFERENCES usuarios(id) ON DELETE SET NULL;
ALTER TABLE casos ADD COLUMN IF NOT EXISTS fase TEXT DEFAULT 'inicial';
ALTER TABLE casos ADD COLUMN IF NOT EXISTS risco TEXT DEFAULT 'medio' CHECK (risco IN ('baixo','medio','alto','critico'));
ALTER TABLE casos ADD COLUMN IF NOT EXISTS sigilo BOOLEAN DEFAULT FALSE;
ALTER TABLE casos ADD COLUMN IF NOT EXISTS tipo_demanda TEXT DEFAULT 'judicial'
    CHECK (tipo_demanda IN ('judicial','consultivo','extrajudicial','preventivo'));
ALTER TABLE casos ADD COLUMN IF NOT EXISTS data_encerramento DATE;
ALTER TABLE casos ADD COLUMN IF NOT EXISTS resultado TEXT;
ALTER TABLE casos ADD COLUMN IF NOT EXISTS estrategia_interna TEXT;

-- 8. AUDIT_LOG — garantir campos completos
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS ip_address TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS user_agent TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS dados_antes JSONB;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS dados_depois JSONB;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS modulo TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS registro_id TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS perfil_usuario TEXT;

-- 9. DOCUMENTOS — controle de sigilo, versão, aprovação
ALTER TABLE legal_documents ADD COLUMN IF NOT EXISTS nivel_sigilo TEXT DEFAULT 'interno'
    CHECK (nivel_sigilo IN ('publico','interno','restrito','confidencial'));
ALTER TABLE legal_documents ADD COLUMN IF NOT EXISTS gerado_por_ia BOOLEAN DEFAULT FALSE;
ALTER TABLE legal_documents ADD COLUMN IF NOT EXISTS status_revisao TEXT DEFAULT 'pendente'
    CHECK (status_revisao IN ('rascunho','em_revisao','aprovado','reprovado','publicado'));
ALTER TABLE legal_documents ADD COLUMN IF NOT EXISTS aprovado_por UUID REFERENCES usuarios(id);
ALTER TABLE legal_documents ADD COLUMN IF NOT EXISTS aprovado_em TIMESTAMPTZ;
ALTER TABLE legal_documents ADD COLUMN IF NOT EXISTS versao INTEGER DEFAULT 1;
ALTER TABLE legal_documents ADD COLUMN IF NOT EXISTS documento_pai UUID REFERENCES legal_documents(id);
ALTER TABLE legal_documents ADD COLUMN IF NOT EXISTS cliente_id UUID REFERENCES clientes(id) ON DELETE SET NULL;
ALTER TABLE legal_documents ADD COLUMN IF NOT EXISTS caso_id UUID REFERENCES casos(id) ON DELETE SET NULL;

-- 10. PRAZOS — expansão de campos
ALTER TABLE prazos ADD COLUMN IF NOT EXISTS caso_id UUID REFERENCES casos(id) ON DELETE SET NULL;
ALTER TABLE prazos ADD COLUMN IF NOT EXISTS cliente_id UUID REFERENCES clientes(id) ON DELETE SET NULL;
ALTER TABLE prazos ADD COLUMN IF NOT EXISTS responsavel_id UUID REFERENCES usuarios(id) ON DELETE SET NULL;
ALTER TABLE prazos ADD COLUMN IF NOT EXISTS origem TEXT DEFAULT 'manual'
    CHECK (origem IN ('manual','datajud','importado','calendario'));
ALTER TABLE prazos ADD COLUMN IF NOT EXISTS historico_alteracoes JSONB DEFAULT '[]';
ALTER TABLE prazos ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- Historico de execucoes dos agentes
CREATE TABLE IF NOT EXISTS agente_execucoes (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agente_id   TEXT NOT NULL,
    caso_id     UUID,
    prompt      TEXT,
    resposta    TEXT,
    tempo_ms    INTEGER,
    usuario_id  UUID REFERENCES usuarios(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_agente_exec_agente ON agente_execucoes(agente_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_agente_exec_caso   ON agente_execucoes(caso_id);

-- ============================================================
-- v15: Índice Remissivo de Leis e Súmulas + Índice de Teses
-- ============================================================

-- Repositório central de leis (artigos indexados)
CREATE TABLE IF NOT EXISTS indice_leis (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    diploma         TEXT NOT NULL,        -- Ex: "Código Civil", "CDC", "CLT"
    numero_lei      TEXT,                 -- Ex: "10.406/2002"
    data_vigencia   DATE,
    artigo          TEXT NOT NULL,        -- Ex: "Art. 186"
    inciso          TEXT,                 -- Ex: "I", "II"
    alinea          TEXT,
    paragrafo       TEXT,                 -- Ex: "§ 1º"
    texto           TEXT NOT NULL,        -- texto literal do dispositivo
    area_juridica   TEXT NOT NULL,
    tema            TEXT,                 -- Ex: "responsabilidade civil"
    palavras_chave  TEXT[],
    ativo           BOOLEAN DEFAULT TRUE,
    fonte_oficial   TEXT,                 -- URL Planalto/LexML
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_leis_diploma  ON indice_leis(diploma);
CREATE INDEX IF NOT EXISTS idx_leis_area     ON indice_leis(area_juridica);
CREATE INDEX IF NOT EXISTS idx_leis_artigo   ON indice_leis(diploma, artigo);
CREATE INDEX IF NOT EXISTS idx_leis_tema     ON indice_leis(tema);
CREATE INDEX IF NOT EXISTS idx_leis_fulltext ON indice_leis
    USING gin(to_tsvector('portuguese', COALESCE(texto,'') || ' ' || COALESCE(tema,'') || ' ' || diploma));

-- Repositório central de súmulas (além das salvas por caso)
CREATE TABLE IF NOT EXISTS indice_sumulas (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tribunal        TEXT NOT NULL,        -- STF, STJ, TST, TRT, TJSP...
    numero          INTEGER NOT NULL,
    tipo            TEXT NOT NULL DEFAULT 'sumula'
                    CHECK (tipo IN ('sumula','sumula_vinculante','oj','precedente_normativo')),
    enunciado       TEXT NOT NULL,
    area_juridica   TEXT NOT NULL,
    temas           TEXT[],
    status          TEXT NOT NULL DEFAULT 'vigente'
                    CHECK (status IN ('vigente','cancelada','superada','revista')),
    data_edicao     DATE,
    data_cancelamento DATE,
    motivo_cancelamento TEXT,
    leis_relacionadas TEXT[],             -- artigos de lei que a súmula interpreta
    palavras_chave  TEXT[],
    fonte_oficial   TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tribunal, numero, tipo)
);
CREATE INDEX IF NOT EXISTS idx_sumulas_tribunal ON indice_sumulas(tribunal);
CREATE INDEX IF NOT EXISTS idx_sumulas_area     ON indice_sumulas(area_juridica, status);
CREATE INDEX IF NOT EXISTS idx_sumulas_numero   ON indice_sumulas(tribunal, numero);
CREATE INDEX IF NOT EXISTS idx_sumulas_fulltext ON indice_sumulas
    USING gin(to_tsvector('portuguese', enunciado || ' ' || COALESCE(array_to_string(temas,' '),'')));

-- Índice de Teses Jurídicas por área (banco estratégico do escritório)
CREATE TABLE IF NOT EXISTS indice_teses (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    titulo          TEXT NOT NULL,
    area_juridica   TEXT NOT NULL,
    subarea         TEXT,                 -- Ex: "rescisão indireta" dentro de "trabalhista"
    tese            TEXT NOT NULL,        -- enunciado sintético da tese
    fundamentos     TEXT NOT NULL,        -- legislação + doutrina + jurisprudência
    argumentos      TEXT,                 -- desenvolvimento argumentativo completo
    contra_argumento TEXT,               -- argumentos que a parte contrária usará
    jurisprudencias TEXT[],               -- precedentes que sustentam
    sumulas         TEXT[],               -- súmulas aplicáveis
    leis            TEXT[],               -- artigos de lei
    viabilidade     TEXT DEFAULT 'media'
                    CHECK (viabilidade IN ('alta','media','baixa','depende_provas')),
    tipo_acao       TEXT[],               -- Ex: ["JEC", "vara cível", "trabalhista"]
    status          TEXT DEFAULT 'ativa'
                    CHECK (status IN ('ativa','desatualizada','superada','em_revisao')),
    uso_count       INTEGER DEFAULT 0,
    aprovada_por    UUID REFERENCES usuarios(id) ON DELETE SET NULL,
    criada_por      UUID REFERENCES usuarios(id) ON DELETE SET NULL,
    tags            TEXT[],
    casos_vinculados INTEGER DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_indice_teses_area     ON indice_teses(area_juridica, status);
CREATE INDEX IF NOT EXISTS idx_indice_teses_subarea  ON indice_teses(subarea);
CREATE INDEX IF NOT EXISTS idx_indice_teses_viab     ON indice_teses(viabilidade, area_juridica);
CREATE INDEX IF NOT EXISTS idx_indice_teses_fulltext ON indice_teses
    USING gin(to_tsvector('portuguese',
        titulo || ' ' || tese || ' ' || COALESCE(fundamentos,'') || ' ' ||
        COALESCE(array_to_string(tags,' '),'')
    ));
