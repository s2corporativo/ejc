"""
EJC — Schemas Pydantic (schemas/legal.py)
Contratos de entrada/saída das APIs
"""
from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from uuid import UUID


# ============================================================
# RAG / Knowledge Base
# ============================================================

class DocumentUploadResponse(BaseModel):
    document_id: UUID
    filename: str
    category: str
    chunks_created: int
    message: str


class RAGQueryRequest(BaseModel):
    query: str = Field(..., min_length=5, max_length=2000,
                       description="Consulta jurídica em linguagem natural")
    top_k: int = Field(8, ge=1, le=20)
    category: Optional[str] = None


class RAGQueryResponse(BaseModel):
    query: str
    answer: str
    sources: list[dict]
    elapsed_ms: float


# ============================================================
# Redação de Peças
# ============================================================

class DraftRequest(BaseModel):
    title: str = Field(..., min_length=3, max_length=300)
    document_type: str = Field(..., description="peticao_inicial|recurso|contrato|parecer|edital")
    facts: str = Field(..., min_length=50, max_length=10000,
                       description="Fatos detalhados do caso")
    objective: str = Field(..., min_length=20, max_length=2000,
                           description="Pedido/objetivo jurídico")
    client_name: Optional[str] = None
    opposing_party: Optional[str] = None
    additional_context: Optional[str] = None


class DraftResponse(BaseModel):
    document_id: UUID
    title: str
    document_type: str
    content_md: str
    word_count: int
    status: str
    elapsed_seconds: float


class DocumentListItem(BaseModel):
    id: UUID
    title: str
    document_type: str
    status: str
    created_at: datetime
    word_count: int


# ============================================================
# Validação
# ============================================================

class ValidationRequest(BaseModel):
    document_id: UUID
    content_md: str


class LegalReference(BaseModel):
    reference: str
    article: Optional[str]
    status: str   # 'vigente' | 'revogado' | 'nao_verificado'
    source_url: Optional[str]


class ValidationResponse(BaseModel):
    document_id: UUID
    references_found: list[LegalReference]
    validation_score: float   # 0.0 – 1.0
    warnings: list[str]
    updated_content_md: Optional[str]


# ============================================================
# Cálculos
# ============================================================

class FGTSRevisionalRequest(BaseModel):
    nome_empregado: str
    data_admissao: str = Field(..., description="YYYY-MM-DD")
    data_demissao: str = Field(..., description="YYYY-MM-DD")
    salarios: list[dict] = Field(
        ...,
        description="Lista de {'competencia': 'YYYY-MM', 'salario_bruto': 3500.00}"
    )
    percentual_fgts: float = Field(8.0, ge=2.0, le=8.0)
    taxa_tr_mensal: Optional[float] = Field(None, description="Se None, usa tabela embutida")


class FGTSRevisionalResponse(BaseModel):
    nome_empregado: str
    total_fgts_devido: str    # formatado BRL
    total_depositado: str
    diferenca: str
    multa_40_percent: str
    total_a_receber: str
    detalhamento: list[dict]
    metodologia: str


class PISCOFINSRequest(BaseModel):
    cnpj_fornecedor: str
    periodo_apuracao: str = Field(..., description="YYYY-MM")
    regime_tributario: str = Field(..., description="lucro_real|lucro_presumido|simples")
    receita_bruta: float
    receita_monofasica: float
    aliquota_pis: Optional[float] = Field(0.65, description="% — padrão cumulativo")
    aliquota_cofins: Optional[float] = Field(3.0, description="% — padrão cumulativo")


class PISCOFINSResponse(BaseModel):
    cnpj_fornecedor: str
    periodo_apuracao: str
    pis_calculado: str
    cofins_calculado: str
    total_tributos: str
    base_calculo_monofasica: str
    creditos_aproveitados: str
    detalhamento: dict
    fundamentacao_legal: list[str]
