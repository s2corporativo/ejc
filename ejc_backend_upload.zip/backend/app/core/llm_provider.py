"""
EJC — LLM Provider Adapter (core/llm_provider.py)

Abstrai o provedor de LLM para que todo o sistema funcione
com Ollama (local) OU Groq (cloud) sem mudar nenhum outro arquivo.

Troca de provedor: defina LLM_PROVIDER no .env
  LLM_PROVIDER=ollama   → LLM 100% local (soberania total)
  LLM_PROVIDER=groq     → Groq API (grátis, mais rápido, requer internet)

Groq gratuito (jun/2025):
  - 14.400 requisições/dia
  - 6.000 tokens/min por modelo
  - Modelos: llama-3.3-70b-versatile, llama-3.1-8b-instant, mixtral-8x7b-32768
  - Obtenha chave em: https://console.groq.com
"""
from __future__ import annotations

import json
import logging
import time
from typing import AsyncGenerator, Optional

import httpx

from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

# ── Constantes Groq API ────────────────────────────────────────────────────
GROQ_BASE_URL   = "https://api.groq.com/openai/v1"
GROQ_CHAT_PATH  = "/chat/completions"

# Mapeamento Ollama → Groq (para migração suave)
MODELO_GROQ_MAP = {
    "llama3":          "llama-3.3-70b-versatile",
    "llama3:8b":       "llama-3.1-8b-instant",
    "llama3:70b":      "llama-3.3-70b-versatile",
    "mistral":         "mixtral-8x7b-32768",
    "mixtral":         "mixtral-8x7b-32768",
    "gemma":           "gemma2-9b-it",
    "gemma2":          "gemma2-9b-it",
}


class LLMProvider:
    """
    Provedor unificado de LLM.
    Internamente chama Ollama ou Groq conforme LLM_PROVIDER no .env.
    A interface é idêntica para o resto do sistema.
    """

    def __init__(self):
        self.provider = settings.llm_provider.lower()
        if self.provider not in ("ollama", "groq"):
            logger.warning(f"[LLM] Provider '{self.provider}' desconhecido — usando ollama")
            self.provider = "ollama"

        if self.provider == "groq" and not settings.groq_api_key:
            raise ValueError(
                "LLM_PROVIDER=groq mas GROQ_API_KEY não está definida no .env.\n"
                "Obtenha sua chave gratuita em https://console.groq.com"
            )

        logger.info(f"[LLM] Provedor ativo: {self.provider.upper()} "
                    f"| Modelo: {self._modelo_ativo()}")

    def _modelo_ativo(self) -> str:
        if self.provider == "groq":
            return settings.groq_model
        return settings.ollama_model

    # ── Geração completa (sem streaming) ──────────────────────────────────

    async def generate(
        self,
        prompt: str,
        system: str = "",
        temperature: float = 0.1,
        max_tokens: int = 8192,
    ) -> str:
        """
        Gera texto completo. Interface única para Ollama e Groq.
        """
        if self.provider == "groq":
            return await self._groq_generate(prompt, system, temperature, max_tokens)
        return await self._ollama_generate(prompt, system, temperature, max_tokens)

    # ── Streaming (tokens em tempo real) ──────────────────────────────────

    async def stream(
        self,
        prompt: str,
        system: str = "",
        temperature: float = 0.1,
        max_tokens: int = 8192,
    ) -> AsyncGenerator[str, None]:
        """
        Gera tokens em streaming (SSE). Interface única para ambos os provedores.
        Cada yield é uma string JSON: {"token": "...", "done": bool}
        """
        if self.provider == "groq":
            async for chunk in self._groq_stream(prompt, system, temperature, max_tokens):
                yield chunk
        else:
            async for chunk in self._ollama_stream(prompt, system, temperature, max_tokens):
                yield chunk

    # ── Health check ──────────────────────────────────────────────────────

    async def check_health(self) -> dict:
        if self.provider == "groq":
            return await self._groq_health()
        return await self._ollama_health()

    # ════════════════════════════════════════════════════════════════════════
    # GROQ
    # ════════════════════════════════════════════════════════════════════════

    def _groq_headers(self) -> dict:
        return {
            "Authorization": f"Bearer {settings.groq_api_key}",
            "Content-Type":  "application/json",
        }

    def _groq_messages(self, prompt: str, system: str) -> list[dict]:
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": prompt})
        return msgs

    async def _groq_generate(
        self, prompt: str, system: str, temperature: float, max_tokens: int
    ) -> str:
        payload = {
            "model":       settings.groq_model,
            "messages":    self._groq_messages(prompt, system),
            "temperature": temperature,
            "max_tokens":  max_tokens,
            "stream":      False,
        }
        t0 = time.time()
        async with httpx.AsyncClient(
            base_url=GROQ_BASE_URL,
            headers=self._groq_headers(),
            timeout=settings.groq_timeout,
        ) as client:
            try:
                resp = await client.post(GROQ_CHAT_PATH, json=payload)
                resp.raise_for_status()
                data = resp.json()
                texto = data["choices"][0]["message"]["content"]
                tokens = data.get("usage", {})
                elapsed = round(time.time() - t0, 1)
                logger.info(
                    f"[Groq] Geração em {elapsed}s | "
                    f"prompt={tokens.get('prompt_tokens','?')} "
                    f"completion={tokens.get('completion_tokens','?')} tokens"
                )
                return texto.strip()
            except httpx.HTTPStatusError as e:
                self._tratar_erro_groq(e)
            except httpx.TimeoutException:
                raise RuntimeError(
                    f"Groq não respondeu em {settings.groq_timeout}s. "
                    "Tente llama-3.1-8b-instant (mais rápido) ou aumente GROQ_TIMEOUT."
                )

    async def _groq_stream(
        self, prompt: str, system: str, temperature: float, max_tokens: int
    ) -> AsyncGenerator[str, None]:
        payload = {
            "model":       settings.groq_model,
            "messages":    self._groq_messages(prompt, system),
            "temperature": temperature,
            "max_tokens":  max_tokens,
            "stream":      True,
        }
        async with httpx.AsyncClient(
            base_url=GROQ_BASE_URL,
            headers=self._groq_headers(),
            timeout=settings.groq_timeout,
        ) as client:
            try:
                async with client.stream("POST", GROQ_CHAT_PATH, json=payload) as resp:
                    resp.raise_for_status()
                    async for line in resp.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        raw = line[5:].strip()
                        if raw == "[DONE]":
                            yield f"data: {json.dumps({'token': '', 'done': True})}\n\n"
                            break
                        try:
                            chunk = json.loads(raw)
                            delta = chunk["choices"][0]["delta"].get("content", "")
                            if delta:
                                yield f"data: {json.dumps({'token': delta, 'done': False})}\n\n"
                        except (json.JSONDecodeError, KeyError):
                            continue
            except httpx.HTTPStatusError as e:
                self._tratar_erro_groq(e)

    async def _groq_health(self) -> dict:
        """Verifica conectividade com a Groq API listando os modelos."""
        try:
            async with httpx.AsyncClient(
                base_url=GROQ_BASE_URL,
                headers=self._groq_headers(),
                timeout=8.0,
            ) as client:
                resp = await client.get("/models")
                resp.raise_for_status()
                modelos = [m["id"] for m in resp.json().get("data", [])]
                modelo_ativo = settings.groq_model
                return {
                    "status":           "online",
                    "provider":         "groq",
                    "configured_model": modelo_ativo,
                    "model_ready":      modelo_ativo in modelos or True,
                    "models_available": modelos[:10],
                    "nota":             "Groq API — LLM em nuvem, dados trafegam pela internet",
                }
        except Exception as e:
            return {"status": "offline", "provider": "groq", "error": str(e)}

    def _tratar_erro_groq(self, e: httpx.HTTPStatusError):
        body = ""
        try:
            body = e.response.json().get("error", {}).get("message", e.response.text)
        except Exception:
            body = e.response.text[:200]

        if e.response.status_code == 401:
            raise RuntimeError(
                "Chave Groq inválida. Verifique GROQ_API_KEY no .env.\n"
                "Obtenha em: https://console.groq.com/keys"
            )
        if e.response.status_code == 429:
            raise RuntimeError(
                "Limite de taxa Groq atingido (6.000 tokens/min ou 14.400 req/dia). "
                "Aguarde 1 minuto ou use LLM_PROVIDER=ollama para sem limites."
            )
        if e.response.status_code == 400:
            raise RuntimeError(f"Groq rejeitou a requisição: {body}")
        raise RuntimeError(f"Groq retornou erro {e.response.status_code}: {body}")

    # ════════════════════════════════════════════════════════════════════════
    # OLLAMA (mantido idêntico ao original)
    # ════════════════════════════════════════════════════════════════════════

    async def _ollama_generate(
        self, prompt: str, system: str, temperature: float, max_tokens: int
    ) -> str:
        payload = {
            "model":  settings.ollama_model,
            "prompt": prompt,
            "system": system,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
                "num_ctx":     16384,
            },
        }
        t0 = time.time()
        async with httpx.AsyncClient(
            base_url=settings.ollama_base_url,
            timeout=settings.ollama_timeout,
        ) as client:
            try:
                resp = await client.post("/api/generate", json=payload)
                resp.raise_for_status()
                data = resp.json()
                elapsed = round(time.time() - t0, 1)
                logger.info(
                    f"[Ollama] Geração em {elapsed}s | "
                    f"tokens={data.get('eval_count','?')}"
                )
                return data.get("response", "").strip()
            except httpx.TimeoutException:
                raise RuntimeError(
                    "Ollama excedeu o tempo limite. "
                    "Use llama3 (menor) ou aumente OLLAMA_TIMEOUT."
                )
            except httpx.HTTPStatusError as e:
                raise RuntimeError(f"Ollama retornou erro {e.response.status_code}: {e.response.text[:200]}")

    async def _ollama_stream(
        self, prompt: str, system: str, temperature: float, max_tokens: int
    ) -> AsyncGenerator[str, None]:
        payload = {
            "model":  settings.ollama_model,
            "prompt": prompt,
            "system": system,
            "stream": True,
            "options": {"temperature": temperature, "num_predict": max_tokens, "num_ctx": 16384},
        }
        async with httpx.AsyncClient(
            base_url=settings.ollama_base_url,
            timeout=settings.ollama_timeout,
        ) as client:
            try:
                async with client.stream("POST", "/api/generate", json=payload) as resp:
                    resp.raise_for_status()
                    async for line in resp.aiter_lines():
                        if not line.strip():
                            continue
                        try:
                            chunk = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        token = chunk.get("response", "")
                        done  = chunk.get("done", False)
                        if token:
                            yield f"data: {json.dumps({'token': token, 'done': False})}\n\n"
                        if done:
                            yield f"data: {json.dumps({'token': '', 'done': True})}\n\n"
                            break
            except httpx.TimeoutException:
                yield f"data: {json.dumps({'token': '', 'done': True, 'erro': 'Timeout Ollama'})}\n\n"

    async def _ollama_health(self) -> dict:
        try:
            async with httpx.AsyncClient(
                base_url=settings.ollama_base_url, timeout=5.0
            ) as client:
                resp = await client.get("/api/tags")
                modelos = [m["name"] for m in resp.json().get("models", [])]
                return {
                    "status":           "online",
                    "provider":         "ollama",
                    "configured_model": settings.ollama_model,
                    "model_ready":      any(settings.ollama_model in m for m in modelos),
                    "models_available": modelos,
                    "nota":             "Ollama local — soberania total, zero custo de API",
                }
        except Exception as e:
            return {"status": "offline", "provider": "ollama", "error": str(e)}


# Singleton compartilhado
_provider: Optional[LLMProvider] = None


def get_llm_provider() -> LLMProvider:
    global _provider
    if _provider is None:
        _provider = LLMProvider()
    return _provider
