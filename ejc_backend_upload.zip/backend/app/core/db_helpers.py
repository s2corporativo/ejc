"""
EJC — Helpers de banco de dados (core/db_helpers.py)
Wrappers com tratamento de erro padronizado para db.execute.
"""
from __future__ import annotations
import logging
from typing import Optional, Any

from fastapi import HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)


async def db_execute(
    db: AsyncSession,
    sql: str,
    params: Optional[dict] = None,
    commit: bool = False,
    error_msg: str = "Erro ao executar operação no banco",
) -> Any:
    """
    Executa SQL com tratamento de erro padronizado.
    Substitui o padrão repetitivo de try/except em cada endpoint.
    """
    try:
        result = await db.execute(text(sql), params or {})
        if commit:
            await db.commit()
        return result
    except HTTPException:
        raise  # Re-lança HTTPException sem modificar
    except Exception as e:
        logger.error(f"[DB] {error_msg}: {e}")
        raise HTTPException(500, f"{error_msg}. Tente novamente.")


async def db_fetch_one(
    db: AsyncSession,
    sql: str,
    params: Optional[dict] = None,
) -> Optional[dict]:
    """Executa query e retorna primeiro resultado como dict ou None."""
    try:
        result = await db.execute(text(sql), params or {})
        row = result.mappings().first()
        return dict(row) if row else None
    except Exception as e:
        logger.debug(f"[DB:fetch_one] {e}")
        return None


async def db_fetch_all(
    db: AsyncSession,
    sql: str,
    params: Optional[dict] = None,
) -> list[dict]:
    """Executa query e retorna todos os resultados como lista de dicts."""
    try:
        result = await db.execute(text(sql), params or {})
        return [dict(r) for r in result.mappings()]
    except Exception as e:
        logger.debug(f"[DB:fetch_all] {e}")
        return []
