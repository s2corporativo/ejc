"""
EJC — Scheduler (core/scheduler.py)
APScheduler com jobs que funcionam para ambos os provedores (Ollama/Groq).
"""
from __future__ import annotations
import logging
from sqlalchemy import text  # usado em _sync_datajud (ramo de alerta WhatsApp)
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.cron import CronTrigger

logger = logging.getLogger(__name__)
_scheduler: AsyncIOScheduler | None = None


def get_scheduler() -> AsyncIOScheduler:
    global _scheduler
    if _scheduler is None:
        _scheduler = AsyncIOScheduler(timezone="America/Sao_Paulo")
    return _scheduler


async def _sync_datajud():
    """
    Sincroniza processos monitorados com o DataJud real (CNJ).
    Detecta novas movimentações, gera alertas e notifica via WhatsApp.
    """
    try:
        from app.core.database import AsyncSessionLocal
        from app.modules.integracao.datajud.monitor import MonitorMovimentacoes
        async with AsyncSessionLocal() as db:
            monitor = MonitorMovimentacoes()
            result = await monitor.sincronizar_com_alertas(db)
            await db.commit()
            novos = result.get("alertas_gerados", 0)
            atualizados = result.get("atualizados", 0)
            logger.info(f"[Scheduler] DataJud CNJ: {atualizados} proc. verificados, {novos} alertas gerados")

            # Notifica via WhatsApp se houver movimentações novas
            if novos > 0:
                try:
                    from app.modules.triagem.router import enviar_whatsapp
                    row = await db.execute(text("""
                        SELECT a.titulo, a.descricao, p.numero_processo, wc.numero_tel
                        FROM alertas_processo a
                        JOIN processos_monitorados p ON p.id = a.processo_id
                        JOIN whatsapp_config wc ON wc.ativo = TRUE
                        WHERE a.lido = FALSE
                        ORDER BY a.created_at DESC LIMIT 5
                    """))
                    for alerta in row.mappings():
                        proc = alerta.get("numero_processo","?")
                        titulo = alerta.get("titulo","Nova movimentacao")
                        desc = str(alerta.get("descricao",""))[:100]
                        msg = "Alerta Processual - Processo: " + proc + " - " + titulo + " - " + desc
                        await enviar_whatsapp(alerta.get("numero_tel",""), msg, db)
                except Exception as we:
                    logger.debug(f"[Scheduler] WhatsApp notif: {we}")
    except Exception as e:
        logger.error(f"[Scheduler] DataJud sync falhou: {e}")


async def _ingerir_jurisprudencia():
    try:
        from app.core.database import AsyncSessionLocal
        from app.modules.integracao.stj.client import TSTClient
        from app.modules.rag.knowledge_base import LegalKnowledgeBase
        temas = ["FGTS", "hora extra", "rescisão", "assédio moral", "terceirização"]
        tst = TSTClient()
        kb  = LegalKnowledgeBase()
        async with AsyncSessionLocal() as db:
            for tema in temas:
                sumulas = await tst.buscar_por_tema(tema)
                if sumulas:
                    texto = f"JURISPRUDÊNCIA TST — {tema.upper()}\n\n"
                    texto += "\n\n".join(f"Súmula TST nº {s['numero']}: {s['texto']}" for s in sumulas)
                    await kb.ingest_file(db=db, file_bytes=texto.encode(),
                        filename=f"tst_auto_{tema.replace(' ','_')}.txt",
                        category="jurisprudencia", metadata={"fonte":"tst_auto","tema":tema})
            await db.commit()
        logger.info("[Scheduler] Jurisprudência TST atualizada.")
    except Exception as e:
        logger.error(f"[Scheduler] TST ingest falhou: {e}")


async def _alertar_prazos():
    try:
        from app.modules.notificacoes.router import job_alertar_prazos_criticos
        await job_alertar_prazos_criticos()
    except Exception as e:
        logger.error(f"[Scheduler] Alertas prazos falhou: {e}")



async def _processar_webhook_queue():
    """Worker da fila de webhooks MP — executa a cada 30s."""
    try:
        from app.core.database import AsyncSessionLocal
        from app.modules.pagamento.webhook_queue import processar_fila
        async with AsyncSessionLocal() as db:
            result = await processar_fila(db)
            if result["total"] > 0:
                logger.info(f"[Scheduler] WebhookQueue: {result}")
    except Exception as e:
        logger.error(f"[Scheduler] WebhookQueue falhou: {e}")

def start_scheduler():
    s = get_scheduler()
    s.add_job(_sync_datajud,           IntervalTrigger(hours=1),
              id="datajud_sync", replace_existing=True)
    s.add_job(_ingerir_jurisprudencia, CronTrigger(day_of_week="mon", hour=7),
              id="tst_ingest", replace_existing=True)
    s.add_job(_alertar_prazos,         CronTrigger(hour=7, minute=0),
              id="notif_prazos", replace_existing=True)
    s.add_job(_processar_webhook_queue, IntervalTrigger(seconds=30),
              id="webhook_queue", replace_existing=True)
    # Monitor DOU/TJs — job real do módulo monitor.
    # (antes: registrar_monitor(s) — função inexistente que quebrava o startup)
    from app.modules.monitor.router import job_monitorar_publicacoes
    s.add_job(job_monitorar_publicacoes, CronTrigger(hour=9, minute=0),
              id="monitor_dou", replace_existing=True)
    s.start()
    logger.info("[Scheduler] Iniciado — 5 jobs: DataJud(1h), TST(seg/7h), "
                "Prazos(7h), WebhookQueue(30s), Monitor DOU(9h)")
