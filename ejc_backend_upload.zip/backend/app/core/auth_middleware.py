"""
EJC - Middleware Global de Autenticacao JWT (auth_middleware.py)
Protege todos os endpoints /api/v1/* exceto whitelist publica.
"""
from __future__ import annotations
import logging
from typing import Optional
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from jose import JWTError, jwt
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

PREFIXOS_PUBLICOS = (
    "/api/v1/publico",
    "/api/v1/cliente",
    "/api/v1/portal",
    "/api/v1/onboarding",
    "/api/v1/bacen",
    "/api/v1/juizados",
    "/api/v1/auth/login",
    "/api/v1/auth/refresh",
    "/api/v1/auth/register",
    "/api/v1/pagamento/webhook",
    "/api/v1/pagamento/status",
    "/api/v1/pedidos/planos",
    "/api/v1/pedidos/criar",
    "/api/v1/pedidos/depoimentos",
    "/api/v1/pedidos/lead-advogado",
    "/api/v1/revisao/info/",
    "/api/v1/triagem/viabilidade",
    "/api/v1/triagem/notificacao-extrajudicial",
    "/api/v1/upload/pedido",
    "/docs",
    "/redoc",
    "/openapi.json",
    "/health",
)

def _is_publica(path: str) -> bool:
    if not path.startswith("/api/v1"):
        return True
    return any(path.startswith(p) for p in PREFIXOS_PUBLICOS)


class AuthMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, secret_key: str, algorithm: str = "HS256"):
        super().__init__(app)
        self.secret_key = secret_key
        self.algorithm = algorithm

    async def dispatch(self, request: Request, call_next) -> Response:
        if request.method == "OPTIONS" or _is_publica(request.url.path):
            return await call_next(request)

        token = self._token(request)
        if not token:
            return JSONResponse(status_code=401, content={
                "erro": "nao_autenticado",
                "mensagem": "Token ausente. Faca login.",
            })

        payload = self._validar(token)
        if payload is None:
            return JSONResponse(status_code=401, content={
                "erro": "token_invalido",
                "mensagem": "Token invalido ou expirado. Faca login novamente.",
            })

        request.state.user_id    = payload.get("sub")
        request.state.user_role  = payload.get("role", "cliente")
        request.state.user_email = payload.get("email", "")
        request.state.user_nome  = payload.get("nome", "")
        return await call_next(request)

    def _token(self, request: Request) -> Optional[str]:
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            t = auth[7:].strip()
            return t or None
        return request.cookies.get("access_token") or None

    def _validar(self, token: str) -> Optional[dict]:
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            return payload if payload.get("sub") else None
        except JWTError as e:
            logger.debug(f"[Auth] Token invalido: {e}")
            return None
        except Exception as e:
            logger.warning(f"[Auth] Erro: {e}")
            return None
