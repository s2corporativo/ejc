"""
EJC — Configurações centrais (core/config.py)
Carregadas via variáveis de ambiente / .env
"""
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # --- App ---
    app_name: str = "Ecossistema Jurídico Clovis"
    app_version: str = "1.0.0"
    environment: str = "development"
    secret_key: str = "change_me_in_production"

    # --- Database ---
    database_url: str = "postgresql+asyncpg://ejc_user:ejc_secret@postgres:5432/ejc_db"

    # --- Provedor de LLM: "ollama" (local) ou "groq" (cloud) ---
    llm_provider: str = "ollama"   # trocar para "groq" para usar Groq API

    # --- Ollama (LLM local) ---
    ollama_base_url: str = "http://ollama:11434"
    ollama_model: str = "llama3"
    ollama_timeout: int = 300

    # --- Groq API (cloud, gratuita) ---
    groq_api_key: str = ""
    # Modelos Groq com suporte a PT-BR (Jun/2025):
    #   llama-3.3-70b-versatile   → melhor qualidade, 128k ctx
    #   llama-3.1-8b-instant      → mais rápido, menor custo
    #   mixtral-8x7b-32768        → bom para textos longos
    #   gemma2-9b-it              → boa alternativa
    groq_model: str = "llama-3.3-70b-versatile"
    groq_timeout: int = 120

    # --- Embeddings (sempre local — soberania dos dados) ---
    embedding_model: str = "sentence-transformers/paraphrase-multilingual-mpnet-base-v2"
    embedding_dimension: int = 768
    chunk_size: int = 1000
    chunk_overlap: int = 200
    rag_top_k: int = 8

    # --- Upload ---
    upload_dir: str = "/app/uploads"
    max_upload_mb: int = 50

    class Config:
        env_file = ".env"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    return Settings()
