"""
EJC - Utilitarios SQL seguros (sql_safe.py)
Previne injecao SQL em clausulas WHERE/SET dinamicas.
"""
from __future__ import annotations
import re

# Colunas permitidas por tabela — whitelist explicita
COLUNAS_PERMITIDAS: dict[str, frozenset[str]] = {
    "casos": frozenset([
        "titulo","area_juridica","status","prioridade","cliente_nome","cliente_cpf_cnpj",
        "parte_contraria","numero_processo","tribunal","valor_causa","honorarios_pct",
        "descricao","observacoes","espaco_id","cliente_id","responsavel_id","fase","risco",
        "sigilo","tipo_demanda","data_encerramento","resultado","estrategia_interna","updated_at",
    ]),
    "clientes": frozenset([
        "nome","cpf","rg","data_nascimento","razao_social","cnpj","nome_fantasia",
        "email","telefone","whatsapp","cep","logradouro","numero","complemento",
        "bairro","cidade","estado","origem","area_interesse","tipo_cliente",
        "status","observacoes","sigilo","responsavel_id","updated_at",
    ]),
    "tarefas": frozenset([
        "titulo","descricao","tipo","status","prioridade","atribuido_para",
        "data_vencimento","concluida_em","updated_at",
    ]),
    "propostas": frozenset([
        "titulo","escopo","exclusoes","tipo_honorario","valor_fixo","valor_exito_pct",
        "valor_total","forma_pagamento","condicoes","validade_dias","status",
        "aceito_em","aceito_por","notas_internas","updated_at",
    ]),
    "crm_leads": frozenset([
        "status","notas","proxima_acao","proxima_data","responsavel_id",
        "cliente_id","caso_id","proposta_id","perdido_motivo","converted_at","updated_at",
    ]),
    "leads_escritorio": frozenset([
        "status_lead","notas","responsavel","prioridade","updated_at",
    ]),
    "prazos": frozenset([
        "titulo","descricao","tipo_prazo","data_vencimento","data_intimacao",
        "status","prioridade","responsavel_id","caso_id","updated_at",
    ]),
}

# Operadores e colunas de filtro permitidos nos WHERE dinamicos
_COLUNA_RE = re.compile(r'^[a-z_][a-z0-9_.]{0,50}$')
_OPERADOR_RE = re.compile(r'^(=|!=|<|>|<=|>=|LIKE|ILIKE|IS NULL|IS NOT NULL|IN|NOT IN)$', re.I)


def validar_coluna(coluna: str, tabela: str = "") -> str:
    """Valida que o nome de coluna e seguro. Lanca ValueError se nao for."""
    if not _COLUNA_RE.match(coluna):
        raise ValueError(f"Nome de coluna invalido: {coluna!r}")
    if tabela and tabela in COLUNAS_PERMITIDAS:
        if coluna not in COLUNAS_PERMITIDAS[tabela]:
            raise ValueError(f"Coluna '{coluna}' nao permitida na tabela '{tabela}'")
    return coluna


def construir_set(campos: dict, tabela: str = "") -> tuple[str, dict]:
    """
    Constroi clausula SET segura a partir de um dict de campos validados.
    Retorna (set_sql, params) onde set_sql usa apenas nomes validados.
    """
    if not campos:
        raise ValueError("Nenhum campo para atualizar")
    sets = []
    params: dict = {}
    for campo, valor in campos.items():
        validar_coluna(campo, tabela)
        sets.append(f"{campo}=:{campo}")
        params[campo] = valor
    sets.append("updated_at=NOW()")
    return ", ".join(sets), params


def construir_where(filtros: list[tuple[str, str, str]], tabela: str = "") -> tuple[str, dict]:
    """
    Constroi clausula WHERE segura.
    filtros: lista de (coluna, operador, nome_param)
    Retorna (where_sql, {}) — valores devem ser adicionados pelo chamador.
    """
    if not filtros:
        return "", {}
    partes = []
    for coluna, operador, param in filtros:
        validar_coluna(coluna, tabela)
        if not _OPERADOR_RE.match(operador):
            raise ValueError(f"Operador invalido: {operador!r}")
        partes.append(f"{coluna} {operador} :{param}")
    return "WHERE " + " AND ".join(partes), {}
