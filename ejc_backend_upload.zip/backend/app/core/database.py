"""
EJC - Conexao assincrona com PostgreSQL (core/database.py)
SQLAlchemy 2.x + asyncpg + pgvector
Pool otimizado para queries paralelas (asyncio.gather no dossie).
"""
import os
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase
from app.core.config import get_settings

settings = get_settings()

# Pool configuravel via env — padrao adequado para servidor medio
_pool_size    = int(os.getenv("DB_POOL_SIZE",    "15"))  # conexoes permanentes
_max_overflow = int(os.getenv("DB_MAX_OVERFLOW", "30"))  # conexoes extras em pico
_pool_timeout = int(os.getenv("DB_POOL_TIMEOUT", "30"))  # segundos esperando conexao livre
_pool_recycle = int(os.getenv("DB_POOL_RECYCLE", "1800")) # recicla conexoes a cada 30min

engine = create_async_engine(
    settings.database_url,
    echo=(settings.environment == "development"),
    pool_pre_ping=True,         # testa conexao antes de usar (evita "connection closed")
    pool_size=_pool_size,
    max_overflow=_max_overflow,
    pool_timeout=_pool_timeout,
    pool_recycle=_pool_recycle,
    # Timeout por query — evita queries presas travar o pool
    connect_args={"command_timeout": 30},
)

AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    # autoflush=False melhora performance em endpoints de leitura
    autoflush=False,
)


class Base(DeclarativeBase):
    pass


async def get_db() -> AsyncSession:
    """Dependency para injecao de sessao nos routers FastAPI."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def get_db_readonly() -> AsyncSession:
    """
    Sessao somente-leitura para endpoints de consulta.
    Nao faz commit — mais rapido para GETs.
    Ideal para o dossie e outros endpoints de leitura intensiva.
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
        except Exception:
            raise
        finally:
            await session.close()
