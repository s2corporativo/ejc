"""
EJC — Rate Limiting Middleware (rate_limiter.py)

Protege endpoints públicos contra abuso/bots.
Implementação em duas camadas:
  1. In-memory (dict + asyncio.Lock) — rápido, sem I/O
  2. Fallback Postgres — persiste entre restarts

Limites padrão:
  /api/v1/pedidos/*          → 30 req/min por IP
  /api/v1/pagamento/webhook  → 60 req/min (alto: MP reenvia)
  /api/v1/cliente/*          → 20 req/min por IP
  /api/v1/tributario/simular → 10 req/min por IP (LLM caro)
  outros públicos             → 60 req/min por IP
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from typing import Callable

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

# ── Configuração de limites por prefixo de rota ──────────────────────────
LIMITES: dict[str, tuple[int, int]] = {
    # (max_requests, janela_segundos)
    "/api/v1/pedidos":            (30,  60),
    "/api/v1/pagamento/webhook":  (60,  60),
    "/api/v1/cliente":            (20,  60),
    "/api/v1/tributario/simular": (10,  60),
    "/api/v1/tributario/chat":    (15,  60),
    "/api/v1/trabalhista/gerar":  (10,  60),
    "/api/v1/publico":            (60,  60),
}
LIMITE_PADRAO = (120, 60)  # rotas autenticadas: mais generoso

# IPs que nunca sofrem rate limit (loopback, health checks)
WHITELIST_IPS = {"127.0.0.1", "::1", "172.17.0.1", "172.18.0.1"}

# ── Contadores em memória ─────────────────────────────────────────────────
_contadores: dict[str, list[float]] = defaultdict(list)
_lock = asyncio.Lock()


def _get_limite(path: str) -> tuple[int, int]:
    for prefixo, limite in LIMITES.items():
        if path.startswith(prefixo):
            return limite
    return LIMITE_PADRAO


def _get_ip(request: Request) -> str:
    # X-Forwarded-For (proxy/nginx) → fallback para host direto
    ff = request.headers.get("x-forwarded-for", "")
    if ff:
        return ff.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Middleware que aplica rate limiting em memória por IP.
    Rotas de health, docs e autenticação são excluídas.
    """

    EXCLUIR = {"/health", "/docs", "/openapi.json", "/redoc", "/api/v1/auth/login", "/api/v1/auth/register"}

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        path = request.url.path

        # Rotas excluídas
        if path in self.EXCLUIR or not path.startswith("/api/v1"):
            return await call_next(request)

        ip = _get_ip(request)

        # Whitelist (dev local, health checks internos)
        if ip in WHITELIST_IPS:
            return await call_next(request)

        max_req, janela = _get_limite(path)
        chave = f"{ip}:{path.split('/')[3] if path.count('/') >= 3 else path}"

        agora = time.monotonic()

        async with _lock:
            # Remove timestamps fora da janela
            _contadores[chave] = [t for t in _contadores[chave] if agora - t < janela]

            if len(_contadores[chave]) >= max_req:
                mais_antigo = _contadores[chave][0]
                retry_after = int(janela - (agora - mais_antigo)) + 1
                logger.warning(f"[RateLimit] IP={ip} path={path} bloqueado ({len(_contadores[chave])}/{max_req})")
                return JSONResponse(
                    status_code=429,
                    content={
                        "erro": "Muitas requisições",
                        "detalhe": f"Limite de {max_req} requisições por {janela}s excedido.",
                        "retry_after": retry_after,
                    },
                    headers={
                        "Retry-After": str(retry_after),
                        "X-RateLimit-Limit": str(max_req),
                        "X-RateLimit-Remaining": "0",
                        "X-RateLimit-Reset": str(int(time.time()) + retry_after),
                    },
                )

            _contadores[chave].append(agora)
            restantes = max_req - len(_contadores[chave])

        response = await call_next(request)
        response.headers["X-RateLimit-Limit"] = str(max_req)
        response.headers["X-RateLimit-Remaining"] = str(restantes)
        return response
