"""
EJC — Módulo Gestão de Casos (modules/casos/router.py)

CRUD completo de casos jurídicos:
  - Cadastro com dados do cliente, parte contrária e processo
  - Vinculação com Espaços de trabalho
  - Movimentações (petições, audiências, decisões, recursos)
  - Jurisprudências favoritas por caso
  - Vinculação com prazos e peças geradas
  - Dashboard com métricas por caso
"""
from __future__ import annotations

from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.sql_safe import construir_set, validar_coluna

from app.core.database import get_db
from app.modules.auth.router import verificar_token, exigir_role
from app.modules.auditoria.middleware import auditar

router = APIRouter(prefix="/casos", tags=["Gestão de Casos"])


# ── Schemas ───────────────────────────────────────────────

class CasoCreate(BaseModel):
    titulo: str
    area_juridica: str
    status: str = "ativo"
    prioridade: str = "media"
    cliente_nome: Optional[str] = None
    cliente_cpf_cnpj: Optional[str] = None
    parte_contraria: Optional[str] = None
    numero_processo: Optional[str] = None
    tribunal: Optional[str] = None
    valor_causa: Optional[float] = None
    honorarios_pct: Optional[float] = None
    descricao: Optional[str] = None
    observacoes: Optional[str] = None
    espaco_id: Optional[str] = None

class CasoUpdate(BaseModel):
    titulo: Optional[str] = None
    status: Optional[str] = None
    prioridade: Optional[str] = None
    numero_processo: Optional[str] = None
    tribunal: Optional[str] = None
    valor_causa: Optional[float] = None
    descricao: Optional[str] = None
    observacoes: Optional[str] = None

class MovimentacaoCreate(BaseModel):
    tipo: str
    descricao: str
    data_evento: Optional[str] = None
    documento_id: Optional[str] = None

class JurisprudenciaSalvar(BaseModel):
    tribunal: str
    numero: Optional[str] = None
    classe: Optional[str] = None
    assunto: Optional[str] = None
    ementa: str
    data_decisao: Optional[str] = None
    relator: Optional[str] = None
    link_original: Optional[str] = None
    tags: Optional[list[str]] = None


# ── Endpoints ─────────────────────────────────────────────

@router.post("/", status_code=201)
async def criar_caso(req: CasoCreate, db: AsyncSession = Depends(get_db)):
    """Cria um novo caso jurídico."""
    cid = uuid4()
    await db.execute(
        text("""
            INSERT INTO casos (id, titulo, area_juridica, status, prioridade,
                cliente_nome, cliente_cpf_cnpj, parte_contraria, numero_processo,
                tribunal, valor_causa, honorarios_pct, descricao, observacoes, espaco_id)
            VALUES (:id,:titulo,:area,:status,:prio,:cn,:ccpf,:pc,:np,:tr,:vc,:hp,:desc,:obs,:eid)
        """),
        {
            "id": str(cid), "titulo": req.titulo, "area": req.area_juridica,
            "status": req.status, "prio": req.prioridade,
            "cn": req.cliente_nome, "ccpf": req.cliente_cpf_cnpj,
            "pc": req.parte_contraria, "np": req.numero_processo,
            "tr": req.tribunal, "vc": req.valor_causa, "hp": req.honorarios_pct,
            "desc": req.descricao, "obs": req.observacoes, "eid": req.espaco_id,
        },
    )
    await auditar(db, "CRIAR_CASO", "casos", str(cid), dados_depois=req.model_dump())
    row = await db.execute(text("SELECT * FROM casos WHERE id=:id"), {"id": str(cid)})
    return dict(row.mappings().first())


@router.get("/")
async def listar_casos(
    status: Optional[str] = None,
    area_juridica: Optional[str] = None,
    prioridade: Optional[str] = None,
    busca: Optional[str] = None,
    limit: int = Query(50, le=200),
    db: AsyncSession = Depends(get_db),
):
    """Lista casos com filtros. Suporta busca por cliente, número de processo ou título."""
    filtros = []
    params: dict = {"limit": limit}

    if status:
        filtros.append("c.status = :status"); params["status"] = status
    if area_juridica:
        filtros.append("c.area_juridica = :area"); params["area"] = area_juridica
    if prioridade:
        filtros.append("c.prioridade = :prio"); params["prio"] = prioridade
    if busca:
        filtros.append("""(
            c.titulo ILIKE :busca OR
            c.cliente_nome ILIKE :busca OR
            c.numero_processo ILIKE :busca OR
            c.parte_contraria ILIKE :busca
        )""")
        params["busca"] = f"%{busca}%"

    where = "WHERE " + " AND ".join(filtros) if filtros else ""
    rows = await db.execute(
        text(f"""
            SELECT c.*,
                   COUNT(DISTINCT cm.id) AS total_movimentacoes,
                   COUNT(DISTINCT p.id) AS total_prazos_pendentes,
                   COUNT(DISTINCT js.id) AS total_jurisprudencias
            FROM casos c
            LEFT JOIN caso_movimentacoes cm ON cm.caso_id = c.id
            LEFT JOIN prazos p ON p.espaco_id = c.espaco_id AND p.status='pendente'
            LEFT JOIN jurisprudencias_salvas js ON js.caso_id = c.id
            {where}
            GROUP BY c.id
            ORDER BY c.updated_at DESC
            LIMIT :limit
        """),
        params,
    )
    return {"casos": [dict(r) for r in rows.mappings()]}


@router.get("/dashboard-metricas")
async def dashboard_metricas(db: AsyncSession = Depends(get_db)):
    """
    6 métricas principais para o Dashboard — conforme especificação do documento.
    """
    row = await db.execute(text("""
        SELECT
            COUNT(*) FILTER (WHERE status='ativo') AS casos_ativos,
            COUNT(*) FILTER (WHERE status='prospeccao') AS casos_prospeccao,
            COUNT(*) FILTER (WHERE prioridade='urgente' AND status='ativo') AS casos_urgentes,
            COUNT(*) FILTER (WHERE status='encerrado') AS casos_encerrados,
            SUM(valor_causa) FILTER (WHERE status IN ('ativo','prospeccao')) AS valor_carteira,
            COUNT(DISTINCT cliente_cpf_cnpj) AS total_clientes
        FROM casos
    """))
    metricas_casos = dict(row.mappings().first())

    row2 = await db.execute(text("""
        SELECT
            COUNT(*) FILTER (WHERE status='pendente') AS prazos_pendentes,
            COUNT(*) FILTER (WHERE status='pendente' AND data_vencimento <= CURRENT_DATE + INTERVAL '3 days') AS prazos_criticos
        FROM prazos
    """))
    metricas_prazos = dict(row2.mappings().first())

    row3 = await db.execute(text("SELECT COUNT(*) AS total_pecas FROM legal_documents"))
    row4 = await db.execute(text("SELECT COUNT(*) AS total_docs FROM documents"))

    return {
        "metricas": {
            "casos_ativos":       metricas_casos.get("casos_ativos", 0),
            "casos_urgentes":     metricas_casos.get("casos_urgentes", 0),
            "valor_carteira":     str(metricas_casos.get("valor_carteira") or "0"),
            "total_clientes":     metricas_casos.get("total_clientes", 0),
            "prazos_criticos":    metricas_prazos.get("prazos_criticos", 0),
            "pecas_geradas":      dict(row3.mappings().first()).get("total_pecas", 0),
        },
        "detalhes": {**metricas_casos, **metricas_prazos},
    }


@router.get("/{caso_id}")
async def buscar_caso(caso_id: str, db: AsyncSession = Depends(get_db)):
    row = await db.execute(text("SELECT * FROM casos WHERE id=:id"), {"id": caso_id})
    c = row.mappings().first()
    if not c:
        raise HTTPException(404, "Caso não encontrado.")
    return dict(c)


@router.put("/{caso_id}")
async def atualizar_caso(
    caso_id: str, req: CasoUpdate,
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio","advogado","assistente"])
    updates = {k: v for k, v in req.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(422, "Nenhum campo para atualizar.")
    set_sql = ", ".join(f"{k}=:{k}" for k in updates)
    updates["id"] = caso_id
    await db.execute(text(f"UPDATE casos SET {set_sql}, updated_at=NOW() WHERE id=:id"), updates)
    await auditar(db, "ATUALIZAR_CASO", "casos", caso_id, dados_depois=updates)
    return {"message": "Caso atualizado."}


@router.delete("/{caso_id}")
async def arquivar_caso(caso_id: str, usuario=Depends(verificar_token), db: AsyncSession = Depends(get_db)):
    exigir_role(usuario, ["admin","socio","advogado"])
    await db.execute(
        text("UPDATE casos SET status='arquivado', updated_at=NOW() WHERE id=:id"),
        {"id": caso_id},
    )
    await auditar(db, "ARQUIVAR_CASO", "casos", caso_id)
    return {"message": "Caso arquivado."}


# ── Movimentações ─────────────────────────────────────────

@router.post("/{caso_id}/movimentacoes", status_code=201)
async def adicionar_movimentacao(
    caso_id: str, req: MovimentacaoCreate, db: AsyncSession = Depends(get_db)
):
    mid = uuid4()
    await db.execute(
        text("""
            INSERT INTO caso_movimentacoes (id, caso_id, tipo, descricao, data_evento, documento_id)
            VALUES (:id,:caso,:tipo,:desc,:de,:did)
        """),
        {"id": str(mid), "caso": caso_id, "tipo": req.tipo,
         "desc": req.descricao, "de": req.data_evento, "did": req.documento_id},
    )
    return {"id": str(mid), "message": "Movimentação registrada."}


@router.get("/{caso_id}/movimentacoes")
async def listar_movimentacoes(caso_id: str, db: AsyncSession = Depends(get_db)):
    rows = await db.execute(
        text("""
            SELECT cm.*, ld.title AS documento_titulo
            FROM caso_movimentacoes cm
            LEFT JOIN legal_documents ld ON ld.id = cm.documento_id
            WHERE cm.caso_id = :id
            ORDER BY cm.created_at DESC
        """),
        {"id": caso_id},
    )
    return {"movimentacoes": [dict(r) for r in rows.mappings()]}


# ── Jurisprudências Favoritas ──────────────────────────────

@router.post("/{caso_id}/jurisprudencias", status_code=201)
async def salvar_jurisprudencia(
    caso_id: str, req: JurisprudenciaSalvar, db: AsyncSession = Depends(get_db)
):
    """Salva uma jurisprudência como favorita vinculada ao caso."""
    jid = uuid4()
    await db.execute(
        text("""
            INSERT INTO jurisprudencias_salvas
                (id, caso_id, tribunal, numero, classe, assunto, ementa,
                 data_decisao, relator, link_original, tags)
            VALUES (:id,:cid,:tr,:num,:cl,:ass,:em,:dd,:rel,:link,:tags)
        """),
        {
            "id": str(jid), "cid": caso_id, "tr": req.tribunal,
            "num": req.numero, "cl": req.classe, "ass": req.assunto,
            "em": req.ementa, "dd": req.data_decisao, "rel": req.relator,
            "link": req.link_original, "tags": req.tags,
        },
    )
    return {"id": str(jid), "message": "Jurisprudência salva como favorita."}


@router.get("/{caso_id}/jurisprudencias")
async def jurisprudencias_do_caso(caso_id: str, db: AsyncSession = Depends(get_db)):
    rows = await db.execute(
        text("""
            SELECT * FROM jurisprudencias_salvas
            WHERE caso_id=:id ORDER BY created_at DESC
        """),
        {"id": caso_id},
    )
    return {"jurisprudencias": [dict(r) for r in rows.mappings()]}
