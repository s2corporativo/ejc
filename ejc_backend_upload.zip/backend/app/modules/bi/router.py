"""
EJC — Módulo BI (modules/bi/router.py)

Dashboard executivo com métricas consolidadas do escritório:
  - Taxa de êxito por área, advogado e tribunal
  - Receita × despesa com projeção 6 meses
  - Volume de peças por tipo e período
  - Clientes mais rentáveis e inadimplentes
  - Prazos críticos e vencidos
  - Atividade recente consolidada
  - Funil de casos (prospecção → ativo → encerrado)
"""
from __future__ import annotations

import logging
from datetime import date, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/bi", tags=["BI — Dashboard Executivo"])


@router.get("/resumo-executivo")
async def resumo_executivo(db: AsyncSession = Depends(get_db)):
    """
    Painel executivo completo para o sócio-administrador.
    Agrega dados de todos os módulos numa única chamada.
    """
    hoje = date.today()
    inicio_mes = hoje.replace(day=1)
    inicio_ano = hoje.replace(month=1, day=1)

    # ── Casos ──────────────────────────────────────────────────────
    r_casos = await db.execute(text("""
        SELECT
            COUNT(*) FILTER (WHERE status='ativo')       AS ativos,
            COUNT(*) FILTER (WHERE status='prospeccao')  AS prospeccao,
            COUNT(*) FILTER (WHERE status='encerrado')   AS encerrados,
            COUNT(*) FILTER (WHERE prioridade='urgente' AND status='ativo') AS urgentes,
            COUNT(DISTINCT cliente_cpf_cnpj)             AS clientes_distintos,
            COALESCE(SUM(valor_causa) FILTER (WHERE status IN ('ativo','prospeccao')), 0)
                                                          AS valor_carteira,
            COUNT(*) FILTER (WHERE created_at >= :inicio_mes) AS novos_no_mes
        FROM casos
    """), {"inicio_mes": str(inicio_mes)})
    casos = dict(r_casos.mappings().first() or {})

    # ── Prazos ──────────────────────────────────────────────────────
    r_prazos = await db.execute(text("""
        SELECT
            COUNT(*) FILTER (WHERE status='pendente')   AS pendentes,
            COUNT(*) FILTER (WHERE status='pendente'
                AND data_vencimento < CURRENT_DATE)     AS vencidos,
            COUNT(*) FILTER (WHERE status='pendente'
                AND data_vencimento <= CURRENT_DATE + INTERVAL '2 days') AS criticos,
            COUNT(*) FILTER (WHERE status='cumprido'
                AND created_at >= :inicio_mes)          AS cumpridos_mes
        FROM prazos
    """), {"inicio_mes": str(inicio_mes)})
    prazos = dict(r_prazos.mappings().first() or {})

    # ── Peças geradas ────────────────────────────────────────────────
    r_pecas = await db.execute(text("""
        SELECT
            COUNT(*)                                    AS total,
            COUNT(*) FILTER (WHERE status='final')      AS finalizadas,
            COUNT(*) FILTER (WHERE created_at >= :inicio_mes) AS no_mes,
            COUNT(*) FILTER (WHERE created_at >= :inicio_ano) AS no_ano
        FROM legal_documents
    """), {"inicio_mes": str(inicio_mes), "inicio_ano": str(inicio_ano)})
    pecas = dict(r_pecas.mappings().first() or {})

    # ── Financeiro ───────────────────────────────────────────────────
    r_fin = await db.execute(text("""
        SELECT
            COALESCE(SUM(ph.valor_pago) FILTER (
                WHERE ph.data_pagamento >= :inicio_mes), 0)  AS receita_mes,
            COALESCE(SUM(ph.valor_pago) FILTER (
                WHERE ph.data_pagamento >= :inicio_ano), 0)  AS receita_ano,
            COALESCE(SUM(parc.valor) FILTER (
                WHERE parc.status='pendente'
                AND parc.data_vencimento < CURRENT_DATE), 0) AS inadimplencia
        FROM pagamentos_honorarios ph
        FULL OUTER JOIN parcelas_honorarios parc ON TRUE
    """), {"inicio_mes": str(inicio_mes), "inicio_ano": str(inicio_ano)})
    fin = dict(r_fin.mappings().first() or {})

    # ── RAG ─────────────────────────────────────────────────────────
    r_rag = await db.execute(text("""
        SELECT COUNT(*) AS total_docs, COUNT(DISTINCT category) AS categorias
        FROM documents
    """))
    rag = dict(r_rag.mappings().first() or {})

    # ── Monitor ─────────────────────────────────────────────────────
    r_mon = await db.execute(text("""
        SELECT COUNT(*) FILTER (WHERE lida=false) AS nao_lidas
        FROM monitor_publicacoes
        WHERE created_at >= NOW() - INTERVAL '7 days'
    """))
    mon = dict(r_mon.mappings().first() or {})

    brl = lambda v: f"R$ {float(v or 0):,.2f}".replace(",","X").replace(".",",").replace("X",".")

    return {
        "periodo": {
            "hoje": str(hoje),
            "inicio_mes": str(inicio_mes),
            "inicio_ano": str(inicio_ano),
        },
        "casos": {
            **casos,
            "valor_carteira_fmt": brl(casos.get("valor_carteira", 0)),
        },
        "prazos": prazos,
        "pecas": pecas,
        "financeiro": {
            **fin,
            "receita_mes_fmt": brl(fin.get("receita_mes", 0)),
            "receita_ano_fmt": brl(fin.get("receita_ano", 0)),
            "inadimplencia_fmt": brl(fin.get("inadimplencia", 0)),
        },
        "base_conhecimento": rag,
        "monitor": mon,
        "alertas": _gerar_alertas(casos, prazos, fin),
    }


def _gerar_alertas(casos: dict, prazos: dict, fin: dict) -> list[dict]:
    alertas = []
    if int(prazos.get("vencidos") or 0) > 0:
        alertas.append({"nivel": "critico", "modulo": "prazos",
                        "msg": f"{prazos['vencidos']} prazo(s) VENCIDO(S) — ação imediata"})
    if int(prazos.get("criticos") or 0) > 0:
        alertas.append({"nivel": "alto", "modulo": "prazos",
                        "msg": f"{prazos['criticos']} prazo(s) vencendo em até 2 dias"})
    if float(fin.get("inadimplencia") or 0) > 0:
        brl = lambda v: f"R$ {float(v):,.2f}".replace(",","X").replace(".",",").replace("X",".")
        alertas.append({"nivel": "medio", "modulo": "financeiro",
                        "msg": f"Inadimplência: {brl(fin['inadimplencia'])}"})
    if int(casos.get("urgentes") or 0) > 0:
        alertas.append({"nivel": "alto", "modulo": "casos",
                        "msg": f"{casos['urgentes']} caso(s) com prioridade urgente"})
    return alertas


@router.get("/casos-por-area")
async def casos_por_area(db: AsyncSession = Depends(get_db)):
    """Distribuição de casos por área do direito — para gráfico de pizza/barras."""
    rows = await db.execute(text("""
        SELECT area_juridica,
               COUNT(*) AS total,
               COUNT(*) FILTER (WHERE status='ativo') AS ativos,
               COUNT(*) FILTER (WHERE status='encerrado') AS encerrados,
               COALESCE(SUM(valor_causa), 0) AS valor_total
        FROM casos
        GROUP BY area_juridica
        ORDER BY total DESC
    """))
    return {"por_area": [dict(r) for r in rows.mappings()]}


@router.get("/evolucao-mensal")
async def evolucao_mensal(
    meses: int = Query(12, ge=3, le=24),
    db: AsyncSession = Depends(get_db),
):
    """
    Série temporal dos últimos N meses:
    Novos casos, peças geradas, receita e prazos cumpridos.
    Dados para gráfico de linha no Dashboard.
    """
    rows_casos = await db.execute(text("""
        SELECT
            DATE_TRUNC('month', created_at) AS mes,
            COUNT(*) AS novos_casos
        FROM casos
        WHERE created_at >= NOW() - INTERVAL ':meses months'
        GROUP BY mes ORDER BY mes ASC
    """.replace(":meses", str(meses))))

    rows_pecas = await db.execute(text("""
        SELECT
            DATE_TRUNC('month', created_at) AS mes,
            COUNT(*) AS pecas_geradas
        FROM legal_documents
        WHERE created_at >= NOW() - INTERVAL ':meses months'
        GROUP BY mes ORDER BY mes ASC
    """.replace(":meses", str(meses))))

    rows_receita = await db.execute(text("""
        SELECT
            DATE_TRUNC('month', data_pagamento::date) AS mes,
            COALESCE(SUM(valor_pago), 0) AS receita
        FROM pagamentos_honorarios
        WHERE data_pagamento::date >= NOW() - INTERVAL ':meses months'
        GROUP BY mes ORDER BY mes ASC
    """.replace(":meses", str(meses))))

    def fmt(rows):
        return [{"mes": str(r["mes"])[:7], **{k: v for k, v in r.items() if k != "mes"}}
                for r in rows.mappings()]

    return {
        "meses_consultados": meses,
        "casos":   fmt(rows_casos),
        "pecas":   fmt(rows_pecas),
        "receita": fmt(rows_receita),
    }


@router.get("/top-clientes")
async def top_clientes(
    limit: int = Query(10, ge=1, le=50),
    db: AsyncSession = Depends(get_db),
):
    """Clientes mais rentáveis (maior valor de causa ativo)."""
    rows = await db.execute(text("""
        SELECT
            cliente_nome,
            cliente_cpf_cnpj,
            COUNT(*) AS total_casos,
            COUNT(*) FILTER (WHERE status='ativo') AS casos_ativos,
            COALESCE(SUM(valor_causa), 0) AS valor_total_causa
        FROM casos
        WHERE cliente_nome IS NOT NULL
        GROUP BY cliente_nome, cliente_cpf_cnpj
        ORDER BY valor_total_causa DESC
        LIMIT :limit
    """), {"limit": limit})
    return {"top_clientes": [dict(r) for r in rows.mappings()]}


@router.get("/funil-casos")
async def funil_casos(db: AsyncSession = Depends(get_db)):
    """Funil de conversão: prospecção → ativo → encerrado."""
    rows = await db.execute(text("""
        SELECT status, COUNT(*) AS total,
               COALESCE(SUM(valor_causa), 0) AS valor_total
        FROM casos
        GROUP BY status
        ORDER BY
            CASE status
                WHEN 'prospeccao' THEN 1
                WHEN 'ativo'      THEN 2
                WHEN 'aguardando' THEN 3
                WHEN 'encerrado'  THEN 4
                ELSE 5
            END
    """))
    return {"funil": [dict(r) for r in rows.mappings()]}


@router.get("/atividade-recente")
async def atividade_recente(
    limit: int = Query(20, ge=5, le=50),
    db: AsyncSession = Depends(get_db),
):
    """Feed de atividade recente consolidado de todos os módulos."""
    rows = await db.execute(text("""
        SELECT acao AS tipo, recurso, created_at,
               'auditoria' AS fonte
        FROM audit_log
        ORDER BY created_at DESC
        LIMIT :limit
    """), {"limit": limit})
    return {"atividades": [dict(r) for r in rows.mappings()]}
