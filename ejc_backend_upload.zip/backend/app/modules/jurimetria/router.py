"""
EJC — Módulo Jurimetria (modules/jurimetria/service.py + router.py)

Análise preditiva e jurimetria:
  - Probabilidade de êxito por tipo de ação/tribunal
  - Tempo médio de tramitação
  - Valor médio de condenação
  - Precedentes relevantes recuperados via RAG
  - Estratégia baseada em padrões de decisão
"""
from __future__ import annotations

import logging
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.redacao.service import LegalDraftService
from app.modules.rag.knowledge_base import LegalKnowledgeBase

logger = logging.getLogger(__name__)

# Base de dados estatísticos locais (simplificada)
# Em produção: alimentar com dados reais do DataJud + jurimetria histórica
DADOS_JURIMETRIA: dict[str, dict] = {
    "rescisao_indireta": {
        "probabilidade_base": 0.72,
        "tempo_medio_dias": 420,
        "valor_medio": "R$ 28.000,00",
        "fatores_positivos": [
            "Não recolhimento comprovado do FGTS por 3+ meses",
            "Redução salarial unilateral documentada",
            "Assédio moral com testemunhas",
            "Registro de reclamação anterior em sindicato",
        ],
        "fatores_negativos": [
            "Longa tolerância do empregado sem reclamar",
            "Assinatura de acordo extrajudicial",
            "Ausência de provas documentais",
        ],
        "tribunal_referencia": "TRT",
    },
    "dano_moral_trabalhista": {
        "probabilidade_base": 0.58,
        "tempo_medio_dias": 380,
        "valor_medio": "R$ 12.000,00",
        "fatores_positivos": [
            "Testemunhas qualificadas",
            "Laudos psicológicos",
            "Comunicações por escrito do assédio",
        ],
        "fatores_negativos": [
            "Ausência de prova documental",
            "Prazo de prescrição próximo",
        ],
        "tribunal_referencia": "TRT",
    },
    "indenizacao_consumidor": {
        "probabilidade_base": 0.65,
        "tempo_medio_dias": 180,
        "valor_medio": "R$ 5.000,00",
        "fatores_positivos": [
            "Protocolo de reclamação (Procon/SAC)",
            "Nota fiscal e comprovante de pagamento",
            "Laudo técnico do defeito",
        ],
        "fatores_negativos": [
            "Uso inadequado do produto",
            "Modificação não autorizada",
        ],
        "tribunal_referencia": "TJSP",
    },
    "fgts_revisional": {
        "probabilidade_base": 0.88,
        "tempo_medio_dias": 280,
        "valor_medio": "depende do período",
        "fatores_positivos": [
            "Extrato FGTS com diferenças comprovadas",
            "Cálculo técnico fundamentado",
            "Período documentado",
        ],
        "fatores_negativos": [
            "Prescrição parcial (5 anos)",
            "Acordos anteriores",
        ],
        "tribunal_referencia": "TRT",
    },
}


class JuriRequest(BaseModel):
    tipo_acao: str
    fatos: str
    tribunal: Optional[str] = None
    valor_pretendido: Optional[str] = None


router = APIRouter(prefix="/jurimetria", tags=["Jurimetria — Análise Preditiva"])

_kb: Optional[LegalKnowledgeBase] = None
_llm: Optional[LegalDraftService] = None


def get_kb() -> LegalKnowledgeBase:
    global _kb
    if not _kb:
        _kb = LegalKnowledgeBase()
    return _kb


def get_llm() -> LegalDraftService:
    global _llm
    if not _llm:
        _llm = LegalDraftService()
    return _llm


@router.post("/analisar")
async def analisar_chances(
    req: JuriRequest,
    db: AsyncSession = Depends(get_db),
    kb: LegalKnowledgeBase = Depends(get_kb),
    llm: LegalDraftService = Depends(get_llm),
):
    """
    Analisa as chances de êxito de uma ação com base em:
    - Dados jurimetrícos locais por tipo de ação
    - Precedentes recuperados via RAG
    - Análise dos fatos pelo LLM
    """
    # 1. Dados base do tipo de ação
    dados = DADOS_JURIMETRIA.get(req.tipo_acao, {
        "probabilidade_base": 0.50,
        "tempo_medio_dias": 365,
        "valor_medio": "a calcular",
        "fatores_positivos": [],
        "fatores_negativos": [],
        "tribunal_referencia": req.tribunal or "TJ",
    })

    # 2. Recupera precedentes via RAG
    precedentes = await kb.semantic_search(
        db=db,
        query=f"{req.tipo_acao} {req.fatos[:300]}",
        top_k=5,
        category="jurisprudencia",
    )

    # 3. Análise do LLM sobre os fatos específicos
    contexto_precedentes = "\n\n".join(p["content"][:500] for p in precedentes)
    analise_prompt = f"""Analise as chances de êxito da ação de '{req.tipo_acao}' com
base nos fatos e precedentes abaixo.

FATOS:
{req.fatos[:2000]}

PRECEDENTES RECUPERADOS:
{contexto_precedentes if contexto_precedentes else 'Nenhum precedente na base ainda.'}

Responda APENAS em JSON com este formato exato:
{{
  "ajuste_probabilidade": 0.05,
  "comentario": "...",
  "fatores_especificos_positivos": ["..."],
  "fatores_especificos_negativos": ["..."],
  "recomendacao": "AJUIZAR | NEGOCIAR | AGUARDAR | NÃO AJUIZAR",
  "justificativa_recomendacao": "..."
}}"""

    try:
        analise_json_str = await llm.answer_from_context(
            query="análise jurimetria", context=req.fatos
        )
        # O LLM retornará texto — fazemos parse melhor possível
        import re, json
        match = re.search(r"\{.*\}", analise_json_str, re.DOTALL)
        if match:
            analise = json.loads(match.group(0))
        else:
            analise = {"ajuste_probabilidade": 0.0, "comentario": analise_json_str[:500],
                       "recomendacao": "ANALISAR COM ADVOGADO"}
    except Exception:
        analise = {"ajuste_probabilidade": 0.0, "comentario": "Análise indisponível.",
                   "recomendacao": "ANALISAR COM ADVOGADO"}

    prob_final = min(0.98, max(0.02,
        dados["probabilidade_base"] + analise.get("ajuste_probabilidade", 0.0)
    ))

    resultado = {
        "tipo_acao": req.tipo_acao,
        "tribunal": req.tribunal or dados["tribunal_referencia"],
        "probabilidade_exito": round(prob_final * 100, 1),
        "classificacao": (
            "ALTA" if prob_final >= 0.70 else
            "MÉDIA" if prob_final >= 0.45 else "BAIXA"
        ),
        "tempo_medio_dias": dados["tempo_medio_dias"],
        "valor_medio_condenacao": dados["valor_medio"],
        "fatores_positivos": dados["fatores_positivos"] + analise.get("fatores_especificos_positivos", []),
        "fatores_negativos": dados["fatores_negativos"] + analise.get("fatores_especificos_negativos", []),
        "recomendacao": analise.get("recomendacao", "ANALISAR COM ADVOGADO"),
        "justificativa": analise.get("justificativa_recomendacao", ""),
        "comentario_ia": analise.get("comentario", ""),
        "precedentes_encontrados": len(precedentes),
        "precedentes": [
            {"filename": p["filename"], "similarity": p["similarity"], "trecho": p["content"][:200]}
            for p in precedentes[:3]
        ],
        "aviso": "Análise baseada em dados estatísticos e RAG. Consulte sempre um advogado para decisão final.",
    }

    # Persiste
    await db.execute(
        text("""
            INSERT INTO analises_jurimetria
                (id, tipo_acao, tribunal, probabilidade_sucesso, tempo_medio_dias,
                 valor_medio_condenacao, fatores_positivos, fatores_negativos,
                 precedentes, metodologia)
            VALUES (:id,:ta,:tr,:prob,:tm,:vm,:fp::jsonb,:fn::jsonb,:prec::jsonb,:met)
        """),
        {
            "id": str(uuid4()), "ta": req.tipo_acao,
            "tr": req.tribunal or dados["tribunal_referencia"],
            "prob": prob_final, "tm": dados["tempo_medio_dias"],
            "vm": dados["valor_medio"],
            "fp": str(resultado["fatores_positivos"]),
            "fn": str(resultado["fatores_negativos"]),
            "prec": str(resultado["precedentes"]),
            "met": f"Base estatística EJC + RAG ({len(precedentes)} precedentes)",
        },
    )

    return resultado


@router.get("/tipos")
async def listar_tipos():
    """Lista os tipos de ação com dados jurimetrícos disponíveis."""
    return {
        "tipos": [
            {"id": k, "probabilidade_base": f"{v['probabilidade_base']*100:.0f}%",
             "tempo_medio": f"{v['tempo_medio_dias']} dias",
             "tribunal": v["tribunal_referencia"]}
            for k, v in DADOS_JURIMETRIA.items()
        ]
    }
