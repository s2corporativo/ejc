"""
EJC — Pesquisa Jurisprudencial (router.py v2)
Usa o JurisprudenciaEngine v2: 8 fontes, BM25, Temas STJ/STF.
"""
from __future__ import annotations
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query, Header
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.modules.pesquisa.jurisprudencia_engine import get_engine

import os, logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/pesquisa", tags=["Pesquisa Jurisprudencial"])
ADMIN_KEY = os.getenv("ADMIN_API_KEY", "ejc_admin_dev_key")


@router.get("/")
async def buscar(
    q:             str            = Query(..., min_length=3, description="Termos de busca"),
    tribunal:      Optional[str]  = Query(None, description="STJ, TRT2, TJSP..."),
    area:          Optional[str]  = Query(None, description="trabalhista, consumidor, civel..."),
    top_k:         int            = Query(10, ge=1, le=30),
    incluir_temas: bool           = Query(True, description="Incluir Temas STJ/STF vinculantes"),
    sem_cache:     bool           = Query(False, description="Forçar busca nova (ignora cache)"),
    db:            AsyncSession   = Depends(get_db),
):
    """
    Busca jurisprudencial completa em 8 fontes.
    Retorna acórdãos, súmulas e temas precedentes ordenados por BM25 + hierarquia.
    """
    engine = get_engine()
    return await engine.buscar(
        query=q, db=db, tribunal=tribunal, area=area,
        top_k=top_k, usar_cache=not sem_cache,
        incluir_temas=incluir_temas,
    )


@router.get("/peticao")
async def buscar_para_peticao(
    area:    str = Query(..., description="Área jurídica"),
    fatos:   str = Query(..., min_length=10, description="Resumo dos fatos"),
    pedidos: str = Query(..., min_length=5,  description="Pedidos principais"),
    db: AsyncSession = Depends(get_db),
):
    """
    Retorna bloco de contexto jurisprudencial formatado para uso em petição.
    Formato pronto para injetar no prompt do LLM.
    """
    engine = get_engine()
    bloco = await engine.buscar_para_peticao(
        area=area, fatos=fatos, pedidos=pedidos, db=db
    )
    return {"bloco_contexto": bloco, "area": area}


class ValidarCitacaoReq(BaseModel):
    tribunal: str
    numero: str
    ementa_esperada: str = ""

@router.post("/validar-citacao")
async def validar_citacao(req: ValidarCitacaoReq, db: AsyncSession = Depends(get_db)):
    """
    Verifica se uma citação jurisprudencial é real.
    Usado para checar se o LLM inventou precedentes.
    """
    engine = get_engine()
    return await engine.validar_citacao(
        tribunal=req.tribunal, numero=req.numero,
        ementa_esperada=req.ementa_esperada, db=db
    )


@router.get("/temas")
async def buscar_temas(
    q:    str           = Query(..., min_length=3),
    casa: Optional[str] = Query(None, description="STJ | STF"),
    db:   AsyncSession  = Depends(get_db),
):
    """
    Busca especificamente em Temas STJ (repetitivos) e STF (repercussão geral).
    São os precedentes mais relevantes para o JEC — vinculam todos os juízes.
    """
    engine = get_engine()
    result = await engine.buscar(
        query=q, db=db,
        tribunal=casa,
        top_k=10,
        incluir_temas=True,
        fontes=["temas","local"],
    )
    # Filtra só temas e súmulas
    result["resultados"] = [r for r in result["resultados"]
                            if r.get("tipo") in ("tema","sumula") or r.get("vinculante")]
    return result


@router.get("/historico")
async def historico(
    limit: int = Query(50, le=200),
    db: AsyncSession = Depends(get_db),
    x_admin_key: str = Header(None),
):
    """Histórico de buscas (admin)."""
    if x_admin_key != ADMIN_KEY:
        raise HTTPException(403, "Acesso negado")
    rows = await db.execute(text("""
        SELECT query, tribunal, area_juridica, total_resultados, tempo_ms, fontes_usadas, created_at
        FROM jurisprudencia_historico ORDER BY created_at DESC LIMIT :lim
    """), {"lim": limit})
    return {"historico": [dict(r) for r in rows.mappings()]}


@router.get("/favoritas")
async def listar_favoritas(
    tribunal: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    filtros = []; params: dict = {}
    if tribunal: filtros.append("tribunal=:tr"); params["tr"] = tribunal
    where = "WHERE " + " AND ".join(filtros) if filtros else ""
    rows = await db.execute(
        text(f"SELECT * FROM jurisprudencias_salvas {where} ORDER BY created_at DESC LIMIT 100"),
        params)
    return {"favoritas": [dict(r) for r in rows.mappings()]}


class SalvarFavoritaReq(BaseModel):
    tribunal: str; ementa: str
    numero: Optional[str] = None; assunto: Optional[str] = None
    data_decisao: Optional[str] = None; relator: Optional[str] = None
    link_original: Optional[str] = None; tags: Optional[list[str]] = None
    caso_id: Optional[str] = None

@router.post("/favoritas", status_code=201)
async def salvar_favorita(req: SalvarFavoritaReq, db: AsyncSession = Depends(get_db)):
    from uuid import uuid4
    jid = str(uuid4())
    await db.execute(text("""
        INSERT INTO jurisprudencias_salvas
            (id,tribunal,numero,assunto,ementa,data_decisao,relator,link_original,tags,caso_id)
        VALUES (:id,:tr,:num,:ass,:em,:dd,:rel,:link,:tags,:cid)
    """), {"id":jid,"tr":req.tribunal,"num":req.numero,"ass":req.assunto,
           "em":req.ementa,"dd":req.data_decisao,"rel":req.relator,
           "link":req.link_original,"tags":req.tags,"cid":req.caso_id})
    await db.commit()
    return {"id": jid, "mensagem": "Salvo como favorito"}

@router.delete("/favoritas/{jid}")
async def remover_favorita(jid: str, db: AsyncSession = Depends(get_db)):
    await db.execute(text("DELETE FROM jurisprudencias_salvas WHERE id=:id"), {"id": jid})
    await db.commit()
    return {"mensagem": "Removido"}
