"""
EJC — Motor de Jurisprudência v2 (jurisprudencia_engine.py)

FONTES (8 + corpus local):
  1. DataJud CNJ   — 25 tribunais (API pública com chave)
  2. STJ Acórdãos  — SCON endpoint público
  3. STJ Temas     — recursos repetitivos (vinculantes)
  4. STF Acórdãos  — API + HTML fallback
  5. STF Temas RG  — repercussão geral (vinculantes)
  6. TST           — API pública + Súmulas/OJs
  7. TJSP          — eSAJ (maior tribunal estadual)
  8. Outros TJs    — via DataJud
  9. Corpus local  — pgvector RAG + 330 súmulas seed

NOVIDADES v2:
  - Temas STJ/STF (precedentes vinculantes para o JEC)
  - Ranking BM25 + boosting por hierarquia jurídica
  - Expansão de query com sinônimos jurídicos por área
  - Deduplicação por número de processo e ementa
  - Cache com TTL diferenciado (sumulas 48h, acórdãos 6h)
  - Integração direta com gerador_peticao.py
  - Validação de citações geradas pelo LLM
"""
from __future__ import annotations
import asyncio, hashlib, json, logging, math, re, time
from dataclasses import dataclass, field
from typing import Optional
import httpx
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)

DATAJUD_KEY  = "cDZHYzlZa0JadVREZDJCendFbXNpTTk="
DATAJUD_BASE = "https://api-publica.datajud.cnj.jus.br"

DATAJUD_INDICES = {
    "STJ":"api_publica_stj","STF":"api_publica_stf","TST":"api_publica_tst",
    "TRF1":"api_publica_trf1","TRF2":"api_publica_trf2","TRF3":"api_publica_trf3",
    "TRF4":"api_publica_trf4","TRF5":"api_publica_trf5","TRF6":"api_publica_trf6",
    "TJSP":"api_publica_tjsp","TJRJ":"api_publica_tjrj","TJMG":"api_publica_tjmg",
    "TJRS":"api_publica_tjrs","TJPR":"api_publica_tjpr","TJSC":"api_publica_tjsc",
    "TJBA":"api_publica_tjba","TJCE":"api_publica_tjce","TJGO":"api_publica_tjgo",
    "TJPE":"api_publica_tjpe","TJDFT":"api_publica_tjdft",
    "TRT1":"api_publica_trt1","TRT2":"api_publica_trt2","TRT3":"api_publica_trt3",
    "TRT4":"api_publica_trt4","TRT15":"api_publica_trt15",
}

AREA_TRIBUNAIS = {
    "trabalhista":    ["TST","TRT2","TRT1","TRT15","TRT3","TRT4"],
    "consumidor":     ["STJ","TJSP","TJRJ","TJMG","TJRS"],
    "civel":          ["STJ","STF","TJSP","TJRJ","TJMG"],
    "previdenciario": ["STJ","TRF4","TRF3","TRF1","TRF2"],
    "tributario":     ["STJ","STF","TRF1","TRF3","TJSP"],
    "penal":          ["STJ","STF","TJSP","TJRJ"],
    "familia":        ["STJ","TJSP","TJRJ","TJMG","TJRS"],
    "constitucional": ["STF","STJ"],
    "bancario":       ["STJ","TJSP","TJRJ"],
}

SINONIMOS_AREA: dict[str, list[str]] = {
    "consumidor":     ["CDC cobrança indevida vício produto dano moral negativação"],
    "trabalhista":    ["CLT rescisão horas extras FGTS verbas rescisórias justa causa"],
    "previdenciario": ["INSS benefício aposentadoria auxílio-doença BPC LOAS"],
    "tributario":     ["tributo imposto ICMS ISS crédito tributário parcelamento"],
    "familia":        ["alimentos guarda divórcio partilha pensão alimentícia"],
    "bancario":       ["juros abusivos revisão contratual capitalização contrato bancário"],
    "civel":          ["responsabilidade civil dano moral indenização contrato"],
}

STOPWORDS_JUR = {
    "a","o","e","de","do","da","em","para","por","com","que","se","ao","os","as",
    "dos","das","no","na","nos","nas","um","uma","uns","umas","ou","mas","mais",
    "este","esta","esse","essa","isso","sendo","tendo","poder","pode","deve",
    "caso","fato","forma","vez","tipo","modo","sua","seu","seus","suas",
    "tribunal","juiz","processo","ação","parte","autor","réu","pedido","recurso",
}


@dataclass
class Jurisprudencia:
    tribunal:        str
    tipo:            str
    numero:          Optional[str] = None
    numero_tema:     Optional[str] = None
    relator:         Optional[str] = None
    data_julgamento: Optional[str] = None
    ementa:          str = ""
    tese:            Optional[str] = None
    link:            Optional[str] = None
    fonte:           str = ""
    relevancia:      float = 0.0
    area:            Optional[str] = None
    vinculante:      bool = False

    def to_dict(self) -> dict:
        return {k: v for k, v in {
            "tribunal": self.tribunal, "tipo": self.tipo,
            "numero": self.numero, "numero_tema": self.numero_tema,
            "relator": self.relator, "data_julgamento": self.data_julgamento,
            "ementa": self.ementa[:900], "tese": self.tese,
            "link": self.link, "fonte": self.fonte,
            "relevancia": round(self.relevancia, 3),
            "area": self.area, "vinculante": self.vinculante,
        }.items() if v is not None}

    def para_citacao(self) -> str:
        if self.tipo == "tema" and self.numero_tema:
            trib = "STJ" if "STJ" in self.tribunal else "STF"
            return f"Tese do Tema {self.numero_tema}/{trib}: {(self.tese or self.ementa)[:280]}"
        if self.tipo == "sumula":
            return f"Súmula {self.numero} do {self.tribunal}: {self.ementa[:280]}"
        partes = [self.tribunal]
        if self.numero:
            pref = "REsp" if "STJ" in self.tribunal else "RE" if "STF" in self.tribunal else "RR" if "TST" in self.tribunal else ""
            partes.append(f"{pref} {self.numero}".strip())
        if self.data_julgamento:
            partes.append(f"j. {self.data_julgamento}")
        return f"{self.ementa[:280].rstrip('.')}. ({', '.join(partes)})"


def _bm25(terms: list[str], doc: str, k1: float = 1.5, b: float = 0.75) -> float:
    words = re.findall(r'\w+', doc.lower())
    dl = len(words)
    if not dl:
        return 0.0
    freq: dict[str, int] = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    score = 0.0
    for t in terms:
        if len(t) < 3:
            continue
        tf = freq.get(t, 0)
        if not tf:
            continue
        idf = math.log((1001 - tf + 0.5) / (tf + 0.5) + 1)
        score += idf * (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl / 200))
    return score


class DataJudAdapter:
    def __init__(self):
        self._c = httpx.AsyncClient(timeout=12.0,
            headers={"Authorization": f"ApiKey {DATAJUD_KEY}",
                     "Content-Type": "application/json"})

    async def buscar(self, query: str, tribunal: str = "STJ", n: int = 5) -> list[Jurisprudencia]:
        indice = DATAJUD_INDICES.get(tribunal.upper(), "api_publica_stj")
        body = {"size": n,
            "query": {"bool": {"should": [
                {"multi_match": {"query": query,
                    "fields": ["ementa^3","assuntos.nome^2","classe.nome"],
                    "type": "best_fields", "fuzziness": "AUTO"}},
                {"match_phrase": {"ementa": {"query": query, "boost": 2}}},
            ], "minimum_should_match": 1}},
            "sort": [{"_score": {"order": "desc"}}, {"dataAjuizamento": {"order": "desc"}}],
            "_source": ["tribunal","classe","assuntos","relator","dataAjuizamento","ementa","numeroProcesso"]}
        try:
            r = await self._c.post(f"{DATAJUD_BASE}/{indice}/_search", json=body)
            r.raise_for_status()
            return [self._n(h, tribunal) for h in r.json().get("hits",{}).get("hits",[]) if h.get("_source")]
        except Exception as e:
            logger.debug(f"[DataJud:{tribunal}] {e}")
            return []

    def _n(self, hit: dict, tribunal: str) -> Jurisprudencia:
        src = hit.get("_source", {})
        ementa = src.get("ementa", "").strip() or " | ".join(
            a.get("nome","") for a in src.get("assuntos",[])[:3]) or "Sem ementa"
        trib = src.get("tribunal", {})
        return Jurisprudencia(
            tribunal=trib.get("nome", tribunal) if isinstance(trib, dict) else tribunal,
            tipo="acordao", numero=src.get("numeroProcesso"),
            relator=(src.get("relator") or {}).get("nome") if isinstance(src.get("relator"), dict) else None,
            data_julgamento=(src.get("dataAjuizamento","") or "")[:10] or None,
            ementa=ementa, link="https://jurisprudencia.cnj.jus.br/", fonte="datajud")

    async def aclose(self): await self._c.aclose()


class STJAcordaosAdapter:
    BASE = "https://scon.stj.jus.br/SCON/pesquisar.jsp"
    def __init__(self):
        self._c = httpx.AsyncClient(timeout=15.0, follow_redirects=True,
            headers={"User-Agent": "Mozilla/5.0 (compatible; EJC/2.0)"})

    async def buscar(self, query: str, n: int = 5) -> list[Jurisprudencia]:
        try:
            r = await self._c.get(self.BASE, params={"b":"ACOR","livre":query,"i":"1","t":str(min(n,10)),"tipo_visualizacao":"RESUMO"})
            r.raise_for_status()
            return self._parse(r.text, query)[:n]
        except Exception as e:
            logger.debug(f"[STJ Acc] {e}"); return []

    def _parse(self, html: str, q: str) -> list[Jurisprudencia]:
        res = []
        ems = re.findall(r'<(?:div|span|td)[^>]+class=["\'][^"\']*ementa[^"\']*["\'][^>]*>(.*?)</(?:div|span|td)>', html, re.DOTALL|re.I)
        if not ems:
            ems = re.findall(r'EMENTA\s*:?\s*<[^>]*>(.*?)</[^>]+>', html, re.DOTALL|re.I)
        nums = re.findall(r'(REsp|AgInt|AREsp|HC|RHC)\s*[\d\.]+(?:/[A-Z]{2})?', html)
        rels = re.findall(r'Ministr[ao]\s+([A-ZÁÉÍÓÚÀÂÊÔÃÕÜ][^<\n,;]{5,60})', html)
        dats = re.findall(r'(\d{2}/\d{2}/\d{4})', html)
        for i, em in enumerate(ems[:6]):
            t = re.sub(r'<[^>]+>',' ',em); t = re.sub(r'\s+',' ',t).strip()
            if len(t) < 40: continue
            res.append(Jurisprudencia(tribunal="STJ", tipo="acordao",
                numero=nums[i] if i < len(nums) else None,
                relator=rels[i].strip() if i < len(rels) else None,
                data_julgamento=dats[i] if i < len(dats) else None,
                ementa=t[:900], link=f"https://scon.stj.jus.br/SCON/pesquisar.jsp?b=ACOR&livre={q}",
                fonte="stj_scon"))
        return res

    async def aclose(self): await self._c.aclose()


class STJTemasAdapter:
    """Temas de recursos repetitivos STJ — vinculam juízes de 1ª e 2ª instância."""
    BASE = "https://scon.stj.jus.br/SCON/pesquisar.jsp"
    def __init__(self):
        self._c = httpx.AsyncClient(timeout=15.0, follow_redirects=True,
            headers={"User-Agent": "Mozilla/5.0 (compatible; EJC/2.0)"})

    async def buscar(self, query: str, n: int = 4) -> list[Jurisprudencia]:
        try:
            r = await self._c.get(self.BASE, params={"b":"TEMA","livre":query,"i":"1","t":str(min(n,10))})
            r.raise_for_status()
            return self._parse(r.text)[:n]
        except Exception as e:
            logger.debug(f"[STJ Temas] {e}"); return []

    def _parse(self, html: str) -> list[Jurisprudencia]:
        res = []
        temas = re.findall(r'Tema[:\s]+(\d+)', html, re.I)
        teses = re.findall(r'(?:Tese|Entendimento)[:\s]*<[^>]*>(.*?)</[^>]+>', html, re.DOTALL|re.I)
        if not teses:
            teses = re.findall(r'(?:Tese|Entendimento)[:\s]+([^<]{30,500})', html, re.I)
        for i, t in enumerate(teses[:5]):
            txt = re.sub(r'<[^>]+>',' ',t); txt = re.sub(r'\s+',' ',txt).strip()
            if len(txt) < 20: continue
            res.append(Jurisprudencia(tribunal="STJ", tipo="tema",
                numero_tema=temas[i] if i < len(temas) else None,
                ementa=txt[:700], tese=txt[:700],
                link="https://processo.stj.jus.br/repetitivos/",
                fonte="stj_temas", vinculante=True, relevancia=0.85))
        return res

    async def aclose(self): await self._c.aclose()


class STFAdapter:
    """STF — acórdãos (API JSON + HTML) + teses de repercussão geral."""
    def __init__(self):
        self._c = httpx.AsyncClient(timeout=15.0, follow_redirects=True,
            headers={"User-Agent": "Mozilla/5.0 (compatible; EJC/2.0)"})

    async def buscar(self, query: str, n: int = 4) -> list[Jurisprudencia]:
        res = []
        try:
            r = await self._c.get("https://jurisprudencia.stf.jus.br/api/search/search",
                params={"query": query, "size": n, "page": 0})
            if r.status_code == 200:
                for h in (r.json().get("result",{}).get("hits",{}).get("hits",[]) or [])[:n]:
                    src = h.get("_source", {})
                    em = src.get("ementa") or src.get("indexacao","")
                    if em:
                        res.append(Jurisprudencia(tribunal="STF", tipo="acordao",
                            numero=src.get("numeroProcesso") or src.get("processo"),
                            relator=src.get("relator"),
                            data_julgamento=(src.get("dataJulgamento","") or "")[:10] or None,
                            ementa=str(em)[:900],
                            link=f"https://jurisprudencia.stf.jus.br/pages/search?query={query}",
                            fonte="stf_api"))
        except Exception as e:
            logger.debug(f"[STF API] {e}")
        if not res:
            try:
                r2 = await self._c.get("https://portal.stf.jus.br/jurisprudencia/listarJurisprudencia.asp",
                    params={"s":"1","base":"acordaos","pesquisa":query})
                if r2.status_code == 200:
                    for em in re.findall(r'<(?:td|span)[^>]+class=["\'][^"\']*ementa[^"\']*["\'][^>]*>(.*?)</(?:td|span)>',
                                        r2.text, re.DOTALL|re.I)[:n]:
                        t = re.sub(r'<[^>]+>',' ',em); t = re.sub(r'\s+',' ',t).strip()
                        if len(t) >= 40:
                            res.append(Jurisprudencia(tribunal="STF", tipo="acordao",
                                ementa=t[:900], fonte="stf_html",
                                link=f"https://portal.stf.jus.br/jurisprudencia/listarJurisprudencia.asp?pesquisa={query}"))
            except Exception as e2:
                logger.debug(f"[STF HTML] {e2}")
        return res[:n]

    async def buscar_temas(self, query: str, n: int = 3) -> list[Jurisprudencia]:
        res = []
        try:
            r = await self._c.get("https://portal.stf.jus.br/jurisprudenciaRepercussao/listarJurisprudencia.asp",
                params={"s":"1","base":"repercussao","pesquisa":query})
            r.raise_for_status()
            nums = re.findall(r'Tema[\s:]+(\d+)', r.text, re.I)
            teses = re.findall(r'(?:Tese|Proposição)[:\s]*<[^>]*>(.*?)</[^>]+>', r.text, re.DOTALL|re.I)
            for i, t in enumerate(teses[:n]):
                txt = re.sub(r'<[^>]+>',' ',t); txt = re.sub(r'\s+',' ',txt).strip()
                if len(txt) >= 20:
                    res.append(Jurisprudencia(tribunal="STF", tipo="tema",
                        numero_tema=nums[i] if i < len(nums) else None,
                        ementa=txt[:700], tese=txt[:700],
                        link="https://portal.stf.jus.br/temasrg/",
                        fonte="stf_temas_rg", vinculante=True, relevancia=0.90))
        except Exception as e:
            logger.debug(f"[STF Temas RG] {e}")
        return res

    async def aclose(self): await self._c.aclose()


class TSTAdapter:
    BASE = "https://jurisprudencia.tst.jus.br/api/v1/pesquisa"
    def __init__(self):
        self._c = httpx.AsyncClient(timeout=12.0, follow_redirects=True,
            headers={"User-Agent": "Mozilla/5.0 (compatible; EJC/2.0)"})

    async def buscar(self, query: str, n: int = 5) -> list[Jurisprudencia]:
        res = []
        try:
            r = await self._c.get(self.BASE, params={"query":query,"size":n,"from":0})
            if r.status_code == 200:
                for h in (r.json().get("hits",{}).get("hits",[]) or [])[:n]:
                    src = h.get("_source",{})
                    em = src.get("ementa") or src.get("texto","")
                    if em:
                        res.append(Jurisprudencia(tribunal="TST",
                            tipo=(src.get("tipo") or "acordao").lower(),
                            numero=src.get("numeroProcesso") or src.get("numero"),
                            relator=src.get("relator"),
                            data_julgamento=(src.get("dataJulgamento","") or "")[:10] or None,
                            ementa=str(em)[:900],
                            link=f"https://jurisprudencia.tst.jus.br/pages/pesquisa?q={query}",
                            fonte="tst_api"))
        except Exception as e:
            logger.debug(f"[TST] {e}")
        return res

    async def aclose(self): await self._c.aclose()


class TJSPAdapter:
    BASE = "https://esaj.tjsp.jus.br/cjpg/pesquisar.do"
    def __init__(self):
        self._c = httpx.AsyncClient(timeout=15.0, follow_redirects=True,
            headers={"User-Agent":"Mozilla/5.0 (compatible; EJC/2.0)",
                     "Accept":"text/html,application/xhtml+xml"})

    async def buscar(self, query: str, n: int = 4) -> list[Jurisprudencia]:
        try:
            r = await self._c.get(self.BASE, params={
                "conversationId":"","dadosConsulta.pesquisaLivre":query,
                "dadosConsulta.tipoNumero":"UNIFICADO","pbEnviar":"Pesquisar"})
            r.raise_for_status()
            return self._parse(r.text, query)[:n]
        except Exception as e:
            logger.debug(f"[TJSP] {e}"); return []

    def _parse(self, html: str, q: str) -> list[Jurisprudencia]:
        res = []
        bls = re.findall(r'<div[^>]+class=["\']ementaClass["\'][^>]*>(.*?)</div>', html, re.DOTALL|re.I)
        if not bls:
            bls = re.findall(r'Ementa[:\s]*</[^>]+>\s*<[^>]+>(.*?)</[^>]+>', html, re.DOTALL|re.I)
        nums = re.findall(r'\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}', html)
        rels = re.findall(r'Relator(?:a)?\s*:\s*([^<\n]{5,60})', html)
        for i, b in enumerate(bls[:5]):
            t = re.sub(r'<[^>]+>',' ',b); t = re.sub(r'\s+',' ',t).strip()
            if len(t) < 40: continue
            res.append(Jurisprudencia(tribunal="TJSP", tipo="acordao",
                numero=nums[i] if i < len(nums) else None,
                relator=rels[i].strip() if i < len(rels) else None,
                ementa=t[:900],
                link=f"https://esaj.tjsp.jus.br/cjpg/pesquisar.do?dadosConsulta.pesquisaLivre={q}",
                fonte="tjsp_esaj"))
        return res

    async def aclose(self): await self._c.aclose()


class LocalCorpusAdapter:
    async def buscar(self, query: str, db: AsyncSession, n: int = 8,
                     area: Optional[str] = None) -> list[Jurisprudencia]:
        res = []
        where = " AND area=:area" if area else ""
        params: dict = {"q": f"%{query.lower()}%", "lim": n}
        if area: params["area"] = area
        try:
            rows = await db.execute(text(f"""
                SELECT tribunal, numero_sumula, ementa, area, relevancia
                FROM jurisprudencias_salvas
                WHERE (LOWER(ementa) LIKE :q OR assunto ILIKE :q) {where}
                ORDER BY relevancia DESC NULLS LAST, tribunal
                LIMIT :lim
            """), params)
            for r in rows.mappings():
                res.append(Jurisprudencia(tribunal=r["tribunal"], tipo="sumula",
                    numero=str(r["numero_sumula"]), ementa=r["ementa"],
                    area=r["area"], fonte="local_sumulas", relevancia=0.9,
                    vinculante="STF" in str(r["tribunal"])))
        except Exception as e: logger.debug(f"[Local:sumulas] {e}")
        if len(res) < n:
            try:
                rows2 = await db.execute(text("""
                    SELECT dc.content, ld.title, ld.category, ld.metadata
                    FROM document_chunks dc
                    JOIN legal_documents ld ON ld.id = dc.document_id
                    WHERE dc.content ILIKE :q ORDER BY dc.created_at DESC LIMIT :lim
                """), {"q": f"%{query}%", "lim": n - len(res)})
                for r in rows2.mappings():
                    meta = r.get("metadata") or {}
                    if isinstance(meta, str):
                        try: meta = json.loads(meta)
                        except: meta = {}
                    res.append(Jurisprudencia(tribunal=meta.get("tribunal","Corpus EJC"),
                        tipo=r["category"] or "legislacao", ementa=r["content"][:600],
                        area=meta.get("area"), fonte="rag_local", relevancia=0.7))
            except Exception as e: logger.debug(f"[Local:rag] {e}")
        return res


class JurisprudenciaEngine:
    def __init__(self):
        self.datajud  = DataJudAdapter()
        self.stj_acc  = STJAcordaosAdapter()
        self.stj_tem  = STJTemasAdapter()
        self.stf      = STFAdapter()
        self.tst      = TSTAdapter()
        self.tjsp     = TJSPAdapter()
        self.local    = LocalCorpusAdapter()

    def _keywords(self, texto: str, area: Optional[str] = None) -> list[str]:
        ws = re.findall(r'\b[a-záéíóúàâêôãõüç]{3,}\b', texto.lower())
        kw = [w for w in ws if w not in STOPWORDS_JUR]
        seen: set[str] = set()
        kw = [k for k in kw if not (k in seen or seen.add(k))]  # type: ignore
        if area:
            extra = " ".join(SINONIMOS_AREA.get(area.lower(), []))
            for w in extra.lower().split():
                if w not in STOPWORDS_JUR and w not in seen:
                    kw.append(w)
                    seen.add(w)
        return kw[:12]

    def _hash(self, query: str, tribunal: Optional[str], area: Optional[str]) -> str:
        return hashlib.sha256(f"{query.lower()}|{tribunal or ''}|{area or ''}".encode()).hexdigest()[:32]

    async def _cache_get(self, h: str, db: AsyncSession) -> Optional[list]:
        try:
            row = await db.execute(text("SELECT resultados FROM jurisprudencia_cache WHERE hash_query=:h AND valido_ate > NOW() ORDER BY created_at DESC LIMIT 1"), {"h": h})
            r = row.scalar()
            if r: return r if isinstance(r, list) else json.loads(r)
        except: pass
        return None

    async def _cache_set(self, h: str, q: str, trib: str, res: list[dict], fonte: str, db: AsyncSession):
        try:
            tem_vin = any(r.get("vinculante") or r.get("tipo") in ("sumula","tema") for r in res)
            ttl = "48 hours" if tem_vin else "6 hours"
            await db.execute(text(f"""
                INSERT INTO jurisprudencia_cache (hash_query,tribunal,query_original,resultados,total_encontrado,fonte,valido_ate)
                VALUES (:h,:t,:q,:r::jsonb,:n,:f,NOW()+INTERVAL '{ttl}')
                ON CONFLICT (hash_query) DO UPDATE SET resultados=EXCLUDED.resultados, valido_ate=EXCLUDED.valido_ate
            """), {"h":h,"t":trib,"q":q,"r":json.dumps(res,ensure_ascii=False),"n":len(res),"f":fonte})
            await db.commit()
        except Exception as e: logger.debug(f"[Cache set] {e}")

    def _rank(self, items: list[Jurisprudencia], kws: list[str]) -> list[Jurisprudencia]:
        import datetime
        ano = datetime.datetime.now().year
        for j in items:
            s = _bm25(kws, j.ementa)
            s = min(0.4, s / 20)
            if j.vinculante: s += 0.40
            elif j.tipo == "tema": s += 0.35
            elif j.tipo == "sumula": s += 0.30
            elif j.tipo == "oj": s += 0.20
            if j.tribunal in ("STF","STJ"): s += 0.20
            elif j.tribunal in ("TST","TRF4","TRF3","TRF1"): s += 0.12
            elif j.tribunal.startswith("TJ"): s += 0.05
            if j.data_julgamento:
                try:
                    a = int(str(j.data_julgamento)[:4])
                    s += 0.12 if a >= ano-1 else 0.06 if a >= ano-3 else 0.03 if a >= ano-5 else 0
                except: pass
            j.relevancia = min(1.0, max(j.relevancia, s))
        return sorted(items, key=lambda x: x.relevancia, reverse=True)

    def _dedup(self, items: list[Jurisprudencia]) -> list[Jurisprudencia]:
        ve: set[str] = set(); vn: set[str] = set(); out = []
        for j in items:
            ke = re.sub(r'\s+',' ', j.ementa[:80].lower().strip())
            kn = f"{j.tribunal}:{j.numero}" if j.numero else None
            if ke in ve or (kn and kn in vn): continue
            ve.add(ke)
            if kn: vn.add(kn)
            out.append(j)
        return out

    async def buscar(self, query: str, db: AsyncSession,
                     tribunal: Optional[str] = None, area: Optional[str] = None,
                     top_k: int = 10, usar_cache: bool = True,
                     incluir_temas: bool = True,
                     fontes: Optional[list[str]] = None) -> dict:
        t0 = time.monotonic()
        kws = self._keywords(query, area)
        h = self._hash(query, tribunal, area)
        if usar_cache:
            cached = await self._cache_get(h, db)
            if cached:
                return {"resultados": cached[:top_k], "total": len(cached),
                        "fontes_usadas": ["cache"], "cache_hit": True,
                        "tempo_ms": int((time.monotonic()-t0)*1000), "query": query}

        tribs = [tribunal] if tribunal else AREA_TRIBUNAIS.get(area or "", ["STJ","STF"])
        fsel = fontes or ["local","stj","stf","tst","tjsp","datajud","temas"]
        tasks: list = []; fnames: list[str] = []
        def add(coro, nm):
            tasks.append(coro); fnames.append(nm)

        if "local" in fsel:    add(self.local.buscar(query, db, n=8, area=area), "local")
        if "stj" in fsel:      add(self.stj_acc.buscar(query, n=5), "stj")
        if "temas" in fsel and incluir_temas:
            add(self.stj_tem.buscar(query, n=4), "stj_temas")
        if "stf" in fsel:
            add(self.stf.buscar(query, n=4), "stf")
            if incluir_temas: add(self.stf.buscar_temas(query, n=3), "stf_temas")
        if "tst" in fsel and (not tribunal or area == "trabalhista" or "TST" in (tribunal or "")):
            add(self.tst.buscar(query, n=5), "tst")
        if "tjsp" in fsel and area in ("consumidor","civel","familia","bancario",None):
            add(self.tjsp.buscar(query, n=4), "tjsp")
        if "datajud" in fsel:
            for tr in tribs[:3]:
                if tr in DATAJUD_INDICES and tr not in ("STJ","STF","TST"):
                    add(self.datajud.buscar(query, tribunal=tr, n=3), f"datajud:{tr}")

        try:
            raw = await asyncio.wait_for(asyncio.gather(*tasks, return_exceptions=True), timeout=20.0)
        except asyncio.TimeoutError:
            raw = []; logger.warning("[JurisEngine] Timeout")

        all_j: list[Jurisprudencia] = []; fn_ok: list[str] = []
        for i, r in enumerate(raw):
            if isinstance(r, list) and r:
                all_j.extend(r)
                if i < len(fnames): fn_ok.append(fnames[i])

        if not all_j:
            all_j = await self.local.buscar(query, db, n=top_k, area=area)
            fn_ok = ["local_fallback"]

        all_j = self._rank(all_j, kws)
        all_j = self._dedup(all_j)
        top = all_j[:top_k]
        dicts = [j.to_dict() for j in top]

        await self._cache_set(h, query, tribunal or "geral", dicts, ",".join(fn_ok), db)
        try:
            ms = int((time.monotonic()-t0)*1000)
            await db.execute(text("""
                INSERT INTO jurisprudencia_historico (query,tribunal,area_juridica,total_resultados,tempo_ms,fontes_usadas)
                VALUES (:q,:t,:a,:n,:ms,:f)
            """), {"q":query[:500],"t":tribunal,"a":area,"n":len(all_j),"ms":ms,"f":fn_ok})
            await db.commit()
        except: pass

        ms2 = int((time.monotonic()-t0)*1000)
        logger.info(f"[JurisEngine] '{query[:40]}' → {len(top)}/{len(all_j)} em {ms2}ms | {fn_ok}")
        return {"resultados": dicts, "total": len(all_j), "fontes_usadas": fn_ok,
                "cache_hit": False, "tempo_ms": ms2, "query": query}

    async def buscar_para_peticao(self, area: str, fatos: str, pedidos: str,
                                   db: AsyncSession, max_citacoes: int = 8) -> str:
        kws = self._keywords(f"{area} {fatos[:300]} {pedidos[:150]}", area)
        query = " ".join(kws[:8])
        res = await self.buscar(query=query, db=db, area=area,
                                 top_k=max_citacoes, incluir_temas=True)
        items = res.get("resultados", [])
        if not items: return ""

        FIELDS = {f for f in ["tribunal","tipo","numero","numero_tema","relator",
                               "data_julgamento","ementa","tese","link","fonte",
                               "relevancia","area","vinculante"]}
        def make(r): return Jurisprudencia(**{k:v for k,v in r.items() if k in FIELDS})

        vincs = [r for r in items if r.get("vinculante") or r.get("tipo") == "tema"]
        sums  = [r for r in items if r.get("tipo") == "sumula" and not r.get("vinculante")]
        accs  = [r for r in items if r.get("tipo") not in ("sumula","tema") and not r.get("vinculante")]
        lines = []
        if vincs:
            lines.append("PRECEDENTES VINCULANTES (aplicação obrigatória pelos juízes):")
            for r in vincs[:3]: lines.append(f"  ▶ {make(r).para_citacao()}")
        if sums:
            lines.append("\nSÚMULAS APLICÁVEIS:")
            for r in sums[:3]: lines.append(f"  • {make(r).para_citacao()}")
        if accs:
            lines.append("\nJURISPRUDÊNCIA RECENTE:")
            for r in accs[:3]: lines.append(f"  – {make(r).para_citacao()}")
        lines.append(f"\n[{len(items)} referências identificadas — {area}]")
        return "\n".join(lines)

    async def validar_citacao(self, tribunal: str, numero: str,
                               ementa_esperada: str, db: AsyncSession) -> dict:
        res = await self.buscar(f"{tribunal} {numero}", db, tribunal=tribunal, top_k=5)
        for r in res.get("resultados", []):
            if r.get("numero") and numero in str(r["numero"]):
                return {"valido": True, "encontrado": r, "confianca": 0.95, "match": "numero"}
            if r.get("numero_tema") and numero in str(r["numero_tema"]):
                return {"valido": True, "encontrado": r, "confianca": 0.90, "match": "tema"}
        termos = set(ementa_esperada.lower().split())
        for r in res.get("resultados", []):
            overlap = len(termos & set(r.get("ementa","").lower().split())) / max(len(termos), 1)
            if overlap >= 0.4:
                return {"valido": True, "encontrado": r, "confianca": round(overlap,2), "match": "ementa"}
        return {"valido": False, "encontrado": None, "confianca": 0.0}

    async def aclose(self):
        for a in [self.datajud, self.stj_acc, self.stj_tem, self.stf, self.tst, self.tjsp]:
            await a.aclose()


_engine: Optional[JurisprudenciaEngine] = None

def get_engine() -> JurisprudenciaEngine:
    global _engine
    if not _engine: _engine = JurisprudenciaEngine()
    return _engine
