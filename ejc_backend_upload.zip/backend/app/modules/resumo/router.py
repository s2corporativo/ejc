"""
EJC — Módulo Resumo (wrapper do módulo Analise)
Alias para /analise/resumo — mantido para compatibilidade com especificação.
"""
from fastapi import APIRouter
router = APIRouter(prefix="/resumo", tags=["Resumo de Documentos"])
# Endpoint canônico: POST /analise/resumo
