"""
EJC — Router Espaços (modules/espacos/router.py)
"""
from __future__ import annotations

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.espacos.service import EspacosService

router = APIRouter(prefix="/espacos", tags=["Espaços — Contexto por Cliente/Processo"])
_svc: Optional[EspacosService] = None

def get_svc() -> EspacosService:
    global _svc
    if not _svc:
        _svc = EspacosService()
    return _svc


class CriarEspacoRequest(BaseModel):
    titulo: str
    tipo: str = "cliente"  # cliente | processo | tema | audiencia
    referencia: Optional[str] = None
    descricao: Optional[str] = None
    cor: str = "#c9960a"

class ChatRequest(BaseModel):
    pergunta: str
    historico: Optional[list[dict]] = None

class ContinuarTrechoRequest(BaseModel):
    trecho_selecionado: str
    nova_pergunta: str


@router.post("/", status_code=201)
async def criar_espaco(
    req: CriarEspacoRequest,
    db: AsyncSession = Depends(get_db),
    svc: EspacosService = Depends(get_svc),
):
    """Cria um novo espaço de trabalho (por cliente, processo ou tema)."""
    return await svc.criar_espaco(
        db, req.titulo, req.tipo, req.referencia, req.descricao, req.cor
    )


@router.get("/")
async def listar_espacos(
    db: AsyncSession = Depends(get_db),
    svc: EspacosService = Depends(get_svc),
):
    """Lista todos os espaços ativos com contadores de conversas e prazos."""
    return {"espacos": await svc.listar_espacos(db)}


@router.get("/{espaco_id}")
async def buscar_espaco(
    espaco_id: str,
    db: AsyncSession = Depends(get_db),
    svc: EspacosService = Depends(get_svc),
):
    """Retorna um espaço com seu contexto acumulado."""
    espaco = await svc.buscar_espaco(db, espaco_id)
    if not espaco:
        raise HTTPException(404, "Espaço não encontrado.")
    return espaco


@router.post("/{espaco_id}/chat")
async def chat_com_contexto(
    espaco_id: str,
    req: ChatRequest,
    db: AsyncSession = Depends(get_db),
    svc: EspacosService = Depends(get_svc),
):
    """
    Pergunta jurídica contextualizada ao espaço.
    Equivalente ao 'Perguntar ao Jus IA' com contexto acumulado.
    """
    try:
        return await svc.chat_com_contexto(db, espaco_id, req.pergunta, req.historico)
    except (ValueError, RuntimeError) as e:
        raise HTTPException(422, str(e))


@router.post("/{espaco_id}/continuar-trecho")
async def continuar_de_trecho(
    espaco_id: str,
    req: ContinuarTrechoRequest,
    db: AsyncSession = Depends(get_db),
    svc: EspacosService = Depends(get_svc),
):
    """
    Continua conversa a partir de um trecho selecionado.
    Recurso 'Perguntar ao Jus IA' inline do Jus.ia.
    """
    try:
        return await svc.continuar_de_trecho(
            db, espaco_id, req.trecho_selecionado, req.nova_pergunta
        )
    except ValueError as e:
        raise HTTPException(422, str(e))


@router.get("/{espaco_id}/conversas")
async def listar_conversas(
    espaco_id: str,
    db: AsyncSession = Depends(get_db),
    svc: EspacosService = Depends(get_svc),
):
    """Lista conversas de um espaço."""
    return {"conversas": await svc.listar_conversas(db, espaco_id)}
