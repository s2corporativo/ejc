"""
EJC — Módulo Espaços (modules/espacos/service.py)

Inspirado no recurso "Espaços" do Jus.ia:
  Agrupa conversas, documentos e prazos de um mesmo cliente,
  processo ou tema. Cada espaço acumula contexto automaticamente,
  tornando cada nova interação mais inteligente e personalizada.

Diferencial do EJC: contexto armazenado no pgvector — permite
recuperação semântica dentro do espaço.
"""
from __future__ import annotations

import logging
from uuid import uuid4, UUID
from typing import Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.redacao.service import LegalDraftService

logger = logging.getLogger(__name__)


class EspacosService:
    """
    Gerencia Espaços de trabalho: contexto acumulado por cliente/processo.
    """

    def __init__(self):
        self._llm = LegalDraftService()

    # ── CRUD Espaços ──────────────────────────────────────────────────────

    async def criar_espaco(
        self,
        db: AsyncSession,
        titulo: str,
        tipo: str,
        referencia: Optional[str] = None,
        descricao: Optional[str] = None,
        cor: str = "#c9960a",
    ) -> dict:
        eid = uuid4()
        await db.execute(
            text("""
                INSERT INTO espacos (id, titulo, tipo, referencia, descricao, cor)
                VALUES (:id, :titulo, :tipo, :ref, :desc, :cor)
            """),
            {"id": str(eid), "titulo": titulo, "tipo": tipo,
             "ref": referencia, "desc": descricao, "cor": cor},
        )
        return {"id": str(eid), "titulo": titulo, "tipo": tipo,
                "referencia": referencia, "cor": cor}

    async def listar_espacos(self, db: AsyncSession) -> list[dict]:
        rows = await db.execute(
            text("""
                SELECT e.id, e.titulo, e.tipo, e.referencia, e.cor, e.ativo,
                       e.created_at, e.updated_at,
                       COUNT(DISTINCT c.id) AS total_conversas,
                       COUNT(DISTINCT p.id) AS total_prazos_pendentes
                FROM espacos e
                LEFT JOIN conversas c ON c.espaco_id = e.id
                LEFT JOIN prazos p ON p.espaco_id = e.id AND p.status = 'pendente'
                WHERE e.ativo = true
                GROUP BY e.id
                ORDER BY e.updated_at DESC
            """)
        )
        return [dict(r) for r in rows.mappings()]

    async def buscar_espaco(self, db: AsyncSession, espaco_id: str) -> Optional[dict]:
        row = await db.execute(
            text("SELECT * FROM espacos WHERE id = :id"),
            {"id": espaco_id},
        )
        r = row.mappings().first()
        return dict(r) if r else None

    async def atualizar_contexto(
        self, db: AsyncSession, espaco_id: str, novo_contexto: str
    ):
        """Acumula contexto no espaço — chamado automaticamente após cada conversa."""
        separador = "\n\n---\n\n"
        await db.execute(
            text("""
                UPDATE espacos
                SET contexto = CASE
                    WHEN contexto IS NULL OR contexto = '' THEN :ctx
                    ELSE contexto || :sep || :ctx
                END,
                updated_at = NOW()
                WHERE id = :id
            """),
            {"ctx": novo_contexto[:5000], "sep": separador, "id": espaco_id},
        )

    # ── Conversas com contexto acumulado ─────────────────────────────────

    async def chat_com_contexto(
        self,
        db: AsyncSession,
        espaco_id: str,
        pergunta: str,
        historico: Optional[list[dict]] = None,
    ) -> dict:
        """
        Responde uma pergunta usando o contexto acumulado do espaço.
        Equivale ao "Perguntar ao Jus IA" com continuidade contextual.

        O contexto do espaço é automaticamente incluído no prompt,
        tornando a resposta mais personalizada para o caso/cliente.
        """
        espaco = await self.buscar_espaco(db, espaco_id)
        if not espaco:
            raise ValueError(f"Espaço {espaco_id} não encontrado.")

        contexto_espaco = espaco.get("contexto") or ""
        historico_fmt = ""
        if historico:
            historico_fmt = "\n".join(
                f"[{m['role'].upper()}] {m['content']}" for m in historico[-6:]
            )

        prompt = f"""Contexto acumulado do espaço "{espaco['titulo']}" ({espaco['tipo']}):
{contexto_espaco if contexto_espaco else '(sem contexto acumulado ainda)'}

Histórico recente da conversa:
{historico_fmt if historico_fmt else '(início da conversa)'}

Pergunta atual do advogado:
{pergunta}

Responda de forma técnica e precisa, aproveitando o contexto do caso.
Se não houver informação suficiente no contexto, informe claramente."""

        resposta = await self._llm.answer_from_context(
            query=pergunta, context=contexto_espaco or "sem contexto"
        )

        # Persiste mensagem na conversa
        await db.execute(
            text("""
                INSERT INTO conversas (id, espaco_id, titulo, mensagens)
                VALUES (:id, :eid, :titulo, :msgs::jsonb)
                ON CONFLICT DO NOTHING
            """),
            {
                "id": str(uuid4()),
                "eid": espaco_id,
                "titulo": pergunta[:80],
                "msgs": str([
                    {"role": "user", "content": pergunta},
                    {"role": "assistant", "content": resposta},
                ]),
            },
        )

        # Atualiza contexto do espaço com o resumo da interação
        await self.atualizar_contexto(
            db, espaco_id,
            f"Pergunta: {pergunta[:200]}\nResposta resumida: {resposta[:500]}"
        )

        return {
            "espaco_id": espaco_id,
            "pergunta": pergunta,
            "resposta": resposta,
            "contexto_utilizado": bool(contexto_espaco),
        }

    async def continuar_de_trecho(
        self,
        db: AsyncSession,
        espaco_id: str,
        trecho_selecionado: str,
        nova_pergunta: str,
    ) -> dict:
        """
        "Perguntar ao Jus IA" inline — continua a conversa a partir
        de um trecho específico de uma resposta anterior.
        Equivalente exato ao recurso do Jus.ia.
        """
        prompt_contextual = (
            f"Com base no seguinte trecho:\n\n"
            f'"{trecho_selecionado}"\n\n'
            f"Responda: {nova_pergunta}"
        )
        return await self.chat_com_contexto(
            db, espaco_id, prompt_contextual
        )

    async def listar_conversas(
        self, db: AsyncSession, espaco_id: str
    ) -> list[dict]:
        rows = await db.execute(
            text("""
                SELECT id, titulo, created_at,
                       jsonb_array_length(mensagens) AS total_mensagens
                FROM conversas
                WHERE espaco_id = :eid
                ORDER BY created_at DESC
                LIMIT 50
            """),
            {"eid": espaco_id},
        )
        return [dict(r) for r in rows.mappings()]
