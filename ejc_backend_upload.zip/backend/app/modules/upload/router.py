"""
EJC — Upload de Documentos pelo Cliente (upload/router.py)
Aceita PDF, imagem, texto. Extrai texto para alimentar o LLM.
"""
from __future__ import annotations
import logging, os, json
from typing import Optional
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/upload", tags=["Upload Documentos"])

TIPOS_OK = {"image/jpeg","image/png","image/webp","application/pdf","text/plain"}
MAX_KB   = 5_000


@router.post("/pedido/{pedido_id}/documento", status_code=201)
async def upload_doc(
    pedido_id: str, token_acesso: str,
    descricao: Optional[str] = None,
    arquivo: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    """Cliente faz upload de documento. Texto extraído entra nos fatos do pedido."""
    row = await db.execute(
        text("SELECT id FROM pedidos WHERE id=:id AND token_acesso=:t"),
        {"id": pedido_id, "t": token_acesso})
    if not row.first():
        raise HTTPException(403, "Acesso negado")
    if arquivo.content_type not in TIPOS_OK:
        raise HTTPException(415, f"Tipo não permitido: {arquivo.content_type}")
    dados = await arquivo.read()
    kb = len(dados) // 1024
    if kb > MAX_KB:
        raise HTTPException(413, f"Arquivo muito grande ({kb}KB). Limite: {MAX_KB}KB")

    # Salva
    dir_ = f"/app/uploads/{pedido_id}"
    os.makedirs(dir_, exist_ok=True)
    key = f"{pedido_id}/{uuid4()}_{arquivo.filename}"
    with open(f"/app/uploads/{key}", "wb") as f:
        f.write(dados)

    # Extrai texto
    ocr = None
    try:
        if arquivo.content_type == "text/plain":
            ocr = dados.decode("utf-8", errors="replace")[:3000]
        elif arquivo.content_type == "application/pdf":
            try:
                import fitz
                doc = fitz.open(stream=dados, filetype="pdf")
                ocr = "\n".join(p.get_text() for p in doc)[:3000]
            except ImportError:
                ocr = "[PDF anexado — instale PyMuPDF para extração automática]"
    except Exception as e:
        logger.warning(f"[Upload OCR] {e}")

    doc_id = str(uuid4())
    await db.execute(text("""
        INSERT INTO documentos_pedido (id,pedido_id,nome,tipo_mime,tamanho_kb,storage_key,descricao,texto_ocr)
        VALUES (:id,:pid,:nome,:mime,:kb,:sk,:desc,:ocr)
    """), {"id":doc_id,"pid":pedido_id,"nome":arquivo.filename,
           "mime":arquivo.content_type,"kb":kb,"sk":key,"desc":descricao,"ocr":ocr})
    if ocr:
        await db.execute(text("""
            UPDATE pedidos SET fatos = fatos || '\n\n[DOC: ' || :nome || ']\n' || :txt WHERE id=:pid
        """), {"nome": arquivo.filename, "txt": ocr[:800], "pid": pedido_id})
    await db.commit()
    logger.info(f"[Upload] {arquivo.filename} ({kb}KB) → pedido {pedido_id}")
    return {"id": doc_id, "nome": arquivo.filename, "tamanho_kb": kb,
            "texto_extraido": bool(ocr), "mensagem": "Documento recebido e processado."}


@router.get("/pedido/{pedido_id}/documentos")
async def listar_docs(pedido_id: str, token_acesso: str, db: AsyncSession = Depends(get_db)):
    row = await db.execute(
        text("SELECT id FROM pedidos WHERE id=:id AND token_acesso=:t"),
        {"id": pedido_id, "t": token_acesso})
    if not row.first():
        raise HTTPException(403, "Acesso negado")
    rows = await db.execute(
        text("SELECT id,nome,tipo_mime,tamanho_kb,descricao,processado,created_at FROM documentos_pedido WHERE pedido_id=:pid ORDER BY created_at"),
        {"pid": pedido_id})
    return {"documentos": [dict(r) for r in rows.mappings()]}
