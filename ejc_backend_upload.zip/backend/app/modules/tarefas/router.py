"""EJC - Gestao de Tarefas Internas + Dossies"""
from __future__ import annotations
import json, logging, os
from typing import Optional
from uuid import uuid4
from fastapi import APIRouter, Depends, Header, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.sql_safe import construir_set, validar_coluna
from app.core.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/tarefas", tags=["Tarefas e Dossies"])
ADMIN_KEY = os.getenv("ADMIN_API_KEY", "ejc_admin_dev_key")


class TarefaCreate(BaseModel):
    titulo: str
    descricao: Optional[str] = None
    prioridade: str = "media"
    atribuido_para: Optional[str] = None
    caso_id: Optional[str] = None
    pedido_id: Optional[str] = None
    data_vencimento: Optional[str] = None
    tipo: str = "revisao"

class TarefaUpdate(BaseModel):
    titulo: Optional[str] = None
    descricao: Optional[str] = None
    status: Optional[str] = None
    prioridade: Optional[str] = None
    atribuido_para: Optional[str] = None
    data_vencimento: Optional[str] = None


@router.post("/", status_code=201)
async def create_task(req: TarefaCreate, x_admin_key: str = Header(None), db: AsyncSession = Depends(get_db)):
    if x_admin_key != ADMIN_KEY: raise HTTPException(403, "Acesso negado")
    if req.prioridade not in ("baixa","media","alta","urgente"): raise HTTPException(422, "prioridade invalida")
    tid = str(uuid4())
    await db.execute(text("""
        INSERT INTO tarefas (id,titulo,descricao,prioridade,status,atribuido_para,caso_id,pedido_id,data_vencimento,tipo)
        VALUES (:id,:tit,:desc,:pri,'pendente',:attr,:cid,:pid,:dv,:tipo)
    """), {"id":tid,"tit":req.titulo,"desc":req.descricao,"pri":req.prioridade,
           "attr":req.atribuido_para,"cid":req.caso_id,"pid":req.pedido_id,
           "dv":req.data_vencimento,"tipo":req.tipo})
    await db.commit()
    return {"id": tid, "status": "pendente"}


@router.get("/")
async def list_tasks(
    status: Optional[str] = Query(None), prioridade: Optional[str] = Query(None),
    atribuido: Optional[str] = Query(None), tipo: Optional[str] = Query(None),
    caso_id: Optional[str] = Query(None), vencimento_ate: Optional[str] = Query(None),
    limit: int = Query(50, le=200),
    x_admin_key: str = Header(None), db: AsyncSession = Depends(get_db),
):
    if x_admin_key != ADMIN_KEY: raise HTTPException(403, "Acesso negado")
    filtros = []; params: dict = {"lim": limit}
    if status:         filtros.append("status=:status");       params["status"] = status
    if prioridade:     filtros.append("prioridade=:pri");      params["pri"] = prioridade
    if atribuido:      filtros.append("atribuido_para=:attr"); params["attr"] = atribuido
    if tipo:           filtros.append("tipo=:tipo");           params["tipo"] = tipo
    if vencimento_ate: filtros.append("data_vencimento<=:dv"); params["dv"] = vencimento_ate
    where = "WHERE " + " AND ".join(filtros) if filtros else ""
    rows = await db.execute(text(f"""
        SELECT * FROM tarefas {where}
        ORDER BY CASE prioridade WHEN 'urgente' THEN 1 WHEN 'alta' THEN 2 WHEN 'media' THEN 3 ELSE 4 END,
                 created_at DESC LIMIT :lim
    """), params)
    tarefas = [dict(r) for r in rows.mappings()]
    try:
        cnt = await db.execute(text("SELECT status, COUNT(*) as total FROM tarefas GROUP BY status"))
        contadores = {r["status"]: r["total"] for r in cnt.mappings()}
    except Exception: contadores = {}
    return {"tarefas": tarefas, "total": len(tarefas), "contadores": contadores}


@router.put("/{tarefa_id}")
async def update_task(tarefa_id: str, req: TarefaUpdate, x_admin_key: str = Header(None), db: AsyncSession = Depends(get_db)):
    if x_admin_key != ADMIN_KEY: raise HTTPException(403, "Acesso negado")
    if req.status and req.status not in ("pendente","em_andamento","concluida","cancelada"):
        raise HTTPException(422, "status invalido")
    sets = []; params = {"id": tarefa_id}
    for campo, val in req.model_dump(exclude_none=True).items():
        sets.append(f"{campo}=:{campo}"); params[campo] = val
    if not sets: raise HTTPException(422, "Nenhum campo para atualizar")
    sets.append("updated_at=NOW()")
    if req.status == "concluida": sets.append("concluida_em=NOW()")
    r = await db.execute(text(f"UPDATE tarefas SET {', '.join(sets)} WHERE id=:id RETURNING id"), params)
    if not r.first(): raise HTTPException(404, "Tarefa nao encontrada")
    await db.commit()
    return {"mensagem": "Atualizada", "id": tarefa_id}


@router.delete("/{tarefa_id}")
async def delete_task(tarefa_id: str, x_admin_key: str = Header(None), db: AsyncSession = Depends(get_db)):
    if x_admin_key != ADMIN_KEY: raise HTTPException(403, "Acesso negado")
    await db.execute(text("DELETE FROM tarefas WHERE id=:id"), {"id": tarefa_id})
    await db.commit()
    return {"mensagem": "Removida"}


@router.post("/{tarefa_id}/atribuir")
async def assign_task(tarefa_id: str, payload: dict, x_admin_key: str = Header(None), db: AsyncSession = Depends(get_db)):
    if x_admin_key != ADMIN_KEY: raise HTTPException(403, "Acesso negado")
    u = payload.get("usuario")
    if not u: raise HTTPException(422, "usuario obrigatorio")
    await db.execute(text("UPDATE tarefas SET atribuido_para=:u, updated_at=NOW() WHERE id=:id"), {"u":u,"id":tarefa_id})
    await db.commit()
    return {"mensagem": f"Atribuida a {u}"}


# ── DOSSIES ───────────────────────────────────────────────────────────────

class DossieCreate(BaseModel):
    titulo: str; descricao: Optional[str] = None
    area_juridica: Optional[str] = None; cliente_nome: Optional[str] = None
    tags: Optional[list[str]] = None

@router.post("/dossies", status_code=201)
async def create_dossie(req: DossieCreate, x_admin_key: str = Header(None), db: AsyncSession = Depends(get_db)):
    if x_admin_key != ADMIN_KEY: raise HTTPException(403, "Acesso negado")
    did = str(uuid4())
    await db.execute(text("""
        INSERT INTO dossies (id,titulo,descricao,area_juridica,cliente_nome,tags,status)
        VALUES (:id,:tit,:desc,:area,:cli,:tags::jsonb,'ativo')
    """), {"id":did,"tit":req.titulo,"desc":req.descricao,"area":req.area_juridica,
           "cli":req.cliente_nome,"tags":json.dumps(req.tags or [])})
    await db.commit()
    return {"id": did}

@router.get("/dossies")
async def list_dossies(status: str = Query("ativo"), area: Optional[str] = Query(None),
                       x_admin_key: str = Header(None), db: AsyncSession = Depends(get_db)):
    if x_admin_key != ADMIN_KEY: raise HTTPException(403, "Acesso negado")
    filtros = ["d.status=:st"]; params: dict = {"st": status}
    if area: filtros.append("d.area_juridica=:area"); params["area"] = area
    rows = await db.execute(text(f"""
        SELECT d.*, COUNT(dc.caso_id) as total_casos FROM dossies d
        LEFT JOIN dossie_casos dc ON dc.dossie_id = d.id
        WHERE {' AND '.join(filtros)} GROUP BY d.id ORDER BY d.created_at DESC
    """), params)
    return {"dossies": [dict(r) for r in rows.mappings()]}

@router.post("/dossies/{did}/casos")
async def add_caso(did: str, payload: dict, x_admin_key: str = Header(None), db: AsyncSession = Depends(get_db)):
    if x_admin_key != ADMIN_KEY: raise HTTPException(403, "Acesso negado")
    cid = payload.get("caso_id") or payload.get("pedido_id")
    if not cid: raise HTTPException(422, "caso_id obrigatorio")
    await db.execute(text("INSERT INTO dossie_casos (id,dossie_id,caso_id,nota) VALUES (:id,:did,:cid::uuid,:n) ON CONFLICT DO NOTHING"),
                     {"id":str(uuid4()),"did":did,"cid":cid,"n":payload.get("nota")})
    await db.commit()
    return {"mensagem": "Caso adicionado"}

@router.delete("/dossies/{did}")
async def archive_dossie(did: str, x_admin_key: str = Header(None), db: AsyncSession = Depends(get_db)):
    if x_admin_key != ADMIN_KEY: raise HTTPException(403, "Acesso negado")
    await db.execute(text("UPDATE dossies SET status='arquivado', updated_at=NOW() WHERE id=:id"), {"id":did})
    await db.commit()
    return {"mensagem": "Arquivado"}
