"""
EJC - Sistema Multi-Agentes (agentes/router.py)

Executa os 24 agentes especializados em 6 frentes.
Cada agente tem system_prompt especifico + ferramentas integradas.
Suporta: execucao simples, streaming SSE, execucao em lote.
"""
from __future__ import annotations
import asyncio
import json
import logging
import time
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.llm_provider import get_llm_provider
from app.modules.agentes.registry import AGENTES, AGENTE_POR_ID, AGENTES_POR_FRENTE, FRENTES
from app.modules.auditoria.middleware import adicionar_aviso, AVISO_CURTO

# Fragmentos que indicam que o aviso ja esta presente na resposta
_INDICADORES_AVISO = (
    "revisão obrigatória",
    "revisao obrigatoria",
    "aviso juridico",
    "aviso jurídico",
    "assistência de ia",
    "assistencia de ia",
    "ia de suporte",
    "exige revisão",
    "exige revisao",
    "não substitui",
    "nao substitui",
    "advogado responsável",
    "advogado responsavel",
)

def _garantir_aviso(resposta: str) -> str:
    """
    Garante que toda resposta de agente contém o aviso jurídico obrigatório.
    Se o LLM não incluiu (modelos menores esquecem), injeta programaticamente.
    """
    lower = resposta.lower()
    if any(ind in lower for ind in _INDICADORES_AVISO):
        return resposta  # ja tem aviso — nao duplica
    return resposta + f"\n\n---\n\n{AVISO_CURTO}"

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/agentes", tags=["Agentes Especializados"])


# ── Modelos de entrada ────────────────────────────────────────────────────

class ExecucaoReq(BaseModel):
    agente_id: str
    prompt: str                              # instrucao especifica
    contexto: Optional[dict] = None          # dados estruturados extras
    caso_id: Optional[str] = None
    stream: bool = False
    salvar_historico: bool = True


class LoteReq(BaseModel):
    agente_ids: list[str]                   # lista de agentes para executar
    prompt: str                             # mesmo prompt para todos
    contexto: Optional[dict] = None
    caso_id: Optional[str] = None


# ── Contexto enriquecido: busca dados do banco para alimentar o agente ──

async def _enriquecer_contexto(
    agente_id: str,
    caso_id: Optional[str],
    contexto: Optional[dict],
    db: AsyncSession,
) -> str:
    """Busca dados relevantes do banco conforme as ferramentas do agente."""
    agente = AGENTE_POR_ID.get(agente_id)
    if not agente:
        return ""

    partes: list[str] = []
    ferramentas = set(agente.ferramentas)

    # Contexto manual passado pelo chamador
    if contexto:
        partes.append(f"CONTEXTO FORNECIDO:\n{json.dumps(contexto, ensure_ascii=False, indent=2)}")

    # Dados do caso (se informado)
    if caso_id and "database" in ferramentas:
        try:
            row = await db.execute(text("""
                SELECT c.titulo, c.area_juridica, c.status, c.numero_processo,
                       c.tribunal, c.descricao, c.estrategia_interna,
                       cl.nome AS cliente_nome, cl.cpf, cl.cnpj, cl.email
                FROM casos c
                LEFT JOIN clientes cl ON cl.id = c.cliente_id
                WHERE c.id = :id
            """), {"id": caso_id})
            caso = row.mappings().first()
            if caso:
                partes.append(f"DADOS DO CASO:\n{json.dumps(dict(caso), ensure_ascii=False, default=str, indent=2)}")
        except Exception as e:
            logger.debug(f"[Agente:{agente_id}] Caso nao encontrado: {e}")

    # Prazos do caso
    if caso_id and "database" in ferramentas and agente.frente == "Prazos & Acompanhamento":
        try:
            rows = await db.execute(text("""
                SELECT titulo, tipo_prazo, data_vencimento, status, prioridade
                FROM prazos WHERE caso_id = :id ORDER BY data_vencimento ASC LIMIT 10
            """), {"id": caso_id})
            prazos = [dict(r) for r in rows.mappings()]
            if prazos:
                partes.append(f"PRAZOS DO CASO:\n{json.dumps(prazos, ensure_ascii=False, default=str, indent=2)}")
        except Exception: pass

    # Jurisprudencia relevante (se ferramenta disponivel)
    if "juris" in ferramentas and contexto and contexto.get("area"):
        try:
            from app.modules.pesquisa.jurisprudencia_engine import get_engine
            engine = get_engine()
            query = contexto.get("query_juris") or contexto.get("area", "")
            if query:
                res = await asyncio.wait_for(
                    engine.buscar(query, db, area=contexto.get("area"), top_k=3, incluir_temas=True),
                    timeout=8.0
                )
                items = res.get("resultados", [])
                if items:
                    juris_txt = "\n".join(
                        f"- [{r.get('tribunal')}] {r.get('ementa','')[:200]}"
                        for r in items[:3]
                    )
                    partes.append(f"JURISPRUDENCIA RELEVANTE:\n{juris_txt}")
        except Exception as e:
            logger.debug(f"[Agente:{agente_id}] Juris falhou: {e}")

    # Calculos (para agentes de prazos/financeiro)
    if caso_id and "calculos" in ferramentas:
        try:
            rows = await db.execute(text("""
                SELECT tipo_honorario, valor_fixo, status_pagamento
                FROM honorarios WHERE caso_id = :id LIMIT 3
            """), {"id": caso_id})
            hons = [dict(r) for r in rows.mappings()]
            if hons:
                partes.append(f"HONORARIOS:\n{json.dumps(hons, ensure_ascii=False, default=str)}")
        except Exception: pass

    return "\n\n".join(partes)


# ── Execucao do agente ────────────────────────────────────────────────────

async def _executar(agente_id: str, prompt_usuario: str, contexto_enriquecido: str) -> str:
    """Chama o LLM com o system prompt do agente + contexto + prompt do usuario."""
    agente = AGENTE_POR_ID.get(agente_id)
    if not agente:
        raise HTTPException(404, f"Agente '{agente_id}' nao encontrado")

    llm = get_llm_provider()

    # Monta o prompt final
    prompt_final = prompt_usuario
    if contexto_enriquecido:
        prompt_final = f"{contexto_enriquecido}\n\n---\n\nINSTRUCAO:\n{prompt_usuario}"

    try:
        resposta = await llm.generate(
            prompt=prompt_final,
            system=agente.system_prompt,
            max_tokens=agente.max_tokens,
            temperature=agente.temperatura,
        )
        return _garantir_aviso(resposta)
    except Exception as e:
        logger.error(f"[Agente:{agente_id}] LLM falhou: {e}")
        raise HTTPException(500, f"Erro ao executar agente: {e}")


async def _salvar_historico(
    agente_id: str,
    caso_id: Optional[str],
    prompt: str,
    resposta: str,
    tempo_ms: int,
    db: AsyncSession,
):
    """Salva execucao do agente no historico para auditoria."""
    try:
        await db.execute(text("""
            INSERT INTO agente_execucoes (agente_id, caso_id, prompt, resposta, tempo_ms)
            VALUES (:aid, :cid, :p, :r, :t)
        """), {
            "aid": agente_id,
            "cid": caso_id,
            "p": prompt[:500],
            "r": resposta[:2000],
            "t": tempo_ms,
        })
        await db.commit()
    except Exception:
        pass  # historico nunca bloqueia execucao


# ── ENDPOINTS ─────────────────────────────────────────────────────────────

@router.get("/")
async def listar_agentes():
    """Lista todos os agentes organizados por frente."""
    return {
        "frentes": [
            {
                "nome": frente,
                "agentes": [
                    {
                        "id": a.id,
                        "nome": a.nome,
                        "emoji": a.emoji,
                        "descricao": a.descricao,
                        "ferramentas": a.ferramentas,
                    }
                    for a in AGENTES_POR_FRENTE.get(frente, [])
                ],
            }
            for frente in FRENTES
        ],
        "total": len(AGENTES),
    }


@router.get("/{agente_id}")
async def detalhe_agente(agente_id: str):
    """Retorna detalhes de um agente especifico."""
    a = AGENTE_POR_ID.get(agente_id)
    if not a:
        raise HTTPException(404, f"Agente '{agente_id}' nao encontrado")
    return {
        "id": a.id, "nome": a.nome, "emoji": a.emoji,
        "frente": a.frente, "descricao": a.descricao,
        "ferramentas": a.ferramentas,
        "temperatura": a.temperatura, "max_tokens": a.max_tokens,
    }


@router.post("/executar")
async def executar_agente(req: ExecucaoReq, db: AsyncSession = Depends(get_db)):
    """
    Executa um agente especifico com o prompt e contexto fornecidos.
    Suporta modo streaming via SSE (req.stream=True).
    """
    agente = AGENTE_POR_ID.get(req.agente_id)
    if not agente:
        raise HTTPException(404, f"Agente '{req.agente_id}' nao encontrado")

    ctx = await _enriquecer_contexto(req.agente_id, req.caso_id, req.contexto, db)
    t0 = time.monotonic()

    # Modo streaming
    if req.stream:
        async def _gen():
            llm = get_llm_provider()
            prompt_final = f"{ctx}\n\n---\n\nINSTRUCAO:\n{req.prompt}" if ctx else req.prompt
            buffer = []
            async for chunk in llm.stream(
                prompt=prompt_final,
                system=agente.system_prompt,
                max_tokens=agente.max_tokens,
            ):
                buffer.append(chunk)
                yield f"data: {json.dumps({'delta': chunk}, ensure_ascii=False)}\n\n"
            # Verifica se o aviso está no texto completo; se não, envia como chunk final
            texto_completo = "".join(buffer)
            if not any(ind in texto_completo.lower() for ind in _INDICADORES_AVISO):
                aviso_chunk = f"\n\n---\n\n{AVISO_CURTO}"
                yield f"data: {json.dumps({'delta': aviso_chunk}, ensure_ascii=False)}\n\n"
            yield f"data: {json.dumps({'done': True, 'agente': agente.nome})}\n\n"

        return StreamingResponse(_gen(), media_type="text/event-stream")

    # Modo normal
    resposta = await _executar(req.agente_id, req.prompt, ctx)
    tempo_ms = int((time.monotonic() - t0) * 1000)

    if req.salvar_historico:
        await _salvar_historico(req.agente_id, req.caso_id, req.prompt, resposta, tempo_ms, db)

    return {
        "agente_id":  agente.id,
        "agente_nome": agente.nome,
        "frente":     agente.frente,
        "resposta":   resposta,
        "tempo_ms":   tempo_ms,
        "requires_human_review": True,
        "aviso_juridico": True,
    }


@router.post("/lote")
async def executar_lote(req: LoteReq, db: AsyncSession = Depends(get_db)):
    """
    Executa multiplos agentes em paralelo com o mesmo prompt.
    Util para: buscar jurisprudencia + elaborar peticao + gerar checklist simultaneamente.
    Limite: 5 agentes por lote.
    """
    if len(req.agente_ids) > 5:
        raise HTTPException(422, "Maximo 5 agentes por lote")
    invalidos = [aid for aid in req.agente_ids if aid not in AGENTE_POR_ID]
    if invalidos:
        raise HTTPException(404, f"Agentes nao encontrados: {invalidos}")

    t0 = time.monotonic()
    ctx = await _enriquecer_contexto(req.agente_ids[0], req.caso_id, req.contexto, db)

    async def _exec_um(agente_id: str):
        try:
            t = time.monotonic()
            r = await _executar(agente_id, req.prompt, ctx)
            return {
                "agente_id": agente_id,
                "agente_nome": AGENTE_POR_ID[agente_id].nome,
                "resposta": r,
                "tempo_ms": int((time.monotonic() - t) * 1000),
                "ok": True,
            }
        except Exception as e:
            return {"agente_id": agente_id, "ok": False, "erro": str(e)}

    resultados = await asyncio.gather(*[_exec_um(aid) for aid in req.agente_ids])

    return {
        "resultados": resultados,
        "tempo_total_ms": int((time.monotonic() - t0) * 1000),
        "requires_human_review": True,
    }


@router.get("/historico/execucoes")
async def historico_execucoes(
    agente_id: Optional[str] = None,
    caso_id: Optional[str] = None,
    limit: int = 20,
    db: AsyncSession = Depends(get_db),
):
    """Retorna historico de execucoes dos agentes."""
    filtros = []; params: dict = {"lim": limit}
    if agente_id: filtros.append("agente_id=:aid"); params["aid"] = agente_id
    if caso_id:   filtros.append("caso_id=:cid");   params["cid"] = caso_id
    where = "WHERE " + " AND ".join(filtros) if filtros else ""
    try:
        rows = await db.execute(text(f"""
            SELECT id, agente_id, caso_id, SUBSTRING(prompt,1,100) AS prompt_preview,
                   SUBSTRING(resposta,1,200) AS resposta_preview, tempo_ms, created_at
            FROM agente_execucoes {where}
            ORDER BY created_at DESC LIMIT :lim
        """), params)
        return {"execucoes": [dict(r) for r in rows.mappings()]}
    except Exception:
        return {"execucoes": []}
