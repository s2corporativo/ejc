"""
EJC — Módulo Diff de Contratos (modules/diff/router.py)

Compara duas versões de um contrato e exibe:
  - Diff visual colorido: verde (adicionado), vermelho (removido), amarelo (movido)
  - Resumo em linguagem natural das alterações (via LLM)
  - Análise de risco das novas cláusulas
  - Exportação do diff como HTML/DOCX

Suporta:
  - PDF, DOCX, TXT (extrai texto automaticamente)
  - Markdown (contratos do EJC)
  - Texto puro

Dependência: pip install diff-match-patch (leve, sem GPU)
"""
from __future__ import annotations

import io
import json
import logging
import re
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.analise.service import AnaliseService
from app.modules.redacao.service import LegalDraftService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/diff", tags=["Diff de Contratos — Comparação de Versões"])

_analise: Optional[AnaliseService] = None
_llm: Optional[LegalDraftService] = None


def get_analise():
    global _analise
    if not _analise:
        _analise = AnaliseService()
    return _analise


def get_llm():
    global _llm
    if not _llm:
        _llm = LegalDraftService()
    return _llm


# ── Núcleo do diff ────────────────────────────────────────────────────

def _calcular_diff(texto1: str, texto2: str) -> dict:
    """
    Calcula diff entre dois textos usando diff-match-patch.
    Retorna: operações, estatísticas e HTML colorido.
    """
    try:
        from diff_match_patch import diff_match_patch
    except ImportError:
        raise RuntimeError(
            "diff-match-patch não instalado. "
            "Execute: pip install diff-match-patch"
        )

    dmp = diff_match_patch()
    dmp.Diff_Timeout = 10.0

    # Divide por parágrafos para diff mais legível
    a, b, linhas = dmp.diff_linesToChars(texto1, texto2)
    diffs = dmp.diff_main(a, b, False)
    dmp.diff_charsToLines(diffs, linhas)
    dmp.diff_cleanupSemantic(diffs)

    # Processa operações
    INSERT  = 1   # diff_match_patch.DIFF_INSERT
    DELETE  = -1  # diff_match_patch.DIFF_DELETE
    EQUAL   = 0   # diff_match_patch.DIFF_EQUAL

    linhas_add = linhas_del = linhas_igual = 0
    html_parts = []
    operacoes  = []

    for op, texto in diffs:
        linhas_no_bloco = texto.count("\n") + (1 if texto and not texto.endswith("\n") else 0)

        if op == INSERT:
            linhas_add += linhas_no_bloco
            esc = _html_escape(texto)
            html_parts.append(f'<ins class="diff-add">{esc}</ins>')
            operacoes.append({"op": "add", "texto": texto[:200]})

        elif op == DELETE:
            linhas_del += linhas_no_bloco
            esc = _html_escape(texto)
            html_parts.append(f'<del class="diff-del">{esc}</del>')
            operacoes.append({"op": "del", "texto": texto[:200]})

        else:  # EQUAL
            linhas_igual += linhas_no_bloco
            esc = _html_escape(texto)
            html_parts.append(f'<span class="diff-eq">{esc}</span>')

    total = max(1, linhas_add + linhas_del + linhas_igual)
    pct_alterado = round((linhas_add + linhas_del) / total * 100, 1)

    return {
        "html": "".join(html_parts),
        "linhas_adicionadas":  linhas_add,
        "linhas_removidas":    linhas_del,
        "linhas_inalteradas":  linhas_igual,
        "percentual_alterado": pct_alterado,
        "operacoes":           operacoes[:50],  # limita para o payload
    }


def _html_escape(texto: str) -> str:
    return (texto
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _extrair_texto(file_bytes: bytes, filename: str) -> str:
    """Extrai texto de PDF, DOCX ou TXT."""
    from app.modules.analise.service import AnaliseService
    svc = AnaliseService()
    return svc.extrair_texto(file_bytes, filename)


def _html_completo(titulo_v1: str, titulo_v2: str, html_diff: str) -> str:
    """Monta o HTML do relatório de diff com estilo embutido."""
    return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>EJC — Diff: {titulo_v1} → {titulo_v2}</title>
<style>
  body {{ font-family: 'Georgia', serif; max-width: 900px; margin: 40px auto;
         background: #0d1117; color: #b8c4d0; line-height: 1.8; padding: 0 20px; }}
  h1 {{ color: #e8bc4a; font-size: 1.4rem; border-bottom: 1px solid #1f2b3e; padding-bottom: 12px; }}
  .diff-add {{ background: rgba(52, 211, 153, 0.15); color: #34d399;
               text-decoration: none; border-left: 3px solid #34d399;
               padding-left: 6px; display: block; }}
  .diff-del {{ background: rgba(224, 90, 106, 0.12); color: #e05a6a;
               text-decoration: line-through; border-left: 3px solid #e05a6a;
               padding-left: 6px; display: block; }}
  .diff-eq  {{ color: #8896a8; display: block; }}
  .stats {{ background: #13191f; border: 1px solid #1f2b3e; border-radius: 8px;
            padding: 16px; margin: 20px 0; display: flex; gap: 24px; }}
  .stat {{ text-align: center; }}
  .stat-val {{ font-size: 1.6rem; font-weight: bold; }}
  .green {{ color: #34d399; }} .red {{ color: #e05a6a; }}
  .gold  {{ color: #c9960a; }}
  pre, code {{ white-space: pre-wrap; word-break: break-word; font-family: 'Courier New'; }}
  .footer {{ font-size: 0.75rem; color: #4a5568; margin-top: 40px;
             border-top: 1px solid #1f2b3e; padding-top: 12px; }}
</style>
</head>
<body>
<h1>⚖️ EJC — Comparação de Versões</h1>
<p><strong>Versão 1:</strong> {titulo_v1} &nbsp;→&nbsp; <strong>Versão 2:</strong> {titulo_v2}</p>
<div class="diff-content">{html_diff}</div>
<div class="footer">Gerado pelo Ecossistema Jurídico Clovis (EJC) — Revisão humana obrigatória.</div>
</body>
</html>"""


# ── Endpoints ──────────────────────────────────────────────────────────

@router.post("/comparar")
async def comparar_documentos(
    versao1: UploadFile = File(..., description="Versão original (PDF, DOCX, TXT)"),
    versao2: UploadFile = File(..., description="Versão nova/atualizada"),
    analisar_com_ia: bool = Form(True, description="Usar LLM para resumir as alterações"),
    db: AsyncSession = Depends(get_db),
    llm: LegalDraftService = Depends(get_llm),
):
    """
    Compara duas versões de um documento jurídico.
    Retorna diff visual + resumo das alterações + análise de risco.
    """
    bytes1 = await versao1.read()
    bytes2 = await versao2.read()

    try:
        texto1 = _extrair_texto(bytes1, versao1.filename or "v1.txt")
        texto2 = _extrair_texto(bytes2, versao2.filename or "v2.txt")
    except Exception as e:
        raise HTTPException(422, f"Erro ao extrair texto: {e}")

    if not texto1.strip() or not texto2.strip():
        raise HTTPException(422, "Nenhum texto extraído de um dos arquivos.")

    try:
        resultado = _calcular_diff(texto1, texto2)
    except RuntimeError as e:
        raise HTTPException(503, str(e))

    resposta: dict = {
        "versao1": versao1.filename,
        "versao2": versao2.filename,
        "estatisticas": {
            "linhas_adicionadas":  resultado["linhas_adicionadas"],
            "linhas_removidas":    resultado["linhas_removidas"],
            "linhas_inalteradas":  resultado["linhas_inalteradas"],
            "percentual_alterado": resultado["percentual_alterado"],
        },
        "html_diff": resultado["html"],
        "analise_ia": None,
    }

    if analisar_com_ia and resultado["linhas_adicionadas"] + resultado["linhas_removidas"] > 0:
        # Monta resumo das alterações para o LLM
        adds = [o["texto"] for o in resultado["operacoes"] if o["op"] == "add"][:10]
        dels = [o["texto"] for o in resultado["operacoes"] if o["op"] == "del"][:10]

        prompt_diff = f"""Analise as alterações entre duas versões de um contrato/documento jurídico.

TRECHOS ADICIONADOS (versão nova):
{chr(10).join(f'+ {t[:200]}' for t in adds) or 'Nenhum'}

TRECHOS REMOVIDOS (versão original):
{chr(10).join(f'- {t[:200]}' for t in dels) or 'Nenhum'}

Responda em Markdown com:
## Resumo das Alterações
[2-3 parágrafos descrevendo o que mudou]

## Cláusulas Novas (Risco)
[Liste cláusulas adicionadas que podem ser desvantajosas]

## Cláusulas Removidas (Impacto)
[Liste cláusulas removidas e o impacto da ausência]

## Avaliação de Risco
[BAIXO / MÉDIO / ALTO / CRÍTICO — com justificativa]

## Recomendação
[O que o advogado deve negociar ou questionar]"""

        try:
            analise = await llm.answer_from_context(
                query="análise de alterações contratuais",
                context=prompt_diff,
            )
            resposta["analise_ia"] = analise
        except Exception as e:
            resposta["analise_ia"] = f"Análise IA indisponível: {e}"

    return resposta


@router.post("/comparar-texto")
async def comparar_texto(payload: dict):
    """
    Compara dois textos enviados diretamente (sem upload de arquivo).
    Ideal para comparar versões de peças geradas pelo EJC.
    """
    texto1 = payload.get("texto1", "")
    texto2 = payload.get("texto2", "")
    titulo1 = payload.get("titulo1", "Versão 1")
    titulo2 = payload.get("titulo2", "Versão 2")

    if not texto1 or not texto2:
        raise HTTPException(422, "Campos 'texto1' e 'texto2' obrigatórios.")

    try:
        resultado = _calcular_diff(texto1, texto2)
    except RuntimeError as e:
        raise HTTPException(503, str(e))

    return {
        "titulo1": titulo1,
        "titulo2": titulo2,
        "estatisticas": {
            "linhas_adicionadas":  resultado["linhas_adicionadas"],
            "linhas_removidas":    resultado["linhas_removidas"],
            "percentual_alterado": resultado["percentual_alterado"],
        },
        "html_diff": resultado["html"],
    }


@router.post("/exportar-html")
async def exportar_html(payload: dict):
    """
    Retorna o relatório de diff como página HTML completa (download).
    """
    texto1  = payload.get("texto1", "")
    texto2  = payload.get("texto2", "")
    titulo1 = payload.get("titulo1", "Versão Original")
    titulo2 = payload.get("titulo2", "Versão Nova")

    if not texto1 or not texto2:
        raise HTTPException(422, "Textos obrigatórios.")

    try:
        resultado = _calcular_diff(texto1, texto2)
    except RuntimeError as e:
        raise HTTPException(503, str(e))

    html = _html_completo(titulo1, titulo2, resultado["html"])
    return HTMLResponse(
        content=html,
        headers={"Content-Disposition": "attachment; filename=diff_contrato.html"},
    )
