"""
EJC — Índice Remissivo de Leis e Súmulas + Índice de Teses Jurídicas (indice/router.py)

Endpoints:
  LEIS         GET /indice/leis        — busca com full-text search
               GET /indice/leis/{id}   — detalhe
               POST /indice/leis       — adiciona (admin/advogado)
               GET /indice/leis/diplomas — lista diplomas disponíveis
               GET /indice/leis/areas   — leis por área jurídica

  SÚMULAS      GET /indice/sumulas     — busca com filtros
               GET /indice/sumulas/{id}
               POST /indice/sumulas
               GET /indice/sumulas/tribunais — agrupa por tribunal

  TESES        GET /indice/teses       — busca por área/subárea/viabilidade
               GET /indice/teses/{id}
               POST /indice/teses
               PUT /indice/teses/{id}
               GET /indice/teses/areas  — todas as áreas com contagem
               GET /indice/teses/mapa   — mapa completo área→teses

  BUSCA UNIFICADA
               GET /indice/buscar      — busca em leis + súmulas + teses simultaneamente
"""
from __future__ import annotations
import asyncio
import logging
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db, get_db_readonly
from app.core.db_helpers import db_fetch_all, db_fetch_one

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/indice", tags=["Índice Remissivo e Teses"])

AREAS = [
    "trabalhista", "consumidor", "civel", "previdenciario", "tributario",
    "penal", "familia", "constitucional", "bancario", "administrativo",
    "empresarial", "ambiental", "digital", "imobiliario",
]


# ══════════════════════════════════════════════════════════════════════════
# LEIS E DISPOSITIVOS
# ══════════════════════════════════════════════════════════════════════════

class LeiCreate(BaseModel):
    diploma: str
    numero_lei: Optional[str] = None
    artigo: str
    inciso: Optional[str] = None
    alinea: Optional[str] = None
    paragrafo: Optional[str] = None
    texto: str
    area_juridica: str
    tema: Optional[str] = None
    palavras_chave: Optional[list[str]] = None
    fonte_oficial: Optional[str] = None


@router.get("/leis")
async def buscar_leis(
    q:          Optional[str] = Query(None, description="Busca no texto e tema"),
    diploma:    Optional[str] = Query(None, description="Ex: CDC, CLT, CC"),
    area:       Optional[str] = Query(None),
    tema:       Optional[str] = Query(None),
    artigo:     Optional[str] = Query(None),
    limit:      int = Query(50, le=200),
    offset:     int = Query(0),
    db: AsyncSession = Depends(get_db_readonly),
):
    """Busca dispositivos legais com full-text search em português."""
    filtros = ["ativo = TRUE"]; params: dict = {"lim": limit, "off": offset}

    if q:
        filtros.append(
            "to_tsvector('portuguese', COALESCE(texto,'') || ' ' || COALESCE(tema,'') || ' ' || diploma) "
            "@@ plainto_tsquery('portuguese', :q)"
        )
        params["q"] = q
    if diploma: filtros.append("LOWER(diploma) LIKE LOWER(:diploma)"); params["diploma"] = f"%{diploma}%"
    if area:    filtros.append("area_juridica = :area");              params["area"] = area
    if tema:    filtros.append("LOWER(tema) LIKE LOWER(:tema)");       params["tema"] = f"%{tema}%"
    if artigo:  filtros.append("artigo ILIKE :artigo");                params["artigo"] = f"%{artigo}%"

    where = "WHERE " + " AND ".join(filtros)
    leis = await db_fetch_all(db, f"""
        SELECT id, diploma, numero_lei, artigo, inciso, paragrafo, alinea,
               LEFT(texto, 300) AS texto_preview, texto,
               area_juridica, tema, palavras_chave, fonte_oficial, updated_at
        FROM indice_leis {where}
        ORDER BY diploma, artigo
        LIMIT :lim OFFSET :off
    """, params)

    cnt = await db_fetch_one(db, f"SELECT COUNT(*) AS n FROM indice_leis {where}",
                              {k:v for k,v in params.items() if k not in ('lim','off')})
    return {"leis": leis, "total": cnt["n"] if cnt else 0, "limit": limit, "offset": offset}


@router.get("/leis/diplomas")
async def listar_diplomas(db: AsyncSession = Depends(get_db_readonly)):
    """Lista todos os diplomas disponíveis agrupados por área."""
    rows = await db_fetch_all(db, """
        SELECT diploma, area_juridica, numero_lei,
               COUNT(*) AS total_artigos
        FROM indice_leis WHERE ativo=TRUE
        GROUP BY diploma, area_juridica, numero_lei
        ORDER BY area_juridica, diploma
    """)
    # Agrupa por área
    por_area: dict[str, list] = {}
    for r in rows:
        area = r.get("area_juridica", "outros")
        por_area.setdefault(area, []).append(r)
    return {"por_area": por_area, "total_diplomas": len(rows)}


@router.get("/leis/{lei_id}")
async def detalhe_lei(lei_id: str, db: AsyncSession = Depends(get_db_readonly)):
    lei = await db_fetch_one(db, "SELECT * FROM indice_leis WHERE id=:id", {"id": lei_id})
    if not lei: raise HTTPException(404, "Dispositivo não encontrado")
    # Busca teses que citam esta lei
    teses = await db_fetch_all(db, """
        SELECT id, titulo, area_juridica, viabilidade
        FROM indice_teses
        WHERE :artigo = ANY(leis) AND status='ativa'
        ORDER BY uso_count DESC LIMIT 5
    """, {"artigo": f"{lei['diploma']} {lei['artigo']}"})
    lei["teses_relacionadas"] = teses
    return lei


@router.post("/leis", status_code=201)
async def criar_lei(req: LeiCreate, db: AsyncSession = Depends(get_db)):
    lid = str(uuid4())
    await db.execute(text("""
        INSERT INTO indice_leis
            (id, diploma, numero_lei, artigo, inciso, alinea, paragrafo, texto,
             area_juridica, tema, palavras_chave, fonte_oficial)
        VALUES (:id,:dip,:nlei,:art,:inc,:ali,:par,:txt,:area,:tema,:kw,:fonte)
    """), {
        "id": lid, "dip": req.diploma, "nlei": req.numero_lei,
        "art": req.artigo, "inc": req.inciso, "ali": req.alinea,
        "par": req.paragrafo, "txt": req.texto, "area": req.area_juridica,
        "tema": req.tema, "kw": req.palavras_chave, "fonte": req.fonte_oficial,
    })
    await db.commit()
    return {"id": lid}


# ══════════════════════════════════════════════════════════════════════════
# SÚMULAS
# ══════════════════════════════════════════════════════════════════════════

class SumulaCreate(BaseModel):
    tribunal: str
    numero: int
    tipo: str = "sumula"
    enunciado: str
    area_juridica: str
    temas: Optional[list[str]] = None
    status: str = "vigente"
    data_edicao: Optional[str] = None
    leis_relacionadas: Optional[list[str]] = None
    palavras_chave: Optional[list[str]] = None
    fonte_oficial: Optional[str] = None


@router.get("/sumulas")
async def buscar_sumulas(
    q:         Optional[str] = Query(None),
    tribunal:  Optional[str] = Query(None),
    area:      Optional[str] = Query(None),
    tipo:      Optional[str] = Query(None),
    status:    str = Query("vigente"),
    numero:    Optional[int] = Query(None),
    limit:     int = Query(50, le=200),
    offset:    int = Query(0),
    db: AsyncSession = Depends(get_db_readonly),
):
    """Busca súmulas com full-text search."""
    filtros = [f"status = '{status}'"]; params: dict = {"lim": limit, "off": offset}

    if q:
        filtros.append(
            "to_tsvector('portuguese', enunciado || ' ' || COALESCE(array_to_string(temas,' '),'')) "
            "@@ plainto_tsquery('portuguese', :q)"
        )
        params["q"] = q
    if tribunal: filtros.append("UPPER(tribunal) = UPPER(:trib)"); params["trib"] = tribunal
    if area:     filtros.append("area_juridica = :area");           params["area"] = area
    if tipo:     filtros.append("tipo = :tipo");                    params["tipo"] = tipo
    if numero:   filtros.append("numero = :num");                   params["num"] = numero

    where = "WHERE " + " AND ".join(filtros)
    sums = await db_fetch_all(db, f"""
        SELECT id, tribunal, numero, tipo, LEFT(enunciado, 400) AS enunciado,
               area_juridica, temas, status, data_edicao, leis_relacionadas,
               palavras_chave, fonte_oficial
        FROM indice_sumulas {where}
        ORDER BY tribunal, numero
        LIMIT :lim OFFSET :off
    """, params)

    cnt = await db_fetch_one(db, f"SELECT COUNT(*) AS n FROM indice_sumulas {where}",
                              {k:v for k,v in params.items() if k not in ('lim','off')})
    return {"sumulas": sums, "total": cnt["n"] if cnt else 0}


@router.get("/sumulas/tribunais")
async def sumulas_por_tribunal(
    area: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db_readonly),
):
    """Agrupa súmulas por tribunal com contagens."""
    where = "WHERE status='vigente'" + (f" AND area_juridica='{area}'" if area else "")
    rows = await db_fetch_all(db, f"""
        SELECT tribunal, tipo, COUNT(*) AS total,
               array_agg(DISTINCT area_juridica ORDER BY area_juridica) AS areas
        FROM indice_sumulas {where}
        GROUP BY tribunal, tipo
        ORDER BY tribunal, tipo
    """)
    # Agrupa por tribunal
    por_tribunal: dict[str, dict] = {}
    for r in rows:
        t = r["tribunal"]
        if t not in por_tribunal:
            por_tribunal[t] = {"tribunal": t, "tipos": {}}
        por_tribunal[t]["tipos"][r["tipo"]] = {
            "total": r["total"], "areas": r["areas"]
        }
    return {"por_tribunal": list(por_tribunal.values()), "total_registros": sum(r["total"] for r in rows)}


@router.get("/sumulas/{sumula_id}")
async def detalhe_sumula(sumula_id: str, db: AsyncSession = Depends(get_db_readonly)):
    s = await db_fetch_one(db, "SELECT * FROM indice_sumulas WHERE id=:id", {"id": sumula_id})
    if not s: raise HTTPException(404, "Súmula não encontrada")
    # Teses que citam esta súmula
    teses = await db_fetch_all(db, """
        SELECT id, titulo, area_juridica, viabilidade
        FROM indice_teses
        WHERE :ref = ANY(sumulas) AND status='ativa'
        ORDER BY uso_count DESC LIMIT 5
    """, {"ref": f"Súmula {s['numero']} {s['tribunal']}"})
    s["teses_relacionadas"] = teses
    return s


@router.post("/sumulas", status_code=201)
async def criar_sumula(req: SumulaCreate, db: AsyncSession = Depends(get_db)):
    sid = str(uuid4())
    try:
        await db.execute(text("""
            INSERT INTO indice_sumulas
                (id, tribunal, numero, tipo, enunciado, area_juridica, temas,
                 status, data_edicao, leis_relacionadas, palavras_chave, fonte_oficial)
            VALUES (:id,:trib,:num,:tipo,:enun,:area,:temas,:st,:de,:leis,:kw,:fonte)
        """), {
            "id": sid, "trib": req.tribunal.upper(), "num": req.numero,
            "tipo": req.tipo, "enun": req.enunciado, "area": req.area_juridica,
            "temas": req.temas, "st": req.status, "de": req.data_edicao,
            "leis": req.leis_relacionadas, "kw": req.palavras_chave, "fonte": req.fonte_oficial,
        })
        await db.commit()
    except Exception as e:
        if "unique" in str(e).lower():
            raise HTTPException(409, f"Súmula {req.numero} do {req.tribunal} já existe")
        raise
    return {"id": sid}


# ══════════════════════════════════════════════════════════════════════════
# ÍNDICE DE TESES JURÍDICAS
# ══════════════════════════════════════════════════════════════════════════

class TeseCreate(BaseModel):
    titulo: str
    area_juridica: str
    subarea: Optional[str] = None
    tese: str
    fundamentos: str
    argumentos: Optional[str] = None
    contra_argumento: Optional[str] = None
    jurisprudencias: Optional[list[str]] = None
    sumulas: Optional[list[str]] = None
    leis: Optional[list[str]] = None
    viabilidade: str = "media"
    tipo_acao: Optional[list[str]] = None
    tags: Optional[list[str]] = None


@router.get("/teses")
async def buscar_teses(
    q:          Optional[str] = Query(None),
    area:       Optional[str] = Query(None),
    subarea:    Optional[str] = Query(None),
    viabilidade: Optional[str] = Query(None),
    status:     str = Query("ativa"),
    tipo_acao:  Optional[str] = Query(None),
    limit:      int = Query(50, le=200),
    offset:     int = Query(0),
    db: AsyncSession = Depends(get_db_readonly),
):
    """Busca teses jurídicas com full-text search."""
    filtros = ["status = :st"]; params: dict = {"lim": limit, "off": offset, "st": status}

    if q:
        filtros.append(
            "to_tsvector('portuguese', titulo || ' ' || tese || ' ' || COALESCE(fundamentos,'') || ' ' || COALESCE(array_to_string(tags,' '),'')) "
            "@@ plainto_tsquery('portuguese', :q)"
        )
        params["q"] = q
    if area:        filtros.append("area_juridica = :area");           params["area"] = area
    if subarea:     filtros.append("LOWER(subarea) LIKE LOWER(:sub)"); params["sub"] = f"%{subarea}%"
    if viabilidade: filtros.append("viabilidade = :via");              params["via"] = viabilidade
    if tipo_acao:   filtros.append(":tpa = ANY(tipo_acao)");           params["tpa"] = tipo_acao

    where = "WHERE " + " AND ".join(filtros)
    teses = await db_fetch_all(db, f"""
        SELECT id, titulo, area_juridica, subarea, tese, viabilidade,
               tipo_acao, tags, sumulas, leis, jurisprudencias,
               uso_count, casos_vinculados, updated_at
        FROM indice_teses {where}
        ORDER BY
            CASE viabilidade WHEN 'alta' THEN 1 WHEN 'media' THEN 2 ELSE 3 END,
            uso_count DESC
        LIMIT :lim OFFSET :off
    """, params)

    cnt = await db_fetch_one(db, f"SELECT COUNT(*) AS n FROM indice_teses {where}",
                              {k:v for k,v in params.items() if k not in ('lim','off')})
    return {"teses": teses, "total": cnt["n"] if cnt else 0}


@router.get("/teses/areas")
async def teses_por_area(db: AsyncSession = Depends(get_db_readonly)):
    """Contagem de teses ativas por área e subárea."""
    rows = await db_fetch_all(db, """
        SELECT area_juridica, subarea, viabilidade,
               COUNT(*) AS total, SUM(uso_count) AS usos
        FROM indice_teses WHERE status='ativa'
        GROUP BY area_juridica, subarea, viabilidade
        ORDER BY area_juridica, subarea
    """)
    # Monta hierarquia área → subareas
    mapa: dict[str, dict] = {}
    for r in rows:
        a = r["area_juridica"]
        if a not in mapa:
            mapa[a] = {"area": a, "total": 0, "usos": 0, "subareas": {}}
        mapa[a]["total"] += r["total"]
        mapa[a]["usos"]  += r["usos"] or 0
        sub = r["subarea"] or "geral"
        if sub not in mapa[a]["subareas"]:
            mapa[a]["subareas"][sub] = {"total": 0, "viabilidades": {}}
        mapa[a]["subareas"][sub]["total"] += r["total"]
        mapa[a]["subareas"][sub]["viabilidades"][r["viabilidade"]] = r["total"]
    return {"areas": list(mapa.values()), "total_areas": len(mapa)}


@router.get("/teses/mapa")
async def mapa_completo_teses(db: AsyncSession = Depends(get_db_readonly)):
    """
    Mapa completo de teses por área — visão estratégica do escritório.
    Retorna todas as áreas com suas teses mais usadas.
    """
    teses = await db_fetch_all(db, """
        SELECT id, titulo, area_juridica, subarea, tese, viabilidade,
               tipo_acao, tags, uso_count, casos_vinculados
        FROM indice_teses WHERE status='ativa'
        ORDER BY area_juridica, subarea,
            CASE viabilidade WHEN 'alta' THEN 1 WHEN 'media' THEN 2 ELSE 3 END,
            uso_count DESC
    """)
    # Agrupa
    mapa: dict[str, list] = {}
    for t in teses:
        a = t["area_juridica"]
        mapa.setdefault(a, []).append(t)
    return {
        "mapa": [{"area": a, "teses": ts, "total": len(ts)} for a, ts in sorted(mapa.items())],
        "total_teses": len(teses),
        "total_areas": len(mapa),
    }


@router.get("/teses/{tese_id}")
async def detalhe_tese(tese_id: str, db: AsyncSession = Depends(get_db)):
    t = await db_fetch_one(db, "SELECT * FROM indice_teses WHERE id=:id", {"id": tese_id})
    if not t: raise HTTPException(404, "Tese não encontrada")
    # Incrementa uso
    await db.execute(text("UPDATE indice_teses SET uso_count=uso_count+1, updated_at=NOW() WHERE id=:id"),
                     {"id": tese_id})
    await db.commit()
    return t


@router.post("/teses", status_code=201)
async def criar_tese(req: TeseCreate, db: AsyncSession = Depends(get_db)):
    tid = str(uuid4())
    await db.execute(text("""
        INSERT INTO indice_teses
            (id, titulo, area_juridica, subarea, tese, fundamentos, argumentos,
             contra_argumento, jurisprudencias, sumulas, leis, viabilidade,
             tipo_acao, tags)
        VALUES (:id,:tit,:area,:sub,:tese,:fund,:arg,:contra,:juris,:sums,:leis,:via,:tpa,:tags)
    """), {
        "id": tid, "tit": req.titulo, "area": req.area_juridica,
        "sub": req.subarea, "tese": req.tese, "fund": req.fundamentos,
        "arg": req.argumentos, "contra": req.contra_argumento,
        "juris": req.jurisprudencias, "sums": req.sumulas,
        "leis": req.leis, "via": req.viabilidade,
        "tpa": req.tipo_acao, "tags": req.tags,
    })
    await db.commit()
    return {"id": tid}


@router.put("/teses/{tese_id}")
async def atualizar_tese(tese_id: str, req: TeseCreate, db: AsyncSession = Depends(get_db)):
    r = await db.execute(text("""
        UPDATE indice_teses SET
            titulo=:tit, area_juridica=:area, subarea=:sub, tese=:tese,
            fundamentos=:fund, argumentos=:arg, contra_argumento=:contra,
            jurisprudencias=:juris, sumulas=:sums, leis=:leis,
            viabilidade=:via, tipo_acao=:tpa, tags=:tags, updated_at=NOW()
        WHERE id=:id RETURNING id
    """), {"id": tese_id, "tit": req.titulo, "area": req.area_juridica,
           "sub": req.subarea, "tese": req.tese, "fund": req.fundamentos,
           "arg": req.argumentos, "contra": req.contra_argumento,
           "juris": req.jurisprudencias, "sums": req.sumulas,
           "leis": req.leis, "via": req.viabilidade,
           "tpa": req.tipo_acao, "tags": req.tags})
    if not r.first(): raise HTTPException(404, "Tese não encontrada")
    await db.commit()
    return {"mensagem": "Tese atualizada"}


# ══════════════════════════════════════════════════════════════════════════
# BUSCA UNIFICADA
# ══════════════════════════════════════════════════════════════════════════

@router.get("/buscar")
async def busca_unificada(
    q: str = Query(..., min_length=3),
    area: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db_readonly),
):
    """
    Busca simultânea em leis, súmulas e teses.
    Retorna resultados dos 3 índices em uma única chamada.
    """
    params_q = {"q": q, "lim": 5}
    if area:
        params_q["area"] = area

    area_filter = "AND area_juridica = :area" if area else ""

    leis_q = f"""
        SELECT id, diploma, artigo, LEFT(texto,200) AS texto, area_juridica, tema,
               'lei' AS tipo
        FROM indice_leis
        WHERE ativo=TRUE {area_filter}
          AND to_tsvector('portuguese', COALESCE(texto,'') || ' ' || COALESCE(tema,'') || ' ' || diploma)
              @@ plainto_tsquery('portuguese', :q)
        LIMIT :lim
    """
    sums_q = f"""
        SELECT id, tribunal, numero::text, LEFT(enunciado,200) AS texto, area_juridica,
               tipo AS subtipo, 'sumula' AS tipo
        FROM indice_sumulas
        WHERE status='vigente' {area_filter}
          AND to_tsvector('portuguese', enunciado) @@ plainto_tsquery('portuguese', :q)
        LIMIT :lim
    """
    teses_q = f"""
        SELECT id, titulo AS diploma, '' AS artigo, LEFT(tese,200) AS texto,
               area_juridica, viabilidade AS tema, 'tese' AS tipo
        FROM indice_teses
        WHERE status='ativa' {area_filter}
          AND to_tsvector('portuguese', titulo || ' ' || tese || ' ' || COALESCE(fundamentos,''))
              @@ plainto_tsquery('portuguese', :q)
        LIMIT :lim
    """

    leis, sums, teses = await asyncio.gather(
        db_fetch_all(db, leis_q, params_q),
        db_fetch_all(db, sums_q, params_q),
        db_fetch_all(db, teses_q, params_q),
    )

    return {
        "query": q,
        "area": area,
        "leis": leis,
        "sumulas": sums,
        "teses": teses,
        "total": len(leis) + len(sums) + len(teses),
    }
