"""
EJC — Módulo Tributário (router.py)
12 endpoints para o módulo de inteligência fiscal.

Endpoints:
  POST /tributario/consultar-cnpj          — busca dados do CNPJ
  POST /tributario/simular                  — simulação de regimes
  GET  /tributario/simulacoes               — histórico do usuário
  GET  /tributario/simulacao/{id}           — detalhes de uma simulação
  GET  /tributario/oportunidades/{empresa}  — oportunidades identificadas
  GET  /tributario/alertas/{empresa}        — alertas fiscais
  GET  /tributario/fundamentos              — base legal disponível
  GET  /tributario/fundamentos/{id}         — detalhe do fundamento
  POST /tributario/gerar-relatorio          — gera PDF/DOCX
  GET  /tributario/historico/{cnpj}         — histórico de análises
  GET  /tributario/regimes                  — tabela de regimes
  POST /tributario/chat                     — assistente IA tributária
"""
from __future__ import annotations
import json
import logging
from typing import Optional
from uuid import uuid4

import httpx
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.tributario.calculadora import DadosFiscais, comparar_regimes

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/tributario", tags=["Tributário — Inteligência Fiscal"])

AVISO_LEGAL = (
    "⚠️ Este módulo realiza simulações tributárias preliminares com finalidade de apoio "
    "à decisão. Nenhuma recomendação deve ser executada sem validação por contador "
    "responsável e, quando necessário, por advogado tributarista. O sistema não "
    "recomenda evasão fiscal, omissão de receitas, fraude ou qualquer conduta "
    "contrária à legislação."
)


# ── Schemas ────────────────────────────────────────────────────

class SimulacaoRequest(BaseModel):
    cnpj: str
    empresa_id: Optional[str] = None
    faturamento_mensal: float = 0
    faturamento_12m: float = 0
    folha_pagamento: float = 0
    prolabore: float = 0
    num_funcionarios: int = 0
    despesas_fixas: float = 0
    despesas_variaveis: float = 0
    compras_mercadorias: float = 0
    creditos_tributarios: float = 0
    margem_lucro: Optional[float] = None
    tipo_atividade: str = "servico"
    cnae_principal: str = ""
    municipio_iss: str = ""
    uf_icms: str = "SP"


class ChatTributarioRequest(BaseModel):
    pergunta: str
    contexto_simulacao_id: Optional[str] = None
    cnpj: Optional[str] = None


# ── Helpers ─────────────────────────────────────────────────────

def _limpar_cnpj(cnpj: str) -> str:
    return ''.join(c for c in cnpj if c.isdigit())


async def _buscar_receita_federal(cnpj: str) -> dict:
    """Consulta dados públicos do CNPJ na API da Receita/BrasilAPI."""
    cnpj_limpo = _limpar_cnpj(cnpj)
    if len(cnpj_limpo) != 14:
        raise HTTPException(422, "CNPJ inválido — informe 14 dígitos.")

    # Tenta BrasilAPI (pública, sem autenticação)
    apis = [
        f"https://brasilapi.com.br/api/cnpj/v1/{cnpj_limpo}",
        f"https://receitaws.com.br/v1/cnpj/{cnpj_limpo}",
    ]

    for url in apis:
        try:
            async with httpx.AsyncClient(timeout=8.0) as client:
                resp = await client.get(url, follow_redirects=True)
                if resp.status_code == 200:
                    data = resp.json()
                    return _normalizar_cnpj_response(data, cnpj_limpo, url)
        except Exception as e:
            logger.warning(f"[CNPJ] Falha em {url}: {e}")
            continue

    # Fallback: retorna estrutura vazia com aviso
    return {
        "cnpj": cnpj_limpo,
        "razao_social": None,
        "situacao": "não consultado",
        "cnae_principal": None,
        "fonte": "nenhuma (API indisponível)",
        "aviso": "Não foi possível consultar os dados do CNPJ. Preencha manualmente.",
    }


def _normalizar_cnpj_response(data: dict, cnpj: str, fonte: str) -> dict:
    """Normaliza resposta de diferentes APIs de CNPJ."""
    # BrasilAPI
    if "cnpj" in data and "descricao_situacao_cadastral" in data:
        cnae = data.get("cnae_fiscal", "") or data.get("cnae_fiscal_principal", {}).get("codigo", "")
        desc_cnae = data.get("cnae_fiscal_descricao", "") or data.get("cnae_fiscal_principal", {}).get("descricao", "")
        return {
            "cnpj": cnpj,
            "razao_social": data.get("razao_social"),
            "nome_fantasia": data.get("nome_fantasia"),
            "situacao": data.get("descricao_situacao_cadastral"),
            "cnae_principal": str(cnae) if cnae else None,
            "cnae_principal_descricao": desc_cnae,
            "cnaes_secundarios": [
                {"codigo": str(c.get("codigo","")), "descricao": c.get("descricao","")}
                for c in data.get("cnaes_secundarios", [])
            ],
            "natureza_juridica": data.get("descricao_natureza_juridica") or data.get("natureza_juridica", {}).get("descricao"),
            "porte": data.get("porte"),
            "data_abertura": data.get("data_inicio_atividade") or data.get("abertura"),
            "municipio": data.get("municipio"),
            "uf": data.get("uf"),
            "logradouro": data.get("logradouro"),
            "socios": [
                {"nome": s.get("nome_socio") or s.get("nome"), "qualificacao": s.get("qualificacao_socio","")}
                for s in data.get("socios", [])
            ],
            "fonte": "BrasilAPI (dados públicos da Receita Federal)",
        }
    # ReceitaWS
    if "status" in data and data.get("status") == "OK":
        return {
            "cnpj": cnpj,
            "razao_social": data.get("nome"),
            "nome_fantasia": data.get("fantasia"),
            "situacao": data.get("situacao"),
            "cnae_principal": data.get("atividade_principal", [{}])[0].get("code","").replace(".","").replace("-",""),
            "cnae_principal_descricao": data.get("atividade_principal", [{}])[0].get("text",""),
            "cnaes_secundarios": [{"codigo": a.get("code",""), "descricao": a.get("text","")} for a in data.get("atividades_secundarias",[])],
            "natureza_juridica": data.get("natureza_juridica"),
            "porte": data.get("porte"),
            "data_abertura": data.get("abertura"),
            "municipio": data.get("municipio"),
            "uf": data.get("uf"),
            "fonte": "ReceitaWS (dados públicos)",
        }
    return {"cnpj": cnpj, "fonte": "desconhecida", "dados_raw": data}


# ── Endpoints ─────────────────────────────────────────────────

@router.post("/consultar-cnpj")
async def consultar_cnpj(
    payload: dict,
    db: AsyncSession = Depends(get_db),
):
    """Busca dados públicos do CNPJ e persiste no banco."""
    cnpj = _limpar_cnpj(payload.get("cnpj", ""))
    dados = await _buscar_receita_federal(cnpj)

    # Verifica se já existe no banco
    row = await db.execute(
        text("SELECT id FROM empresas_consultadas WHERE cnpj=:cnpj"),
        {"cnpj": cnpj}
    )
    existing = row.scalar()

    if not existing:
        empresa_id = str(uuid4())
        await db.execute(text("""
            INSERT INTO empresas_consultadas
              (id, cnpj, razao_social, nome_fantasia, situacao, cnae_principal,
               cnaes_secundarios, natureza_juridica, porte, data_abertura)
            VALUES (:id, :cnpj, :rs, :nf, :sit, :cnae, :cnaes::jsonb, :nj, :porte, :dt)
            ON CONFLICT (cnpj) DO UPDATE
              SET razao_social=EXCLUDED.razao_social,
                  situacao=EXCLUDED.situacao,
                  updated_at=NOW()
        """), {
            "id":    empresa_id,
            "cnpj":  cnpj,
            "rs":    dados.get("razao_social"),
            "nf":    dados.get("nome_fantasia"),
            "sit":   dados.get("situacao"),
            "cnae":  dados.get("cnae_principal"),
            "cnaes": json.dumps(dados.get("cnaes_secundarios", [])),
            "nj":    dados.get("natureza_juridica"),
            "porte": dados.get("porte"),
            "dt":    dados.get("data_abertura"),
        })
    else:
        empresa_id = existing

    await db.execute(text("""
        INSERT INTO historico_analises (cnpj, tipo_acao, resumo)
        VALUES (:cnpj, 'consulta_cnpj', :res)
    """), {"cnpj": cnpj, "res": f"Consulta CNPJ: {dados.get('razao_social','')}"})
    await db.commit()

    return {
        "empresa_id": str(empresa_id),
        "dados": dados,
        "aviso_legal": AVISO_LEGAL,
    }


@router.post("/simular", status_code=201)
async def simular_regimes(req: SimulacaoRequest, db: AsyncSession = Depends(get_db)):
    """
    Simulação comparativa entre Simples Nacional, Lucro Presumido e Lucro Real.
    Retorna cargas tributárias estimadas, oportunidades e alertas.
    """
    dados = DadosFiscais(
        faturamento_mensal=req.faturamento_mensal,
        faturamento_12m=req.faturamento_12m,
        folha_pagamento=req.folha_pagamento,
        prolabore=req.prolabore,
        num_funcionarios=req.num_funcionarios,
        despesas_fixas=req.despesas_fixas,
        despesas_variaveis=req.despesas_variaveis,
        compras_mercadorias=req.compras_mercadorias,
        creditos_tributarios=req.creditos_tributarios,
        margem_lucro=req.margem_lucro,
        tipo_atividade=req.tipo_atividade,
        cnae_principal=req.cnae_principal,
        municipio_iss=req.municipio_iss,
        uf_icms=req.uf_icms,
    )

    resultado = comparar_regimes(dados)

    # Persiste simulação
    sim_id = str(uuid4())
    cnpj = _limpar_cnpj(req.cnpj)

    # Garante empresa no banco
    row_e = await db.execute(
        text("SELECT id FROM empresas_consultadas WHERE cnpj=:c"), {"c": cnpj}
    )
    empresa_id = row_e.scalar()
    if not empresa_id:
        empresa_id = str(uuid4())
        await db.execute(text("""
            INSERT INTO empresas_consultadas (id, cnpj)
            VALUES (:id, :cnpj) ON CONFLICT DO NOTHING
        """), {"id": empresa_id, "cnpj": cnpj})

    await db.execute(text("""
        INSERT INTO simulacoes_tributarias (
            id, empresa_id, cnpj,
            faturamento_mensal, faturamento_12m, folha_pagamento, prolabore,
            despesas_fixas, despesas_variaveis, compras_mercadorias,
            margem_lucro, regime_simulado,
            resultado_simples, resultado_presumido, resultado_real,
            regime_recomendado, economia_mensal_estimada, economia_anual_estimada,
            nivel_confiabilidade
        ) VALUES (
            :id, :eid, :cnpj,
            :fm, :f12, :fp, :pl,
            :df, :dv, :cm,
            :ml, :rs,
            :rsim::jsonb, :rpre::jsonb, :rrea::jsonb,
            :rr, :em, :ea, 'preliminar'
        )
    """), {
        "id": sim_id, "eid": str(empresa_id), "cnpj": cnpj,
        "fm": req.faturamento_mensal, "f12": req.faturamento_12m,
        "fp": req.folha_pagamento, "pl": req.prolabore,
        "df": req.despesas_fixas, "dv": req.despesas_variaveis,
        "cm": req.compras_mercadorias,
        "ml": req.margem_lucro, "rs": req.tipo_atividade,
        "rsim": json.dumps(resultado["regimes"]["simples"]),
        "rpre": json.dumps(resultado["regimes"]["presumido"]),
        "rrea": json.dumps(resultado["regimes"]["real"]),
        "rr": resultado["regime_recomendado"],
        "em": resultado["economia_mensal_estimada"],
        "ea": resultado["economia_anual_estimada"],
    })

    # Persiste oportunidades e alertas
    for op in resultado["oportunidades"]:
        await db.execute(text("""
            INSERT INTO oportunidades_tributarias
              (empresa_id, simulacao_id, tipo, titulo, descricao, base_legal, tributo, risco)
            VALUES (:eid, :sid, :tipo, :tit, :desc, :bl, :trib, :risco)
        """), {
            "eid": str(empresa_id), "sid": sim_id,
            "tipo": op["tipo"], "tit": op["titulo"],
            "desc": op["descricao"], "bl": op.get("base_legal",""),
            "trib": op.get("tributo",""), "risco": op.get("risco","baixo"),
        })

    for al in resultado["alertas"]:
        await db.execute(text("""
            INSERT INTO alertas_fiscais
              (empresa_id, simulacao_id, tipo, titulo, descricao, severidade, acao_recomendada)
            VALUES (:eid, :sid, :tipo, :tit, :desc, :sev, :acao)
        """), {
            "eid": str(empresa_id), "sid": sim_id,
            "tipo": al["tipo"], "tit": al["titulo"],
            "desc": al["descricao"], "sev": al.get("severidade","medio"),
            "acao": al.get("acao",""),
        })

    await db.commit()

    return {
        "simulacao_id": sim_id,
        "empresa_id": str(empresa_id),
        **resultado,
    }


@router.get("/simulacoes")
async def listar_simulacoes(cnpj: Optional[str] = None, db: AsyncSession = Depends(get_db)):
    """Lista histórico de simulações."""
    where = "WHERE s.cnpj=:cnpj" if cnpj else ""
    params = {"cnpj": _limpar_cnpj(cnpj)} if cnpj else {}
    rows = await db.execute(text(f"""
        SELECT s.id, s.cnpj, e.razao_social, s.faturamento_mensal,
               s.regime_recomendado, s.economia_mensal_estimada,
               s.nivel_confiabilidade, s.created_at
        FROM simulacoes_tributarias s
        LEFT JOIN empresas_consultadas e ON e.id=s.empresa_id
        {where}
        ORDER BY s.created_at DESC LIMIT 50
    """), params)
    return {"simulacoes": [dict(r) for r in rows.mappings()]}


@router.get("/simulacao/{sim_id}")
async def detalhe_simulacao(sim_id: str, db: AsyncSession = Depends(get_db)):
    row = await db.execute(
        text("SELECT * FROM simulacoes_tributarias WHERE id=:id"), {"id": sim_id}
    )
    s = row.mappings().first()
    if not s:
        raise HTTPException(404, "Simulação não encontrada")

    ops = await db.execute(
        text("SELECT * FROM oportunidades_tributarias WHERE simulacao_id=:id ORDER BY risco"), {"id": sim_id}
    )
    als = await db.execute(
        text("SELECT * FROM alertas_fiscais WHERE simulacao_id=:id ORDER BY severidade DESC"), {"id": sim_id}
    )
    return {
        "simulacao": dict(s),
        "oportunidades": [dict(r) for r in ops.mappings()],
        "alertas": [dict(r) for r in als.mappings()],
        "aviso_legal": AVISO_LEGAL,
    }


@router.get("/oportunidades/{empresa_id}")
async def oportunidades(empresa_id: str, db: AsyncSession = Depends(get_db)):
    rows = await db.execute(text("""
        SELECT * FROM oportunidades_tributarias
        WHERE empresa_id=:eid AND ativo=true
        ORDER BY risco, economia_estimada DESC NULLS LAST
    """), {"eid": empresa_id})
    return {"oportunidades": [dict(r) for r in rows.mappings()]}


@router.get("/alertas/{empresa_id}")
async def alertas(empresa_id: str, db: AsyncSession = Depends(get_db)):
    rows = await db.execute(text("""
        SELECT * FROM alertas_fiscais
        WHERE empresa_id=:eid AND resolvido=false
        ORDER BY CASE severidade WHEN 'critico' THEN 1 WHEN 'alto' THEN 2 WHEN 'medio' THEN 3 ELSE 4 END
    """), {"eid": empresa_id})
    return {"alertas": [dict(r) for r in rows.mappings()]}


@router.get("/fundamentos")
async def fundamentos(tributo: Optional[str] = None, regime: Optional[str] = None, db: AsyncSession = Depends(get_db)):
    conds, params = ["ativo=true"], {}
    if tributo:
        conds.append("tributo ILIKE :tributo")
        params["tributo"] = f"%{tributo}%"
    if regime:
        conds.append("(regime=:regime OR regime IS NULL)")
        params["regime"] = regime
    rows = await db.execute(
        text(f"SELECT * FROM fundamentos_legais WHERE {' AND '.join(conds)} ORDER BY tema"),
        params
    )
    return {"fundamentos": [dict(r) for r in rows.mappings()]}


@router.get("/regimes")
async def listar_regimes(db: AsyncSession = Depends(get_db)):
    rows = await db.execute(text("SELECT * FROM regimes_tributarios WHERE ativo=true ORDER BY limite_faturamento NULLS LAST"))
    return {"regimes": [dict(r) for r in rows.mappings()]}


@router.get("/historico/{cnpj}")
async def historico(cnpj: str, db: AsyncSession = Depends(get_db)):
    cnpj_l = _limpar_cnpj(cnpj)
    rows = await db.execute(text("""
        SELECT tipo_acao, resumo, created_at FROM historico_analises
        WHERE cnpj=:cnpj ORDER BY created_at DESC LIMIT 30
    """), {"cnpj": cnpj_l})
    return {"historico": [dict(r) for r in rows.mappings()]}


@router.post("/gerar-relatorio")
async def gerar_relatorio(payload: dict, db: AsyncSession = Depends(get_db)):
    """Gera relatório tributário em Markdown (convertível a PDF/DOCX)."""
    sim_id = payload.get("simulacao_id")
    tipo = payload.get("tipo", "comparativo")

    row = await db.execute(
        text("SELECT s.*, e.razao_social, e.cnpj FROM simulacoes_tributarias s LEFT JOIN empresas_consultadas e ON e.id=s.empresa_id WHERE s.id=:id"),
        {"id": sim_id}
    )
    s = row.mappings().first()
    if not s:
        raise HTTPException(404, "Simulação não encontrada")

    nome = s.get("razao_social") or s.get("cnpj")
    md = _gerar_md_relatorio(dict(s), tipo)

    rel_id = str(uuid4())
    await db.execute(text("""
        INSERT INTO relatorios_tributarios (id, empresa_id, simulacao_id, tipo, titulo, conteudo_md, formato)
        VALUES (:id, :eid, :sid, :tipo, :tit, :md, 'md')
    """), {
        "id": rel_id, "eid": s.get("empresa_id"), "sid": sim_id,
        "tipo": tipo, "tit": f"Relatório {tipo.title()} — {nome}",
        "md": md,
    })
    await db.commit()

    return {"relatorio_id": rel_id, "titulo": f"Relatório {tipo.title()} — {nome}", "conteudo_md": md}


def _gerar_md_relatorio(sim: dict, tipo: str) -> str:
    from datetime import datetime
    nome = sim.get("razao_social") or sim.get("cnpj","")
    data = datetime.now().strftime("%d/%m/%Y")

    if tipo == "comparativo":
        rr = sim.get("resultado_real") or {}
        rp = sim.get("resultado_presumido") or {}
        rs = sim.get("resultado_simples") or {}
        recomendado = sim.get("regime_recomendado","").upper()
        ec_m = sim.get("economia_mensal_estimada") or 0
        ec_a = sim.get("economia_anual_estimada") or 0

        return f"""# Relatório Comparativo de Regimes Tributários
## {nome} | {data}

---

> ⚠️ {AVISO_LEGAL}

---

## 1. Dados da Simulação

| Item | Valor |
|---|---|
| Faturamento mensal | R$ {sim.get('faturamento_mensal',0):,.2f} |
| Folha de pagamento | R$ {sim.get('folha_pagamento',0):,.2f} |
| Pró-labore | R$ {sim.get('prolabore',0):,.2f} |
| Despesas fixas | R$ {sim.get('despesas_fixas',0):,.2f} |
| Tipo de atividade | {sim.get('regime_simulado','não informado')} |

## 2. Comparativo de Regimes

| Regime | Carga Mensal Estimada | Carga Anual |
|---|---|---|
| Simples Nacional | R$ {rs.get('total_mensal',0):,.2f} | R$ {rs.get('total_anual',0):,.2f} |
| Lucro Presumido  | R$ {rp.get('total_mensal',0):,.2f} | R$ {rp.get('total_anual',0):,.2f} |
| Lucro Real       | R$ {rr.get('total_mensal',0):,.2f} | R$ {rr.get('total_anual',0):,.2f} |

## 3. Recomendação Preliminar

Com base nos dados informados e nas premissas adotadas, o regime aparentemente
mais vantajoso é o **{recomendado}**, com economia potencial estimada de:

- **R$ {ec_m:,.2f}/mês**
- **R$ {ec_a:,.2f}/ano**

Esta recomendação é condicionada à validação por contador responsável
e conferência da legislação vigente.

## 4. Checklist para Validação

- [ ] Confirmar CNAE e atividade real exercida
- [ ] Validar folha de pagamento e pró-labore
- [ ] Verificar alíquota ISS no município
- [ ] Verificar alíquota ICMS no Estado
- [ ] Apurar créditos de PIS/COFINS disponíveis
- [ ] Verificar possíveis impeditivos ao Simples Nacional
- [ ] Confirmar faturamento dos últimos 12 meses

---
*Simulação gerada pelo EJC — Ecossistema Jurídico Clovis*
*Dados meramente estimados. Obrigatória validação por contador.*
"""
    return f"# Relatório {tipo}\n\nEmpresa: {nome}\nData: {data}\n\n{AVISO_LEGAL}"


@router.post("/chat")
async def chat_tributario(req: ChatTributarioRequest, db: AsyncSession = Depends(get_db)):
    """
    Assistente IA para dúvidas tributárias.
    Usa o LLM do EJC com contexto especializado em tributário.
    """
    from app.core.llm_provider import LLMProvider

    # Contexto da simulação, se informado
    contexto_sim = ""
    if req.contexto_simulacao_id:
        row = await db.execute(
            text("SELECT * FROM simulacoes_tributarias WHERE id=:id"),
            {"id": req.contexto_simulacao_id}
        )
        s = row.mappings().first()
        if s:
            contexto_sim = f"""
Dados da simulação em contexto:
- Faturamento mensal: R$ {s.get('faturamento_mensal',0):,.2f}
- Regime recomendado: {s.get('regime_recomendado','não determinado')}
- Economia mensal estimada: R$ {s.get('economia_mensal_estimada',0):,.2f}
"""

    # Busca fundamentos relacionados
    words = req.pergunta.split()[:5]
    termos = " ".join(words)
    rows_fl = await db.execute(text("""
        SELECT titulo, fundamento, base_legal FROM fundamentos_legais
        WHERE ativo=true AND (tema ILIKE :t OR tributo ILIKE :t)
        LIMIT 3
    """), {"t": f"%{termos}%"})
    fund_ctx = "\n".join(
        f"- {r['titulo']}: {r['fundamento'][:200]} (Base: {r['base_legal']})"
        for r in rows_fl.mappings()
    )

    system_prompt = f"""Você é o Assistente Tributário do EJC — especialista em direito tributário brasileiro.

REGRAS OBRIGATÓRIAS:
1. Use linguagem técnica, conservadora e prudente
2. NUNCA recomende sonegação, fraude, evasão fiscal ou qualquer conduta ilícita
3. Sempre diferencie: elisão lícita / tese discutível / conduta vedada
4. Sempre recomende validação por contador e/ou advogado tributarista
5. Quando houver base legal, cite-a. Quando não houver, diga expressamente.
6. Trabalhe com planejamento tributário LÍCITO: elisão fiscal, aproveitamento de benefícios, créditos admitidos em lei.

FUNDAMENTOS DISPONÍVEIS NA BASE:
{fund_ctx if fund_ctx else 'Nenhum fundamento específico carregado para esta consulta.'}

CONTEXTO DA SIMULAÇÃO:
{contexto_sim if contexto_sim else 'Nenhuma simulação em contexto.'}

Aviso legal fixo que deve constar em respostas sobre decisões: "{AVISO_LEGAL}"
"""
    try:
        provider = LLMProvider()
        resposta = await provider.generate(
            prompt=req.pergunta,
            system=system_prompt,
            max_tokens=1200,
        )
    except Exception as e:
        logger.error(f"[Chat Tributário] LLM erro: {e}")
        resposta = (
            "Não foi possível processar a consulta via IA no momento. "
            "Consulte diretamente um contador ou advogado tributarista."
        )

    return {
        "resposta": resposta,
        "aviso_legal": AVISO_LEGAL,
        "fundamentos_referenciados": [dict(r) for r in rows_fl.mappings()] if fund_ctx else [],
    }
