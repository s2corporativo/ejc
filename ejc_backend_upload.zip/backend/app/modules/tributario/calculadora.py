"""
EJC — Motor de Cálculo Tributário
Calcula carga tributária estimada em cada regime: Simples, Presumido, Real.
Todos os cálculos são PRELIMINARES e devem ser validados por contador.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class DadosFiscais:
    """Dados financeiros informados pelo usuário para simulação."""
    faturamento_mensal: float = 0.0
    faturamento_12m: float = 0.0       # Receita bruta últimos 12 meses
    folha_pagamento: float = 0.0       # Folha mensal (sem pró-labore)
    prolabore: float = 0.0
    num_funcionarios: int = 0
    despesas_fixas: float = 0.0
    despesas_variaveis: float = 0.0
    compras_mercadorias: float = 0.0   # Para crédito PIS/COFINS no real
    creditos_tributarios: float = 0.0
    margem_lucro: Optional[float] = None  # % ex: 0.15 = 15%
    cnae_principal: str = ""
    tipo_atividade: str = "servico"    # comercio | servico | industria | misto
    municipio_iss: str = ""
    uf_icms: str = "SP"

    @property
    def faturamento_anual(self) -> float:
        if self.faturamento_12m > 0:
            return self.faturamento_12m
        return self.faturamento_mensal * 12

    @property
    def fator_r(self) -> float:
        """Fator R = Folha 12m / Receita Bruta 12m (Simples Nacional)."""
        rb12 = self.faturamento_12m or (self.faturamento_mensal * 12)
        fp12 = self.folha_pagamento * 12
        if rb12 == 0:
            return 0.0
        return fp12 / rb12

    @property
    def lucro_estimado_mensal(self) -> float:
        if self.margem_lucro:
            return self.faturamento_mensal * self.margem_lucro
        # Estimativa conservadora
        despesas = self.folha_pagamento + self.prolabore + self.despesas_fixas + \
                   self.despesas_variaveis + self.compras_mercadorias
        return max(0, self.faturamento_mensal - despesas)


@dataclass
class ResultadoRegime:
    regime: str
    tributos: dict = field(default_factory=dict)
    total_mensal: float = 0.0
    total_anual: float = 0.0
    carga_percentual: float = 0.0
    observacoes: list = field(default_factory=list)
    dados_faltantes: list = field(default_factory=list)
    confiabilidade: str = "preliminar"  # preliminar | estimada | alta


# ── Tabelas Simples Nacional 2024 ──────────────────────────────────────────

SIMPLES_ANEXO_I = [  # Comércio
    (180000,   0.04,   0),
    (360000,   0.073,  5940),
    (720000,   0.095,  13860),
    (1800000,  0.107,  22500),
    (3600000,  0.143,  87300),
    (4800000,  0.19,   378000),
]

SIMPLES_ANEXO_III = [  # Serviços (Fator R >= 28% ou atividades específicas)
    (180000,   0.06,   0),
    (360000,   0.112,  9360),
    (720000,   0.135,  17640),
    (1800000,  0.16,   35640),
    (3600000,  0.21,   125640),
    (4800000,  0.33,   648000),
]

SIMPLES_ANEXO_V = [  # Serviços (Fator R < 28%)
    (180000,   0.155,  0),
    (360000,   0.18,   4500),
    (720000,   0.195,  9900),
    (1800000,  0.205,  17100),
    (3600000,  0.23,   62100),
    (4800000,  0.305,  540000),
]

SIMPLES_ANEXO_IV = [  # Serviços específicos (construção civil, limpeza, vigilância)
    (180000,   0.045,  0),
    (360000,   0.09,   8100),
    (720000,   0.102,  12420),
    (1800000,  0.14,   39780),
    (3600000,  0.22,   183780),
    (4800000,  0.33,   828000),
]


def calcular_aliquota_simples(rb12: float, tabela: list) -> tuple[float, float]:
    """Retorna (alíquota efetiva, valor dedução) para o RBT12 informado."""
    for limite, aliq, deducao in tabela:
        if rb12 <= limite:
            aliq_efetiva = (rb12 * aliq - deducao) / rb12 if rb12 > 0 else 0
            return aliq_efetiva, deducao
    # Acima do limite — não é Simples
    return 0, 0


def _escolher_tabela_simples(dados: DadosFiscais) -> tuple[list, str]:
    """Escolhe o Anexo correto com base no tipo de atividade e Fator R."""
    tipo = dados.tipo_atividade
    if tipo == "comercio":
        return SIMPLES_ANEXO_I, "Anexo I — Comércio"
    if tipo == "servico":
        fr = dados.fator_r
        if fr >= 0.28:
            return SIMPLES_ANEXO_III, f"Anexo III — Serviços (Fator R={fr:.1%} ≥ 28%)"
        else:
            return SIMPLES_ANEXO_V, f"Anexo V — Serviços (Fator R={fr:.1%} < 28%)"
    if tipo == "industria":
        return SIMPLES_ANEXO_I, "Anexo II — Indústria (estimado pelo Anexo I)"
    return SIMPLES_ANEXO_III, "Anexo III (padrão)"


def calcular_simples(dados: DadosFiscais) -> ResultadoRegime:
    r = ResultadoRegime(regime="simples")
    rb12 = dados.faturamento_12m or (dados.faturamento_mensal * 12)
    fat_m = dados.faturamento_mensal

    # Verificações de elegibilidade
    if rb12 > 4_800_000:
        r.observacoes.append("⚠ Faturamento acima de R$4,8M — empresa NÃO é elegível ao Simples Nacional.")
        r.confiabilidade = "inaplicavel"
        return r

    if not fat_m:
        r.dados_faltantes.append("Faturamento mensal")

    tabela, obs_tabela = _escolher_tabela_simples(dados)
    r.observacoes.append(f"Tabela: {obs_tabela}")

    aliq_ef, _ = calcular_aliquota_simples(rb12, tabela)
    das_mensal = fat_m * aliq_ef

    r.tributos = {
        "DAS (unificado)": das_mensal,
        "INSS sobre pró-labore (20%)": dados.prolabore * 0.20,
        "IRPF sócios (estimado)": dados.prolabore * 0.115,  # alíquota média
    }
    r.total_mensal = sum(r.tributos.values())
    r.total_anual = r.total_mensal * 12
    r.carga_percentual = (r.total_mensal / fat_m * 100) if fat_m else 0

    r.observacoes.append(f"Alíquota efetiva DAS: {aliq_ef:.2%}")
    r.observacoes.append(f"Fator R calculado: {dados.fator_r:.2%}")

    if not dados.folha_pagamento:
        r.dados_faltantes.append("Folha de pagamento (necessária para cálculo do Fator R)")

    r.confiabilidade = "estimada" if rb12 > 0 and fat_m > 0 else "preliminar"
    return r


def calcular_presumido(dados: DadosFiscais) -> ResultadoRegime:
    r = ResultadoRegime(regime="presumido")
    fat_m = dados.faturamento_mensal
    rb12 = dados.faturamento_12m or (fat_m * 12)

    if rb12 > 78_000_000:
        r.observacoes.append("⚠ Faturamento anual > R$78M — Lucro Presumido NÃO disponível. Lucro Real obrigatório.")
        r.confiabilidade = "inaplicavel"
        return r

    tipo = dados.tipo_atividade

    # Percentuais de presunção (sobre receita bruta)
    pres_irpj = 0.32 if tipo == "servico" else 0.08
    pres_csll = 0.32 if tipo == "servico" else 0.12

    lucro_pres_irpj = fat_m * pres_irpj
    lucro_pres_csll = fat_m * pres_csll

    irpj_base = lucro_pres_irpj * 0.15
    adicional_irpj = max(0, (lucro_pres_irpj - 20_000)) * 0.10
    csll = lucro_pres_csll * 0.09

    # PIS/COFINS regime cumulativo (Presumido)
    pis = fat_m * 0.0065
    cofins = fat_m * 0.03

    # ISS estimado (serviços) — varia por município (2% a 5%)
    iss = fat_m * 0.05 if tipo in ("servico", "misto") else 0

    # ICMS (comércio) estimado
    icms = fat_m * 0.12 if tipo in ("comercio", "industria", "misto") else 0

    # CPP (INSS patronal) sobre folha
    cpp = (dados.folha_pagamento + dados.prolabore) * 0.20

    r.tributos = {
        "IRPJ (15%)":          irpj_base,
        "Adicional IRPJ (10%)": adicional_irpj,
        "CSLL (9%)":           csll,
        "PIS (0,65% cumulativo)": pis,
        "COFINS (3% cumulativo)": cofins,
        "ISS estimado":         iss,
        "ICMS estimado":        icms,
        "INSS patronal (20%)":  cpp,
    }
    r.tributos = {k: v for k, v in r.tributos.items() if v > 0}
    r.total_mensal = sum(r.tributos.values())
    r.total_anual = r.total_mensal * 12
    r.carga_percentual = (r.total_mensal / fat_m * 100) if fat_m else 0

    r.observacoes.append(f"Presunção IRPJ: {pres_irpj:.0%} | CSLL: {pres_csll:.0%}")
    r.observacoes.append("ISS estimado à alíquota máxima de 5% — verificar alíquota do município")
    r.observacoes.append("ICMS estimado — verificar alíquota interna do Estado")

    if not dados.municipio_iss:
        r.dados_faltantes.append("Município (para alíquota ISS exata)")
    if not dados.uf_icms:
        r.dados_faltantes.append("UF (para alíquota ICMS exata)")

    r.confiabilidade = "estimada" if fat_m > 0 else "preliminar"
    return r


def calcular_real(dados: DadosFiscais) -> ResultadoRegime:
    r = ResultadoRegime(regime="real")
    fat_m = dados.faturamento_mensal

    # Lucro real = receita - despesas
    lucro_m = dados.lucro_estimado_mensal

    if lucro_m <= 0:
        r.observacoes.append("ℹ Lucro estimado negativo ou zero — IRPJ/CSLL = 0 neste cenário (possível prejuízo fiscal).")

    irpj = max(0, lucro_m * 0.15)
    adicional = max(0, (lucro_m - 20_000) * 0.10)
    csll = max(0, lucro_m * 0.09)

    # PIS/COFINS não cumulativo
    pis_bruto = fat_m * 0.0165
    cofins_bruto = fat_m * 0.076

    # Créditos sobre compras (estimado)
    pis_credito = dados.compras_mercadorias * 0.0165
    cofins_credito = dados.compras_mercadorias * 0.076
    pis_liquido = max(0, pis_bruto - pis_credito)
    cofins_liquido = max(0, cofins_bruto - cofins_credito)

    tipo = dados.tipo_atividade
    iss = fat_m * 0.05 if tipo in ("servico", "misto") else 0
    icms = fat_m * 0.12 if tipo in ("comercio", "industria", "misto") else 0

    cpp = (dados.folha_pagamento + dados.prolabore) * 0.20

    r.tributos = {
        "IRPJ (15% s/ lucro real)":   irpj,
        "Adicional IRPJ (10%)":        adicional,
        "CSLL (9% s/ lucro real)":     csll,
        "PIS (1,65% líq. créditos)":   pis_liquido,
        "COFINS (7,6% líq. créditos)": cofins_liquido,
        "ISS estimado":                iss,
        "ICMS estimado":               icms,
        "INSS patronal (20%)":         cpp,
    }
    r.tributos = {k: v for k, v in r.tributos.items() if v > 0}
    r.total_mensal = sum(r.tributos.values())
    r.total_anual = r.total_mensal * 12
    r.carga_percentual = (r.total_mensal / fat_m * 100) if fat_m else 0

    r.observacoes.append("Créditos PIS/COFINS calculados sobre compras de mercadorias informadas")
    r.observacoes.append("Lucro real = faturamento − despesas informadas (estimativa)")

    if not dados.margem_lucro and not (dados.despesas_fixas or dados.despesas_variaveis):
        r.dados_faltantes.append("Despesas operacionais ou margem de lucro (para cálculo correto do Lucro Real)")
    if not dados.compras_mercadorias:
        r.dados_faltantes.append("Compras de mercadorias/insumos (para cálculo de créditos PIS/COFINS)")

    r.confiabilidade = "estimada" if (fat_m > 0 and dados.margem_lucro) else "preliminar"
    return r


def identificar_oportunidades(dados: DadosFiscais, resultados: dict) -> list[dict]:
    """Identifica oportunidades legais de economia tributária."""
    ops = []

    # Oportunidade 1: Fator R
    if dados.tipo_atividade == "servico" and dados.faturamento_12m > 0:
        fr = dados.fator_r
        if fr < 0.28:
            folha_alvo = dados.faturamento_12m * 0.28 / 12
            ops.append({
                "tipo": "fator_r",
                "titulo": "Fator R — Redução de alíquota no Simples Nacional",
                "descricao": f"Seu Fator R atual é {fr:.1%} (< 28%). Se a folha de pagamento aumentar para R$ {folha_alvo:,.2f}/mês, sua empresa migra do Anexo V para o Anexo III, reduzindo a alíquota.",
                "base_legal": "LC 123/2006, Anexos III e V; Resolução CGSN 140/2018",
                "tributo": "Simples Nacional",
                "risco": "baixo",
            })

    # Oportunidade 2: Créditos PIS/COFINS (Lucro Real vs Presumido)
    r_real = resultados.get("real")
    r_presumido = resultados.get("presumido")
    if r_real and r_presumido:
        if r_real.total_mensal < r_presumido.total_mensal:
            economia = r_presumido.total_mensal - r_real.total_mensal
            ops.append({
                "tipo": "regime",
                "titulo": "Migração para Lucro Real pode gerar economia",
                "descricao": f"A simulação indica economia potencial de R$ {economia:,.2f}/mês ao migrar para o Lucro Real, principalmente pelo aproveitamento de créditos de PIS/COFINS (1,65% e 7,6%) sobre insumos.",
                "base_legal": "Lei 10.637/2002 e Lei 10.833/2003",
                "tributo": "PIS/COFINS",
                "risco": "baixo",
                "economia_estimada": economia,
            })

    # Oportunidade 3: Exclusão ICMS base PIS/COFINS (Tese do Século)
    if dados.tipo_atividade in ("comercio", "industria", "misto"):
        ops.append({
            "tipo": "tese_juridica",
            "titulo": "Exclusão do ICMS da base de PIS/COFINS (Tema 69 STF)",
            "descricao": "O STF fixou que o ICMS não integra a base de cálculo do PIS e COFINS (RE 574.706). É possível recuperar valores pagos a maior nos últimos 5 anos, mediante habilitação administrativa ou ação judicial.",
            "base_legal": "STF RE 574.706 — Tema 69 (Tese do Século)",
            "tributo": "PIS/COFINS",
            "risco": "baixo",
            "prazo_prescricional": "5 anos (CTN, art. 168)",
        })

    # Oportunidade 4: Revisão CNAE
    if not dados.cnae_principal:
        ops.append({
            "tipo": "cnae",
            "titulo": "Revisar CNAE — Impacto direto na tributação",
            "descricao": "O CNAE define o Anexo do Simples Nacional e pode afetar alíquotas de ISS e ICMS. CNAEs incompatíveis com a atividade real geram risco fiscal e podem impedir o Simples Nacional.",
            "base_legal": "LC 123/2006; Resolução CGSN 140/2018",
            "tributo": "Múltiplos",
            "risco": "medio",
        })

    return ops


def identificar_alertas(dados: DadosFiscais, resultados: dict) -> list[dict]:
    """Identifica alertas de risco fiscal."""
    alertas = []
    rb12 = dados.faturamento_12m or (dados.faturamento_mensal * 12)

    # Alerta: próximo do limite Simples
    if rb12 > 0:
        if 4_320_000 <= rb12 <= 4_800_000:
            alertas.append({
                "tipo": "limite_regime",
                "titulo": "Faturamento próximo do limite do Simples Nacional",
                "descricao": f"Seu faturamento anual (R$ {rb12:,.2f}) está próximo do limite de R$ 4,8M do Simples Nacional. Planeje a transição com antecedência.",
                "severidade": "alto",
                "acao": "Consultar contador para planejar transição de regime antes de ultrapassar o limite",
            })
        elif 72_000_000 <= rb12 <= 78_000_000:
            alertas.append({
                "tipo": "limite_regime",
                "titulo": "Faturamento próximo do limite do Lucro Presumido",
                "descricao": f"Faturamento próximo de R$ 78M/ano. Acima desse valor o Lucro Real é obrigatório.",
                "severidade": "alto",
                "acao": "Iniciar estruturação da contabilidade para Lucro Real",
            })

    # Alerta: margem incompatível
    if dados.margem_lucro and dados.tipo_atividade == "servico":
        if dados.margem_lucro < 0.15 and rb12 > 0:
            alertas.append({
                "tipo": "margem_incompativel",
                "titulo": "Margem de lucro muito baixa para prestação de serviços",
                "descricao": f"Margem de {dados.margem_lucro:.0%} pode ser incompatível com o Lucro Presumido (que presume 32%). Isso significa que você pode estar pagando IRPJ sobre lucro que não existe.",
                "severidade": "medio",
                "acao": "Avaliar migração para Lucro Real onde o imposto incide sobre o lucro real apurado",
            })

    # Alerta: CNAE ausente
    if not dados.cnae_principal:
        alertas.append({
            "tipo": "dados_faltantes",
            "titulo": "CNAE principal não informado",
            "descricao": "O CNAE é fundamental para determinar o regime tributário correto, o Anexo do Simples Nacional e as alíquotas de ISS e ICMS.",
            "severidade": "medio",
            "acao": "Informar o CNAE principal da empresa",
        })

    # Alerta: folha sem dados
    if dados.tipo_atividade == "servico" and not dados.folha_pagamento:
        alertas.append({
            "tipo": "dados_faltantes",
            "titulo": "Folha de pagamento não informada",
            "descricao": "Sem a folha de pagamento, não é possível calcular o Fator R, que é determinante para a alíquota de serviços no Simples Nacional.",
            "severidade": "medio",
            "acao": "Informar a folha de pagamento dos últimos 12 meses",
        })

    return alertas


def comparar_regimes(dados: DadosFiscais) -> dict:
    """Executa comparativo completo entre os três regimes."""
    simples   = calcular_simples(dados)
    presumido = calcular_presumido(dados)
    real      = calcular_real(dados)

    resultados = {
        "simples": simples,
        "presumido": presumido,
        "real": real,
    }

    # Determina regime mais econômico (apenas entre aplicáveis)
    aplicaveis = {
        k: v for k, v in resultados.items()
        if v.confiabilidade != "inaplicavel" and v.total_mensal > 0
    }

    if aplicaveis:
        regime_min = min(aplicaveis, key=lambda k: aplicaveis[k].total_mensal)
        regime_max = max(aplicaveis, key=lambda k: aplicaveis[k].total_mensal)
        economia_m = aplicaveis[regime_max].total_mensal - aplicaveis[regime_min].total_mensal
    else:
        regime_min = None
        economia_m = 0

    oportunidades = identificar_oportunidades(dados, resultados)
    alertas = identificar_alertas(dados, resultados)

    return {
        "regimes": {
            k: {
                "tributos": v.tributos,
                "total_mensal": round(v.total_mensal, 2),
                "total_anual": round(v.total_anual, 2),
                "carga_percentual": round(v.carga_percentual, 2),
                "observacoes": v.observacoes,
                "dados_faltantes": v.dados_faltantes,
                "confiabilidade": v.confiabilidade,
            }
            for k, v in resultados.items()
        },
        "regime_recomendado": regime_min,
        "economia_mensal_estimada": round(economia_m, 2),
        "economia_anual_estimada": round(economia_m * 12, 2),
        "fator_r": round(dados.fator_r, 4),
        "oportunidades": oportunidades,
        "alertas": alertas,
        "aviso_legal": (
            "Esta simulação é PRELIMINAR e tem finalidade de apoio à decisão. "
            "Com base nos dados informados e nas premissas adotadas, o regime "
            f"aparentemente mais vantajoso é o {regime_min or 'não determinado'}, "
            "condicionado à validação por contador responsável e conferência da "
            "legislação vigente. Nenhuma alteração de regime deve ser executada "
            "sem orientação profissional."
        ),
    }
