"""
EJC — Módulo Financeiro (modules/financeiro/router.py)

Gestão financeira do escritório:
  - Honorários por caso (fixo + êxito)
  - Controle de parcelas e inadimplência
  - Geração de link de pagamento Pix (estático)
  - Relatório mensal de receita por área e advogado
  - Previsão de receita de êxito (integrado à jurimetria)
  - DRE simplificado do escritório
"""
from __future__ import annotations

import logging
import qrcode
import io
import base64
from datetime import date, datetime
from decimal import Decimal, ROUND_HALF_UP, getcontext
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)
getcontext().prec = 28
router = APIRouter(prefix="/financeiro", tags=["Financeiro — Honorários & Cobrança"])

brl = lambda v: f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


# ── Schemas ────────────────────────────────────────────────

class HonorarioCreate(BaseModel):
    caso_id: str
    tipo: str = "fixo"        # fixo | exito | misto
    valor_fixo: float = 0
    percentual_exito: float = 0
    valor_sinal: float = 0
    numero_parcelas: int = 1
    data_primeira_parcela: str  # YYYY-MM-DD
    observacoes: Optional[str] = None


class PagamentoCreate(BaseModel):
    honorario_id: str
    valor_pago: float
    data_pagamento: str  # YYYY-MM-DD
    forma_pagamento: str = "pix"  # pix | transferencia | dinheiro | cartao
    comprovante: Optional[str] = None


class DespesaCreate(BaseModel):
    caso_id: Optional[str] = None
    descricao: str
    valor: float
    data: str  # YYYY-MM-DD
    tipo: str = "custo_processual"  # custo_processual | deslocamento | pericia | outros
    reembolsavel: bool = True


# ── Endpoints ──────────────────────────────────────────────

@router.post("/honorarios", status_code=201)
async def cadastrar_honorario(req: HonorarioCreate, db: AsyncSession = Depends(get_db)):
    """Cadastra honorários de um caso com parcelamento."""
    hid = str(uuid4())
    parcela_valor = Decimal(str(req.valor_fixo)) / max(req.numero_parcelas, 1)
    parcela_valor = parcela_valor.quantize(Decimal("0.01"), ROUND_HALF_UP)

    await db.execute(
        text("""
            INSERT INTO honorarios (id, caso_id, tipo, valor_fixo, percentual_exito,
                valor_sinal, numero_parcelas, valor_parcela, data_primeira_parcela,
                status, observacoes)
            VALUES (:id,:cid,:tipo,:vf,:pct,:sinal,:np,:vp,:dp,'ativo',:obs)
        """),
        {
            "id": hid, "cid": req.caso_id, "tipo": req.tipo,
            "vf": req.valor_fixo, "pct": req.percentual_exito,
            "sinal": req.valor_sinal, "np": req.numero_parcelas,
            "vp": float(parcela_valor), "dp": req.data_primeira_parcela,
            "obs": req.observacoes,
        },
    )

    # Gera parcelas
    from datetime import timedelta
    d = datetime.strptime(req.data_primeira_parcela, "%Y-%m-%d").date()
    for i in range(req.numero_parcelas):
        venc = d.replace(month=(d.month - 1 + i) % 12 + 1,
                         year=d.year + ((d.month - 1 + i) // 12))
        await db.execute(
            text("""
                INSERT INTO parcelas_honorarios (id, honorario_id, numero, valor, data_vencimento)
                VALUES (:id,:hid,:n,:v,:dv)
            """),
            {"id": str(uuid4()), "hid": hid, "n": i+1,
             "v": float(parcela_valor), "dv": str(venc)},
        )

    return {
        "id": hid, "caso_id": req.caso_id,
        "valor_fixo": brl(Decimal(str(req.valor_fixo))),
        "valor_parcela": brl(parcela_valor),
        "numero_parcelas": req.numero_parcelas,
    }


@router.get("/honorarios/{caso_id}")
async def honorarios_do_caso(caso_id: str, db: AsyncSession = Depends(get_db)):
    """Honorários e parcelas de um caso."""
    # JOIN único — elimina N+1 queries
    rows_h = await db.execute(
        text("""
            SELECT h.*,
                   COALESCE(json_agg(
                       json_build_object(
                           'id', p.id, 'numero', p.numero, 'valor', p.valor,
                           'data_vencimento', p.data_vencimento,
                           'valor_pago', p.valor_pago, 'pago', p.pago
                       ) ORDER BY p.numero
                   ) FILTER (WHERE p.id IS NOT NULL), '[]') AS parcelas,
                   COALESCE(SUM(p.valor_pago), 0) AS total_pago_raw
            FROM honorarios h
            LEFT JOIN parcelas_honorarios p ON p.honorario_id = h.id
            WHERE h.caso_id = :id
            GROUP BY h.id
        """), {"id": caso_id}
    )
    hons = []
    for r in rows_h.mappings():
        h = dict(r)
        import json as _json
        h["parcelas"] = _json.loads(h["parcelas"]) if isinstance(h["parcelas"], str) else (h["parcelas"] or [])
        pago = float(h.pop("total_pago_raw") or 0)
        h["total_pago"] = brl(Decimal(str(pago)))
        h["total_pendente"] = brl(Decimal(str(h["valor_fixo"] or 0)) - Decimal(str(pago)))

    return {"honorarios": hons}


@router.post("/pagamentos", status_code=201)
async def registrar_pagamento(req: PagamentoCreate, db: AsyncSession = Depends(get_db)):
    """Registra um pagamento de honorários."""
    pid = str(uuid4())
    await db.execute(
        text("""
            INSERT INTO pagamentos_honorarios (id, honorario_id, valor_pago,
                data_pagamento, forma_pagamento)
            VALUES (:id,:hid,:vp,:dp,:fp)
        """),
        {"id": pid, "hid": req.honorario_id, "vp": req.valor_pago,
         "dp": req.data_pagamento, "fp": req.forma_pagamento},
    )
    # Atualiza parcela mais antiga como paga
    await db.execute(
        text("""
            UPDATE parcelas_honorarios SET valor_pago=:v, data_pagamento=:dp, status='pago'
            WHERE honorario_id=:hid AND status='pendente'
              AND id=(SELECT id FROM parcelas_honorarios WHERE honorario_id=:hid AND status='pendente' ORDER BY numero LIMIT 1)
        """),
        {"v": req.valor_pago, "dp": req.data_pagamento, "hid": req.honorario_id},
    )
    return {"id": pid, "message": "Pagamento registrado."}


@router.post("/despesas", status_code=201)
async def registrar_despesa(req: DespesaCreate, db: AsyncSession = Depends(get_db)):
    """Registra despesa processual ou do escritório."""
    did = str(uuid4())
    await db.execute(
        text("""
            INSERT INTO despesas (id, caso_id, descricao, valor, data, tipo, reembolsavel)
            VALUES (:id,:cid,:desc,:v,:dt,:tipo,:reimb)
        """),
        {"id": did, "cid": req.caso_id, "desc": req.descricao, "v": req.valor,
         "dt": req.data, "tipo": req.tipo, "reimb": req.reembolsavel},
    )
    return {"id": did, "message": "Despesa registrada."}


@router.get("/relatorio-mensal")
async def relatorio_mensal(
    ano: int = Query(date.today().year),
    mes: int = Query(date.today().month, ge=1, le=12),
    db: AsyncSession = Depends(get_db),
):
    """DRE simplificado do escritório para o mês."""
    mes_str = f"{ano}-{mes:02d}"

    row = await db.execute(
        text("""
            SELECT
                COALESCE(SUM(ph.valor_pago), 0) AS receita_honorarios,
                COUNT(DISTINCT ph.honorario_id) AS pagamentos_recebidos
            FROM pagamentos_honorarios ph
            WHERE ph.data_pagamento LIKE :mes
        """),
        {"mes": f"{mes_str}%"},
    )
    receita = dict(row.mappings().first())

    row2 = await db.execute(
        text("SELECT COALESCE(SUM(valor),0) AS despesas FROM despesas WHERE data LIKE :mes"),
        {"mes": f"{mes_str}%"},
    )
    despesas = dict(row2.mappings().first())

    rec = Decimal(str(receita["receita_honorarios"]))
    desp = Decimal(str(despesas["despesas"]))
    lucro = rec - desp

    return {
        "periodo": f"{mes:02d}/{ano}",
        "receita_bruta":   brl(rec),
        "despesas_totais": brl(desp),
        "lucro_liquido":   brl(lucro),
        "margem":          f"{float(lucro / rec * 100):.1f}%" if rec > 0 else "0%",
        "pagamentos_recebidos": receita["pagamentos_recebidos"],
    }


@router.get("/inadimplentes")
async def listar_inadimplentes(db: AsyncSession = Depends(get_db)):
    """Lista parcelas vencidas não pagas."""
    rows = await db.execute(
        text("""
            SELECT p.id, p.numero, p.valor, p.data_vencimento,
                   h.caso_id, c.titulo AS caso_titulo, c.cliente_nome,
                   CURRENT_DATE - p.data_vencimento AS dias_atraso
            FROM parcelas_honorarios p
            JOIN honorarios h ON h.id = p.honorario_id
            JOIN casos c ON c.id = h.caso_id
            WHERE p.status = 'pendente'
              AND p.data_vencimento < CURRENT_DATE
            ORDER BY p.data_vencimento ASC
        """)
    )
    inadimplentes = [dict(r) for r in rows.mappings()]
    total_em_atraso = sum(Decimal(str(i["valor"])) for i in inadimplentes)

    return {
        "total_em_atraso": brl(total_em_atraso),
        "casos_inadimplentes": len(inadimplentes),
        "detalhamento": inadimplentes,
    }


@router.get("/pix-qrcode")
async def gerar_pix_qrcode(
    valor: float = Query(..., description="Valor em R$"),
    chave_pix: str = Query(..., description="Chave Pix do escritório"),
    nome_beneficiario: str = Query("Escritorio de Advocacia", max_length=25),
    descricao: str = Query("Honorarios Advocaticios", max_length=30),
):
    """
    Gera QR Code Pix estático para cobrança de honorários.
    Retorna imagem PNG base64 + payload Pix.
    """
    # Payload Pix estático (padrão EMV/BACEN — BR Code)
    def emv(id: str, valor: str) -> str:
        length = f"{len(valor):02d}"
        return f"{id}{length}{valor}"

    chave_limpa = chave_pix.replace(" ", "")
    gui = "BR.GOV.BCB.PIX"
    gui_valor = emv("00", gui) + emv("01", chave_limpa) + emv("02", descricao[:25])
    merchant_info = emv("26", gui_valor)
    valor_str = f"{valor:.2f}"

    payload_sem_crc = (
        emv("00", "01") +
        merchant_info +
        emv("52", "0000") +
        emv("53", "986") +       # BRL
        emv("54", valor_str) +
        emv("58", "BR") +
        emv("59", nome_beneficiario[:25]) +
        emv("60", "SAO PAULO") +
        emv("62", emv("05", "***")) +
        "6304"
    )

    # CRC16
    def crc16(data: str) -> str:
        crc = 0xFFFF
        for char in data.encode("ascii"):
            crc ^= char << 8
            for _ in range(8):
                crc = (crc << 1) ^ 0x1021 if crc & 0x8000 else crc << 1
            crc &= 0xFFFF
        return format(crc, "04X")

    payload = payload_sem_crc + crc16(payload_sem_crc)

    # Gera QR Code
    try:
        import qrcode
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(payload)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        qr_b64 = base64.b64encode(buf.getvalue()).decode()
    except ImportError:
        qr_b64 = None

    return {
        "payload_pix": payload,
        "qr_base64": qr_b64,
        "valor": brl(Decimal(str(valor))),
        "chave": chave_pix,
        "beneficiario": nome_beneficiario,
        "instrucao": "Exiba o QR Code ao cliente para pagamento via qualquer app bancário.",
    }
