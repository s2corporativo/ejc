"""
EJC — Módulo Portal do Cliente (modules/portal/router.py)

Área exclusiva para clientes acompanharem seu caso:
  - Acesso via token único (sem senha complexa)
  - Visualização do status e movimentações do caso
  - Download de documentos liberados pelo advogado
  - Próximos prazos e audiências
  - Envio de documentos ao advogado
  - Chat simplificado com aviso jurídico
  - Interface pensada para leigos (linguagem acessível)
"""
from __future__ import annotations

import logging
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials, HTTPBasic
from fastapi import Security
from jose import JWTError, jwt
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_db
from app.modules.auditoria.middleware import adicionar_aviso, AVISO_CURTO
from app.modules.redacao.service import LegalDraftService

logger = logging.getLogger(__name__)
settings = get_settings()
router = APIRouter(prefix="/portal", tags=["Portal do Cliente"])

bearer = HTTPBearer(auto_error=False)

PORTAL_TOKEN_EXPIRE_DAYS = 30
ALGORITHM = "HS256"


# ── Helpers de token do portal ──────────────────────────────

def _criar_token_portal(caso_id: str, cliente_nome: str) -> str:
    payload = {
        "sub":    caso_id,
        "nome":   cliente_nome,
        "type":   "portal",
        "exp":    datetime.now(timezone.utc) + timedelta(days=PORTAL_TOKEN_EXPIRE_DAYS),
    }
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)


def _verificar_token_portal(token: str) -> dict:
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
        if payload.get("type") != "portal":
            raise HTTPException(401, "Token de portal inválido")
        return payload
    except JWTError:
        raise HTTPException(401, "Token expirado ou inválido. Solicite novo link ao seu advogado.")


async def get_portal_user(
    creds: Optional[HTTPAuthorizationCredentials] = Security(bearer),
) -> dict:
    if not creds:
        raise HTTPException(401, "Token obrigatório — solicite o link de acesso ao seu advogado")
    return _verificar_token_portal(creds.credentials)


# ── Schemas ─────────────────────────────────────────────────

class GerarTokenReq(BaseModel):
    caso_id: str
    cliente_nome: str
    dias_validade: int = 30


class MensagemClienteReq(BaseModel):
    mensagem: str


# ── Endpoints de administração (advogado gera token) ────────

@router.post("/gerar-link")
async def gerar_link_cliente(
    req: GerarTokenReq,
    db: AsyncSession = Depends(get_db),
):
    """
    Gera link de acesso para o cliente acompanhar seu caso.
    Chamado pelo advogado. O link é enviado ao cliente por e-mail/WhatsApp.
    """
    # Verifica se o caso existe
    row = await db.execute(text("SELECT id,titulo FROM casos WHERE id=:id"), {"id": req.caso_id})
    caso = row.mappings().first()
    if not caso:
        raise HTTPException(404, "Caso não encontrado")

    token = _criar_token_portal(req.caso_id, req.cliente_nome)

    # Registra acesso no banco
    await db.execute(
        text("""
            INSERT INTO portal_tokens (id, caso_id, cliente_nome, token, expira_em)
            VALUES (:id,:cid,:nome,:tok,:exp)
            ON CONFLICT (caso_id) DO UPDATE
            SET token=:tok, cliente_nome=:nome, expira_em=:exp, updated_at=NOW()
        """),
        {
            "id": str(uuid4()), "cid": req.caso_id, "nome": req.cliente_nome,
            "tok": token[:50] + "...",
            "exp": datetime.now(timezone.utc) + timedelta(days=req.dias_validade),
        },
    )

    return {
        "token": token,
        "link_portal": f"http://localhost:3000/portal?token={token}",
        "cliente": req.cliente_nome,
        "caso": dict(caso),
        "validade_dias": req.dias_validade,
        "instrucoes": "Envie o link acima ao cliente. Ele pode acessar o portal sem precisar criar conta.",
    }


# ── Endpoints do cliente ────────────────────────────────────

@router.get("/meu-caso")
async def meu_caso(
    db: AsyncSession = Depends(get_db),
    portal: dict = Depends(get_portal_user),
):
    """
    Retorna informações do caso em linguagem acessível para o cliente.
    """
    caso_id = portal["sub"]
    row = await db.execute(text("SELECT * FROM casos WHERE id=:id"), {"id": caso_id})
    caso = row.mappings().first()
    if not caso:
        raise HTTPException(404, "Caso não encontrado")
    c = dict(caso)

    # Traduz status para linguagem do cliente
    status_amigavel = {
        "prospeccao": "Em análise inicial",
        "ativo":      "Em andamento",
        "aguardando": "Aguardando decisão",
        "encerrado":  "Encerrado",
        "arquivado":  "Arquivado",
    }

    return {
        "seu_caso": {
            "titulo":         c["titulo"],
            "area":           c["area_juridica"],
            "status":         status_amigavel.get(c["status"], c["status"]),
            "numero_processo": c.get("numero_processo", "Em processamento"),
            "tribunal":       c.get("tribunal", "A definir"),
        },
        "bem_vindo": f"Olá, {portal['nome']}! Aqui você acompanha seu processo.",
        "aviso": "Para dúvidas, fale com seu advogado. Este portal é apenas informativo.",
    }


@router.get("/andamentos")
async def meus_andamentos(
    db: AsyncSession = Depends(get_db),
    portal: dict = Depends(get_portal_user),
):
    """Movimentações do caso em linguagem acessível."""
    rows = await db.execute(
        text("""
            SELECT tipo, descricao, data_evento, created_at
            FROM caso_movimentacoes
            WHERE caso_id=:id
            ORDER BY created_at DESC
            LIMIT 20
        """),
        {"id": portal["sub"]},
    )
    tipos_amigaveis = {
        "peticao": "📄 Petição apresentada",
        "audiencia": "⚖️ Audiência",
        "decisao": "📋 Decisão do juiz",
        "recurso": "📤 Recurso apresentado",
        "acordo": "🤝 Proposta de acordo",
        "outros": "📌 Atualização",
    }
    andamentos = []
    for r in rows.mappings():
        d = dict(r)
        d["tipo_amigavel"] = tipos_amigaveis.get(d["tipo"], d["tipo"])
        andamentos.append(d)
    return {"andamentos": andamentos, "total": len(andamentos)}


@router.get("/proximos-passos")
async def proximos_passos(
    db: AsyncSession = Depends(get_db),
    portal: dict = Depends(get_portal_user),
):
    """Prazos e audiências futuras do caso (versão simplificada)."""
    caso = await db.execute(text("SELECT espaco_id FROM casos WHERE id=:id"), {"id": portal["sub"]})
    c = caso.mappings().first()
    espaco_id = c["espaco_id"] if c else None

    prazos = []
    if espaco_id:
        rows = await db.execute(
            text("""
                SELECT titulo, tipo_prazo, data_vencimento, status
                FROM prazos
                WHERE espaco_id=:eid AND status='pendente' AND data_vencimento >= CURRENT_DATE
                ORDER BY data_vencimento ASC LIMIT 5
            """),
            {"eid": espaco_id},
        )
        prazos = [dict(r) for r in rows.mappings()]

    return {
        "proximos_passos": prazos,
        "mensagem": "Estas são as próximas datas importantes do seu processo." if prazos
                    else "Nenhuma data importante cadastrada ainda. Seu advogado atualizará em breve.",
    }


@router.get("/documentos")
async def meus_documentos(
    db: AsyncSession = Depends(get_db),
    portal: dict = Depends(get_portal_user),
):
    """Documentos liberados pelo advogado para visualização do cliente."""
    rows = await db.execute(
        text("""
            SELECT ld.id, ld.title, ld.document_type, ld.status, ld.created_at
            FROM legal_documents ld
            JOIN caso_movimentacoes cm ON cm.documento_id = ld.id
            WHERE cm.caso_id=:cid AND ld.status='final'
            ORDER BY ld.created_at DESC
        """),
        {"id": portal["sub"]},
    )
    docs = [dict(r) for r in rows.mappings()]
    return {
        "documentos": docs,
        "aviso": "Apenas documentos marcados como 'final' pelo advogado ficam disponíveis aqui.",
    }


@router.post("/enviar-documento")
async def enviar_documento_para_advogado(
    file: UploadFile = File(...),
    descricao: str = "",
    db: AsyncSession = Depends(get_db),
    portal: dict = Depends(get_portal_user),
):
    """Cliente envia documento para o advogado (procurações, contratos, etc.)."""
    content = await file.read()
    # Salva como documento na base RAG com categoria "cliente"
    from app.modules.rag.knowledge_base import LegalKnowledgeBase
    kb = LegalKnowledgeBase()
    resultado = await kb.ingest_file(
        db=db, file_bytes=content, filename=f"cliente_{file.filename}",
        category="cliente",
        metadata={"caso_id": portal["sub"], "cliente": portal["nome"],
                  "descricao": descricao},
    )
    # Registra movimentação no caso
    await db.execute(
        text("""
            INSERT INTO caso_movimentacoes (id, caso_id, tipo, descricao)
            VALUES (:id,:cid,'outros',:desc)
        """),
        {"id": str(uuid4()), "cid": portal["sub"],
         "desc": f"[PORTAL CLIENTE] Documento enviado: {file.filename} — {descricao}"},
    )
    return {
        "mensagem": "Documento enviado com sucesso! Seu advogado foi notificado.",
        "filename": file.filename,
    }


@router.post("/chat")
async def chat_cliente(
    req: MensagemClienteReq,
    db: AsyncSession = Depends(get_db),
    portal: dict = Depends(get_portal_user),
):
    """
    Chat simplificado para o cliente. Respostas em linguagem acessível.
    Aviso jurídico obrigatório em todas as respostas.
    """
    llm = LegalDraftService()
    prompt = f"""Você está respondendo para um cliente leigo (não advogado).
Use linguagem simples, sem jargão jurídico. Seja claro e tranquilizador.
Se a pergunta precisar de análise jurídica específica do caso, oriente o cliente
a falar diretamente com seu advogado.

Pergunta do cliente: {req.mensagem}"""

    resposta = await llm.answer_from_context(query=req.mensagem, context=req.mensagem)
    return {
        "resposta": adicionar_aviso(resposta, curto=True),
        "dica": "Para assuntos específicos do seu processo, entre em contato com seu advogado.",
    }
