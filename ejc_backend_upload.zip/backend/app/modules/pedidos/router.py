"""
EJC — Módulo Pedidos Públicos (modules/pedidos/router.py)

API pública para o site de venda de petições.
Endpoints sem autenticação JWT — qualquer pessoa pode acessar.

Fluxo completo:
  POST /pedidos/criar          → cria pedido + gera link MP
  GET  /pedidos/{id}/status    → polling do status
  GET  /pedidos/{id}/download  → baixa petição (após pagamento)
  GET  /pedidos/planos          → lista planos e preços
"""
from __future__ import annotations

import logging
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.pagamento.router import criar_preferencia_mp, get_mp

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/pedidos", tags=["Pedidos — Site Público"])

AREAS = [
    "consumidor", "trabalhista", "civil", "previdenciario",
    "tributario", "familia", "criminal", "administrativo",
]

ESTADOS_BR = [
    "AC","AL","AM","AP","BA","CE","DF","ES","GO","MA","MG","MS",
    "MT","PA","PB","PE","PI","PR","RJ","RN","RO","RR","RS","SC",
    "SE","SP","TO",
]


# ── Schemas ─────────────────────────────────────────────────────

class CriarPedidoRequest(BaseModel):
    plano_id: str = Field(..., description="peticao ou peticao_instrucoes")
    # Dados pessoais
    cliente_nome:     str = Field(..., min_length=3, max_length=120)
    cliente_email:    EmailStr
    cliente_cpf:      Optional[str] = None
    cliente_telefone: Optional[str] = None
    cliente_estado:   str = Field(..., description="UF — ex: SP, MG, RJ")
    # Dados da petição
    area_juridica:    str = Field(..., description="consumidor | trabalhista | civil ...")
    fatos:            str = Field(..., min_length=100, max_length=5000,
                                  description="Descreva os fatos com detalhes")
    objetivo:         str = Field(..., min_length=30, max_length=1000,
                                  description="O que você quer obter com a ação")
    parte_contraria:  Optional[str] = None
    valor_causa:      Optional[float] = Field(None, gt=0)


# ── Endpoints ───────────────────────────────────────────────────

@router.get("/planos")
async def listar_planos(db: AsyncSession = Depends(get_db)):
    """Lista os planos disponíveis com preços."""
    rows = await db.execute(
        text("SELECT * FROM planos WHERE ativo=true ORDER BY preco ASC")
    )
    planos = [dict(r) for r in rows.mappings()]
    return {
        "planos": planos,
        "beneficios": {
            "peticao": [
                "✅ Petição completa gerada por IA jurídica",
                "✅ Fundamentação legal automática",
                "✅ Download em PDF e DOCX",
                "✅ Enviada por e-mail",
                "✅ Pronta para protocolar",
            ],
            "peticao_instrucoes": [
                "✅ Tudo do plano Petição",
                "✅ Guia completo do Juizado Especial do seu estado",
                "✅ Passo a passo para dar entrada na ação",
                "✅ Endereço e horários do JE mais próximo",
                "✅ Lista de documentos necessários",
                "✅ Orientações sobre audiência de conciliação",
            ],
        },
    }


@router.post("/criar", status_code=201)
async def criar_pedido(
    req: CriarPedidoRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Cria um novo pedido e retorna o link de pagamento do Mercado Pago.
    O cliente é redirecionado para o checkout do MP.
    Após o pagamento, a petição é gerada automaticamente.
    """
    # Valida plano
    row_plano = await db.execute(
        text("SELECT * FROM planos WHERE id=:id AND ativo=true"),
        {"id": req.plano_id},
    )
    plano = row_plano.mappings().first()
    if not plano:
        raise HTTPException(404, f"Plano '{req.plano_id}' não encontrado")

    # Valida área e estado
    if req.area_juridica not in AREAS:
        raise HTTPException(422, f"Área inválida. Válidas: {AREAS}")
    if req.cliente_estado.upper() not in ESTADOS_BR:
        raise HTTPException(422, f"Estado inválido. Use a sigla: SP, RJ, MG...")

    # Cria o pedido no banco
    pedido_id = str(uuid4())
    await db.execute(
        text("""
            INSERT INTO pedidos (
                id, plano_id, cliente_nome, cliente_email, cliente_cpf,
                cliente_telefone, cliente_estado, area_juridica,
                tipo_documento, fatos, objetivo, parte_contraria, valor_causa
            ) VALUES (
                :id,:plano,:nome,:email,:cpf,
                :tel,:uf,:area,
                'peticao_inicial',:fatos,:obj,:pc,:vc
            )
        """),
        {
            "id":    pedido_id,
            "plano": req.plano_id,
            "nome":  req.cliente_nome,
            "email": req.cliente_email,
            "cpf":   req.cliente_cpf,
            "tel":   req.cliente_telefone,
            "uf":    req.cliente_estado.upper(),
            "area":  req.area_juridica,
            "fatos": req.fatos,
            "obj":   req.objetivo,
            "pc":    req.parte_contraria,
            "vc":    req.valor_causa,
        },
    )

    # Busca número gerado
    row_num = await db.execute(
        text("SELECT numero FROM pedidos WHERE id=:id"), {"id": pedido_id}
    )
    numero = row_num.scalar()

    # Cria preferência de pagamento no MP
    cfg = get_mp()
    try:
        mp = await criar_preferencia_mp(
            pedido_id=pedido_id,
            numero=numero,
            plano_nome=plano["nome"],
            valor=float(plano["preco"]),
            email_cliente=req.cliente_email,
            nome_cliente=req.cliente_nome,
            cfg=cfg,
        )

        # Salva a preferência MP no pedido
        await db.execute(
            text("UPDATE pedidos SET mp_preference_id=:pref WHERE id=:id"),
            {"pref": mp["preference_id"], "id": pedido_id},
        )

    except RuntimeError as e:
        # MP não configurado — modo desenvolvimento: aprova automaticamente
        logger.warning(f"[Pedidos] MP não configurado: {e} — modo dev ativo")
        mp = {
            "preference_id": "dev-mode",
            "init_point":    f"/pedido/{numero}/dev-aprovado",
            "sandbox_point": f"/pedido/{numero}/dev-aprovado",
        }

    await db.commit()

    return {
        "pedido_id":     pedido_id,
        "numero":        numero,
        "plano":         plano["nome"],
        "valor":         f"R$ {float(plano['preco']):.2f}".replace(".", ","),
        "checkout_url":  mp["init_point"],
        "sandbox_url":   mp.get("sandbox_point", ""),
        "instrucoes":    "Você será redirecionado para o pagamento. Após confirmar, a petição será gerada automaticamente e enviada para seu e-mail.",
    }


@router.get("/{pedido_id}/status")
async def status_pedido(pedido_id: str, db: AsyncSession = Depends(get_db)):
    """
    Polling do status do pedido.
    Frontend chama a cada 3s enquanto status='gerando'.
    """
    row = await db.execute(
        text("""
            SELECT id, numero, status, plano_id,
                   cliente_nome, cliente_email, cliente_estado,
                   area_juridica, pago_em, entregue_em,
                   peticao_md IS NOT NULL AS tem_peticao,
                   instrucoes_md IS NOT NULL AS tem_instrucoes,
                   created_at
            FROM pedidos WHERE id=:id
        """),
        {"id": pedido_id},
    )
    p = row.mappings().first()
    if not p:
        raise HTTPException(404, "Pedido não encontrado")

    d = dict(p)
    d["mensagem_status"] = {
        "aguardando_pagamento": "Aguardando confirmação do pagamento...",
        "pago":                 "Pagamento confirmado! Gerando sua petição...",
        "gerando":              "⚙️ Gerando sua petição com IA jurídica...",
        "pronto":               "✅ Petição pronta! Enviando por e-mail...",
        "entregue":             "🎉 Petição entregue! Verifique seu e-mail.",
        "cancelado":            "Pedido cancelado.",
        "reembolsado":          "Reembolso processado.",
    }.get(d["status"], d["status"])

    return d


@router.get("/{pedido_id}/download")
async def download_peticao(
    pedido_id: str,
    formato: str = "md",   # md | pdf
    db: AsyncSession = Depends(get_db),
):
    """
    Download da petição após pagamento confirmado.
    Formato md = Markdown | pdf = PDF via LibreOffice.
    """
    row = await db.execute(
        text("SELECT status, peticao_md, instrucoes_md, cliente_nome, numero FROM pedidos WHERE id=:id"),
        {"id": pedido_id},
    )
    p = row.mappings().first()
    if not p:
        raise HTTPException(404, "Pedido não encontrado")

    if p["status"] not in ("pronto", "entregue"):
        raise HTTPException(402, "Pedido não pago ou petição ainda não gerada.")

    if not p["peticao_md"]:
        raise HTTPException(503, "Petição ainda sendo gerada. Tente em instantes.")

    conteudo = p["peticao_md"]
    if p["instrucoes_md"]:
        conteudo += f"\n\n---\n\n{p['instrucoes_md']}"

    if formato == "pdf":
        # Converte via exportação DOCX→PDF
        from app.modules.exportacao.router import _gerar_docx
        import subprocess, tempfile, os, io
        try:
            docx_bytes = _gerar_docx(f"Petição — Pedido {p['numero']}", conteudo)
            with tempfile.TemporaryDirectory() as tmp:
                docx_path = os.path.join(tmp, "peticao.docx")
                pdf_path  = os.path.join(tmp, "peticao.pdf")
                with open(docx_path, "wb") as f:
                    f.write(docx_bytes)
                result = subprocess.run(
                    ["libreoffice", "--headless", "--convert-to", "pdf", "--outdir", tmp, docx_path],
                    capture_output=True, timeout=30
                )
                if result.returncode == 0 and os.path.exists(pdf_path):
                    with open(pdf_path, "rb") as f:
                        pdf_bytes = f.read()
                    return StreamingResponse(
                        io.BytesIO(pdf_bytes),
                        media_type="application/pdf",
                        headers={"Content-Disposition": f"attachment; filename=peticao_{p['numero']}.pdf"},
                    )
        except Exception as e:
            logger.warning(f"PDF falhou: {e} — entregando Markdown")

    # Fallback: entrega Markdown como .txt
    return StreamingResponse(
        iter([conteudo.encode()]),
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename=peticao_{p['numero']}.txt"},
    )


@router.post("/{pedido_id}/dev-aprovar")
async def dev_aprovar(
    pedido_id: str,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
):
    """
    APENAS DESENVOLVIMENTO — aprova um pedido sem pagamento real.
    Remover em produção ou proteger com autenticação admin.
    """
    await db.execute(
        text("""
            UPDATE pedidos
            SET status='pago', mp_payment_id='dev-test',
                valor_pago=19.90, pago_em=NOW(), updated_at=NOW()
            WHERE id=:id AND status='aguardando_pagamento'
        """),
        {"id": pedido_id},
    )
    await db.commit()
    background_tasks.add_task(
        __import__("app.modules.pagamento.router", fromlist=["_gerar_e_entregar_peticao"])
        ._gerar_e_entregar_peticao,
        pedido_id
    )
    return {"message": "Pedido aprovado (modo dev). Gerando petição..."}


# ── Contadores públicos ────────────────────────────────────────────────

@router.get("/estatisticas")
async def estatisticas_publicas(db: AsyncSession = Depends(get_db)):
    """
    Contadores para exibir na landing page.
    Retorna números reais do banco de dados.
    """
    row = await db.execute(text("""
        SELECT
            COUNT(*) FILTER (WHERE status IN ('pronto','entregue')) AS peticoes_entregues,
            COUNT(*) FILTER (WHERE status='entregue')               AS clientes_atendidos,
            COUNT(DISTINCT cliente_estado)                           AS estados_atendidos,
            COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '24 hours') AS hoje
        FROM pedidos
    """))
    r = dict(row.mappings().first() or {})
    return {
        "peticoes_geradas":   int(r.get("peticoes_entregues", 0)),
        "clientes_atendidos": int(r.get("clientes_atendidos", 0)),
        "estados_atendidos":  int(r.get("estados_atendidos", 0)),
        "hoje":               int(r.get("hoje", 0)),
    }


@router.get("/depoimentos")
async def listar_depoimentos(db: AsyncSession = Depends(get_db)):
    """Depoimentos de clientes para a landing page."""
    rows = await db.execute(
        text("SELECT nome, estado, area, texto, resultado FROM depoimentos WHERE ativo=true ORDER BY ordem ASC")
    )
    return {"depoimentos": [dict(r) for r in rows.mappings()]}


# ── Lead "só paga se ganhar" ────────────────────────────────────────────

@router.post("/lead-advogado", status_code=201)
async def cadastrar_lead(payload: dict, db: AsyncSession = Depends(get_db)):
    """
    Captura lead para o modelo 'só paga se ganhar'.
    Um advogado parceiro entra em contato pelo WhatsApp.
    """
    from uuid import uuid4
    lid = str(uuid4())
    await db.execute(text("""
        INSERT INTO leads_advogado (id, nome, email, telefone, estado, area, descricao, valor_estimado)
        VALUES (:id,:nome,:email,:tel,:uf,:area,:desc,:val)
    """), {
        "id":   lid,
        "nome": payload.get("nome", ""),
        "email":payload.get("email", ""),
        "tel":  payload.get("telefone"),
        "uf":   payload.get("estado", ""),
        "area": payload.get("area", "consumidor"),
        "desc": payload.get("descricao", ""),
        "val":  payload.get("valor_estimado"),
    })
    # Notifica via Telegram
    try:
        from app.modules.notificacoes.router import enviar_telegram
        msg = (
            f"🆕 *Novo Lead — Só Paga Se Ganhar*\n"
            f"Nome: {payload.get('nome')}\n"
            f"Estado: {payload.get('estado')} | Área: {payload.get('area')}\n"
            f"Valor estimado: R$ {payload.get('valor_estimado','?')}\n"
            f"Tel: {payload.get('telefone','não informado')}\n"
            f"Caso: {str(payload.get('descricao',''))[:200]}"
        )
        await enviar_telegram(msg)
    except Exception:
        pass
    return {"id": lid, "mensagem": "Recebemos seu caso! Um advogado parceiro entrará em contato em até 24h pelo WhatsApp."}


# ── Acompanhar por e-mail (sem login) ─────────────────────────────────

@router.get("/meus-pedidos/{email}")
async def pedidos_por_email(email: str, db: AsyncSession = Depends(get_db)):
    """
    Retorna pedidos de um e-mail sem exigir login.
    Cliente acessa pelo link enviado no e-mail.
    """
    rows = await db.execute(text("""
        SELECT numero, status, plano_id, area_juridica, created_at,
               peticao_md IS NOT NULL AS tem_peticao, id
        FROM pedidos
        WHERE LOWER(cliente_email)=LOWER(:email)
        ORDER BY created_at DESC
        LIMIT 20
    """), {"email": email})
    pedidos = [dict(r) for r in rows.mappings()]
    if not pedidos:
        raise HTTPException(404, "Nenhum pedido encontrado para este e-mail.")
    return {"email": email, "pedidos": pedidos}
