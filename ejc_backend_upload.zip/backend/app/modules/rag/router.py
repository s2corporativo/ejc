"""
EJC — Router RAG (modules/rag/router.py)
Endpoints: upload de documentos e consulta semântica
"""
from __future__ import annotations

import time
import logging
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_db
from app.modules.rag.knowledge_base import LegalKnowledgeBase
from app.modules.redacao.service import LegalDraftService
from app.schemas.legal import (
    DocumentUploadResponse,
    RAGQueryRequest,
    RAGQueryResponse,
)

logger = logging.getLogger(__name__)
settings = get_settings()
router = APIRouter(prefix="/rag", tags=["Base de Conhecimento (RAG)"])

# Singleton — inicializado na primeira requisição
_knowledge_base: Optional[LegalKnowledgeBase] = None
_draft_service: Optional[LegalDraftService] = None


def get_kb() -> LegalKnowledgeBase:
    global _knowledge_base
    if _knowledge_base is None:
        _knowledge_base = LegalKnowledgeBase()
    return _knowledge_base


def get_draft_svc() -> LegalDraftService:
    global _draft_service
    if _draft_service is None:
        _draft_service = LegalDraftService()
    return _draft_service


@router.post("/upload", response_model=DocumentUploadResponse, status_code=status.HTTP_201_CREATED)
async def upload_document(
    file: UploadFile = File(...),
    category: str = Form("geral"),
    db: AsyncSession = Depends(get_db),
    kb: LegalKnowledgeBase = Depends(get_kb),
):
    """
    Ingere um documento (PDF/DOCX/TXT) na base de conhecimento jurídico.
    Gera embeddings locais e armazena no pgvector.
    """
    max_bytes = settings.max_upload_mb * 1024 * 1024
    content = await file.read()

    if len(content) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"Arquivo excede o limite de {settings.max_upload_mb}MB.",
        )

    allowed_types = {"application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                     "text/plain"}
    if file.content_type not in allowed_types:
        raise HTTPException(status_code=415, detail="Tipo de arquivo não suportado. Use PDF, DOCX ou TXT.")

    try:
        result = await kb.ingest_file(
            db=db,
            file_bytes=content,
            filename=file.filename,
            category=category,
        )
        return DocumentUploadResponse(**result)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        logger.exception("Erro na ingestão do documento")
        raise HTTPException(status_code=500, detail=f"Erro interno na ingestão: {str(e)}")


@router.post("/query", response_model=RAGQueryResponse)
async def query_knowledge_base(
    request: RAGQueryRequest,
    db: AsyncSession = Depends(get_db),
    kb: LegalKnowledgeBase = Depends(get_kb),
    svc: LegalDraftService = Depends(get_draft_svc),
):
    """
    Consulta semântica na base + resposta gerada pelo LLM local (Ollama).
    """
    t0 = time.time()

    chunks = await kb.semantic_search(
        db=db,
        query=request.query,
        top_k=request.top_k,
        category=request.category,
    )

    if not chunks:
        return RAGQueryResponse(
            query=request.query,
            answer="Nenhum documento relevante encontrado na base de conhecimento para esta consulta.",
            sources=[],
            elapsed_ms=round((time.time() - t0) * 1000, 1),
        )

    context = "\n\n---\n\n".join(c["content"] for c in chunks)
    answer = await svc.answer_from_context(query=request.query, context=context)

    return RAGQueryResponse(
        query=request.query,
        answer=answer,
        sources=[
            {"filename": c["filename"], "category": c["category"], "similarity": c["similarity"]}
            for c in chunks
        ],
        elapsed_ms=round((time.time() - t0) * 1000, 1),
    )


@router.get("/documents")
async def list_documents(
    db: AsyncSession = Depends(get_db),
    kb: LegalKnowledgeBase = Depends(get_kb),
):
    """Lista todos os documentos na base de conhecimento."""
    docs = await kb.list_documents(db)
    return {"documents": docs, "total": len(docs)}
