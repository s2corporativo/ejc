"""
EJC — Módulo RAG: LegalKnowledgeBase (modules/rag/knowledge_base.py)

Pipeline:
  1. Recebe arquivo (PDF/DOCX/TXT)
  2. Extrai texto e divide em chunks sobrepostos
  3. Gera embeddings com sentence-transformers (local, sem API)
  4. Armazena chunks + vetores no PostgreSQL/pgvector
  5. Busca semântica via cosine similarity
"""
from __future__ import annotations

import io
import logging
import os
import time
from pathlib import Path
from typing import Optional
from uuid import UUID, uuid4

import PyPDF2
import aiofiles
from docx import Document as DocxDocument
from sentence_transformers import SentenceTransformer
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class LegalKnowledgeBase:
    """
    Cérebro do EJC: gerencia a base de conhecimento jurídico vetorial.
    Instanciar uma vez e reutilizar (o modelo de embeddings é pesado).
    """

    def __init__(self):
        logger.info(f"Carregando modelo de embeddings: {settings.embedding_model}")
        self._embedder = SentenceTransformer(settings.embedding_model)
        logger.info("Modelo de embeddings carregado com sucesso.")

    # ------------------------------------------------------------------
    # INGESTÃO
    # ------------------------------------------------------------------

    async def ingest_file(
        self,
        db: AsyncSession,
        file_bytes: bytes,
        filename: str,
        category: str = "geral",
        metadata: Optional[dict] = None,
    ) -> dict:
        """
        Processa um arquivo e armazena seus chunks vetorizados no banco.
        Retorna um resumo da operação.
        """
        t0 = time.time()
        doc_id = uuid4()
        source_type = self._detect_type(filename)
        text_content = self._extract_text(file_bytes, filename, source_type)

        if not text_content.strip():
            raise ValueError(f"Nenhum texto extraído de '{filename}'. Verifique o arquivo.")

        chunks = self._split_text(text_content)
        logger.info(f"[RAG] '{filename}' → {len(chunks)} chunks | categoria={category}")

        # Persiste documento pai
        await db.execute(
            text("""
                INSERT INTO documents (id, filename, source_type, category, metadata)
                VALUES (:id, :fn, :st, :cat, :meta::jsonb)
            """),
            {
                "id": str(doc_id),
                "fn": filename,
                "st": source_type,
                "cat": category,
                "meta": str(metadata or {}),
            },
        )

        # Gera embeddings em lote (muito mais rápido que um por vez)
        embeddings = self._embedder.encode(chunks, show_progress_bar=False)

        # Persiste chunks com vetores
        for idx, (chunk, emb) in enumerate(zip(chunks, embeddings)):
            await db.execute(
                text("""
                    INSERT INTO document_chunks
                        (id, document_id, chunk_index, content, embedding, metadata)
                    VALUES
                        (:id, :doc_id, :idx, :content, :emb::vector, :meta::jsonb)
                """),
                {
                    "id": str(uuid4()),
                    "doc_id": str(doc_id),
                    "idx": idx,
                    "content": chunk,
                    "emb": "[" + ",".join(str(float(v)) for v in emb) + "]",
                    "meta": f'{{"chunk_index": {idx}}}',
                },
            )

        elapsed = round(time.time() - t0, 2)
        logger.info(f"[RAG] Ingestão concluída em {elapsed}s | doc_id={doc_id}")

        # Salva arquivo no disco
        upload_path = Path(settings.upload_dir) / filename
        upload_path.parent.mkdir(parents=True, exist_ok=True)
        async with aiofiles.open(upload_path, "wb") as f:
            await f.write(file_bytes)

        return {
            "document_id": doc_id,
            "filename": filename,
            "category": category,
            "chunks_created": len(chunks),
            "message": f"Documento ingerido com sucesso em {elapsed}s.",
        }

    # ------------------------------------------------------------------
    # BUSCA SEMÂNTICA
    # ------------------------------------------------------------------

    async def semantic_search(
        self,
        db: AsyncSession,
        query: str,
        top_k: int = 8,
        category: Optional[str] = None,
    ) -> list[dict]:
        """
        Busca os chunks mais relevantes para a query por similaridade coseno.
        """
        query_emb = self._embedder.encode([query])[0]
        emb_str = "[" + ",".join(str(float(v)) for v in query_emb) + "]"

        category_filter = "AND d.category = :cat" if category else ""
        params: dict = {"emb": emb_str, "top_k": top_k}
        if category:
            params["cat"] = category

        rows = await db.execute(
            text(f"""
                SELECT
                    dc.content,
                    dc.chunk_index,
                    d.filename,
                    d.category,
                    d.id AS document_id,
                    1 - (dc.embedding <=> :emb::vector) AS similarity
                FROM document_chunks dc
                JOIN documents d ON d.id = dc.document_id
                WHERE 1=1 {category_filter}
                ORDER BY dc.embedding <=> :emb::vector
                LIMIT :top_k
            """),
            params,
        )

        results = []
        for row in rows.mappings():
            results.append({
                "content": row["content"],
                "filename": row["filename"],
                "category": row["category"],
                "document_id": str(row["document_id"]),
                "chunk_index": row["chunk_index"],
                "similarity": round(float(row["similarity"]), 4),
            })
        return results

    async def list_documents(self, db: AsyncSession) -> list[dict]:
        """Lista todos os documentos da base de conhecimento."""
        rows = await db.execute(
            text("""
                SELECT d.id, d.filename, d.category, d.source_type, d.created_at,
                       COUNT(dc.id) AS chunk_count
                FROM documents d
                LEFT JOIN document_chunks dc ON dc.document_id = d.id
                GROUP BY d.id
                ORDER BY d.created_at DESC
            """)
        )
        return [dict(r) for r in rows.mappings()]

    # ------------------------------------------------------------------
    # HELPERS PRIVADOS
    # ------------------------------------------------------------------

    def _detect_type(self, filename: str) -> str:
        ext = Path(filename).suffix.lower()
        mapping = {".pdf": "pdf", ".docx": "docx", ".doc": "docx", ".txt": "txt"}
        return mapping.get(ext, "txt")

    def _extract_text(self, data: bytes, filename: str, source_type: str) -> str:
        if source_type == "pdf":
            return self._extract_pdf(data)
        elif source_type == "docx":
            return self._extract_docx(data)
        else:
            return data.decode("utf-8", errors="replace")

    def _extract_pdf(self, data: bytes) -> str:
        reader = PyPDF2.PdfReader(io.BytesIO(data))
        pages = []
        for page in reader.pages:
            t = page.extract_text()
            if t:
                pages.append(t.strip())
        return "\n\n".join(pages)

    def _extract_docx(self, data: bytes) -> str:
        doc = DocxDocument(io.BytesIO(data))
        paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
        return "\n\n".join(paragraphs)

    def _split_text(self, text: str) -> list[str]:
        """
        Divide o texto em chunks com sobreposição controlada.
        Estratégia: divide por parágrafos e agrupa até chunk_size.
        """
        size = settings.chunk_size
        overlap = settings.chunk_overlap
        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]

        chunks: list[str] = []
        current = ""

        for para in paragraphs:
            if len(current) + len(para) + 2 <= size:
                current = (current + "\n\n" + para).strip()
            else:
                if current:
                    chunks.append(current)
                # sobreposição: pega o final do chunk anterior
                tail = current[-overlap:] if len(current) > overlap else current
                current = (tail + "\n\n" + para).strip()

        if current:
            chunks.append(current)

        return chunks or [text[:size]]
