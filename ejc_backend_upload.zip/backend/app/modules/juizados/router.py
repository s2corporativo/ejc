"""
EJC — Módulo Juizados Especiais (modules/juizados/router.py)

Guia completo e atualizado dos Juizados Especiais Cíveis de todos os
27 estados brasileiros para o plano premium (R$ 99,90).

Conteúdo por estado:
  - Como ingressar (passo a passo)
  - Portal eletrônico oficial com link
  - Documentos necessários
  - Competência (até R$ 40 salários mínimos = R$ 60.720 em 2025)
  - Orientações sobre audiência de conciliação
  - Dicas específicas por área do direito
"""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, HTTPException
from app.modules.redacao.service import LegalDraftService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/juizados", tags=["Juizados Especiais"])

SM_2025 = 1518.00   # Salário mínimo 2025
LIMITE_JE = SM_2025 * 40  # R$ 60.720,00

# ── Base de dados dos Juizados por estado ──────────────────────
JUIZADOS: dict[str, dict] = {
    "SP": {
        "nome_completo": "Tribunal de Justiça de São Paulo",
        "portal": "https://esaj.tjsp.jus.br/cejusc/",
        "portal_nome": "ESAJ — Portal de Serviços do TJSP",
        "peticionamento_eletronico": True,
        "descricao_ingresso": "Em São Paulo você pode entrar com a ação 100% online pelo ESAJ, sem precisar ir ao fórum.",
        "passos": [
            "Acesse https://esaj.tjsp.jus.br e clique em 'Juizado Especial Cível'",
            "Clique em 'Petição Inicial — Juizado Especial' e faça login com CPF",
            "Selecione a comarca mais próxima da sua residência ou do fato",
            "Preencha o formulário com os dados da parte contrária (nome + CNPJ/CPF + endereço)",
            "Anexe a petição gerada (PDF) e os documentos comprobatórios",
            "Confirme e aguarde a notificação por e-mail sobre a data da audiência",
        ],
        "documentos_gerais": [
            "RG e CPF (ou CNH)",
            "Comprovante de residência atualizado",
            "Petição inicial (o arquivo que você recebeu)",
            "Documentos que comprovam o problema (nota fiscal, contrato, prints, fotos)",
            "Comprovante de tentativa de resolução prévia (protocolo SAC, e-mail etc.)",
        ],
        "observacoes": "Em SP, não é necessário advogado para causas até 20 salários mínimos (R$ 30.360). Acima disso é obrigatório.",
    },
    "RJ": {
        "nome_completo": "Tribunal de Justiça do Rio de Janeiro",
        "portal": "https://www3.tjrj.jus.br/ejud/",
        "portal_nome": "e-JUD — Portal TJRJ",
        "peticionamento_eletronico": True,
        "descricao_ingresso": "No RJ é possível protocolar pelo portal e-JUD ou presencialmente no Juizado mais próximo.",
        "passos": [
            "Acesse https://www3.tjrj.jus.br/ejud/ e crie sua conta com CPF",
            "Clique em 'Nova Ação — JEC Cível'",
            "Informe comarca (município onde mora ou onde ocorreu o fato)",
            "Preencha dados das partes e anexe a petição em PDF",
            "Aguarde citação da parte contrária e data de audiência por e-mail/SMS",
        ],
        "documentos_gerais": [
            "Documento de identidade com foto",
            "CPF",
            "Comprovante de residência",
            "Petição inicial gerada",
            "Provas do caso (contratos, notas, fotos, conversas)",
        ],
        "observacoes": "O RJ tem Juizados Especiais em todos os municípios. Para empresas do Rio, verifique se há foro especial previsto no contrato.",
    },
    "MG": {
        "nome_completo": "Tribunal de Justiça de Minas Gerais",
        "portal": "https://pje.tjmg.jus.br/pje/login.seam",
        "portal_nome": "PJe — Processo Judicial Eletrônico TJMG",
        "peticionamento_eletronico": True,
        "descricao_ingresso": "Em MG, o protocolo eletrônico é feito pelo PJe. Para quem não tem certificado digital, é possível ir presencialmente.",
        "passos": [
            "Acesse https://pje.tjmg.jus.br e crie conta de cidadão (sem certificado digital)",
            "Selecione 'Processo — Novo — Juizado Especial Cível'",
            "Informe a vara/comarca da sua cidade",
            "Anexe a petição (PDF) e documentos de prova",
            "Acompanhe o processo pelo próprio PJe",
        ],
        "documentos_gerais": [
            "RG/CNH",
            "CPF",
            "Comprovante de endereço",
            "Petição inicial",
            "Documentos probatórios",
        ],
        "observacoes": "No TJMG, o juizado de BH fica na Cidade Judiciária (Av. Álvares Cabral). Cidades menores costumam ter vara única que acumula JE.",
    },
    "RS": {
        "nome_completo": "Tribunal de Justiça do Rio Grande do Sul",
        "portal": "https://www.tjrs.jus.br/site/processos/peticao_inicial/index.html",
        "portal_nome": "Portal TJRS — Petição Inicial Online",
        "peticionamento_eletronico": True,
        "descricao_ingresso": "O TJRS permite protocolo online pelo portal próprio. Também é possível ir ao fórum da sua cidade.",
        "passos": [
            "Acesse o portal do TJRS e localize 'Juizado Especial — Petição Inicial'",
            "Faça login com CPF e senha gov.br ou certificado digital",
            "Selecione a comarca correspondente ao seu município",
            "Preencha o formulário e anexe a petição em PDF",
            "Imprima o protocolo e guarde para controle",
        ],
        "documentos_gerais": [
            "Documento com foto",
            "CPF",
            "Comprovante de residência",
            "Petição inicial",
            "Provas documentais",
        ],
        "observacoes": "Porto Alegre tem vara especializada por matéria (consumidor, locação, etc.). No interior, o JE funciona junto com a vara cível.",
    },
    "BA": {
        "nome_completo": "Tribunal de Justiça da Bahia",
        "portal": "https://esaj.tjba.jus.br/esaj/portal.do?servico=190000",
        "portal_nome": "ESAJ Bahia",
        "peticionamento_eletronico": True,
        "descricao_ingresso": "A Bahia usa o sistema ESAJ para protocolo eletrônico.",
        "passos": [
            "Acesse o ESAJ Bahia e cadastre-se com CPF",
            "Selecione 'Petição Inicial — JEC'",
            "Escolha a comarca da sua cidade ou do fato gerador",
            "Preencha dados das partes e anexe petição + provas",
            "Aguarde citação e pauta de audiência",
        ],
        "documentos_gerais": ["RG/CPF","Comprovante residência","Petição","Provas"],
        "observacoes": "Salvador tem Juizados temáticos. No interior, varas únicas acumulam função de JE.",
    },
    "PR": {
        "nome_completo": "Tribunal de Justiça do Paraná",
        "portal": "https://projudi.tjpr.jus.br/projudi/",
        "portal_nome": "PROJUDI — TJPR",
        "peticionamento_eletronico": True,
        "descricao_ingresso": "O Paraná usa o PROJUDI, um dos sistemas mais completos do país para peticionamento eletrônico.",
        "passos": [
            "Acesse https://projudi.tjpr.jus.br e crie conta de usuário",
            "Clique em 'Nova Petição — Juizado Especial Cível'",
            "Selecione comarca do seu município",
            "Preencha a petição (ou anexe o PDF gerado) e documentos",
            "Confirme e anote o número do processo gerado",
        ],
        "documentos_gerais": ["Documento com foto","CPF","Comprovante residência","Petição PDF","Documentos do caso"],
        "observacoes": "Curitiba tem varas especializadas. Cidades com mais de 50 mil habitantes geralmente têm JE próprio.",
    },
    "PE": {
        "nome_completo": "Tribunal de Justiça de Pernambuco",
        "portal": "https://srv01.tjpe.jus.br/consultaprocessualunificada/",
        "portal_nome": "Portal TJPE",
        "peticionamento_eletronico": True,
        "descricao_ingresso": "Pernambuco aceita protocolo eletrônico pelo portal do tribunal.",
        "passos": [
            "Acesse o portal TJPE e localize a seção de JEC",
            "Cadastre-se com CPF",
            "Escolha a vara da sua comarca",
            "Anexe petição e documentos",
            "Aguarde intimação por e-mail",
        ],
        "documentos_gerais": ["RG/CPF","Comprovante residência","Petição","Provas"],
        "observacoes": "Recife tem Juizados especializados em consumidor, Fazenda Pública e família.",
    },
    "CE": {
        "nome_completo": "Tribunal de Justiça do Ceará",
        "portal": "https://esaj.tjce.jus.br/",
        "portal_nome": "ESAJ Ceará",
        "peticionamento_eletronico": True,
        "descricao_ingresso": "O Ceará usa o ESAJ para protocolo eletrônico dos JECs.",
        "passos": [
            "Acesse o ESAJ TJCE em https://esaj.tjce.jus.br",
            "Crie conta e selecione 'Juizado Especial — Petição Inicial'",
            "Informe dados das partes e comarca",
            "Anexe petição (PDF) e documentos",
            "Acompanhe pelo portal",
        ],
        "documentos_gerais": ["RG/CPF","Comprovante","Petição","Provas"],
        "observacoes": "Fortaleza tem 10 varas de JEC. Interior: vara única com competência cumulativa.",
    },
    "GO": {"nome_completo":"Tribunal de Justiça de Goiás","portal":"https://projudi.tjgo.jus.br/","portal_nome":"PROJUDI TJGO","peticionamento_eletronico":True,"descricao_ingresso":"Goiás usa o PROJUDI para protocolo eletrônico.","passos":["Acesse https://projudi.tjgo.jus.br","Cadastre-se com CPF","Selecione JEC e comarca","Preencha e anexe documentos","Acompanhe online"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Goiânia tem varas especializadas. Interior: vara única."},
    "SC": {"nome_completo":"Tribunal de Justiça de Santa Catarina","portal":"https://esaj.tjsc.jus.br/","portal_nome":"ESAJ TJSC","peticionamento_eletronico":True,"descricao_ingresso":"Santa Catarina usa o ESAJ para protocolo eletrônico.","passos":["Acesse https://esaj.tjsc.jus.br","Login com CPF","Selecione JEC e comarca","Anexe petição e provas","Aguarde audiência"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Florianópolis tem juizados temáticos. Interior varia conforme porte."},
    "PA": {"nome_completo":"Tribunal de Justiça do Pará","portal":"https://tucujuris.tjpa.jus.br/","portal_nome":"TucuJuris — TJPA","peticionamento_eletronico":True,"descricao_ingresso":"O Pará usa o sistema TucuJuris para peticionamento eletrônico.","passos":["Acesse TucuJuris","Cadastre-se","Selecione JEC","Anexe documentos","Acompanhe online"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Belém tem varas especializadas. Interior com acesso limitado — verifique presencialmente."},
    "MA": {"nome_completo":"Tribunal de Justiça do Maranhão","portal":"https://pje.tjma.jus.br/","portal_nome":"PJe TJMA","peticionamento_eletronico":True,"descricao_ingresso":"Maranhão usa o PJe para protocolos.","passos":["Acesse https://pje.tjma.jus.br","Crie conta","Selecione JEC","Preencha dados e anexe petição","Acompanhe online"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"São Luís tem juizados específicos. Interior: vara única."},
    "AM": {"nome_completo":"Tribunal de Justiça do Amazonas","portal":"https://pje1g.tjam.jus.br/","portal_nome":"PJe TJAM","peticionamento_eletronico":True,"descricao_ingresso":"Amazonas usa PJe para protocolo eletrônico.","passos":["Acesse https://pje1g.tjam.jus.br","Cadastro com CPF","JEC — nova ação","Anexe documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Manaus: varas especializadas. Interior: dificuldades de acesso eletrônico — verificar presencialmente."},
    "MT": {"nome_completo":"Tribunal de Justiça de Mato Grosso","portal":"https://pje.tjmt.jus.br/","portal_nome":"PJe TJMT","peticionamento_eletronico":True,"descricao_ingresso":"Mato Grosso usa PJe.","passos":["Acesse PJe TJMT","Crie conta","Selecione JEC","Preencha e anexe","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Cuiabá: varas especializadas."},
    "MS": {"nome_completo":"Tribunal de Justiça de Mato Grosso do Sul","portal":"https://esaj.tjms.jus.br/","portal_nome":"ESAJ TJMS","peticionamento_eletronico":True,"descricao_ingresso":"MS usa ESAJ para protocolos.","passos":["Acesse ESAJ TJMS","Login com CPF","JEC — nova ação","Anexe documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Campo Grande tem varas por área temática."},
    "ES": {"nome_completo":"Tribunal de Justiça do Espírito Santo","portal":"https://esaj.tjes.jus.br/","portal_nome":"ESAJ TJES","peticionamento_eletronico":True,"descricao_ingresso":"ES usa ESAJ para peticionamento.","passos":["Acesse ESAJ TJES","Cadastro","JEC — petição inicial","Anexe documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Vitória: varas especializadas. Grande Vitória tem boa cobertura."},
    "PB": {"nome_completo":"Tribunal de Justiça da Paraíba","portal":"https://pje.tjpb.jus.br/","portal_nome":"PJe TJPB","peticionamento_eletronico":True,"descricao_ingresso":"Paraíba usa PJe.","passos":["Acesse PJe TJPB","Cadastro com CPF","JEC","Anexe documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"João Pessoa: varas por área."},
    "RN": {"nome_completo":"Tribunal de Justiça do Rio Grande do Norte","portal":"https://esaj.tjrn.jus.br/","portal_nome":"ESAJ TJRN","peticionamento_eletronico":True,"descricao_ingresso":"RN usa ESAJ.","passos":["ESAJ TJRN","Login","JEC","Documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Natal: varas especializadas."},
    "AL": {"nome_completo":"Tribunal de Justiça de Alagoas","portal":"https://pje.tjal.jus.br/","portal_nome":"PJe TJAL","peticionamento_eletronico":True,"descricao_ingresso":"Alagoas usa PJe.","passos":["PJe TJAL","Cadastro","JEC","Documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Maceió: varas especializadas."},
    "PI": {"nome_completo":"Tribunal de Justiça do Piauí","portal":"https://pje.tjpi.jus.br/","portal_nome":"PJe TJPI","peticionamento_eletronico":True,"descricao_ingresso":"Piauí usa PJe.","passos":["PJe TJPI","Cadastro","JEC","Documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Teresina: varas por área."},
    "SE": {"nome_completo":"Tribunal de Justiça de Sergipe","portal":"https://pje.tjse.jus.br/","portal_nome":"PJe TJSE","peticionamento_eletronico":True,"descricao_ingresso":"Sergipe usa PJe.","passos":["PJe TJSE","Cadastro","JEC","Documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Aracaju: varas especializadas."},
    "RO": {"nome_completo":"Tribunal de Justiça de Rondônia","portal":"https://pje.tjro.jus.br/","portal_nome":"PJe TJRO","peticionamento_eletronico":True,"descricao_ingresso":"Rondônia usa PJe.","passos":["PJe TJRO","Cadastro","JEC","Documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Porto Velho: vara única para JEC."},
    "TO": {"nome_completo":"Tribunal de Justiça do Tocantins","portal":"https://pje.tjto.jus.br/","portal_nome":"PJe TJTO","peticionamento_eletronico":True,"descricao_ingresso":"Tocantins usa PJe.","passos":["PJe TJTO","Cadastro","JEC","Documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Palmas: vara única JEC."},
    "AC": {"nome_completo":"Tribunal de Justiça do Acre","portal":"https://pje.tjac.jus.br/","portal_nome":"PJe TJAC","peticionamento_eletronico":True,"descricao_ingresso":"Acre usa PJe.","passos":["PJe TJAC","Cadastro","JEC","Documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Rio Branco: vara única JEC. Interior: presencial."},
    "AP": {"nome_completo":"Tribunal de Justiça do Amapá","portal":"https://pje.tjap.jus.br/","portal_nome":"PJe TJAP","peticionamento_eletronico":True,"descricao_ingresso":"Amapá usa PJe.","passos":["PJe TJAP","Cadastro","JEC","Documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Macapá: vara única JEC."},
    "RR": {"nome_completo":"Tribunal de Justiça de Roraima","portal":"https://pje.tjrr.jus.br/","portal_nome":"PJe TJRR","peticionamento_eletronico":True,"descricao_ingresso":"Roraima usa PJe.","passos":["PJe TJRR","Cadastro","JEC","Documentos","Acompanhe"],"documentos_gerais":["RG/CPF","Comprovante","Petição","Provas"],"observacoes":"Boa Vista: vara única JEC."},
    "DF": {
        "nome_completo": "Tribunal de Justiça do Distrito Federal e Territórios",
        "portal": "https://pje.tjdft.jus.br/",
        "portal_nome": "PJe — TJDFT",
        "peticionamento_eletronico": True,
        "descricao_ingresso": "O DF tem um dos sistemas mais avançados do país. Protocolo 100% online pelo PJe.",
        "passos": [
            "Acesse https://pje.tjdft.jus.br e crie conta com CPF ou gov.br",
            "Selecione 'Juizado Especial Cível'",
            "Escolha a circunscrição do DF (Brasília, Ceilândia, Taguatinga etc.)",
            "Preencha os dados das partes e do pedido",
            "Anexe a petição em PDF e os documentos de prova",
            "Protocole e acompanhe o número do processo",
        ],
        "documentos_gerais": [
            "RG ou CNH",
            "CPF",
            "Comprovante de residência",
            "Petição inicial gerada",
            "Documentos comprobatórios",
        ],
        "observacoes": "O TJDFT tem Juizados Especiais em todas as regiões administrativas. Muito eficiente — prazo médio de audiência: 30-60 dias.",
    },
}

DICAS_POR_AREA = {
    "consumidor": """
## Dicas Específicas — Direito do Consumidor no JE

**Antes da audiência:**
- Tente resolver diretamente com a empresa antes de acionar o JE (guarde protocolo)
- O JE de consumidor é gratuito em 1ª instância (sem custas, sem advogado obrigatório)
- Leve cópia de todas as provas em 2 vias (1 para o juiz, 1 para a parte contrária)

**Na audiência:**
- Chegue 15 minutos antes
- Na conciliação, você pode aceitar um acordo MENOR se for vantajoso (dinheiro certo × incerteza do processo)
- Se não houver acordo, aguarda julgamento (geralmente na mesma audiência ou em semanas)

**Valores habituais para dano moral em consumidor (JE-SP):**
- Inscrição indevida no SPC/Serasa: R$ 5.000–15.000
- Produto com defeito não resolvido: R$ 2.000–8.000
- Cobrança indevida: R$ 2.000–5.000
""",
    "trabalhista": """
## Dicas Específicas — Reclamação Trabalhista

**Atenção:** Para causas trabalhistas, use o **JET (Juizado Especial Trabalhista / Vara do Trabalho)**, não o JEC cível.

**Portal:** https://pje.trt-XX.jus.br (substitua XX pela região do TRT)
- TRT2 (São Paulo): https://pje.trt2.jus.br
- TRT3 (Minas Gerais): https://pje.trt3.jus.br
- TRT4 (Rio Grande do Sul): https://pje.trt4.jus.br

**Prazo prescricional:** 2 anos após a demissão para ações trabalhistas (art. 7º, XXIX, CF).

**Documentos essenciais:**
- Carteira de Trabalho (CTPS)
- Holerites dos últimos 3 anos
- Extrato do FGTS
- Termo de rescisão (TRCT)
""",
    "civil": """
## Dicas Específicas — Ações Cíveis no JE

**Competência:** Causas até R$ 60.720 (40 salários mínimos de 2025).
**Sem advogado:** Até 20 SM (R$ 30.360) você pode ir sem advogado.
**Com advogado:** Entre 20 e 40 SM é obrigatório.

**Casos comuns:**
- Cobrança de dívidas
- Danos causados por vizinhos
- Contratos descumpridos entre pessoas físicas
- Acidentes de trânsito (indenização por danos materiais)

**Dica:** Em casos de acidente de trânsito, leve: BO, fotos, orçamento de conserto e laudo pericial se houver.
""",
    "previdenciario": """
## Dicas Específicas — Juizado Especial Federal (JEF)

**Atenção:** Ações contra o INSS são julgadas no **Juizado Especial Federal (JEF)**, não no JEC estadual.

**Portal Nacional:** https://eproc.jfpr.jus.br (varia por região)
- Acesse https://www.cjf.jus.br/cjf/servicos/jef para encontrar o JEF da sua cidade

**Sem advogado:** Até 60 SM (R$ 91.080) você pode se representar pessoalmente.

**Documentos:**
- CNIS atualizado (www.meu.inss.gov.br)
- Carta de indeferimento do INSS
- Laudos médicos (se incapacidade)
- Histórico de trabalho completo
""",
}


def _montar_guia(estado: str, area: str) -> str:
    """Monta o guia completo em Markdown para o estado e área solicitados."""
    je = JUIZADOS.get(estado.upper())
    if not je:
        return f"# Guia do Juizado Especial — {estado}\n\nInformações não disponíveis para este estado. Acesse o portal do TJXX da sua UF diretamente."

    passos_md = "\n".join(f"{i+1}. {p}" for i, p in enumerate(je["passos"]))
    docs_md   = "\n".join(f"- {d}" for d in je["documentos_gerais"])
    dica_area = DICAS_POR_AREA.get(area, "")

    return f"""# Guia Completo — Juizado Especial de {estado}
## {je['nome_completo']}

---

## O que é o Juizado Especial?

O Juizado Especial Cível (JEC) é um tribunal simplificado para causas de **até R$ {LIMITE_JE:,.2f}** (40 salários mínimos de 2025), criado pela Lei 9.099/1995. É **gratuito em 1ª instância**, mais rápido que a justiça comum e **não exige advogado** para causas de até R$ {SM_2025 * 20:,.2f} (20 salários mínimos).

---

## Como Entrar com a Sua Ação

{je['descricao_ingresso']}

**Portal Oficial:** [{je['portal_nome']}]({je['portal']})

### Passo a Passo:

{passos_md}

---

## Documentos Necessários

{docs_md}

---

## Na Audiência de Conciliação

1. **Chegue 15 minutos antes** com toda a documentação organizada
2. A primeira audiência é de **conciliação** — tente um acordo justo
3. Se não houver acordo, será marcada audiência de instrução e julgamento
4. Você **não precisa de advogado** se o valor for até R$ {SM_2025 * 20:,.2f}
5. Fale com calma, apresente seus documentos e explique os fatos de forma objetiva

---

## Observações Importantes

{je['observacoes']}

---

{dica_area}

---

## Aviso Legal

⚠️ Este guia tem caráter informativo. Cada caso tem particularidades.
Para situações complexas, consulte um advogado.
A petição gerada deve ser revisada antes do protocolo.

---
*Guia gerado pelo EJC — Ecossistema Jurídico Clovis | {estado} | Atualizado 2025*
"""


async def get_guia_estado(estado: str, area: str = "consumidor") -> str:
    """Retorna guia do JE para o estado. Usado pelo módulo pedidos."""
    return _montar_guia(estado, area)


@router.get("/estados")
async def listar_estados():
    return {
        "estados": [
            {"uf": uf, "nome": d["nome_completo"], "portal": d["portal"]}
            for uf, d in JUIZADOS.items()
        ]
    }


@router.get("/{estado}")
async def guia_estado(estado: str, area: str = "consumidor"):
    """Retorna o guia completo do JE para um estado específico."""
    guia = _montar_guia(estado.upper(), area)
    return {"estado": estado.upper(), "area": area, "guia_md": guia}
