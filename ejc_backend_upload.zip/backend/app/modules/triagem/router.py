"""
EJC — Triagem: Viabilidade + Notif. Extrajudicial + WhatsApp (triagem/router.py)
"""
from __future__ import annotations
import logging, os, json
from typing import Optional
from uuid import uuid4
from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/triagem", tags=["Triagem e Viabilidade"])
ADMIN_KEY = os.getenv("ADMIN_API_KEY", "ejc_admin_dev_key")


# ── 1. VIABILIDADE PRÉ-PAGAMENTO ─────────────────────────────────────────

class ViabilidadeReq(BaseModel):
    area_juridica: str; fatos: str
    valor_estimado: Optional[float] = None
    data_ocorrencia: Optional[str] = None   # YYYY-MM-DD

@router.post("/viabilidade")
async def viabilidade(req: ViabilidadeReq, db: AsyncSession = Depends(get_db)):
    """
    Análise gratuita de viabilidade antes do pagamento.
    Verifica prescrição, competência JEC, valor da causa.
    Retorna score, alertas e prévia de jurisprudência.
    """
    from app.modules.calculos.calculos_expandidos import calcular_prescricao
    SM = 1518.00
    problemas: list[str] = []; score = 1.0
    prescrito = False; elegivel_jec = True

    # Prescrição
    if req.data_ocorrencia:
        mapa = {"consumidor":"cdc_fato_produto","trabalhista":"trabalhista_verbas",
                "civel":"indenizacao_civil","previdenciario":"inss_beneficio_negado","familia":"alimentos_atrasados"}
        tp = mapa.get(req.area_juridica.lower(), "contrato_geral")
        try:
            from datetime import date as D
            p = calcular_prescricao(tp, D.fromisoformat(req.data_ocorrencia))
            if p.get("prescrito"):
                problemas.append(f"⚠ PRESCRIÇÃO: prazo venceu em {p.get('data_vencimento')}.")
                score -= 0.4; prescrito = True
            elif p.get("urgente"):
                problemas.append(f"⚡ URGENTE: {p.get('dias_restantes')} dias restantes.")
                score -= 0.1
        except Exception: pass

    # Valor x JEC
    if req.valor_estimado:
        if req.valor_estimado > 40 * SM:
            problemas.append("⚠ Valor acima de 40 SM — não é JEC. Precisa de advogado e vara comum.")
            elegivel_jec = False; score -= 0.3
        elif req.valor_estimado > 20 * SM:
            problemas.append("ℹ Valor entre 20-40 SM — JEC com advogado obrigatório.")
            score -= 0.1

    # Jurisprudência preview
    juris = []
    try:
        from app.modules.pesquisa.jurisprudencia_engine import get_engine
        res = await get_engine().buscar(f"{req.area_juridica} {req.fatos[:100]}", db,
                                         area=req.area_juridica, top_k=3, incluir_temas=True)
        juris = [{"tipo": r.get("tipo"), "tribunal": r.get("tribunal"),
                  "ementa": r.get("ementa","")[:150], "vinculante": r.get("vinculante")}
                 for r in res.get("resultados", [])]
    except Exception: pass

    score = max(0.0, min(1.0, score))
    rec = ("✅ Caso viável — pode prosseguir com a petição." if score >= 0.7 and not prescrito
           else "⚠ Caso com ressalvas — leia os alertas." if score >= 0.4
           else "❌ Impedimentos sérios — consulte um advogado.")

    aid = str(uuid4())
    try:
        await db.execute(text("""
            INSERT INTO analises_viabilidade (id,area_juridica,fatos,score,elegivel_jec,prescrito,valor_estimado,problemas,recomendacao)
            VALUES (:id,:area,:fatos,:sc,:jec,:pres,:val,:prob::jsonb,:rec)
        """), {"id":aid,"area":req.area_juridica,"fatos":req.fatos[:500],"sc":score,
               "jec":elegivel_jec,"pres":prescrito,"val":req.valor_estimado,
               "prob":json.dumps(problemas,ensure_ascii=False),"rec":rec})
        await db.commit()
    except Exception: pass

    return {"id":aid,"score":round(score,2),"viavel":score>=0.5 and not prescrito,
            "elegivel_jec":elegivel_jec,"prescrito":prescrito,
            "problemas":problemas,"recomendacao":rec,"jurisprudencia_preview":juris}


# ── 2. NOTIFICAÇÃO EXTRAJUDICIAL (R$ 9,90) ──────────────────────────────

class NotifReq(BaseModel):
    remetente_nome: str; remetente_email: str
    destinatario: str; assunto: str
    descricao_problema: str
    valor_cobrado: Optional[float] = None
    prazo_dias: int = 10

@router.post("/notificacao-extrajudicial", status_code=201)
async def notificacao_extrajudicial(req: NotifReq, db: AsyncSession = Depends(get_db)):
    """Gera notificação extrajudicial formal via LLM. Produto de R$ 9,90."""
    from app.core.llm_provider import LLMProvider
    prompt = f"""Redija NOTIFICAÇÃO EXTRAJUDICIAL formal e completa.

REMETENTE: {req.remetente_nome} ({req.remetente_email})
DESTINATÁRIO: {req.destinatario}
ASSUNTO: {req.assunto}
PRAZO: {req.prazo_dias} dias úteis para resposta
{f"VALOR EM DISPUTA: R$ {req.valor_cobrado:,.2f}" if req.valor_cobrado else ""}

FATOS:
{req.descricao_problema}

INSTRUÇÕES: Use linguagem formal e jurídica. Cite CDC/CC/CLT conforme pertinente.
Advertir sobre recurso ao Juizado Especial em caso de inércia. Formato Markdown."""
    corpo = await LLMProvider().generate(prompt=prompt,
        system="Você é advogado especialista. Redija notificações extrajudiciais formais.",
        max_tokens=2000)
    nid = str(uuid4())
    await db.execute(text("""
        INSERT INTO notificacoes_extrajudiciais (id,remetente_nome,remetente_email,destinatario,assunto,corpo_notif)
        VALUES (:id,:rem,:email,:dest,:ass,:corpo)
    """), {"id":nid,"rem":req.remetente_nome,"email":req.remetente_email,
           "dest":req.destinatario,"ass":req.assunto,"corpo":corpo})
    await db.commit()
    return {"id":nid,"corpo_notificacao":corpo,
            "dica":"Envie por e-mail com AR ou carta registrada e guarde o comprovante."}


# ── 3. WHATSAPP PARA ADVOGADOS ────────────────────────────────────────────

class WppConfigReq(BaseModel):
    numero_tel: str; provider: str = "evolution_api"
    api_url: Optional[str] = None; api_token: Optional[str] = None

@router.post("/whatsapp/configurar")
async def wpp_configurar(
    req: WppConfigReq,
    x_admin_key: str = Header(None),
    db: AsyncSession = Depends(get_db),
):
    if x_admin_key != ADMIN_KEY:
        raise HTTPException(403, "Acesso negado")
    uid = "00000000-0000-0000-0000-000000000001"
    await db.execute(text("""
        INSERT INTO whatsapp_config (id,usuario_id,numero_tel,provider,api_url,api_token)
        VALUES (:id,:uid,:tel,:prov,:url,:tok)
        ON CONFLICT (usuario_id) DO UPDATE SET numero_tel=EXCLUDED.numero_tel,
          api_url=EXCLUDED.api_url, api_token=EXCLUDED.api_token, ativo=TRUE
    """), {"id":str(uuid4()),"uid":uid,"tel":req.numero_tel,"prov":req.provider,
           "url":req.api_url,"tok":req.api_token})
    await db.commit()
    return {"configurado": True, "numero": req.numero_tel}


async def enviar_whatsapp(numero: str, mensagem: str, db: AsyncSession) -> bool:
    """Envia mensagem WhatsApp via Evolution API (ou simula em dev)."""
    try:
        row = await db.execute(text("SELECT * FROM whatsapp_config WHERE ativo=TRUE LIMIT 1"))
        cfg = row.mappings().first()
        if not cfg or not cfg.get("api_url"):
            logger.info(f"[WPP-SIM] → {numero}: {mensagem[:60]}...")
            return False
        import httpx
        async with httpx.AsyncClient(timeout=10.0) as c:
            r = await c.post(f"{cfg['api_url'].rstrip('/')}/message/sendText/ejc",
                json={"number": numero, "text": mensagem, "delay": 1000},
                headers={"apikey": cfg.get("api_token",""), "Content-Type":"application/json"})
            ok = r.status_code in (200, 201)
        await db.execute(text("""
            INSERT INTO whatsapp_log (id,numero_dest,mensagem,status)
            VALUES (:id,:num,:msg,:st)
        """), {"id":str(uuid4()),"num":numero,"msg":mensagem[:1000],"st":"enviada" if ok else "erro"})
        await db.commit()
        return ok
    except Exception as e:
        logger.error(f"[WPP] {e}"); return False


@router.post("/whatsapp/teste")
async def wpp_teste(
    payload: dict,
    x_admin_key: str = Header(None),
    db: AsyncSession = Depends(get_db),
):
    if x_admin_key != ADMIN_KEY:
        raise HTTPException(403, "Acesso negado")
    ok = await enviar_whatsapp(payload.get("numero",""), payload.get("mensagem","Teste EJC"), db)
    return {"enviado": ok}
