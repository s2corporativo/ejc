"""
EJC — Módulo BACEN (modules/bacen/router.py)

Integração com a API pública do Banco Central do Brasil.
Fornece taxas reais para cálculos jurídicos:
  - TR mensal (substitui a tabela estática do FGTS)
  - IPCA, INPC, IGPM (correção monetária de dívidas)
  - SELIC (juros de mora em débitos tributários/contratuais)
  - CDI, taxa de câmbio

API gratuita, sem autenticação:
  https://api.bcb.gov.br/dados/serie/bcdata.sgs.{codigo}/dados

Códigos principais:
  433  → IPCA mensal (%)
  188  → INPC mensal (%)
  189  → IGPM mensal (%)
   11  → SELIC meta (% a.a.)
  226  → TR mensal (%)
   12  → CDI (% a.a.)
  1  → Taxa de câmbio USD/BRL
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP, getcontext
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)
getcontext().prec = 28
router = APIRouter(prefix="/bacen", tags=["BACEN — Taxas Banco Central"])

BACEN_BASE = "https://api.bcb.gov.br/dados/serie/bcdata.sgs"

CODIGOS = {
    "ipca":   433,
    "inpc":   188,
    "igpm":   189,
    "selic":   11,
    "tr":     226,
    "cdi":     12,
    "usd_brl": 1,
    "poupanca": 25,
}

DESCRICOES = {
    "ipca":    "IPCA — Índice Nacional de Preços ao Consumidor Amplo (mensal %)",
    "inpc":    "INPC — Índice Nacional de Preços ao Consumidor (mensal %)",
    "igpm":    "IGPM — Índice Geral de Preços – Mercado (mensal %)",
    "selic":   "SELIC meta (% a.a.)",
    "tr":      "TR — Taxa Referencial (mensal %)",
    "cdi":     "CDI (% a.a.)",
    "usd_brl": "Taxa de Câmbio USD/BRL (venda)",
    "poupanca": "Taxa de poupança (mensal %)",
}

# Cache simples em memória com TTL de 6h
_cache: dict[str, tuple[list, datetime]] = {}
_CACHE_TTL = timedelta(hours=6)


async def _fetch_serie(
    codigo: int,
    data_inicio: Optional[str] = None,
    data_fim: Optional[str] = None,
    ultimos: Optional[int] = None,
) -> list[dict]:
    """
    Busca série temporal do BACEN com cache em memória.
    """
    cache_key = f"{codigo}_{data_inicio}_{data_fim}_{ultimos}"
    if cache_key in _cache:
        data, ts = _cache[cache_key]
        if datetime.now() - ts < _CACHE_TTL:
            return data

    url_params: dict = {"formato": "json"}
    if data_inicio:
        url_params["dataInicial"] = data_inicio
    if data_fim:
        url_params["dataFinal"] = data_fim
    if ultimos:
        url_params["ultimos"] = str(ultimos)

    url = f"{BACEN_BASE}.{codigo}/dados"
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(url, params=url_params)
            resp.raise_for_status()
            data = resp.json()
            _cache[cache_key] = (data, datetime.now())
            return data
    except httpx.HTTPStatusError as e:
        logger.error(f"[BACEN] Erro HTTP {e.response.status_code} para série {codigo}")
        raise RuntimeError(f"BACEN retornou erro {e.response.status_code}")
    except httpx.RequestError as e:
        logger.error(f"[BACEN] Falha de conexão: {e}")
        raise RuntimeError("Falha de conexão com a API do Banco Central")


@router.get("/taxas")
async def listar_taxas_disponiveis():
    """Lista todas as taxas disponíveis com descrições."""
    return {
        "taxas": [
            {"codigo": nome, "serie_bcb": cod, "descricao": DESCRICOES.get(nome, "")}
            for nome, cod in CODIGOS.items()
        ],
        "documentacao": "https://dadosabertos.bcb.gov.br/dataset/taxas-de-juros-basicas-historico",
    }


@router.get("/taxa/{nome}")
async def buscar_taxa(
    nome: str,
    ultimos: int = Query(12, ge=1, le=120, description="Últimos N registros"),
    data_inicio: Optional[str] = Query(None, description="DD/MM/AAAA"),
    data_fim: Optional[str] = Query(None, description="DD/MM/AAAA"),
):
    """
    Retorna série histórica de uma taxa do BACEN.
    Exemplo: GET /bacen/taxa/tr?ultimos=24
    """
    codigo = CODIGOS.get(nome.lower())
    if not codigo:
        raise HTTPException(404, f"Taxa '{nome}' não encontrada. Disponíveis: {list(CODIGOS)}")
    try:
        dados = await _fetch_serie(codigo, data_inicio, data_fim, ultimos if not data_inicio else None)
        return {
            "taxa": nome,
            "codigo_bcb": codigo,
            "descricao": DESCRICOES.get(nome, ""),
            "registros": dados,
            "total": len(dados),
            "ultimo_valor": dados[-1] if dados else None,
        }
    except RuntimeError as e:
        raise HTTPException(503, str(e))


@router.get("/tr-acumulada")
async def tr_acumulada(
    data_inicio: str = Query(..., description="YYYY-MM-DD"),
    data_fim: str = Query(None, description="YYYY-MM-DD (padrão: hoje)"),
):
    """
    Calcula a TR acumulada entre duas datas.
    Substitui a tabela estática TR_TABLE do módulo FGTS.
    Usa dados reais do Banco Central.
    """
    fim = data_fim or date.today().strftime("%Y-%m-%d")

    # Converte para formato BACEN (DD/MM/AAAA)
    di = datetime.strptime(data_inicio, "%Y-%m-%d").strftime("%d/%m/%Y")
    df = datetime.strptime(fim, "%Y-%m-%d").strftime("%d/%m/%Y")

    try:
        dados = await _fetch_serie(226, data_inicio=di, data_fim=df)
    except RuntimeError as e:
        raise HTTPException(503, str(e))

    if not dados:
        return {
            "data_inicio": data_inicio, "data_fim": fim,
            "tr_acumulada_decimal": "0.00000000",
            "tr_acumulada_pct": "0.0000%",
            "registros": 0,
        }

    # Calcula produto acumulado: (1 + tr1) × (1 + tr2) × ... − 1
    fator = Decimal("1")
    for reg in dados:
        try:
            taxa_str = str(reg.get("valor", "0")).replace(",", ".")
            tr_mensal = Decimal(taxa_str) / Decimal("100")
            fator *= (Decimal("1") + tr_mensal)
        except Exception:
            continue

    tr_acum = (fator - Decimal("1")).quantize(Decimal("0.00000001"), ROUND_HALF_UP)

    return {
        "data_inicio": data_inicio,
        "data_fim": fim,
        "tr_acumulada_decimal": str(tr_acum),
        "tr_acumulada_pct": f"{float(tr_acum * 100):.6f}%",
        "fator_multiplicador": str(fator.quantize(Decimal("0.00000001"), ROUND_HALF_UP)),
        "registros_usados": len(dados),
        "fonte": "Banco Central do Brasil — Série 226",
    }


@router.get("/correcao-monetaria")
async def calcular_correcao_monetaria(
    valor: float = Query(..., description="Valor original em R$"),
    data_inicio: str = Query(..., description="YYYY-MM-DD"),
    data_fim: str = Query(None, description="YYYY-MM-DD (padrão: hoje)"),
    indice: str = Query("ipca", description="ipca | inpc | igpm | selic | tr"),
):
    """
    Calcula a correção monetária de um valor entre duas datas.
    Usa índices reais do Banco Central.
    Fundamental para atualização de débitos trabalhistas e contratuais.
    """
    fim = data_fim or date.today().strftime("%Y-%m-%d")
    codigo = CODIGOS.get(indice.lower())
    if not codigo:
        raise HTTPException(404, f"Índice '{indice}' inválido.")

    di = datetime.strptime(data_inicio, "%Y-%m-%d").strftime("%d/%m/%Y")
    df = datetime.strptime(fim, "%Y-%m-%d").strftime("%d/%m/%Y")

    try:
        dados = await _fetch_serie(codigo, data_inicio=di, data_fim=df)
    except RuntimeError as e:
        raise HTTPException(503, str(e))

    if not dados:
        raise HTTPException(404, f"Sem dados do {indice.upper()} para o período.")

    valor_dec = Decimal(str(valor))
    fator = Decimal("1")
    for reg in dados:
        try:
            taxa_str = str(reg.get("valor", "0")).replace(",", ".")
            taxa = Decimal(taxa_str) / Decimal("100")
            fator *= (Decimal("1") + taxa)
        except Exception:
            continue

    valor_corrigido = (valor_dec * fator).quantize(Decimal("0.01"), ROUND_HALF_UP)
    diferenca = (valor_corrigido - valor_dec).quantize(Decimal("0.01"), ROUND_HALF_UP)

    brl = lambda v: f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

    return {
        "valor_original": brl(valor_dec),
        "valor_corrigido": brl(valor_corrigido),
        "diferenca": brl(diferenca),
        "fator": str(fator.quantize(Decimal("0.00000001"), ROUND_HALF_UP)),
        "variacao_pct": f"{float((fator - Decimal('1')) * 100):.4f}%",
        "indice": indice.upper(),
        "data_inicio": data_inicio,
        "data_fim": fim,
        "periodos_utilizados": len(dados),
        "fonte": f"Banco Central do Brasil — Série {codigo}",
    }


@router.get("/selic-atual")
async def selic_atual():
    """Retorna a taxa SELIC meta atual e histórico recente."""
    try:
        dados = await _fetch_serie(11, ultimos=13)
        return {
            "selic_atual": dados[-1] if dados else None,
            "historico_12_meses": dados[:-1] if len(dados) > 1 else [],
            "fonte": "Banco Central do Brasil — Série 11",
        }
    except RuntimeError as e:
        raise HTTPException(503, str(e))


@router.get("/juros-mora")
async def calcular_juros_mora(
    valor: float = Query(..., description="Valor do débito"),
    data_inicio: str = Query(..., description="YYYY-MM-DD — data do vencimento"),
    data_fim: str = Query(None, description="YYYY-MM-DD — data de hoje"),
    base: str = Query("selic", description="selic | cdi | fixo1"),
    taxa_fixa_am: float = Query(1.0, description="Taxa mensal % (só se base=fixo1)"),
):
    """
    Calcula juros moratórios sobre um débito.
    Base SELIC: padrão em débitos tributários (Lei 9.250/1995).
    Base CDI: comum em contratos bancários.
    Base fixa: contratos com taxa definida (ex: 1% a.m.).
    """
    fim = data_fim or date.today().strftime("%Y-%m-%d")
    di_dt = datetime.strptime(data_inicio, "%Y-%m-%d")
    df_dt = datetime.strptime(fim, "%Y-%m-%d")
    dias = (df_dt - di_dt).days

    if base == "fixo1":
        meses = dias / 30
        fator = (Decimal("1") + Decimal(str(taxa_fixa_am)) / Decimal("100")) ** Decimal(str(meses))
    else:
        codigo = CODIGOS.get(base.lower())
        if not codigo:
            raise HTTPException(404, f"Base '{base}' inválida.")
        di_fmt = di_dt.strftime("%d/%m/%Y")
        df_fmt = df_dt.strftime("%d/%m/%Y")
        try:
            dados = await _fetch_serie(codigo, data_inicio=di_fmt, data_fim=df_fmt)
        except RuntimeError as e:
            raise HTTPException(503, str(e))
        fator = Decimal("1")
        for reg in dados:
            try:
                t = Decimal(str(reg.get("valor", "0")).replace(",", ".")) / Decimal("100")
                fator *= (Decimal("1") + t)
            except Exception:
                continue

    valor_dec = Decimal(str(valor))
    juros = ((fator - Decimal("1")) * valor_dec).quantize(Decimal("0.01"), ROUND_HALF_UP)
    total = (valor_dec + juros).quantize(Decimal("0.01"), ROUND_HALF_UP)

    brl = lambda v: f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

    return {
        "valor_principal": brl(valor_dec),
        "juros_calculados": brl(juros),
        "total_com_juros": brl(total),
        "base_calculo": base.upper(),
        "dias_decorridos": dias,
        "data_inicio": data_inicio,
        "data_fim": fim,
    }
