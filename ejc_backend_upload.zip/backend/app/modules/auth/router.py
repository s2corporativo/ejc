"""
EJC — Módulo Autenticação (modules/auth/router.py)

JWT multi-usuário com roles:
  admin      → acesso total + usuários + auditoria
  socio      → acesso total exceto gerenciar usuários
  advogado   → todos os módulos, exportação
  estagiario → chat, pesquisa, base de conhecimento (somente leitura)
  cliente    → portal do cliente (ver próprio caso)

Tokens: JWT com expiração configurável (padrão 8h)
Refresh token: 30 dias com rotação
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Security, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_db

logger = logging.getLogger(__name__)
settings = get_settings()

router = APIRouter(prefix="/auth", tags=["Autenticação — JWT Multi-Usuário"])

# ── Crypto ─────────────────────────────────────────────────
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
bearer_scheme = HTTPBearer(auto_error=False)

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_HOURS  = 8
REFRESH_TOKEN_EXPIRE_DAYS  = 30

ROLES_HIERARQUIA = ["cliente","estagiario","atendimento","assistente","financeiro","advogado","socio","admin","superadmin"]

ROLES_PERMISSOES: dict[str, list[str]] = {
    "superadmin": ["*"],
    "admin":      ["*"],
    "socio":      ["rag","redacao","validacao","calculos","integracao","espacos",
                   "analise","prazos","jurimetria","casos","chat","exportacao",
                   "templates","pesquisa","agente","visual_law","bacen","trabalhista",
                   "streaming","teses","notificacoes","clientes","propostas","crm",
                   "financeiro","tarefas","ocr","documentos"],
    "advogado":   ["rag","redacao","validacao","calculos","integracao","espacos",
                   "analise","prazos","casos","chat","exportacao","templates",
                   "pesquisa","agente","visual_law","bacen","trabalhista","streaming",
                   "teses","clientes","propostas","crm","tarefas","ocr","documentos"],
    "assistente": ["rag","chat","pesquisa","casos","prazos","analise","streaming",
                   "clientes","tarefas","documentos","templates"],
    "financeiro": ["financeiro","propostas","casos","clientes","exportacao"],
    "atendimento":["crm","clientes","casos","chat","tarefas"],
    "estagiario": ["rag","chat","pesquisa","casos","prazos","analise","streaming","documentos"],
    "cliente":    ["portal"],
}


# ── SQL helpers ────────────────────────────────────────────

async def _get_user_by_email(db: AsyncSession, email: str) -> Optional[dict]:
    r = await db.execute(text("SELECT * FROM usuarios WHERE email=:e AND ativo=true"), {"e": email})
    row = r.mappings().first()
    return dict(row) if row else None


async def _get_user_by_id(db: AsyncSession, uid: str) -> Optional[dict]:
    r = await db.execute(text("SELECT * FROM usuarios WHERE id=:id AND ativo=true"), {"id": uid})
    row = r.mappings().first()
    return dict(row) if row else None


# ── JWT helpers ────────────────────────────────────────────

def _create_token(data: dict, expires_delta: timedelta) -> str:
    payload = data.copy()
    payload["exp"] = datetime.now(timezone.utc) + expires_delta
    payload["iat"] = datetime.now(timezone.utc)
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)


def criar_access_token(user_id: str, role: str, nome: str) -> str:
    return _create_token(
        {"sub": user_id, "role": role, "nome": nome, "type": "access"},
        timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS),
    )


def criar_refresh_token(user_id: str) -> str:
    return _create_token(
        {"sub": user_id, "type": "refresh"},
        timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS),
    )


def _verificar_token(token: str, tipo: str = "access") -> dict:
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
        if payload.get("type") != tipo:
            raise HTTPException(401, "Tipo de token inválido")
        return payload
    except JWTError:
        raise HTTPException(401, "Token inválido ou expirado")


# ── Dependências de autenticação ────────────────────────────

async def get_current_user(
    creds: Optional[HTTPAuthorizationCredentials] = Security(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Dependência principal: valida JWT e retorna usuário atual."""
    if not creds:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Token de acesso obrigatório",
                            headers={"WWW-Authenticate": "Bearer"})
    payload = _verificar_token(creds.credentials, "access")
    user = await _get_user_by_id(db, payload["sub"])
    if not user:
        raise HTTPException(401, "Usuário não encontrado ou inativo")
    return user


def require_role(*roles: str):
    """Factory de dependência que exige um dos roles especificados."""
    async def _check(user: dict = Depends(get_current_user)) -> dict:
        if user["role"] not in roles and user["role"] != "admin":
            raise HTTPException(
                status.HTTP_403_FORBIDDEN,
                f"Acesso negado. Roles permitidos: {', '.join(roles)}"
            )
        return user
    return _check


def require_modulo(modulo: str):
    """Verifica se o role do usuário tem acesso ao módulo."""
    async def _check(user: dict = Depends(get_current_user)) -> dict:
        perms = ROLES_PERMISSOES.get(user["role"], [])
        if "*" not in perms and modulo not in perms:
            raise HTTPException(403, f"Seu perfil ({user['role']}) não tem acesso ao módulo '{modulo}'")
        return user
    return _check


# ── Schemas ────────────────────────────────────────────────

class LoginReq(BaseModel):
    email: str
    senha: str


class CriarUsuarioReq(BaseModel):
    nome: str
    email: str
    senha: str
    role: str = "advogado"
    oab_numero: Optional[str] = None
    oab_estado: Optional[str] = None


class AlterarSenhaReq(BaseModel):
    senha_atual: str
    nova_senha: str


class RefreshReq(BaseModel):
    refresh_token: str


# ── Endpoints ──────────────────────────────────────────────

@router.post("/login")
async def login(req: LoginReq, db: AsyncSession = Depends(get_db)):
    """Autentica o usuário e retorna access_token + refresh_token."""
    user = await _get_user_by_email(db, req.email)
    if not user or not pwd_context.verify(req.senha, user["senha_hash"]):
        raise HTTPException(401, "E-mail ou senha incorretos")

    # Atualiza last_login
    await db.execute(
        text("UPDATE usuarios SET ultimo_acesso=NOW() WHERE id=:id"),
        {"id": user["id"]},
    )

    access  = criar_access_token(user["id"], user["role"], user["nome"])
    refresh = criar_refresh_token(user["id"])

    logger.info(f"[Auth] Login: {user['email']} ({user['role']})")
    return {
        "access_token":  access,
        "refresh_token": refresh,
        "token_type":    "bearer",
        "expires_in":    ACCESS_TOKEN_EXPIRE_HOURS * 3600,
        "usuario": {
            "id": user["id"], "nome": user["nome"],
            "email": user["email"], "role": user["role"],
            "permissoes": ROLES_PERMISSOES.get(user["role"], []),
        },
    }


@router.post("/refresh")
async def refresh_token(req: RefreshReq, db: AsyncSession = Depends(get_db)):
    """Emite novo access_token a partir de um refresh_token válido."""
    payload = _verificar_token(req.refresh_token, "refresh")
    user = await _get_user_by_id(db, payload["sub"])
    if not user:
        raise HTTPException(401, "Usuário não encontrado")
    access = criar_access_token(user["id"], user["role"], user["nome"])
    return {"access_token": access, "token_type": "bearer", "expires_in": ACCESS_TOKEN_EXPIRE_HOURS * 3600}


@router.get("/me")
async def me(user: dict = Depends(get_current_user)):
    """Retorna dados do usuário autenticado."""
    return {
        "id": user["id"], "nome": user["nome"], "email": user["email"],
        "role": user["role"], "oab_numero": user.get("oab_numero"),
        "oab_estado": user.get("oab_estado"),
        "permissoes": ROLES_PERMISSOES.get(user["role"], []),
        "ultimo_acesso": str(user.get("ultimo_acesso", "")),
    }


@router.post("/usuarios", status_code=201)
async def criar_usuario(
    req: CriarUsuarioReq,
    db: AsyncSession = Depends(get_db),
    admin: dict = Depends(require_role("admin", "socio")),
):
    """Cria um novo usuário. Apenas admin e sócio podem criar usuários."""
    if req.role not in ROLES_HIERARQUIA:
        raise HTTPException(422, f"Role inválido: {req.role}. Válidos: {ROLES_HIERARQUIA}")
    # Sócio não pode criar admin
    if admin["role"] == "socio" and req.role == "admin":
        raise HTTPException(403, "Sócios não podem criar usuários admin")

    existe = await _get_user_by_email(db, req.email)
    if existe:
        raise HTTPException(409, f"E-mail '{req.email}' já cadastrado")

    uid = str(uuid4())
    hash_senha = pwd_context.hash(req.senha)
    await db.execute(
        text("""
            INSERT INTO usuarios (id, nome, email, senha_hash, role, oab_numero, oab_estado)
            VALUES (:id,:nome,:email,:hash,:role,:oab,:uf)
        """),
        {"id": uid, "nome": req.nome, "email": req.email, "hash": hash_senha,
         "role": req.role, "oab": req.oab_numero, "uf": req.oab_estado},
    )
    return {"id": uid, "nome": req.nome, "email": req.email, "role": req.role}


@router.get("/usuarios")
async def listar_usuarios(
    db: AsyncSession = Depends(get_db),
    admin: dict = Depends(require_role("admin", "socio")),
):
    rows = await db.execute(
        text("SELECT id,nome,email,role,oab_numero,oab_estado,ativo,ultimo_acesso,created_at FROM usuarios ORDER BY created_at")
    )
    return {"usuarios": [dict(r) for r in rows.mappings()]}


@router.post("/alterar-senha")
async def alterar_senha(
    req: AlterarSenhaReq,
    db: AsyncSession = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    if not pwd_context.verify(req.senha_atual, user["senha_hash"]):
        raise HTTPException(400, "Senha atual incorreta")
    nova_hash = pwd_context.hash(req.nova_senha)
    await db.execute(
        text("UPDATE usuarios SET senha_hash=:h WHERE id=:id"),
        {"h": nova_hash, "id": user["id"]},
    )
    return {"message": "Senha alterada com sucesso"}


@router.delete("/usuarios/{uid}")
async def desativar_usuario(
    uid: str,
    db: AsyncSession = Depends(get_db),
    admin: dict = Depends(require_role("admin")),
):
    """Desativa (não apaga) um usuário. Auditoria mantida."""
    if uid == admin["id"]:
        raise HTTPException(400, "Não é possível desativar seu próprio usuário")
    await db.execute(text("UPDATE usuarios SET ativo=false WHERE id=:id"), {"id": uid})
    return {"message": "Usuário desativado"}
