"""
EJC — Módulo Notificações (modules/notificacoes/router.py)

Alertas proativos de prazos críticos via:
  - E-mail SMTP (qualquer provedor: Gmail, Outlook, SendGrid)
  - WhatsApp Business API (via Twilio — opcional)
  - Telegram Bot API (gratuito e robusto)
  - Resumo diário de prazos (scheduler automático)

Configuração via .env:
  SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM
  TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
  TWILIO_SID, TWILIO_TOKEN, TWILIO_WHATSAPP_FROM
"""
from __future__ import annotations

import logging
import smtplib
from datetime import date, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from pydantic_settings import BaseSettings
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/notificacoes", tags=["Notificações — E-mail · WhatsApp · Telegram"])


# ── Configurações de notificação ──────────────────────────
class NotifSettings(BaseSettings):
    smtp_host:   str = "smtp.gmail.com"
    smtp_port:   int = 587
    smtp_user:   str = ""
    smtp_pass:   str = ""
    smtp_from:   str = ""
    telegram_bot_token: str = ""
    telegram_chat_id:   str = ""
    twilio_sid:         str = ""
    twilio_token:       str = ""
    twilio_whatsapp_from: str = "whatsapp:+14155238886"  # Twilio sandbox
    notif_dias_antecedencia: list[int] = [5, 2, 1]

    class Config:
        env_file = ".env"
        case_sensitive = False
        extra = "ignore"


_notif_settings: Optional[NotifSettings] = None


def get_notif_settings() -> NotifSettings:
    global _notif_settings
    if not _notif_settings:
        _notif_settings = NotifSettings()
    return _notif_settings


# ── E-mail ─────────────────────────────────────────────────

def _montar_html_prazo(prazo: dict, dias_restantes: int) -> str:
    urgencia_cor = "#c0394a" if dias_restantes <= 1 else "#c9960a" if dias_restantes <= 3 else "#2a7a5e"
    return f"""
<html><body style="font-family:Arial,sans-serif;background:#f5f5f5;padding:20px">
<div style="max-width:560px;margin:0 auto;background:#fff;border-radius:10px;padding:28px;border-top:4px solid {urgencia_cor}">
  <h2 style="color:{urgencia_cor};margin-top:0">⚠️ PRAZO PROCESSUAL — {dias_restantes} DIA(S)</h2>
  <table style="width:100%;border-collapse:collapse">
    <tr><td style="color:#666;padding:6px 0">Processo:</td><td style="font-weight:bold">{prazo.get('numero_processo','N/D')}</td></tr>
    <tr><td style="color:#666;padding:6px 0">Tribunal:</td><td>{prazo.get('tribunal','N/D')}</td></tr>
    <tr><td style="color:#666;padding:6px 0">Tipo:</td><td>{prazo.get('tipo_prazo','')}</td></tr>
    <tr><td style="color:#666;padding:6px 0">Vencimento:</td><td style="color:{urgencia_cor};font-weight:bold">{prazo.get('data_vencimento','')}</td></tr>
    <tr><td style="color:#666;padding:6px 0">Descrição:</td><td>{prazo.get('titulo','')}</td></tr>
  </table>
  <p style="color:#666;font-size:12px;margin-top:20px;border-top:1px solid #eee;padding-top:12px">
    Ecossistema Jurídico Clovis (EJC) — Sistema de Gestão de Prazos<br>
    <em>Este é um alerta automático. Verifique o processo no sistema EJC.</em>
  </p>
</div></body></html>"""


async def enviar_email(
    destinatario: str,
    assunto: str,
    corpo_html: str,
    cfg: NotifSettings = None,
) -> bool:
    if not cfg:
        cfg = get_notif_settings()
    if not cfg.smtp_user or not cfg.smtp_pass:
        logger.warning("[Notif] SMTP não configurado — skipping e-mail")
        return False
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = assunto
        msg["From"]    = cfg.smtp_from or cfg.smtp_user
        msg["To"]      = destinatario
        msg.attach(MIMEText(corpo_html, "html", "utf-8"))

        with smtplib.SMTP(cfg.smtp_host, cfg.smtp_port) as server:
            server.ehlo()
            server.starttls()
            server.login(cfg.smtp_user, cfg.smtp_pass)
            server.sendmail(msg["From"], [destinatario], msg.as_string())
        logger.info(f"[Notif] E-mail enviado para {destinatario}")
        return True
    except Exception as e:
        logger.error(f"[Notif] Falha e-mail: {e}")
        return False


# ── Telegram ───────────────────────────────────────────────

async def enviar_telegram(mensagem: str, cfg: NotifSettings = None) -> bool:
    if not cfg:
        cfg = get_notif_settings()
    if not cfg.telegram_bot_token or not cfg.telegram_chat_id:
        logger.warning("[Notif] Telegram não configurado")
        return False
    try:
        url = f"https://api.telegram.org/bot{cfg.telegram_bot_token}/sendMessage"
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(url, json={
                "chat_id": cfg.telegram_chat_id,
                "text": mensagem,
                "parse_mode": "Markdown",
            })
            ok = resp.status_code == 200
            if ok:
                logger.info("[Notif] Telegram enviado")
            return ok
    except Exception as e:
        logger.error(f"[Notif] Falha Telegram: {e}")
        return False


# ── WhatsApp via Twilio ────────────────────────────────────

async def enviar_whatsapp(numero: str, mensagem: str, cfg: NotifSettings = None) -> bool:
    if not cfg:
        cfg = get_notif_settings()
    if not cfg.twilio_sid or not cfg.twilio_token:
        logger.warning("[Notif] Twilio não configurado")
        return False
    try:
        url = f"https://api.twilio.com/2010-04-01/Accounts/{cfg.twilio_sid}/Messages.json"
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                url,
                auth=(cfg.twilio_sid, cfg.twilio_token),
                data={
                    "From": cfg.twilio_whatsapp_from,
                    "To":   f"whatsapp:{numero}",
                    "Body": mensagem,
                },
            )
            ok = resp.status_code in (200, 201)
            if ok:
                logger.info(f"[Notif] WhatsApp enviado para {numero}")
            return ok
    except Exception as e:
        logger.error(f"[Notif] Falha WhatsApp: {e}")
        return False


# ── Job agendado: verificar prazos críticos ───────────────

async def job_alertar_prazos_criticos():
    """Executado pelo APScheduler às 7h. Verifica prazos e dispara alertas."""
    from app.core.database import AsyncSessionLocal
    cfg = get_notif_settings()
    hoje = date.today()

    async with AsyncSessionLocal() as db:
        for dias in cfg.notif_dias_antecedencia:
            data_alvo = hoje + timedelta(days=dias)
            rows = await db.execute(
                text("""
                    SELECT p.*, e.titulo AS espaco_titulo
                    FROM prazos p
                    LEFT JOIN espacos e ON e.id = p.espaco_id
                    WHERE p.status = 'pendente'
                      AND p.data_vencimento = :data
                """),
                {"data": str(data_alvo)},
            )
            for prazo in rows.mappings():
                p = dict(prazo)
                msg = (
                    f"⚖️ *EJC — PRAZO CRÍTICO*\n"
                    f"Vence em *{dias} dia(s)*\n"
                    f"📋 {p.get('titulo','')}\n"
                    f"📁 Processo: {p.get('numero_processo','N/D')}\n"
                    f"🗓 Vencimento: {p.get('data_vencimento','')}\n"
                    f"⚡ Tipo: {p.get('tipo_prazo','')}"
                )
                await enviar_telegram(msg, cfg)

                if cfg.smtp_user:
                    html = _montar_html_prazo(p, dias)
                    await enviar_email(cfg.smtp_user, f"[EJC] Prazo em {dias} dia(s): {p.get('titulo','')}", html, cfg)

        await db.commit()
    logger.info("[Scheduler] Job alertar_prazos_criticos concluído")


# ── Endpoints ──────────────────────────────────────────────

class EmailManualReq(BaseModel):
    destinatario: str
    assunto: str
    mensagem: str


class TelegramReq(BaseModel):
    mensagem: str


class WhatsAppReq(BaseModel):
    numero: str
    mensagem: str


@router.post("/email")
async def enviar_email_manual(req: EmailManualReq):
    """Envia e-mail manual via SMTP configurado."""
    ok = await enviar_email(req.destinatario, req.assunto, f"<p>{req.mensagem}</p>")
    if not ok:
        raise HTTPException(503, "Falha ao enviar e-mail. Verifique configurações SMTP no .env")
    return {"enviado": True, "destinatario": req.destinatario}


@router.post("/telegram")
async def enviar_telegram_manual(req: TelegramReq):
    """Envia mensagem ao canal/grupo Telegram configurado."""
    ok = await enviar_telegram(req.mensagem)
    if not ok:
        raise HTTPException(503, "Falha Telegram. Configure TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID no .env")
    return {"enviado": True}


@router.post("/whatsapp")
async def enviar_whatsapp_manual(req: WhatsAppReq):
    """Envia mensagem WhatsApp via Twilio."""
    ok = await enviar_whatsapp(req.numero, req.mensagem)
    if not ok:
        raise HTTPException(503, "Falha WhatsApp. Configure TWILIO_SID e TWILIO_TOKEN no .env")
    return {"enviado": True, "numero": req.numero}


@router.post("/testar")
async def testar_notificacoes():
    """Testa todos os canais de notificação configurados."""
    cfg = get_notif_settings()
    resultados = {
        "email_configurado":    bool(cfg.smtp_user and cfg.smtp_pass),
        "telegram_configurado": bool(cfg.telegram_bot_token and cfg.telegram_chat_id),
        "whatsapp_configurado": bool(cfg.twilio_sid and cfg.twilio_token),
    }
    if resultados["telegram_configurado"]:
        resultados["telegram_teste"] = await enviar_telegram("🟢 EJC — Teste de notificação funcionando!", cfg)
    return resultados


@router.post("/disparar-alertas-agora")
async def disparar_alertas_agora(db: AsyncSession = Depends(get_db)):
    """Força o disparo imediato dos alertas de prazos (normalmente automático às 7h)."""
    await job_alertar_prazos_criticos()
    return {"message": "Alertas disparados com sucesso."}


@router.get("/configuracao")
async def status_configuracao():
    """Retorna quais canais de notificação estão configurados."""
    cfg = get_notif_settings()
    return {
        "canais": {
            "email":    {"ativo": bool(cfg.smtp_user), "host": cfg.smtp_host, "porta": cfg.smtp_port},
            "telegram": {"ativo": bool(cfg.telegram_bot_token), "chat_id": cfg.telegram_chat_id[:10] + "..." if cfg.telegram_chat_id else ""},
            "whatsapp": {"ativo": bool(cfg.twilio_sid), "from": cfg.twilio_whatsapp_from},
        },
        "antecedencia_alertas": cfg.notif_dias_antecedencia,
        "instrucoes": {
            "email":    "Defina SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM no .env",
            "telegram": "Crie um bot em @BotFather, defina TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID no .env",
            "whatsapp": "Crie conta Twilio, defina TWILIO_SID, TWILIO_TOKEN no .env",
        },
    }
