"""
EJC — Router Redação (modules/redacao/router.py)
"""
from __future__ import annotations

import logging
import time
from uuid import uuid4
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.rag.knowledge_base import LegalKnowledgeBase
from app.modules.rag.router import get_kb
from app.modules.redacao.service import LegalDraftService
from app.schemas.legal import DraftRequest, DraftResponse, DocumentListItem

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/redacao", tags=["Redação de Peças Jurídicas"])

_draft_service: Optional[LegalDraftService] = None


def get_svc() -> LegalDraftService:
    global _draft_service
    if _draft_service is None:
        _draft_service = LegalDraftService()
    return _draft_service


@router.post("/gerar", response_model=DraftResponse)
async def generate_document(
    request: DraftRequest,
    db: AsyncSession = Depends(get_db),
    kb: LegalKnowledgeBase = Depends(get_kb),
    svc: LegalDraftService = Depends(get_svc),
):
    """
    Gera uma peça jurídica completa usando RAG + Ollama local.
    Pipeline: busca semântica → prompt estruturado → geração → persistência.
    """
    t0 = time.time()
    doc_id = uuid4()

    # 1. Recupera contexto jurídico relevante
    rag_query = f"{request.document_type} {request.objective} {request.facts[:500]}"
    chunks = await kb.semantic_search(db=db, query=rag_query, top_k=8)
    rag_context = "\n\n---\n\n".join(c["content"] for c in chunks) if chunks else \
        "Base de conhecimento ainda sem documentos para esta área. Baseie-se apenas no direito positivo vigente."

    # 2. Gera a peça
    try:
        content_md = await svc.generate_draft(
            title=request.title,
            document_type=request.document_type,
            facts=request.facts,
            objective=request.objective,
            rag_context=rag_context,
            client_name=request.client_name,
            opposing_party=request.opposing_party,
            additional_context=request.additional_context,
        )
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))

    word_count = len(content_md.split())
    elapsed = round(time.time() - t0, 2)

    # 3. Persiste no banco
    await db.execute(
        text("""
            INSERT INTO legal_documents
                (id, title, document_type, input_facts, input_objective, content_md, status)
            VALUES (:id, :title, :dt, :facts, :obj, :content, 'draft')
        """),
        {
            "id": str(doc_id),
            "title": request.title,
            "dt": request.document_type,
            "facts": request.facts,
            "obj": request.objective,
            "content": content_md,
        },
    )

    return DraftResponse(
        document_id=doc_id,
        title=request.title,
        document_type=request.document_type,
        content_md=content_md,
        word_count=word_count,
        status="draft",
        elapsed_seconds=elapsed,
    )


@router.get("/documentos", response_model=list[DocumentListItem])
async def list_documents(db: AsyncSession = Depends(get_db)):
    """Lista todas as peças jurídicas geradas."""
    rows = await db.execute(
        text("""
            SELECT id, title, document_type, status, created_at,
                   array_length(string_to_array(content_md, ' '), 1) AS word_count
            FROM legal_documents
            ORDER BY created_at DESC
            LIMIT 100
        """)
    )
    return [DocumentListItem(**dict(r)) for r in rows.mappings()]


@router.get("/documentos/{doc_id}")
async def get_document(doc_id: str, db: AsyncSession = Depends(get_db)):
    """Recupera uma peça jurídica por ID."""
    row = await db.execute(
        text("SELECT * FROM legal_documents WHERE id = :id"),
        {"id": doc_id},
    )
    doc = row.mappings().first()
    if not doc:
        raise HTTPException(status_code=404, detail="Documento não encontrado.")
    return dict(doc)


@router.patch("/documentos/{doc_id}/status")
async def update_status(doc_id: str, status: str, db: AsyncSession = Depends(get_db)):
    """Atualiza o status de uma peça (draft → validated → final)."""
    valid = {"draft", "validated", "final"}
    if status not in valid:
        raise HTTPException(status_code=422, detail=f"Status inválido. Use: {valid}")
    await db.execute(
        text("UPDATE legal_documents SET status = :status WHERE id = :id"),
        {"status": status, "id": doc_id},
    )
    return {"message": f"Status atualizado para '{status}'."}
