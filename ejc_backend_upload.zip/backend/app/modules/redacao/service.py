"""
EJC — Módulo Redação: LegalDraftService (modules/redacao/service.py)

Usa LLMProvider — funciona com Ollama (local) OU Groq (cloud).
Troca de provedor: LLM_PROVIDER=ollama | groq no .env
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from app.core.config import get_settings
from app.core.llm_provider import get_llm_provider

logger   = logging.getLogger(__name__)
settings = get_settings()

EJC_SYSTEM_PROMPT = """Você é o motor de inteligência do Ecossistema Jurídico Clovis.
Atue em modo técnico conservador. Priorize precisão normativa, legalidade e aplicabilidade prática.
Use apenas informações verificáveis da base de conhecimento fornecida.
Nunca invente dados, jurisprudência ou dispositivos legais que não constem no contexto.
Sua redação deve ser formal, exauriente e estruturada para advogados de elite.
Quando citar legislação, indique sempre: lei, artigo, parágrafo e inciso.
Quando citar jurisprudência, indique: tribunal, número do processo e data.
Produza peças com estrutura completa: qualificação das partes, fatos, fundamentos jurídicos, pedidos e fechamento.
Minuta deve ter no mínimo 10 páginas de conteúdo substantivo."""

DOCUMENT_TYPE_INSTRUCTIONS = {
    "peticao_inicial": "Redija uma PETIÇÃO INICIAL completa com: endereçamento, qualificação das partes, dos fatos, do direito, dos pedidos e do valor da causa.",
    "recurso":         "Redija um RECURSO completo com: tempestividade, preparo, razões recursais detalhadas e pedido de provimento.",
    "contrato":        "Redija um CONTRATO completo com: partes, objeto, obrigações, prazo, valor, penalidades, rescisão e foro.",
    "parecer":         "Redija um PARECER JURÍDICO completo com: ementa, relatório, análise fundamentada e conclusão.",
    "edital":          "Redija um EDITAL completo com: preâmbulo, objeto, requisitos, condições, critérios e disposições finais.",
    "defesa":          "Redija uma DEFESA/CONTESTAÇÃO completa com: preliminares, impugnação dos fatos, fundamentos e pedidos.",
    "notificacao":     "Redija uma NOTIFICAÇÃO EXTRAJUDICIAL completa com: qualificação, fatos, exigência e prazo.",
}


class LegalDraftService:
    """
    Serviço de geração de peças jurídicas.
    Funciona com Ollama (local) ou Groq (cloud) sem alteração no código.
    """

    def __init__(self):
        self._llm = get_llm_provider()

    async def generate_draft(
        self,
        title: str,
        document_type: str,
        facts: str,
        objective: str,
        rag_context: str,
        client_name: Optional[str] = None,
        opposing_party: Optional[str] = None,
        additional_context: Optional[str] = None,
    ) -> str:
        instrucao = DOCUMENT_TYPE_INSTRUCTIONS.get(
            document_type,
            f"Redija um documento jurídico do tipo '{document_type}' de forma completa e fundamentada."
        )
        partes = ""
        if client_name:
            partes += f"\n- REQUERENTE/CLIENTE: {client_name}"
        if opposing_party:
            partes += f"\n- REQUERIDO/PARTE CONTRÁRIA: {opposing_party}"
        extra = f"\n\n### Contexto Adicional\n{additional_context}" if additional_context else ""

        prompt = f"""## Tarefa: {instrucao}

### Título da Peça
{title}

### Partes{partes if partes else ' (não especificadas)'}

### Fatos do Caso
{facts}

### Objetivo / Pedido
{objective}
{extra}

### Base de Conhecimento Jurídico (RAG)
---
{rag_context}
---

Produza a peça COMPLETA em Markdown, mínimo 10 páginas.
Use ## para seções principais, ### para subseções.
Inclua: Dos Fatos, Do Direito, Dos Pedidos."""

        t0 = time.time()
        resultado = await self._llm.generate(
            prompt=prompt,
            system=EJC_SYSTEM_PROMPT,
            temperature=0.1,
            max_tokens=8192,
        )
        logger.info(f"[Redação] {round(time.time()-t0,1)}s | provider={self._llm.provider}")
        return resultado

    async def answer_from_context(self, query: str, context: str) -> str:
        prompt = f"""Consulta Jurídica: {query}

Contexto da Base de Conhecimento:
---
{context}
---
Responda citando dispositivos legais do contexto. Se não houver dados suficientes, informe."""
        return await self._llm.generate(
            prompt=prompt, system=EJC_SYSTEM_PROMPT,
            temperature=0.1, max_tokens=4096,
        )

    async def check_health(self) -> dict:
        return await self._llm.check_health()
