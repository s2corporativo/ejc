"""
EJC — Módulo Agente (modules/agente/router.py)

Modo agêntico para planejamento autônomo de estratégia jurídica:
  - Recebe um caso e planeja autonomamente as próximas ações
  - Gera roteiro de peças a produzir
  - Sugere pesquisas necessárias e prazos críticos
  - Identifica provas e documentos faltantes
"""
from __future__ import annotations

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.redacao.service import LegalDraftService
from app.modules.auditoria.middleware import adicionar_aviso, AVISO_CURTO

router = APIRouter(prefix="/agente", tags=["Agente Jurídico — Modo Autônomo"])

_llm: Optional[LegalDraftService] = None


def get_llm() -> LegalDraftService:
    global _llm
    if not _llm:
        _llm = LegalDraftService()
    return _llm


class PlanoRequest(BaseModel):
    caso_id: Optional[str] = None
    descricao_caso: str
    area_juridica: str = "trabalhista"
    objetivo: str
    documentos_disponiveis: Optional[list[str]] = None
    prazo_urgente: bool = False


@router.post("/planejar")
async def planejar_caso(
    req: PlanoRequest,
    db: AsyncSession = Depends(get_db),
    llm: LegalDraftService = Depends(get_llm),
):
    """
    Modo agêntico: analisa o caso e gera um plano de ação autônomo
    com próximos passos, peças a produzir e alertas.
    """
    prompt = f"""Você é um advogado sênior fazendo o planejamento estratégico de um caso.

CASO:
Área: {req.area_juridica}
Objetivo: {req.objetivo}
Descrição: {req.descricao_caso}
Documentos disponíveis: {', '.join(req.documentos_disponiveis or ['não informados'])}
Urgência: {'ALTA — prazo crítico' if req.prazo_urgente else 'Normal'}

Elabore um PLANO DE AÇÃO COMPLETO em JSON com este formato exato:
{{
  "resumo_caso": "...",
  "estrategia_recomendada": "...",
  "proximas_acoes": [
    {{"ordem": 1, "acao": "...", "prazo_dias": 5, "prioridade": "critica"}},
    ...
  ],
  "pecas_a_produzir": [
    {{"tipo": "peticao_inicial", "titulo": "...", "urgencia": "alta"}},
    ...
  ],
  "documentos_necessarios": ["..."],
  "pontos_atencao": ["..."],
  "probabilidade_exito_estimada": "alta/media/baixa",
  "observacoes": "..."
}}

Responda APENAS com o JSON, sem texto adicional."""

    resultado_raw = await llm.answer_from_context(
        query="planejar caso jurídico", context=req.descricao_caso
    )

    # Tenta parsear JSON da resposta
    import re, json
    match = re.search(r'\{.*\}', resultado_raw, re.DOTALL)
    try:
        plano = json.loads(match.group(0)) if match else {"raw": resultado_raw}
    except Exception:
        plano = {"raw": resultado_raw, "erro_parse": "LLM não retornou JSON válido"}

    return {
        "caso_id": req.caso_id,
        "area_juridica": req.area_juridica,
        "plano": plano,
        "aviso": AVISO_CURTO,
    }


@router.post("/chat")
async def chat_agente(
    payload: dict,
    db: AsyncSession = Depends(get_db),
    llm: LegalDraftService = Depends(get_llm),
):
    """
    Chat direto com o Agente Jurídico EJC.
    Responde perguntas jurídicas com contexto de caso quando fornecido.
    """
    mensagem = payload.get("mensagem", "")
    contexto = payload.get("contexto", "")
    if not mensagem:
        raise HTTPException(422, "mensagem obrigatória")

    resposta = await llm.answer_from_context(query=mensagem, context=contexto or mensagem)
    return {
        "resposta": adicionar_aviso(resposta, curto=True),
        "aviso_juridico": True,
    }


@router.get("/status")
async def status_agente(llm: LegalDraftService = Depends(get_llm)):
    """Verifica status do Agente Jurídico (modelo Ollama)."""
    saude = await llm.check_health()
    return {
        "agente": "EJC Agente Jurídico",
        "modo": "agêntico + RAG",
        "llm": saude,
    }
