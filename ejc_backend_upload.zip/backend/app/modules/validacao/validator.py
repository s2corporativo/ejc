"""
EJC — Módulo Validação: LegalValidator (modules/validacao/validator.py)

Responsabilidades:
  1. Extrai referências a leis, artigos e jurisprudência do texto gerado
  2. Verifica vigência consultando fontes governamentais (LexML, Planalto)
  3. Retorna score de confiabilidade e alertas
"""
from __future__ import annotations

import logging
import re
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


# Padrões regex para identificar citações jurídicas brasileiras
PATTERNS = {
    "lei_ordinaria": re.compile(
        r"\b(Lei\s+(?:Complementar\s+)?(?:n[oº°]?\s*)?(\d{1,6}(?:\.\d{3})*(?:\/\d{4})?))(?:[\s,;]|$)",
        re.IGNORECASE,
    ),
    "decreto": re.compile(
        r"\b(Decreto(?:-Lei)?\s+(?:n[oº°]?\s*)?(\d{1,6}(?:\.\d{3})*(?:\/\d{4})?))(?:[\s,;]|$)",
        re.IGNORECASE,
    ),
    "artigo": re.compile(
        r"\bart(?:igo|\.)\s*(\d+[º°]?(?:-[A-Z])?(?:,\s*§\s*\d+[º°]?)?(?:,\s*inc(?:iso|\.)?\s*[IVXLC]+)?)",
        re.IGNORECASE,
    ),
    "constituicao": re.compile(
        r"\b(Constituição\s+(?:Federal|da\s+República)?(?:\s+de\s+\d{4})?)(?:[\s,;]|$)",
        re.IGNORECASE,
    ),
    "stj_stf": re.compile(
        r"\b((?:STJ|STF|TRT|TRF|TST)[^,;\n]{5,80}(?:n[oº°]?\s*)?[\d\.\-\/]+(?:\/\d{2,4})?)",
        re.IGNORECASE,
    ),
}

# Mapeamento de leis conhecidas com status verificado
KNOWN_LAWS: dict[str, dict] = {
    "10.406/2002": {"status": "vigente", "nome": "Código Civil", "url": "https://www.planalto.gov.br/ccivil_03/leis/2002/l10406compilada.htm"},
    "13.105/2015": {"status": "vigente", "nome": "CPC/2015", "url": "https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2015/lei/l13105.htm"},
    "5.452/1943":  {"status": "vigente", "nome": "CLT", "url": "https://www.planalto.gov.br/ccivil_03/decreto-lei/del5452compilado.htm"},
    "8.078/1990":  {"status": "vigente", "nome": "CDC", "url": "https://www.planalto.gov.br/ccivil_03/leis/l8078compilado.htm"},
    "14.133/2021": {"status": "vigente", "nome": "Lei de Licitações", "url": "https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm"},
    "8.666/1993":  {"status": "parcialmente_revogada", "nome": "Lei Antiga de Licitações (revogada pela 14.133/2021)", "url": ""},
    "9.307/1996":  {"status": "vigente", "nome": "Lei de Arbitragem", "url": ""},
    "13.709/2018": {"status": "vigente", "nome": "LGPD", "url": "https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm"},
    "8.212/1991":  {"status": "vigente", "nome": "Lei Custeio INSS", "url": ""},
    "8.036/1990":  {"status": "vigente", "nome": "Lei FGTS", "url": "https://www.planalto.gov.br/ccivil_03/leis/l8036consol.htm"},
}


class LegalValidator:
    """
    Valida referências jurídicas em peças geradas pelo EJC.
    """

    async def validate(self, content_md: str) -> dict:
        """
        Analisa o conteúdo e retorna relatório de validação.
        """
        references = self._extract_references(content_md)
        validated = []
        warnings = []
        verified = 0

        for ref in references:
            result = await self._check_reference(ref)
            validated.append(result)
            if result["status"] == "revogado":
                warnings.append(
                    f"⚠️ ALERTA: '{ref['reference']}' pode estar revogada ou desatualizada. Verifique."
                )
            elif result["status"] == "vigente":
                verified += 1

        score = round(verified / len(references), 2) if references else 1.0

        return {
            "references_found": validated,
            "validation_score": score,
            "warnings": warnings,
            "summary": f"{verified}/{len(references)} referências verificadas como vigentes.",
        }

    def _extract_references(self, text: str) -> list[dict]:
        """Extrai todas as referências jurídicas do texto."""
        found = []
        seen = set()

        for ref_type, pattern in PATTERNS.items():
            for match in pattern.finditer(text):
                ref_text = match.group(0).strip()
                if ref_text not in seen:
                    seen.add(ref_text)
                    found.append({"reference": ref_text, "type": ref_type, "article": None})

        return found

    async def _check_reference(self, ref: dict) -> dict:
        """
        Verifica se uma referência é conhecida e vigente.
        Prioridade: tabela local → consulta ao Planalto (scraping leve)
        """
        ref_text = ref["reference"]

        # Tenta match na tabela local
        for law_num, info in KNOWN_LAWS.items():
            if law_num in ref_text or law_num.replace("/", ".") in ref_text:
                return {
                    "reference": ref_text,
                    "article": ref.get("article"),
                    "status": info["status"],
                    "source_url": info.get("url"),
                    "note": info["nome"],
                }

        # Se não está na tabela local, tenta busca no LexML
        status = await self._query_lexml(ref_text)

        return {
            "reference": ref_text,
            "article": ref.get("article"),
            "status": status,
            "source_url": None,
            "note": "Verificado via LexML" if status != "nao_verificado" else "Não encontrado automaticamente",
        }

    async def _query_lexml(self, reference: str) -> str:
        """
        Consulta básica ao LexML (portal da legislação federal).
        Retorna: 'vigente' | 'nao_verificado'
        """
        try:
            # Extrai número da lei para pesquisa
            num_match = re.search(r"(\d{3,6}(?:\.\d{3})*(?:\/\d{4})?)", reference)
            if not num_match:
                return "nao_verificado"

            num = num_match.group(1).replace(".", "").replace("/", "")
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get(
                    f"https://www.lexml.gov.br/urn/urn:lex:br:federal:lei:{num}",
                    follow_redirects=True,
                    headers={"Accept": "application/json"},
                )
                if resp.status_code == 200:
                    return "vigente"
        except Exception as e:
            logger.debug(f"[Validação] LexML indisponível para '{reference}': {e}")

        return "nao_verificado"
