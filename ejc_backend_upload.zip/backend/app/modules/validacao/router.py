"""
EJC — Router Validação (modules/validacao/router.py)
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.validacao.validator import LegalValidator
from app.schemas.legal import ValidationRequest, ValidationResponse

router = APIRouter(prefix="/validacao", tags=["Validação Jurídica"])
_validator = LegalValidator()


@router.post("/validar", response_model=ValidationResponse)
async def validate_document(
    request: ValidationRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Valida referências legais de uma peça gerada.
    Verifica vigência de leis citadas e retorna score de confiabilidade.
    """
    result = await _validator.validate(request.content_md)

    # Persiste log de validação no banco
    await db.execute(
        text("""
            UPDATE legal_documents
            SET validation_log = :log::jsonb, status = 'validated'
            WHERE id = :id
        """),
        {"log": str(result), "id": str(request.document_id)},
    )

    return ValidationResponse(
        document_id=request.document_id,
        references_found=result["references_found"],
        validation_score=result["validation_score"],
        warnings=result["warnings"],
        updated_content_md=None,
    )


@router.post("/extrair-referencias")
async def extract_references(content: dict):
    """
    Extrai todas as referências jurídicas de um texto sem validar.
    Útil para pré-visualização rápida.
    """
    refs = _validator._extract_references(content.get("text", ""))
    return {"references": refs, "total": len(refs)}
