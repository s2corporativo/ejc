"""
EJC — Módulo Auditoria LGPD (modules/auditoria/)

Implementa:
  1. Log de auditoria para todas as ações sensíveis
  2. Aviso jurídico OBRIGATÓRIO em todas as respostas de IA
  3. Middleware de LGPD compliance
  4. Anonimização de dados pessoais
  5. Criptografia AES-256 para dados sensíveis

Conformidade:
  - LGPD (Lei 13.709/2018)
  - Resolução CNJ sobre IA no Judiciário
  - OAB — proibição de divulgação de dados de clientes
"""
from __future__ import annotations

import hashlib
import logging
from base64 import b64encode, b64decode
from typing import Any, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)

# ── Aviso jurídico obrigatório (Resolução CNJ + OAB) ──────
AVISO_JURIDICO = (
    "\n\n---\n"
    "⚠️ **AVISO JURÍDICO OBRIGATÓRIO**: Esta resposta foi gerada por inteligência "
    "artificial e tem caráter meramente informativo e de suporte ao trabalho jurídico. "
    "Não constitui parecer jurídico, consultoria ou aconselhamento legal. "
    "Todo conteúdo gerado deve ser revisado e validado por advogado habilitado "
    "antes de qualquer uso oficial. O EJC utiliza IA local (Ollama) — nenhum dado "
    "é enviado a servidores externos. Conformidade: LGPD (Lei 13.709/2018) · "
    "Resolução CNJ nº 332/2020 · Código de Ética da OAB."
)

AVISO_CURTO = (
    "*⚠️ IA de suporte — revisar com advogado habilitado. "
    "Dados protegidos por LGPD. IA local sem envio a terceiros.*"
)


def adicionar_aviso(texto: str, curto: bool = False) -> str:
    """Appenda o aviso jurídico obrigatório a qualquer resposta de IA."""
    return texto + (AVISO_CURTO if curto else AVISO_JURIDICO)


# ── Criptografia AES-256 ────────────────────────────────── 
try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    import os

    _CRYPTO_KEY: Optional[bytes] = None

    def _get_key() -> bytes:
        global _CRYPTO_KEY
        if not _CRYPTO_KEY:
            from app.core.config import get_settings
            salt = b"ejc_salt_2024"
            kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=100_000)
            _CRYPTO_KEY = b64encode(kdf.derive(get_settings().secret_key.encode()))
        return _CRYPTO_KEY

    def criptografar(dado: str) -> str:
        f = Fernet(_get_key())
        return f.encrypt(dado.encode()).decode()

    def descriptografar(cifrado: str) -> str:
        f = Fernet(_get_key())
        return f.decrypt(cifrado.encode()).decode()

    CRYPTO_DISPONIVEL = True
except ImportError:
    CRYPTO_DISPONIVEL = False
    def criptografar(dado: str) -> str:
        return f"[NÃO CRIPTOGRAFADO: instalar cryptography]: {dado}"
    def descriptografar(cifrado: str) -> str:
        return cifrado


# ── Anonimização LGPD ────────────────────────────────────
def anonimizar_cpf(cpf: str) -> str:
    """Exibe apenas últimos 3 dígitos: ***.***.***-XX"""
    digits = "".join(c for c in cpf if c.isdigit())
    return f"***.***.***-{digits[-2:]}" if len(digits) >= 2 else "***"


def anonimizar_cnpj(cnpj: str) -> str:
    digits = "".join(c for c in cnpj if c.isdigit())
    return f"**.***.***/****-{digits[-2:]}" if len(digits) >= 2 else "**"


def hash_dado_sensivel(dado: str) -> str:
    """SHA-256 para pseudonimização de dados pessoais."""
    return hashlib.sha256(dado.encode()).hexdigest()[:16]


# ── Função de auditoria ──────────────────────────────────
async def auditar(
    db: AsyncSession,
    acao: str,
    recurso: str,
    recurso_id: Optional[str] = None,
    usuario: str = "sistema",
    dados_antes: Optional[Any] = None,
    dados_depois: Optional[Any] = None,
    ip_origem: Optional[str] = None,
):
    """
    Registra ação na tabela audit_log.
    Chame em todos os endpoints que manipulam dados sensíveis.
    """
    try:
        await db.execute(
            text("""
                INSERT INTO audit_log
                    (id, acao, recurso, recurso_id, usuario, ip_origem,
                     dados_antes, dados_depois)
                VALUES
                    (gen_random_uuid(), :acao, :rec, :rid, :usr, :ip,
                     :da::jsonb, :dd::jsonb)
            """),
            {
                "acao": acao, "rec": recurso, "rid": recurso_id,
                "usr": usuario, "ip": ip_origem,
                "da": str(dados_antes) if dados_antes else None,
                "dd": str(dados_depois) if dados_depois else None,
            },
        )
    except Exception as e:
        logger.warning(f"[Auditoria] Falha ao registrar log: {e}")


# ── Router ────────────────────────────────────────────────
router = APIRouter(prefix="/auditoria", tags=["Auditoria & LGPD"])


@router.get("/logs")
async def listar_logs(
    acao: Optional[str] = None,
    recurso: Optional[str] = None,
    limit: int = Query(100, le=500),
    db: AsyncSession = Depends(get_db),
):
    """Lista logs de auditoria com filtros."""
    filtros = []
    params: dict = {"limit": limit}
    if acao:
        filtros.append("acao=:acao"); params["acao"] = acao
    if recurso:
        filtros.append("recurso=:recurso"); params["recurso"] = recurso
    where = "WHERE " + " AND ".join(filtros) if filtros else ""
    rows = await db.execute(
        text(f"SELECT * FROM audit_log {where} ORDER BY created_at DESC LIMIT :limit"),
        params,
    )
    return {"logs": [dict(r) for r in rows.mappings()]}


@router.get("/lgpd/relatorio")
async def relatorio_lgpd(db: AsyncSession = Depends(get_db)):
    """Relatório de conformidade LGPD — dados coletados e tratados."""
    row = await db.execute(text("""
        SELECT
            COUNT(*) AS total_logs,
            COUNT(DISTINCT recurso) AS recursos_distintos,
            MAX(created_at) AS ultima_atividade
        FROM audit_log
    """))
    return {
        "conformidade": {
            "lgpd": True,
            "criptografia_ativa": CRYPTO_DISPONIVEL,
            "aviso_juridico_ativo": True,
            "ia_local_sem_nuvem": True,
            "logs": dict(row.mappings().first()),
        },
        "bases_legais": [
            "LGPD — Lei 13.709/2018",
            "Resolução CNJ nº 332/2020 — IA no Judiciário",
            "Código de Ética OAB — sigilo profissional",
        ],
        "aviso_juridico": AVISO_JURIDICO,
    }


@router.post("/lgpd/excluir-dados")
async def excluir_dados_usuario(
    payload: dict, db: AsyncSession = Depends(get_db)
):
    """
    Direito de exclusão LGPD (art. 18, IV).
    Remove dados identificáveis de um cliente por CPF/CNPJ.
    """
    cpf_cnpj = payload.get("cpf_cnpj", "")
    if not cpf_cnpj:
        return {"error": "CPF/CNPJ obrigatório"}

    # Anonimiza dados do cliente nos casos
    await db.execute(
        text("""
            UPDATE casos
            SET cliente_nome = 'ANONIMIZADO',
                cliente_cpf_cnpj = :hash,
                updated_at = NOW()
            WHERE cliente_cpf_cnpj = :cpf
        """),
        {"hash": hash_dado_sensivel(cpf_cnpj), "cpf": cpf_cnpj},
    )
    await auditar(db, "EXCLUIR_DADOS_LGPD", "casos", usuario="lgpd_request",
                  dados_depois={"cpf_hash": hash_dado_sensivel(cpf_cnpj)})
    return {"message": "Dados anonimizados conforme art. 18, IV da LGPD."}


@router.get("/lgpd/relatorio-usuario/{user_id}")
async def relatorio_lgpd_usuario(user_id: str, db: AsyncSession = Depends(get_db)):
    """Art. 18 LGPD — relatório completo de dados tratados por usuário/cliente."""
    operacoes = await db.execute(text("""
        SELECT acao, modulo, registro_id, criado_em, ip_address
        FROM audit_log WHERE usuario_id=:uid OR registro_id=:uid
        ORDER BY criado_em DESC LIMIT 500
    """), {"uid": user_id})
    return {
        "user_id": user_id,
        "total_operacoes": 0,
        "operacoes": [dict(r) for r in operacoes.mappings()],
        "aviso": "Relatório gerado em conformidade com Art. 18 da LGPD (Lei 13.709/2018)",
        "gerado_em": __import__("datetime").datetime.now().isoformat(),
    }

@router.get("/logs/dashboard")
async def dashboard_auditoria(db: AsyncSession = Depends(get_db)):
    """Dashboard de auditoria para administradores."""
    try:
        stats = await db.execute(text("""
            SELECT
                COUNT(*) as total_logs,
                COUNT(DISTINCT usuario_id) as usuarios_ativos,
                COUNT(*) FILTER (WHERE criado_em > NOW() - INTERVAL '24h') as ultimas_24h,
                COUNT(*) FILTER (WHERE acao LIKE '%DELETE%' OR acao LIKE '%excluir%') as exclusoes
            FROM audit_log WHERE criado_em > NOW() - INTERVAL '30d'
        """))
        s = dict(stats.mappings().first() or {})

        recentes = await db.execute(text("""
            SELECT a.acao, a.modulo, a.criado_em, u.nome as usuario, u.role
            FROM audit_log a LEFT JOIN usuarios u ON u.id::text=a.usuario_id
            ORDER BY a.criado_em DESC LIMIT 20
        """))
        s["logs_recentes"] = [dict(r) for r in recentes.mappings()]
        return s
    except Exception:
        return {"total_logs": 0, "logs_recentes": []}
