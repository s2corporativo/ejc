"""
EJC — Router Cálculos (modules/calculos/router.py)
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from uuid import uuid4

from app.core.database import get_db
from app.modules.calculos.fgts import calcular_fgts_revisional
from app.modules.calculos.pis_cofins import calcular_pis_cofins_monofasico
from app.schemas.legal import (
    FGTSRevisionalRequest, FGTSRevisionalResponse,
    PISCOFINSRequest, PISCOFINSResponse,
)

router = APIRouter(prefix="/calculos", tags=["Cálculos Jurídicos"])


@router.post("/fgts-revisional", response_model=FGTSRevisionalResponse)
async def fgts_revisional(
    request: FGTSRevisionalRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Calcula FGTS Revisional com atualização pela TR.
    Fundamento: Lei 8.036/1990, arts. 15 e 18.
    """
    try:
        result = calcular_fgts_revisional(
            nome_empregado=request.nome_empregado,
            data_admissao=request.data_admissao,
            data_demissao=request.data_demissao,
            salarios=[s.model_dump() for s in request.salarios] if hasattr(request.salarios[0], 'model_dump') else request.salarios,
            percentual_fgts=request.percentual_fgts,
            taxa_tr_mensal=request.taxa_tr_mensal,
        )
    except (ValueError, Exception) as e:
        raise HTTPException(status_code=422, detail=str(e))

    # Log no banco
    await db.execute(
        text("""
            INSERT INTO calculation_log (id, calc_type, input_data, result_data)
            VALUES (:id, 'fgts_revisional', :inp::jsonb, :res::jsonb)
        """),
        {"id": str(uuid4()), "inp": str(request.model_dump()), "res": str(result)},
    )

    return FGTSRevisionalResponse(**result)


@router.post("/pis-cofins-monofasico", response_model=PISCOFINSResponse)
async def pis_cofins_monofasico(
    request: PISCOFINSRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Apura PIS/COFINS diferenciando receitas monofásicas.
    Fundamento: Lei 10.147/2000, Lei 10.637/2002, Lei 10.833/2003.
    """
    try:
        result = calcular_pis_cofins_monofasico(
            cnpj_fornecedor=request.cnpj_fornecedor,
            periodo_apuracao=request.periodo_apuracao,
            regime_tributario=request.regime_tributario,
            receita_bruta=request.receita_bruta,
            receita_monofasica=request.receita_monofasica,
            aliquota_pis=request.aliquota_pis or 0.65,
            aliquota_cofins=request.aliquota_cofins or 3.0,
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))

    await db.execute(
        text("""
            INSERT INTO calculation_log (id, calc_type, input_data, result_data)
            VALUES (:id, 'pis_cofins_monofasico', :inp::jsonb, :res::jsonb)
        """),
        {"id": str(uuid4()), "inp": str(request.model_dump()), "res": str(result)},
    )

    return PISCOFINSResponse(**result)


@router.get("/historico")
async def historico_calculos(db: AsyncSession = Depends(get_db), limit: int = 50):
    """Retorna histórico de cálculos realizados."""
    rows = await db.execute(
        text("SELECT id, calc_type, created_at FROM calculation_log ORDER BY created_at DESC LIMIT :l"),
        {"l": limit},
    )
    return {"calculos": [dict(r) for r in rows.mappings()]}


# ═══════════════════════════════════════════════════════════════════════════
# CALCULADORAS EXPANDIDAS v9
# ═══════════════════════════════════════════════════════════════════════════
from app.modules.calculos.calculos_expandidos import (
    verificar_aposentadoria, calcular_bpc_loas, calcular_atualizacao_monetaria,
    calcular_danos_morais, calcular_alimentos, calcular_pensao_atualizada,
    calcular_dobro_cdc, calcular_juros_abusivos, calcular_prescricao,
    PRAZOS_PRESCRICAO,
)
from pydantic import BaseModel as BM
from datetime import date as d_
from typing import Optional as Opt
import json as _json
from uuid import uuid4 as _uuid4

# ── Previdenciário ──────────────────────────────────────────────────────────

class AposentadoriaReq(BM):
    sexo: str = "M"
    idade: int
    tempo_contribuicao_anos: float
    media_salarios: float
    data_filiacao: Opt[str] = None

class BPCReq(BM):
    renda_familiar_total: float
    num_membros_familia: int
    incapaz: bool = True
    idade: int = 0

@router.post("/aposentadoria")
async def calc_aposentadoria(req: AposentadoriaReq, db: AsyncSession = Depends(get_db)):
    """Verifica elegibilidade e calcula benefício de aposentadoria (EC 103/2019)."""
    r = verificar_aposentadoria(
        sexo=req.sexo,
        idade=req.idade,
        tempo_contrib_anos=req.tempo_contribuicao_anos,
        media_salarios=req.media_salarios,
    )
    resultado = {k: v for k, v in vars(r).items()}
    await db.execute(text("""
        INSERT INTO calculos_realizados (id, tipo, subtipo, inputs, resultado)
        VALUES (:id, 'previdenciario', 'aposentadoria', :inp::jsonb, :res::jsonb)
    """), {"id": str(_uuid4()), "inp": _json.dumps(req.model_dump()), "res": _json.dumps(resultado)})
    await db.commit()
    return resultado

@router.post("/bpc-loas")
async def calc_bpc(req: BPCReq, db: AsyncSession = Depends(get_db)):
    """Verifica elegibilidade ao BPC/LOAS (Lei 8.742/1993)."""
    r = calcular_bpc_loas(**req.model_dump())
    resultado = {k: v for k, v in vars(r).items()}
    await db.execute(text("""
        INSERT INTO calculos_realizados (id, tipo, subtipo, inputs, resultado)
        VALUES (:id, 'previdenciario', 'bpc_loas', :inp::jsonb, :res::jsonb)
    """), {"id": str(_uuid4()), "inp": _json.dumps(req.model_dump()), "res": _json.dumps(resultado)})
    await db.commit()
    return resultado

# ── Cível / Consumidor ──────────────────────────────────────────────────────

class AtualizacaoReq(BM):
    valor_original: float
    data_origem: str        # YYYY-MM-DD
    data_calculo: Opt[str] = None
    indice: str = "IPCA-E"
    juros_ao_mes: float = 0.01

class DanosMoraisReq(BM):
    tipo_dano: str
    gravidade: str = "media"
    salario_minimos: int = 0

@router.post("/atualizacao-monetaria")
async def calc_atualizacao(req: AtualizacaoReq, db: AsyncSession = Depends(get_db)):
    """Atualização monetária IPCA-E + juros 1% a.m. (Súmula 54 STJ)."""
    data_o = date.fromisoformat(req.data_origem)
    data_c = date.fromisoformat(req.data_calculo) if req.data_calculo else None
    r = calcular_atualizacao_monetaria(req.valor_original, data_o, data_c, req.indice, req.juros_ao_mes)
    await db.execute(text("""
        INSERT INTO calculos_realizados (id, tipo, subtipo, inputs, resultado)
        VALUES (:id, 'civel', 'atualizacao_monetaria', :inp::jsonb, :res::jsonb)
    """), {"id": str(_uuid4()), "inp": _json.dumps(req.model_dump()), "res": _json.dumps(r)})
    await db.commit()
    return r

@router.post("/danos-morais")
async def calc_danos_morais(req: DanosMoraisReq, db: AsyncSession = Depends(get_db)):
    """Estima indenização por danos morais com base nos parâmetros do STJ."""
    r = calcular_danos_morais(req.tipo_dano, req.gravidade, req.salario_minimos)
    await db.execute(text("""
        INSERT INTO calculos_realizados (id, tipo, subtipo, inputs, resultado)
        VALUES (:id, 'civel', 'danos_morais', :inp::jsonb, :res::jsonb)
    """), {"id": str(_uuid4()), "inp": _json.dumps(req.model_dump()), "res": _json.dumps(r)})
    await db.commit()
    return r

# ── Família ─────────────────────────────────────────────────────────────────

class AlimentosReq(BM):
    renda_liq_devedor: float
    num_filhos: int
    despesas_basicas_filho: float = 0
    necessidade_alimentar: float = 0

class PensaoAtualizadaReq(BM):
    valor_original: float
    data_fixacao: str

@router.post("/alimentos")
async def calc_alimentos(req: AlimentosReq, db: AsyncSession = Depends(get_db)):
    """Calcula alimentos com base na capacidade × necessidade (Arts. 1694/1703 CC)."""
    r = calcular_alimentos(**req.model_dump())
    await db.execute(text("""
        INSERT INTO calculos_realizados (id, tipo, subtipo, inputs, resultado)
        VALUES (:id, 'familia', 'alimentos', :inp::jsonb, :res::jsonb)
    """), {"id": str(_uuid4()), "inp": _json.dumps(req.model_dump()), "res": _json.dumps(r)})
    await db.commit()
    return r

@router.post("/pensao-atualizada")
async def calc_pensao(req: PensaoAtualizadaReq, db: AsyncSession = Depends(get_db)):
    """Atualiza pensão alimentícia pelo INPC desde a data de fixação."""
    from datetime import date
    r = calcular_pensao_atualizada(req.valor_original, date.fromisoformat(req.data_fixacao))
    await db.execute(text("""
        INSERT INTO calculos_realizados (id, tipo, subtipo, inputs, resultado)
        VALUES (:id, 'familia', 'pensao_atualizada', :inp::jsonb, :res::jsonb)
    """), {"id": str(_uuid4()), "inp": _json.dumps(req.model_dump()), "res": _json.dumps(r)})
    await db.commit()
    return r

# ── CDC ─────────────────────────────────────────────────────────────────────

class DobroCDCReq(BM):
    valor_cobrado_indevido: float
    ja_pago: bool = True

class JurosAbusivosReq(BM):
    taxa_contratada_ao_mes: float
    taxa_mercado_bacen: float = 0.0
    valor_financiado: float = 0
    meses: int = 12

@router.post("/dobro-cdc")
async def calc_dobro_cdc(req: DobroCDCReq, db: AsyncSession = Depends(get_db)):
    """Calcula restituição em dobro por cobrança indevida (Art. 42 CDC)."""
    r = calcular_dobro_cdc(**req.model_dump())
    await db.execute(text("""
        INSERT INTO calculos_realizados (id, tipo, subtipo, inputs, resultado)
        VALUES (:id, 'cdc', 'dobro_indevido', :inp::jsonb, :res::jsonb)
    """), {"id": str(_uuid4()), "inp": _json.dumps(req.model_dump()), "res": _json.dumps(r)})
    await db.commit()
    return r

@router.post("/juros-abusivos")
async def calc_juros_abusivos(req: JurosAbusivosReq, db: AsyncSession = Depends(get_db)):
    """Analisa abusividade de juros bancários (STJ Súmula 382, 596)."""
    r = calcular_juros_abusivos(**req.model_dump())
    await db.execute(text("""
        INSERT INTO calculos_realizados (id, tipo, subtipo, inputs, resultado)
        VALUES (:id, 'cdc', 'juros_abusivos', :inp::jsonb, :res::jsonb)
    """), {"id": str(_uuid4()), "inp": _json.dumps(req.model_dump()), "res": _json.dumps(r)})
    await db.commit()
    return r

# ── Prescrição ───────────────────────────────────────────────────────────────

class PrescricaoReq(BM):
    tipo_acao: str
    data_marco_inicial: str   # YYYY-MM-DD

@router.post("/prescricao")
async def calc_prescricao(req: PrescricaoReq, db: AsyncSession = Depends(get_db)):
    """Calcula prazo prescricional, vencimento e situação (dentro/fora do prazo)."""
    from datetime import date
    r = calcular_prescricao(req.tipo_acao, date.fromisoformat(req.data_marco_inicial))
    await db.execute(text("""
        INSERT INTO calculos_realizados (id, tipo, subtipo, inputs, resultado)
        VALUES (:id, 'prescricao', :sub, :inp::jsonb, :res::jsonb)
    """), {"id": str(_uuid4()), "sub": req.tipo_acao, "inp": _json.dumps(req.model_dump()), "res": _json.dumps(r)})
    await db.commit()
    return r

@router.get("/prescricao/tipos")
async def listar_tipos_prescricao():
    """Lista todos os tipos de ação mapeados para cálculo de prescrição."""
    return {
        "tipos": {
            k: {
                "prazo": f"{v.get('prazo_anos','?')} anos" if v.get('prazo_anos') else f"{v.get('prazo_dias')} dias",
                "marco": v["marco_inicial"],
                "base_legal": v["base_legal"],
            }
            for k, v in PRAZOS_PRESCRICAO.items()
        }
    }
