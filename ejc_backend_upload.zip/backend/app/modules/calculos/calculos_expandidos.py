"""
EJC — Calculadoras Jurídicas Expandidas (calculos_expandidos.py)

Módulos:
  1. Previdenciário — aposentadoria, BPC/LOAS, tempo de contribuição, RMI
  2. Cível/Consumidor — atualização monetária IPCA-E, danos morais, juros
  3. Família — alimentos, pensão, partilha simplificada
  4. CDC — dobro indevido, juros abusivos, limitação contratual
  5. Prescrição — prazo por tipo de ação, marco inicial, data de vencimento

ATENÇÃO: Todos os cálculos são estimativas. Validar com profissional habilitado.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Optional
import math


# ═══════════════════════════════════════════════════════════
# 1. PREVIDENCIÁRIO
# ═══════════════════════════════════════════════════════════

# Constantes — importadas da fonte canônica (trabalhista/calculos.py)
try:
    from decimal import Decimal as _Dec
    from app.modules.trabalhista.calculos import SALARIO_MINIMO_2025 as _SM
    SM_2025 = float(_SM)
except ImportError:
    SM_2025 = 1518.00   # fallback se importação circular

TETO_INSS_2025 = 8157.41   # Teto do RGPS 2025


@dataclass
class ResultadoPrevidenciario:
    tipo: str
    elegivel: bool
    valor_beneficio_estimado: float = 0.0
    tempo_contribuicao_anos: float = 0.0
    fator_previdenciario: Optional[float] = None
    regra_aplicavel: str = ""
    observacoes: list = field(default_factory=list)
    pendencias: list = field(default_factory=list)
    base_legal: str = ""


def calcular_tempo_contribuicao(data_admissao: date, data_demissao: Optional[date] = None) -> float:
    """Retorna anos de contribuição (aproximado)."""
    fim = data_demissao or date.today()
    delta = fim - data_admissao
    return delta.days / 365.25


def calcular_fator_previdenciario(
    tempo_contrib: float, idade: int, expectativa_sobrevida: float = 20.0
) -> float:
    """Fórmula do fator previdenciário (Lei 9.876/99)."""
    aliq = 0.31
    es = expectativa_sobrevida
    Tc = tempo_contrib
    Id = idade
    return round((Tc * aliq / es) * (1 + ((Id + Tc * aliq) / 100)), 4)


def calcular_rmi(media_salarios: float, fator: float) -> float:
    """RMI = Média dos salários de contribuição × fator previdenciário."""
    rmi = media_salarios * fator
    return max(SM_2025, min(rmi, TETO_INSS_2025))


def verificar_aposentadoria(
    sexo: str,          # M | F
    idade: int,
    tempo_contrib_anos: float,
    media_salarios: float,
    data_filiacao: Optional[date] = None,
) -> ResultadoPrevidenciario:
    """
    Verifica elegibilidade e calcula benefício de aposentadoria.
    Considera as regras de transição (Emenda 103/2019).
    """
    r = ResultadoPrevidenciario(
        tipo="aposentadoria_por_idade",
        elegivel=False,
        base_legal="EC 103/2019; Lei 8.213/1991",
    )

    # Regra permanente (após 2023)
    idade_min = 65 if sexo.upper() == "M" else 62
    contrib_min = 20 if sexo.upper() == "M" else 15

    if idade >= idade_min and tempo_contrib_anos >= contrib_min:
        r.elegivel = True
        r.tipo = "aposentadoria_por_idade"
        r.regra_aplicavel = f"Regra permanente EC 103/2019 — {idade_min} anos + {contrib_min} anos contribuição"

        # RMI = 60% + 2% por ano acima do mínimo
        anos_excedentes = max(0, tempo_contrib_anos - contrib_min)
        percentual = min(1.0, 0.60 + 0.02 * anos_excedentes)
        r.valor_beneficio_estimado = round(
            max(SM_2025, min(media_salarios * percentual, TETO_INSS_2025)), 2
        )
        r.tempo_contribuicao_anos = tempo_contrib_anos
        r.observacoes.append(f"Percentual de cálculo: {percentual:.0%} da média")
        r.observacoes.append(f"Para 100% do benefício são necessários {contrib_min + 20} anos de contribuição")

    # Aposentadoria por tempo (regras de transição)
    elif tempo_contrib_anos >= 35 and sexo.upper() == "M":
        r.elegivel = True
        r.tipo = "aposentadoria_por_tempo"
        r.regra_aplicavel = "Regra de transição — pedágio 50% ou progressiva"
        fator = calcular_fator_previdenciario(tempo_contrib_anos, idade)
        r.fator_previdenciario = fator
        r.valor_beneficio_estimado = round(calcular_rmi(media_salarios, fator), 2)
        r.observacoes.append(f"Fator previdenciário: {fator:.4f}")
        r.observacoes.append("Verificar regra mais vantajosa: pedágio 50%, pedágio 100% ou progressiva")

    elif tempo_contrib_anos >= 30 and sexo.upper() == "F":
        r.elegivel = True
        r.tipo = "aposentadoria_por_tempo"
        r.regra_aplicavel = "Regra de transição — pedágio 50% ou progressiva"
        fator = calcular_fator_previdenciario(tempo_contrib_anos, idade)
        r.fator_previdenciario = fator
        r.valor_beneficio_estimado = round(calcular_rmi(media_salarios, fator), 2)
        r.observacoes.append(f"Fator previdenciário: {fator:.4f}")

    else:
        falta_idade = max(0, idade_min - idade)
        falta_contrib = max(0, contrib_min - tempo_contrib_anos)
        if falta_idade > 0:
            r.pendencias.append(f"Faltam {falta_idade} ano(s) de idade")
        if falta_contrib > 0:
            r.pendencias.append(f"Faltam {falta_contrib:.1f} ano(s) de contribuição")
        r.observacoes.append("Não atingiu os requisitos mínimos para aposentadoria pelas regras atuais")

    r.observacoes.append("⚠ Cálculo estimado — obtenha o CNIS atualizado em meu.inss.gov.br para cálculo preciso")
    return r


def calcular_bpc_loas(
    renda_familiar_total: float,
    num_membros_familia: int,
    incapaz: bool = True,
    idade: int = 0,
) -> ResultadoPrevidenciario:
    """
    Verifica elegibilidade ao BPC/LOAS.
    Fundamento: Lei 8.742/1993; EC 119/2022.
    """
    r = ResultadoPrevidenciario(
        tipo="bpc_loas",
        elegivel=False,
        valor_beneficio_estimado=SM_2025,
        base_legal="Lei 8.742/1993 (LOAS); EC 119/2022",
    )

    renda_per_capita = renda_familiar_total / max(1, num_membros_familia)
    limite = SM_2025 / 4  # R$ 379,50 (25% do SM)

    elegivel_renda = renda_per_capita <= limite
    elegivel_condicao = incapaz or idade >= 65

    if elegivel_renda and elegivel_condicao:
        r.elegivel = True
        r.regra_aplicavel = "BPC/LOAS — renda per capita ≤ 1/4 SM + condição especial"
        r.observacoes.append(f"Renda per capita: R$ {renda_per_capita:.2f} (limite: R$ {limite:.2f})")
        r.observacoes.append("Valor: 1 salário mínimo (R$ 1.518,00 em 2025)")
        r.observacoes.append("Carência: zero — não exige contribuição prévia")
    else:
        if not elegivel_renda:
            r.pendencias.append(f"Renda per capita (R$ {renda_per_capita:.2f}) acima do limite (R$ {limite:.2f})")
        if not elegivel_condicao:
            r.pendencias.append("Não atende condição de deficiência/incapacidade ou idade mínima (65 anos)")

    r.observacoes.append("⚠ Critério de renda pode ser flexibilizado por decisão judicial — consulte advogado")
    return r


# ═══════════════════════════════════════════════════════════
# 2. CÍVEL / CONSUMIDOR — Atualização Monetária e Danos Morais
# ═══════════════════════════════════════════════════════════

# IPCA-E acumulado por ano (aproximado — para cálculo exato usar IBGE)
IPCA_E_ANUAL = {
    2019: 0.0371, 2020: 0.0416, 2021: 0.1062, 2022: 0.0797,
    2023: 0.0536, 2024: 0.0539, 2025: 0.0250,  # estimativa
}


def calcular_atualizacao_monetaria(
    valor_original: float,
    data_origem: date,
    data_calculo: Optional[date] = None,
    indice: str = "IPCA-E",
    juros_ao_mes: float = 0.01,
) -> dict:
    """
    Calcula atualização monetária + juros moratórios.
    Padrão STJ: IPCA-E + 1% a.m.
    Fundamento: Súmula 54 STJ; Art. 406 CC; Tema 905 STF.
    """
    data_fim = data_calculo or date.today()
    anos = (data_fim - data_origem).days / 365.25
    meses = (data_fim - data_origem).days / 30.44

    # Correção monetária acumulada
    correcao = 1.0
    ano_ini = data_origem.year
    ano_fim = data_fim.year
    for ano in range(ano_ini, ano_fim + 1):
        taxa = IPCA_E_ANUAL.get(ano, 0.04)
        if ano == ano_ini and ano == ano_fim:
            frac = (data_fim - data_origem).days / 365.0
            correcao *= (1 + taxa) ** frac
        elif ano == ano_ini:
            frac = (date(ano + 1, 1, 1) - data_origem).days / 365.0
            correcao *= (1 + taxa) ** frac
        elif ano == ano_fim:
            frac = (data_fim - date(ano, 1, 1)).days / 365.0
            correcao *= (1 + taxa) ** frac
        else:
            correcao *= (1 + taxa)

    valor_corrigido = valor_original * correcao

    # Juros moratórios simples (1% a.m.)
    juros = valor_corrigido * juros_ao_mes * meses

    total = valor_corrigido + juros

    return {
        "valor_original":   round(valor_original, 2),
        "valor_corrigido":  round(valor_corrigido, 2),
        "juros_moratorios": round(juros, 2),
        "total_atualizado": round(total, 2),
        "periodo_meses":    round(meses, 1),
        "correcao_aplicada": round((correcao - 1) * 100, 2),
        "indice_correcao":  indice,
        "taxa_juros":       f"{juros_ao_mes:.0%} a.m.",
        "data_origem":      data_origem.isoformat(),
        "data_calculo":     data_fim.isoformat(),
        "base_legal":       "Súmula 54 STJ; Art. 406 CC; Tema 905 STF",
        "observacao":       "Cálculo estimado com IPCA-E anual. Para valor judicial exato, utilizar IPCA-E mensal oficial do IBGE.",
    }


def calcular_danos_morais(
    tipo_dano: str,
    gravidade: str = "media",      # leve | media | grave | gravissima
    salario_minimos: int = 0,      # se 0, usa tabela padrão
) -> dict:
    """
    Estima indenização por danos morais com base em parâmetros do STJ.
    Fundamento: Art. 944 CC; STJ REsp 1.152.541.
    """
    # Tabela de referência STJ (em salários mínimos de 2025)
    PARAMETROS = {
        "inscricao_spc_serasa_indevida": {"leve": 3, "media": 8, "grave": 15, "gravissima": 30},
        "negativacao_indevida":          {"leve": 5, "media": 10, "grave": 20, "gravissima": 40},
        "cobranca_indevida":             {"leve": 2, "media": 5, "grave": 10, "gravissima": 20},
        "produto_com_defeito":           {"leve": 2, "media": 5, "grave": 10, "gravissima": 25},
        "servico_nao_prestado":          {"leve": 2, "media": 5, "grave": 8,  "gravissima": 20},
        "cancelamento_voo":              {"leve": 5, "media": 10, "grave": 20, "gravissima": 40},
        "fraude_cartao":                 {"leve": 3, "media": 8, "grave": 15, "gravissima": 30},
        "violacao_privacidade":          {"leve": 5, "media": 10, "grave": 25, "gravissima": 50},
        "demissao_discriminatoria":      {"leve": 10,"media": 20, "grave": 40, "gravissima": 80},
        "acidente_trabalho":             {"leve": 20,"media": 40, "grave": 80, "gravissima": 200},
        "outros":                        {"leve": 3, "media": 8, "grave": 15, "gravissima": 30},
    }

    tipo_key = tipo_dano.lower().replace(" ", "_")
    tabela = PARAMETROS.get(tipo_key, PARAMETROS["outros"])
    sms = salario_minimos or tabela[gravidade]
    valor = sms * SM_2025

    return {
        "tipo_dano": tipo_dano,
        "gravidade": gravidade,
        "salarios_minimos_referencia": sms,
        "valor_estimado": round(valor, 2),
        "valor_minimo": round(tabela["leve"] * SM_2025, 2),
        "valor_maximo": round(tabela["gravissima"] * SM_2025, 2),
        "base_legal": "Art. 944 CC; STJ REsp 1.152.541; Súmula 326 STJ",
        "observacao": (
            "Valor estimado com base em parâmetros do STJ. O juiz fixará livremente "
            "conforme as circunstâncias do caso, extensão do dano e capacidade econômica das partes. "
            "Dano moral é presumido (in re ipsa) nos casos de negativação indevida e cobrança abusiva."
        ),
    }


# ═══════════════════════════════════════════════════════════
# 3. FAMÍLIA — Alimentos, Pensão, Partilha
# ═══════════════════════════════════════════════════════════

def calcular_alimentos(
    renda_liq_devedor: float,
    num_filhos: int,
    despesas_basicas_filho: float = 0,
    necessidade_alimentar: float = 0,
) -> dict:
    """
    Calcula alimentos com base na capacidade × necessidade.
    Fundamento: Art. 1.694 CC; Art. 1.703 CC.
    """
    # Parâmetros comuns do TJSP/STJ
    percentuais_pratica = {
        1: 0.30, 2: 0.40, 3: 0.50, 4: 0.55, 5: 0.60,
    }
    perc = percentuais_pratica.get(min(num_filhos, 5), 0.60)
    valor_percentual = renda_liq_devedor * perc

    # Necessidade do filho (se informada)
    if necessidade_alimentar > 0:
        valor_necessidade = necessidade_alimentar
    elif despesas_basicas_filho > 0:
        valor_necessidade = despesas_basicas_filho * 1.3  # estimativa com margem
    else:
        valor_necessidade = SM_2025 * 0.8 * num_filhos  # estimativa mínima digna

    # Valor sugerido: menor entre capacidade e necessidade
    valor_sugerido = min(valor_percentual, valor_necessidade)
    valor_minimo = SM_2025 * num_filhos * 0.30  # piso prático

    return {
        "renda_liquida_devedor": round(renda_liq_devedor, 2),
        "num_filhos": num_filhos,
        "percentual_pratica": f"{perc:.0%}",
        "valor_pelo_percentual": round(valor_percentual, 2),
        "valor_pela_necessidade": round(valor_necessidade, 2),
        "valor_sugerido": round(max(valor_minimo, valor_sugerido), 2),
        "valor_por_filho": round(max(valor_minimo, valor_sugerido) / num_filhos, 2),
        "base_legal": "Arts. 1.694, 1.695 e 1.703 CC; Súmula 277 STJ",
        "observacao": (
            "Valor estimado com base na capacidade × necessidade × binômio alimentar. "
            "O juiz fixará conforme prova nos autos. Percentuais variam por tribunal."
        ),
    }


def calcular_pensao_atualizada(
    valor_original: float,
    data_fixacao: date,
    indice: str = "INPC",
) -> dict:
    """Atualiza pensão alimentícia pelo INPC desde a data de fixação."""
    # INPC acumulado por ano (aproximado)
    INPC_ANUAL = {
        2019: 0.0477, 2020: 0.0548, 2021: 0.1016, 2022: 0.0803,
        2023: 0.0556, 2024: 0.0546, 2025: 0.0280,
    }
    anos_meses = (date.today() - data_fixacao).days / 30.44
    correcao = 1.0
    for ano in range(data_fixacao.year, date.today().year + 1):
        taxa = INPC_ANUAL.get(ano, 0.05)
        if ano == data_fixacao.year:
            frac = (date(ano + 1, 1, 1) - data_fixacao).days / 365.0
            correcao *= (1 + taxa) ** frac
        elif ano == date.today().year:
            frac = (date.today() - date(ano, 1, 1)).days / 365.0
            correcao *= (1 + taxa) ** frac
        else:
            correcao *= (1 + taxa)

    valor_atual = valor_original * correcao
    return {
        "valor_original": round(valor_original, 2),
        "valor_atualizado": round(valor_atual, 2),
        "variacao_percentual": round((correcao - 1) * 100, 2),
        "periodo_meses": round(anos_meses, 1),
        "indice": indice,
        "data_fixacao": data_fixacao.isoformat(),
        "base_legal": "Art. 1.710 CC; Art. 13 Lei 5.478/68",
    }


# ═══════════════════════════════════════════════════════════
# 4. CDC — Dobro Indevido, Juros Abusivos
# ═══════════════════════════════════════════════════════════

def calcular_dobro_cdc(
    valor_cobrado_indevido: float,
    ja_pago: bool = True,
) -> dict:
    """
    Calcula restituição em dobro por cobrança indevida (Art. 42 CDC).
    Fundamento: STJ Súmula 388; REsp 1.413.425 (Tema 929).
    """
    if not ja_pago:
        return {
            "aplicavel": False,
            "motivo": "A restituição em dobro (Art. 42 CDC) exige que o valor tenha sido efetivamente pago",
            "alternativa": "Exigir cancelamento + indenização por dano moral (Art. 940 CC não exige pagamento prévio)",
            "base_legal": "Art. 42 parágrafo único CDC; STJ Súmula 388",
        }

    valor_dobro = valor_cobrado_indevido * 2
    return {
        "aplicavel": True,
        "valor_cobrado": round(valor_cobrado_indevido, 2),
        "restituicao_em_dobro": round(valor_dobro, 2),
        "acrescimo": round(valor_cobrado_indevido, 2),
        "excecao": "O fornecedor afasta o dobro provando engano justificável",
        "base_legal": "Art. 42, parágrafo único, CDC; STJ Súmula 388; Tema 929",
        "prescricao": "5 anos (Art. 27 CDC) a contar da cobrança indevida",
        "observacao": "Pode ser cumulada com dano moral se houver lesão extrapatrimonial",
    }


def calcular_juros_abusivos(
    taxa_contratada_ao_mes: float,
    taxa_mercado_bacen: float = 0.0,
    valor_financiado: float = 0,
    meses: int = 12,
) -> dict:
    """
    Analisa abusividade de juros em contratos bancários.
    Fundamento: STJ Súmula 382, 596; Tema 27.
    """
    # Taxa média do BACEN (estimada — ideal buscar da API BACEN)
    taxa_ref = taxa_mercado_bacen or 0.025  # 2,5% a.m. (referência crédito pessoal)

    diferenca = taxa_contratada_ao_mes - taxa_ref
    percentual_acima = (diferenca / taxa_ref * 100) if taxa_ref > 0 else 0

    # STJ: não fixa limite, mas considera abusivo quando muito acima da média
    potencialmente_abusivo = percentual_acima > 50  # >50% acima da média do mercado

    # Calcula diferença de custo
    custo_contratado = valor_financiado * ((1 + taxa_contratada_ao_mes)**meses - 1)
    custo_mercado = valor_financiado * ((1 + taxa_ref)**meses - 1)
    excesso = custo_contratado - custo_mercado

    return {
        "taxa_contratada_ao_mes": f"{taxa_contratada_ao_mes:.2%}",
        "taxa_contratada_ao_ano": f"{(1+taxa_contratada_ao_mes)**12-1:.2%}",
        "taxa_referencia_mercado": f"{taxa_ref:.2%}",
        "percentual_acima_mercado": f"{percentual_acima:.1f}%",
        "potencialmente_abusivo": potencialmente_abusivo,
        "custo_total_contratado": round(custo_contratado, 2),
        "custo_referencia_mercado": round(custo_mercado, 2),
        "excesso_estimado": round(excesso, 2),
        "base_legal": "STJ Súmula 382, 530, 596; Tema 27; Art. 52 CDC",
        "observacao": (
            "O STJ NÃO fixa limite absoluto de juros bancários, mas admite revisão "
            "quando há abusividade manifesta comparada à taxa média do mercado (BACEN). "
            "Necessário laudo técnico com a taxa média BACEN vigente na data do contrato."
        ),
    }


# ═══════════════════════════════════════════════════════════
# 5. PRESCRIÇÃO — Prazo por tipo de ação
# ═══════════════════════════════════════════════════════════

PRAZOS_PRESCRICAO = {
    # Trabalhista
    "trabalhista_verbas": {
        "prazo_anos": 2, "prazo_retroativo_anos": 5,
        "marco_inicial": "Data da extinção do contrato de trabalho",
        "base_legal": "Art. 7º, XXIX, CF/88; Art. 11 CLT",
        "obs": "2 anos para propor a ação + retroage 5 anos antes do ajuizamento"
    },
    "fgts": {
        "prazo_anos": 30, "prazo_retroativo_anos": None,
        "marco_inicial": "Data do depósito (ou deveria ter sido depositado)",
        "base_legal": "Art. 23, §5º, Lei 8.036/90; Súmula 362 TST",
        "obs": "Prazo de 30 anos para o FGTS (Súmula 362 TST) — atenção: 2 anos para a ação"
    },
    # Consumidor
    "cdc_vicio_produto_nao_duravel": {
        "prazo_anos": None, "prazo_dias": 30,
        "marco_inicial": "Aparecimento do vício",
        "base_legal": "Art. 26, I, CDC",
        "obs": "Prazo decadencial (extingue o direito)"
    },
    "cdc_vicio_produto_duravel": {
        "prazo_anos": None, "prazo_dias": 90,
        "marco_inicial": "Aparecimento do vício",
        "base_legal": "Art. 26, II, CDC",
        "obs": "Prazo decadencial (extingue o direito)"
    },
    "cdc_fato_produto": {
        "prazo_anos": 5,
        "marco_inicial": "Conhecimento do dano e da autoria",
        "base_legal": "Art. 27, CDC",
        "obs": "Prazo prescricional para responsabilidade pelo fato do produto/serviço"
    },
    "cdc_cobranca_indevida": {
        "prazo_anos": 5,
        "marco_inicial": "Data da cobrança indevida",
        "base_legal": "Art. 27 CDC; STJ Tema 929",
        "obs": "Prazo de 5 anos para restituição em dobro"
    },
    # Civil
    "indenizacao_civil": {
        "prazo_anos": 3,
        "marco_inicial": "Data do ato ou do conhecimento do dano",
        "base_legal": "Art. 206, §3º, V, CC",
        "obs": "Reparação civil em geral"
    },
    "contrato_geral": {
        "prazo_anos": 10,
        "marco_inicial": "Data do inadimplemento",
        "base_legal": "Art. 205, CC (regra geral)",
        "obs": "Prazo geral quando não houver prazo especial"
    },
    "divida_titulo_judicial": {
        "prazo_anos": 10,
        "marco_inicial": "Trânsito em julgado",
        "base_legal": "Art. 206, §5º, I, CC",
        "obs": "Execução de título judicial"
    },
    # Previdenciário
    "inss_beneficio_negado": {
        "prazo_anos": 5,
        "marco_inicial": "Data do indeferimento administrativo",
        "base_legal": "Art. 103, Lei 8.213/91",
        "obs": "Prescrição quinquenal — contar do indeferimento ou cessação"
    },
    "bpc_loas": {
        "prazo_anos": 5,
        "marco_inicial": "Data do indeferimento ou requerimento",
        "base_legal": "Art. 103, Lei 8.213/91; Art. 20 LOAS",
        "obs": "Retroatividade de 5 anos da propositura da ação"
    },
    # Família
    "alimentos_atrasados": {
        "prazo_anos": 2,
        "marco_inicial": "Vencimento de cada parcela",
        "base_legal": "Art. 206, §2º, CC",
        "obs": "Prazo de 2 anos para cobrar parcelas vencidas"
    },
}


def calcular_prescricao(
    tipo_acao: str,
    data_marco_inicial: date,
) -> dict:
    """
    Calcula prazo prescricional, data de vencimento e situação atual.
    """
    info = PRAZOS_PRESCRICAO.get(tipo_acao)
    if not info:
        tipos_disponiveis = list(PRAZOS_PRESCRICAO.keys())
        return {
            "erro": f"Tipo de ação '{tipo_acao}' não mapeado",
            "tipos_disponiveis": tipos_disponiveis,
        }

    hoje = date.today()
    prazo_dias = info.get("prazo_dias")
    prazo_anos = info.get("prazo_anos")

    if prazo_dias:
        data_vencimento = data_marco_inicial + timedelta(days=prazo_dias)
        prazo_str = f"{prazo_dias} dias"
    elif prazo_anos:
        try:
            data_vencimento = data_marco_inicial.replace(year=data_marco_inicial.year + prazo_anos)
        except ValueError:
            data_vencimento = data_marco_inicial + timedelta(days=prazo_anos * 365)
        prazo_str = f"{prazo_anos} anos"
    else:
        return {"erro": "Prazo não mapeado para este tipo"}

    dias_restantes = (data_vencimento - hoje).days
    prescrito = dias_restantes < 0
    urgente = 0 <= dias_restantes <= 90

    return {
        "tipo_acao": tipo_acao,
        "prazo": prazo_str,
        "marco_inicial": info["marco_inicial"],
        "data_marco_informada": data_marco_inicial.isoformat(),
        "data_vencimento": data_vencimento.isoformat(),
        "dias_restantes": dias_restantes,
        "situacao": "PRESCRITO" if prescrito else ("⚠ URGENTE" if urgente else "dentro do prazo"),
        "prescrito": prescrito,
        "urgente": urgente,
        "prazo_retroativo_anos": info.get("prazo_retroativo_anos"),
        "base_legal": info["base_legal"],
        "observacao": info.get("obs", ""),
        "aviso": (
            "⚠ PRAZO PRESCRITO — direito possivelmente extinto. Consultar advogado imediatamente."
            if prescrito else
            ("⚠ PRAZO VENCENDO — consulte advogado com urgência." if urgente else "")
        ),
    }
