"""
EJC — Módulo Cálculos: FGTS Revisional (modules/calculos/fgts.py)

Fundamento legal:
  - Lei 8.036/1990 (Lei do FGTS)
  - Art. 15: depósito mensal de 8% sobre a remuneração
  - Art. 18: multa rescisória de 40% sobre o saldo
  - Circular CAIXA 541/2000 e atualizações TR

Lógica:
  1. Para cada competência, calcula o FGTS devido = salário_bruto × aliquota
  2. Aplica a TR acumulada para atualização monetária
  3. Apura diferença entre o devido e o depositado
  4. Calcula multa rescisória de 40% sobre as diferenças
"""
from __future__ import annotations

import logging
from decimal import Decimal, ROUND_HALF_UP, getcontext
from datetime import date, datetime
from typing import Optional

logger = logging.getLogger(__name__)

# Precisão máxima para cálculos financeiros
getcontext().prec = 28

# TR histórica mensal estimada (simplificada — em produção use tabela Caixa oficial)
# Chave: "YYYY-MM" → taxa decimal mensal
TR_TABLE: dict[str, Decimal] = {
    "2020-01": Decimal("0.00000"), "2020-02": Decimal("0.00000"),
    "2020-03": Decimal("0.00000"), "2020-04": Decimal("0.00000"),
    "2020-05": Decimal("0.00000"), "2020-06": Decimal("0.00000"),
    "2020-07": Decimal("0.00000"), "2020-08": Decimal("0.00000"),
    "2020-09": Decimal("0.00000"), "2020-10": Decimal("0.00000"),
    "2020-11": Decimal("0.00000"), "2020-12": Decimal("0.00000"),
    "2021-01": Decimal("0.00000"), "2021-02": Decimal("0.00000"),
    "2021-03": Decimal("0.00000"), "2021-04": Decimal("0.00000"),
    "2021-05": Decimal("0.00000"), "2021-06": Decimal("0.00000"),
    "2021-07": Decimal("0.00000"), "2021-08": Decimal("0.00000"),
    "2021-09": Decimal("0.00000"), "2021-10": Decimal("0.00000"),
    "2021-11": Decimal("0.00000"), "2021-12": Decimal("0.00000"),
    "2022-01": Decimal("0.00000"), "2022-02": Decimal("0.00000"),
    "2022-03": Decimal("0.00053"), "2022-04": Decimal("0.00078"),
    "2022-05": Decimal("0.00079"), "2022-06": Decimal("0.00083"),
    "2022-07": Decimal("0.00091"), "2022-08": Decimal("0.00096"),
    "2022-09": Decimal("0.00075"), "2022-10": Decimal("0.00062"),
    "2022-11": Decimal("0.00047"), "2022-12": Decimal("0.00057"),
    "2023-01": Decimal("0.00047"), "2023-02": Decimal("0.00058"),
    "2023-03": Decimal("0.00069"), "2023-04": Decimal("0.00079"),
    "2023-05": Decimal("0.00068"), "2023-06": Decimal("0.00057"),
    "2023-07": Decimal("0.00065"), "2023-08": Decimal("0.00072"),
    "2023-09": Decimal("0.00071"), "2023-10": Decimal("0.00065"),
    "2023-11": Decimal("0.00062"), "2023-12": Decimal("0.00078"),
    "2024-01": Decimal("0.00086"), "2024-02": Decimal("0.00074"),
    "2024-03": Decimal("0.00081"), "2024-04": Decimal("0.00079"),
    "2024-05": Decimal("0.00083"), "2024-06": Decimal("0.00085"),
    "2024-07": Decimal("0.00088"), "2024-08": Decimal("0.00091"),
    "2024-09": Decimal("0.00079"), "2024-10": Decimal("0.00076"),
    "2024-11": Decimal("0.00082"), "2024-12": Decimal("0.00089"),
    # 2025 — estimativa conservadora; atualizar com tabela CAIXA oficial
    "2025-01": Decimal("0.00093"), "2025-02": Decimal("0.00087"),
    "2025-03": Decimal("0.00085"), "2025-04": Decimal("0.00082"),
    "2025-05": Decimal("0.00079"), "2025-06": Decimal("0.00077"),
    "2025-07": Decimal("0.00075"), "2025-08": Decimal("0.00074"),
    "2025-09": Decimal("0.00073"), "2025-10": Decimal("0.00072"),
    "2025-11": Decimal("0.00071"), "2025-12": Decimal("0.00070"),
}

CENTAVOS = Decimal("0.01")
BRL = lambda v: f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def calcular_fgts_revisional(
    nome_empregado: str,
    data_admissao: str,
    data_demissao: str,
    salarios: list[dict],  # [{"competencia": "YYYY-MM", "salario_bruto": 3500.0, "depositado": 280.0}]
    percentual_fgts: float = 8.0,
    taxa_tr_mensal: Optional[float] = None,
) -> dict:
    """
    Calcula o FGTS revisional com atualização pela TR.

    Args:
        nome_empregado: Nome completo do empregado
        data_admissao: Data de admissão (YYYY-MM-DD)
        data_demissao: Data de demissão (YYYY-MM-DD)
        salarios: Lista de competências com salário bruto e valor depositado
        percentual_fgts: Alíquota FGTS (padrão 8%, exceto aprendizes: 2%)
        taxa_tr_mensal: TR fixa se informada; None = usa tabela histórica

    Returns:
        Dicionário completo com detalhamento e totais
    """
    aliquota = Decimal(str(percentual_fgts)) / Decimal("100")
    data_dem = datetime.strptime(data_demissao, "%Y-%m-%d").date()

    detalhamento = []
    total_devido = Decimal("0")
    total_depositado = Decimal("0")
    total_diferenca = Decimal("0")

    for item in salarios:
        competencia = item["competencia"]  # "YYYY-MM"
        salario = Decimal(str(item["salario_bruto"])).quantize(CENTAVOS, ROUND_HALF_UP)
        depositado = Decimal(str(item.get("depositado", 0))).quantize(CENTAVOS, ROUND_HALF_UP)

        # FGTS bruto devido
        fgts_devido = (salario * aliquota).quantize(CENTAVOS, ROUND_HALF_UP)

        # Diferença bruta
        diferenca_bruta = (fgts_devido - depositado).quantize(CENTAVOS, ROUND_HALF_UP)

        # Correção pela TR até a data da demissão
        tr_acumulada = _calcular_tr_acumulada(competencia, data_demissao, taxa_tr_mensal)
        diferenca_corrigida = (diferenca_bruta * (Decimal("1") + tr_acumulada)).quantize(CENTAVOS, ROUND_HALF_UP)

        total_devido += fgts_devido
        total_depositado += depositado
        total_diferenca += diferenca_corrigida

        detalhamento.append({
            "competencia": competencia,
            "salario_bruto": BRL(salario),
            "fgts_devido": BRL(fgts_devido),
            "fgts_depositado": BRL(depositado),
            "diferenca_bruta": BRL(diferenca_bruta),
            "tr_acumulada_pct": f"{float(tr_acumulada * 100):.4f}%",
            "diferenca_corrigida": BRL(diferenca_corrigida),
        })

    # Multa rescisória 40% (art. 18, Lei 8.036/90)
    multa_40 = (total_diferenca * Decimal("0.40")).quantize(CENTAVOS, ROUND_HALF_UP)
    total_geral = (total_diferenca + multa_40).quantize(CENTAVOS, ROUND_HALF_UP)

    metodologia = (
        f"Cálculo conforme Lei 8.036/1990 e Circular CAIXA 541/2000. "
        f"Alíquota aplicada: {percentual_fgts}%. "
        f"Período: {data_admissao} a {data_demissao}. "
        f"Atualização monetária: TR mensal acumulada por competência. "
        f"Multa rescisória: 40% sobre diferenças corrigidas (art. 18, §1º, Lei 8.036/90)."
    )

    return {
        "nome_empregado": nome_empregado,
        "total_fgts_devido": BRL(total_devido),
        "total_depositado": BRL(total_depositado),
        "diferenca": BRL(total_diferenca),
        "multa_40_percent": BRL(multa_40),
        "total_a_receber": BRL(total_geral),
        "detalhamento": detalhamento,
        "metodologia": metodologia,
    }


def _calcular_tr_acumulada(
    competencia_inicio: str,
    data_fim: str,
    taxa_fixa: Optional[float] = None,
) -> Decimal:
    """
    Calcula TR acumulada da competência até a data_fim.
    Se taxa_fixa informada, usa composto simples mensal.
    """
    if taxa_fixa is not None:
        # Estima meses entre competência e data_fim
        ini = datetime.strptime(competencia_inicio + "-01", "%Y-%m-%d").date()
        fim = datetime.strptime(data_fim, "%Y-%m-%d").date()
        meses = max(0, (fim.year - ini.year) * 12 + (fim.month - ini.month))
        tr_mensal = Decimal(str(taxa_fixa))
        return ((Decimal("1") + tr_mensal) ** meses - Decimal("1")).quantize(
            Decimal("0.00000001"), ROUND_HALF_UP
        )

    # Usa tabela histórica acumulando competência a competência
    ini = datetime.strptime(competencia_inicio + "-01", "%Y-%m-%d").date()
    fim = datetime.strptime(data_fim, "%Y-%m-%d").date()

    fator = Decimal("1")
    current = ini
    while current <= fim:
        key = current.strftime("%Y-%m")
        tr = TR_TABLE.get(key, Decimal("0"))
        fator *= (Decimal("1") + tr)
        # avança um mês
        if current.month == 12:
            current = current.replace(year=current.year + 1, month=1)
        else:
            current = current.replace(month=current.month + 1)

    return (fator - Decimal("1")).quantize(Decimal("0.00000001"), ROUND_HALF_UP)
