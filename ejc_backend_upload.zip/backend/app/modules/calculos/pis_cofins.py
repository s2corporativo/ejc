"""
EJC — Módulo Cálculos: PIS/COFINS Monofásico (modules/calculos/pis_cofins.py)

Fundamento legal:
  - Lei 10.637/2002 (PIS não-cumulativo)
  - Lei 10.833/2003 (COFINS não-cumulativo)
  - Lei 10.147/2000 (monofásico — produtos da cadeia farmacêutica/higiene)
  - MP 2.158-35/2001 e Instrução Normativa RFB 2.121/2022

Regime Monofásico:
  A indústria/importadora paga alíquota concentrada (PIS 2,1% / COFINS 9,9%
  para medicamentos, ou 2,2% / 10,3% para higiene — Lei 10.147/2000, art. 1º).
  Os atacadistas e varejistas pagam alíquota ZERO sobre essas receitas.

Cálculo simplificado para revenda (alíquota zero na monofásica):
  Base de cálculo = receita total - receita monofásica
  PIS = base × alíquota_pis
  COFINS = base × alíquota_cofins
"""
from __future__ import annotations

import logging
from decimal import Decimal, ROUND_HALF_UP, getcontext

logger = logging.getLogger(__name__)
getcontext().prec = 28

CENTAVOS = Decimal("0.01")
BRL = lambda v: f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

# Alíquotas do regime monofásico (Lei 10.147/2000)
ALIQUOTAS_MONOFASICO = {
    "medicamentos": {"pis": Decimal("0.021"), "cofins": Decimal("0.099")},
    "higiene_cosmeticos": {"pis": Decimal("0.022"), "cofins": Decimal("0.103")},
    "automoveis": {"pis": Decimal("0.02"), "cofins": Decimal("0.09")},
    "combustiveis": {"pis": Decimal("0.0"),  "cofins": Decimal("0.0")},   # específico/advalorem
}

# Alíquotas padrão cumulativo (Lei 9.718/1998)
ALIQUOTAS_CUMULATIVO = {
    "pis": Decimal("0.0065"),
    "cofins": Decimal("0.03"),
}

# Alíquotas não-cumulativo (Leis 10.637/02 e 10.833/03)
ALIQUOTAS_NAO_CUMULATIVO = {
    "pis": Decimal("0.0165"),
    "cofins": Decimal("0.076"),
}


def calcular_pis_cofins_monofasico(
    cnpj_fornecedor: str,
    periodo_apuracao: str,           # "YYYY-MM"
    regime_tributario: str,          # "lucro_real" | "lucro_presumido" | "simples"
    receita_bruta: float,
    receita_monofasica: float,
    aliquota_pis: float = 0.65,
    aliquota_cofins: float = 3.0,
    produto_monofasico: str = "medicamentos",
) -> dict:
    """
    Apura PIS e COFINS diferenciando receita sujeita ao regime monofásico.

    No regime monofásico (revendedores):
      - Receita monofásica → alíquota ZERO (substituição tributária na indústria)
      - Receita demais → alíquota normal do regime

    Returns:
        Dicionário completo com cálculo detalhado e fundamentação legal
    """
    rb = Decimal(str(receita_bruta)).quantize(CENTAVOS, ROUND_HALF_UP)
    rm = Decimal(str(receita_monofasica)).quantize(CENTAVOS, ROUND_HALF_UP)

    if rm > rb:
        raise ValueError("Receita monofásica não pode ser maior que receita bruta total.")

    # Base de cálculo normal (não-monofásica)
    base_normal = (rb - rm).quantize(CENTAVOS, ROUND_HALF_UP)

    # Determina alíquotas conforme regime
    if regime_tributario == "simples":
        # Simples Nacional: PIS/COFINS já embutidos no DAS — não há apuração separada
        return {
            "cnpj_fornecedor": cnpj_fornecedor,
            "periodo_apuracao": periodo_apuracao,
            "pis_calculado": "R$ 0,00",
            "cofins_calculado": "R$ 0,00",
            "total_tributos": "R$ 0,00",
            "base_calculo_monofasica": BRL(rm),
            "creditos_aproveitados": "R$ 0,00",
            "detalhamento": {
                "regime": "Simples Nacional",
                "observacao": "PIS/COFINS recolhidos via DAS — não há apuração separada (LC 123/2006).",
            },
            "fundamentacao_legal": ["Lei Complementar 123/2006, art. 13"],
        }

    # Alíquotas conforme regime
    if regime_tributario == "lucro_real":
        aliq_pis = Decimal(str(aliquota_pis / 100)) if aliquota_pis != 0.65 \
            else ALIQUOTAS_NAO_CUMULATIVO["pis"]
        aliq_cofins = Decimal(str(aliquota_cofins / 100)) if aliquota_cofins != 3.0 \
            else ALIQUOTAS_NAO_CUMULATIVO["cofins"]
        regime_nome = "Lucro Real (não-cumulativo)"
        fundamento = ["Lei 10.637/2002 (PIS não-cumulativo)", "Lei 10.833/2003 (COFINS não-cumulativo)"]
    else:
        aliq_pis = Decimal(str(aliquota_pis / 100)) if aliquota_pis != 0.65 \
            else ALIQUOTAS_CUMULATIVO["pis"]
        aliq_cofins = Decimal(str(aliquota_cofins / 100)) if aliquota_cofins != 3.0 \
            else ALIQUOTAS_CUMULATIVO["cofins"]
        regime_nome = "Lucro Presumido (cumulativo)"
        fundamento = ["Lei 9.718/1998, art. 2º e 3º"]

    # Apuração
    pis = (base_normal * aliq_pis).quantize(CENTAVOS, ROUND_HALF_UP)
    cofins = (base_normal * aliq_cofins).quantize(CENTAVOS, ROUND_HALF_UP)
    total = (pis + cofins).quantize(CENTAVOS, ROUND_HALF_UP)

    # Créditos (apenas lucro real — art. 3º Lei 10.637/02 e art. 3º Lei 10.833/03)
    creditos = Decimal("0")
    if regime_tributario == "lucro_real":
        # Crédito sobre receita monofásica: contribuinte pode apropriar crédito da aquisição
        # (simplificação — em produção, cruzar com NFs de entrada)
        aliq_mono = ALIQUOTAS_MONOFASICO.get(produto_monofasico, {"pis": Decimal("0"), "cofins": Decimal("0")})
        credito_pis = (rm * aliq_mono["pis"]).quantize(CENTAVOS, ROUND_HALF_UP)
        credito_cofins = (rm * aliq_mono["cofins"]).quantize(CENTAVOS, ROUND_HALF_UP)
        creditos = (credito_pis + credito_cofins).quantize(CENTAVOS, ROUND_HALF_UP)
        fundamento += ["Lei 10.147/2000, art. 2º §3º (crédito monofásico)"]

    fundamento += [
        "Lei 10.147/2000 (regime monofásico — medicamentos e higiene)",
        "IN RFB 2.121/2022",
    ]

    return {
        "cnpj_fornecedor": cnpj_fornecedor,
        "periodo_apuracao": periodo_apuracao,
        "pis_calculado": BRL(pis),
        "cofins_calculado": BRL(cofins),
        "total_tributos": BRL(total),
        "base_calculo_monofasica": BRL(rm),
        "creditos_aproveitados": BRL(creditos),
        "detalhamento": {
            "regime": regime_nome,
            "receita_bruta_total": BRL(rb),
            "receita_monofasica": BRL(rm),
            "base_calculo_normal": BRL(base_normal),
            "aliquota_pis_aplicada": f"{float(aliq_pis * 100):.2f}%",
            "aliquota_cofins_aplicada": f"{float(aliq_cofins * 100):.2f}%",
            "produto_monofasico": produto_monofasico,
            "pis_bruto": BRL(pis),
            "cofins_bruto": BRL(cofins),
            "creditos_monofasicos": BRL(creditos),
            "pis_liquido": BRL(max(pis - creditos, Decimal("0"))),
            "cofins_liquido": BRL(cofins),
        },
        "fundamentacao_legal": fundamento,
    }
