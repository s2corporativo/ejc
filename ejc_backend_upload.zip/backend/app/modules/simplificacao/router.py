"""
EJC — Módulo Simplificação (wrapper do módulo Analise)
Alias para /analise/simplificar — mantido para compatibilidade com especificação.
"""
from app.modules.analise.router import router as _analise_router
from fastapi import APIRouter

router = APIRouter(prefix="/simplificacao", tags=["Simplificação Jurídica"])

# Reexporta os endpoints de simplificação do módulo analise
# Endpoints canônicos: POST /analise/simplificar e POST /analise/simplificar-texto
