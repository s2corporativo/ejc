"""
EJC — Módulo Whisper (modules/whisper/router.py)

Transcrição de áudio via OpenAI Whisper local (sem API externa).
Modelo recomendado: whisper-large-v3 (melhor PT-BR).
Modelo leve: whisper-base (rápido, menor qualidade).

Casos de uso:
  - Transcrever audiências gravadas
  - Ditar petições por voz
  - Extrair depoimentos de gravações
  - Transcrever laudos médicos ditados

Instalação: pip install openai-whisper
GPU acelera ~10x (CUDA opcional).
"""
from __future__ import annotations

import io
import logging
import tempfile
import os
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.rag.knowledge_base import LegalKnowledgeBase

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/whisper", tags=["Whisper — Transcrição de Áudio"])

_model = None  # lazy load — modelo é pesado (~1.5GB para large-v3)
_model_name = "base"

_kb_inst: Optional[LegalKnowledgeBase] = None

def get_kb():
    global _kb_inst
    if not _kb_inst:
        _kb_inst = LegalKnowledgeBase()
    return _kb_inst


def _get_whisper_model(nome: str = "base"):
    global _model, _model_name
    if _model is None or _model_name != nome:
        try:
            import whisper
            logger.info(f"[Whisper] Carregando modelo '{nome}'...")
            _model = whisper.load_model(nome)
            _model_name = nome
            logger.info(f"[Whisper] Modelo '{nome}' carregado.")
        except ImportError:
            raise RuntimeError(
                "Whisper não instalado. Execute: pip install openai-whisper\n"
                "Para suporte a GPU: pip install openai-whisper torch torchvision torchaudio"
            )
    return _model


def _transcrever(audio_bytes: bytes, ext: str, modelo: str = "base", lang: str = "pt") -> dict:
    """Transcreve áudio usando Whisper local."""
    model = _get_whisper_model(modelo)

    with tempfile.NamedTemporaryFile(suffix=f".{ext}", delete=False) as tmp:
        tmp.write(audio_bytes)
        tmp_path = tmp.name

    try:
        result = model.transcribe(
            tmp_path,
            language=lang,
            task="transcribe",
            verbose=False,
            fp16=False,  # compatível com CPU
        )
        return {
            "texto": result["text"].strip(),
            "segmentos": [
                {
                    "inicio": f"{int(s['start'] // 60):02d}:{int(s['start'] % 60):02d}",
                    "fim":    f"{int(s['end'] // 60):02d}:{int(s['end'] % 60):02d}",
                    "texto":  s["text"].strip(),
                }
                for s in result.get("segments", [])
            ],
            "idioma_detectado": result.get("language", lang),
        }
    finally:
        os.unlink(tmp_path)


FORMATOS_ACEITOS = {"mp3", "mp4", "wav", "m4a", "ogg", "flac", "webm", "mpeg"}
MODELOS_DISPONIVEIS = {
    "tiny":   "Mínimo — muito rápido, qualidade básica (PT-BR ruim)",
    "base":   "Básico — rápido, qualidade razoável (recomendado para testes)",
    "small":  "Pequeno — equilíbrio qualidade/velocidade",
    "medium": "Médio — boa qualidade PT-BR, ~5min para 1h de áudio",
    "large-v3": "Máximo — melhor qualidade PT-BR, requer GPU para ser viável",
}


@router.get("/modelos")
async def listar_modelos():
    """Lista os modelos Whisper disponíveis com descrições."""
    return {
        "modelos": [{"nome": k, "descricao": v} for k, v in MODELOS_DISPONIVEIS.items()],
        "recomendado_cpu": "small",
        "recomendado_gpu": "large-v3",
        "formatos_suportados": sorted(FORMATOS_ACEITOS),
    }


@router.post("/transcrever")
async def transcrever_audio(
    file: UploadFile = File(...),
    modelo: str = Form("base", description="tiny|base|small|medium|large-v3"),
    lang: str = Form("pt", description="Código de idioma: pt, en, es"),
    formato_saida: str = Form("texto", description="texto|segmentos|ambos"),
):
    """
    Transcreve arquivo de áudio para texto usando Whisper local.
    Suporta: MP3, MP4, WAV, M4A, OGG, FLAC, WebM.
    """
    filename = file.filename or "audio.mp3"
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else "mp3"

    if ext not in FORMATOS_ACEITOS:
        raise HTTPException(415, f"Formato '{ext}' não suportado. Use: {', '.join(sorted(FORMATOS_ACEITOS))}")

    content = await file.read()
    if len(content) > 500 * 1024 * 1024:  # 500MB
        raise HTTPException(413, "Arquivo muito grande. Limite: 500MB.")

    try:
        resultado = _transcrever(content, ext, modelo, lang)
    except RuntimeError as e:
        raise HTTPException(503, str(e))

    resposta = {"filename": filename, "modelo": modelo, "idioma": resultado["idioma_detectado"]}

    if formato_saida in ("texto", "ambos"):
        resposta["texto"] = resultado["texto"]
        resposta["palavras"] = len(resultado["texto"].split())
        resposta["chars"] = len(resultado["texto"])

    if formato_saida in ("segmentos", "ambos"):
        resposta["segmentos"] = resultado["segmentos"]

    return resposta


@router.post("/transcrever-e-ingerir")
async def transcrever_e_ingerir(
    file: UploadFile = File(...),
    modelo: str = Form("base"),
    lang: str = Form("pt"),
    category: str = Form("geral"),
    titulo: str = Form(""),
    db: AsyncSession = Depends(get_db),
    kb: LegalKnowledgeBase = Depends(get_kb),
):
    """
    Transcreve áudio e ingere o texto automaticamente na base RAG.
    Ideal para: audiências, depoimentos, laudos ditados.
    """
    filename = file.filename or "audio.mp3"
    ext = filename.rsplit(".", 1)[-1].lower()

    if ext not in FORMATOS_ACEITOS:
        raise HTTPException(415, f"Formato '{ext}' não suportado.")

    content = await file.read()

    try:
        resultado = _transcrever(content, ext, modelo, lang)
    except RuntimeError as e:
        raise HTTPException(503, str(e))

    texto = resultado["texto"]
    if not texto.strip():
        raise HTTPException(422, "Nenhum texto transcrito. Verifique a qualidade do áudio.")

    # Adiciona cabeçalho estruturado
    titulo_final = titulo or f"Transcrição: {filename}"
    conteudo_completo = f"# {titulo_final}\n\n{texto}"

    resultado_ingestao = await kb.ingest_file(
        db=db,
        file_bytes=conteudo_completo.encode("utf-8"),
        filename=f"whisper_{filename}.txt",
        category=category,
        metadata={"origem": "whisper", "arquivo_original": filename,
                  "modelo": modelo, "idioma": lang},
    )

    return {
        "filename": filename,
        "chars_transcritos": len(texto),
        "palavras": len(texto.split()),
        "chunks_criados": resultado_ingestao["chunks_created"],
        "document_id": str(resultado_ingestao["document_id"]),
        "preview": texto[:400] + "..." if len(texto) > 400 else texto,
    }
