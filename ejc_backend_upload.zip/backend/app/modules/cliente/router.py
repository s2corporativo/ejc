"""
EJC — Painel do Cliente (módulo cliente/router.py)

Permite que o cliente acesse seus pedidos sem criar conta.
Fluxo completo:
  1. POST /cliente/solicitar-acesso  → recebe email → envia link mágico por e-mail
  2. GET  /cliente/verificar/{token} → valida token → retorna JWT temporário
  3. GET  /cliente/meus-pedidos      → lista pedidos do e-mail autenticado
  4. GET  /cliente/pedido/{token_acesso} → detalhes + download da petição
  5. POST /cliente/pedido/{id}/pedir-impugnacao → solicita impugnação

Segurança:
  - Token de 32 bytes (hex = 64 chars) gerado com secrets
  - Expira em 7 dias
  - Uso único: token marcado como usado após primeira autenticação
  - Sessão: JWT temporário de 24h emitido no verificar
"""
from __future__ import annotations

import logging
import secrets
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel, EmailStr
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/cliente", tags=["Painel do Cliente"])


# ── Schemas ───────────────────────────────────────────────────────────────

class SolicitarAcessoReq(BaseModel):
    email: str


class PedirImpugnacaoReq(BaseModel):
    descricao: str
    fatos_novos: Optional[str] = None


# ── Helpers ───────────────────────────────────────────────────────────────

async def _enviar_email_link_magico(email: str, token: str, base_url: str):
    """Envia e-mail com link de acesso ao painel."""
    link = f"{base_url}/painel-cliente?token={token}"

    # Tenta via SMTP configurado
    try:
        import smtplib
        import os
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText

        smtp_host = os.getenv("SMTP_HOST", "")
        smtp_port = int(os.getenv("SMTP_PORT", "587"))
        smtp_user = os.getenv("SMTP_USER", "")
        smtp_pass = os.getenv("SMTP_PASS", "")
        from_email = os.getenv("FROM_EMAIL", smtp_user or "noreply@ejc.com.br")

        if not smtp_host or not smtp_user:
            logger.warning(f"[Cliente] SMTP não configurado — link mágico: {link}")
            return

        html = f"""
        <div style="font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto;">
          <h2 style="color: #1a1a2e;">Acesse seus pedidos</h2>
          <p>Clique no botão abaixo para acessar o painel com seus pedidos de petição:</p>
          <a href="{link}"
             style="display:inline-block;background:#e8bc4a;color:#1a1a2e;padding:14px 28px;
                    border-radius:8px;text-decoration:none;font-weight:bold;margin:16px 0;">
            Acessar Meus Pedidos
          </a>
          <p style="color:#666;font-size:12px;">
            Link válido por 7 dias · Uso único · Se não foi você, ignore este e-mail.
          </p>
        </div>
        """

        msg = MIMEMultipart("alternative")
        msg["Subject"] = "Acesse seus pedidos — EJC Petições"
        msg["From"] = from_email
        msg["To"] = email
        msg.attach(MIMEText(html, "html"))

        with smtplib.SMTP(smtp_host, smtp_port) as s:
            s.ehlo()
            s.starttls()
            s.login(smtp_user, smtp_pass)
            s.sendmail(from_email, email, msg.as_string())

        logger.info(f"[Cliente] E-mail enviado para {email}")

    except Exception as e:
        logger.error(f"[Cliente] Falha ao enviar e-mail: {e}")
        logger.info(f"[Cliente] Link mágico (fallback log): {link}")


# ── Endpoints ─────────────────────────────────────────────────────────────

@router.post("/solicitar-acesso")
async def solicitar_acesso(
    req: SolicitarAcessoReq,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
):
    """
    Envia link mágico para o e-mail do cliente.
    Retorna 200 mesmo se o e-mail não existir (não revela cadastro).
    """
    email = req.email.lower().strip()

    # Verifica se o e-mail tem pedidos
    row = await db.execute(
        text("SELECT COUNT(*) as n FROM pedidos WHERE LOWER(cliente_email)=:e"),
        {"e": email},
    )
    count = row.scalar()

    # Cria token mesmo se não tiver pedidos (evita enumeração de e-mails)
    token = secrets.token_hex(32)

    await db.execute(text("""
        INSERT INTO tokens_cliente (email, token, expira_em)
        VALUES (:e, :t, NOW() + INTERVAL '7 days')
    """), {"e": email, "t": token})
    await db.commit()

    import os
    base_url = os.getenv("APP_BASE_URL", "https://ejc.com.br")
    background_tasks.add_task(_enviar_email_link_magico, email, token, base_url)

    logger.info(f"[Cliente] Acesso solicitado para {email} (tem {count} pedidos)")

    return {
        "mensagem": "Se houver pedidos cadastrados com esse e-mail, você receberá o link de acesso em breve.",
        "dev_token": token if os.getenv("AMBIENTE") == "dev" else None,  # só em dev
    }


@router.get("/verificar/{token}")
async def verificar_token(token: str, db: AsyncSession = Depends(get_db)):
    """
    Valida o token do link mágico e retorna os dados da sessão.
    Marca o token como usado (uso único).
    """
    row = await db.execute(text("""
        SELECT id, email, usado, expira_em
        FROM tokens_cliente
        WHERE token=:t
    """), {"t": token})
    tc = row.mappings().first()

    if not tc:
        raise HTTPException(401, "Link inválido ou expirado")

    if tc["usado"]:
        raise HTTPException(401, "Link já utilizado. Solicite um novo acesso.")

    if datetime.utcnow() > tc["expira_em"].replace(tzinfo=None):
        raise HTTPException(401, "Link expirado. Solicite um novo acesso.")

    # Marca como usado
    await db.execute(
        text("UPDATE tokens_cliente SET usado=TRUE WHERE id=:id"),
        {"id": tc["id"]},
    )
    await db.commit()

    email = tc["email"]

    # Gera sessão temporária (token de 24h)
    sessao_token = secrets.token_hex(24)
    await db.execute(text("""
        INSERT INTO tokens_cliente (email, token, expira_em)
        VALUES (:e, :t, NOW() + INTERVAL '24 hours')
    """), {"e": email, "t": sessao_token})
    await db.commit()

    logger.info(f"[Cliente] Login bem-sucedido: {email}")

    return {
        "email": email,
        "sessao_token": sessao_token,
        "expira_em": (datetime.utcnow() + timedelta(hours=24)).isoformat(),
        "mensagem": "Acesso autorizado. Redirecionando...",
    }


@router.get("/meus-pedidos")
async def meus_pedidos(
    sessao_token: str,
    db: AsyncSession = Depends(get_db),
):
    """
    Lista todos os pedidos do cliente autenticado via sessão token.
    """
    # Valida sessão
    row = await db.execute(text("""
        SELECT email FROM tokens_cliente
        WHERE token=:t AND usado=FALSE AND expira_em > NOW()
    """), {"t": sessao_token})
    sess = row.mappings().first()
    if not sess:
        raise HTTPException(401, "Sessão inválida ou expirada")

    email = sess["email"]

    rows = await db.execute(text("""
        SELECT
            id, numero, status, area_juridica, tipo_documento,
            objetivo, valor_causa, pago_em, entregue_em,
            peticao_md IS NOT NULL AS tem_peticao,
            instrucoes_md IS NOT NULL AS tem_instrucoes,
            token_acesso, created_at
        FROM pedidos
        WHERE LOWER(cliente_email)=:e
        ORDER BY created_at DESC
    """), {"e": email.lower()})

    pedidos = [dict(r) for r in rows.mappings()]

    return {
        "email": email,
        "total": len(pedidos),
        "pedidos": pedidos,
    }


@router.get("/pedido/{token_acesso}")
async def detalhe_pedido_cliente(
    token_acesso: str,
    db: AsyncSession = Depends(get_db),
):
    """
    Retorna detalhes completos de um pedido pelo token de acesso.
    Não requer login — o token é o acesso direto ao pedido.
    """
    row = await db.execute(text("""
        SELECT
            id, numero, status, area_juridica, tipo_documento,
            fatos, objetivo, parte_contraria, valor_causa,
            peticao_md, instrucoes_md,
            metodo_pagamento, valor_pago,
            pago_em, entregue_em, created_at
        FROM pedidos
        WHERE token_acesso=:t
    """), {"t": token_acesso})

    p = row.mappings().first()
    if not p:
        raise HTTPException(404, "Pedido não encontrado")

    return {
        "pedido": dict(p),
        "pode_baixar": p["status"] in ("pronto", "entregue"),
        "pode_pedir_impugnacao": p["status"] in ("pronto", "entregue") and p["peticao_md"],
    }


@router.post("/pedido/{pedido_id}/pedir-impugnacao")
async def pedir_impugnacao(
    pedido_id: str,
    req: PedirImpugnacaoReq,
    token_acesso: str,
    db: AsyncSession = Depends(get_db),
):
    """
    Cliente solicita impugnação/resposta para um pedido existente.
    Cria novo pedido do tipo 'impugnacao' vinculado ao original.
    """
    # Valida acesso ao pedido original
    row = await db.execute(text("""
        SELECT id, cliente_email, cliente_nome, cliente_estado, area_juridica, peticao_md
        FROM pedidos
        WHERE id=:id AND token_acesso=:t
    """), {"id": pedido_id, "t": token_acesso})
    original = row.mappings().first()

    if not original:
        raise HTTPException(403, "Acesso não autorizado")

    if not original["peticao_md"]:
        raise HTTPException(400, "Pedido original ainda não tem petição gerada")

    # Cria pedido de impugnação
    import uuid as _uuid
    novo_id = str(_uuid.uuid4())
    fatos_completos = f"IMPUGNAÇÃO DO PEDIDO {pedido_id}\n\n{req.descricao}"
    if req.fatos_novos:
        fatos_completos += f"\n\nFATOS NOVOS:\n{req.fatos_novos}"

    novo_token = secrets.token_hex(32)

    await db.execute(text("""
        INSERT INTO pedidos (
            id, plano_id, cliente_email, cliente_nome,
            cliente_estado, area_juridica, tipo_documento,
            fatos, objetivo, status, token_acesso
        ) VALUES (
            :id, 'impugnacao', :email, :nome,
            :estado, :area, 'impugnacao',
            :fatos, 'Impugnação da decisão', 'aguardando_pagamento', :token
        )
    """), {
        "id": novo_id,
        "email": original["cliente_email"],
        "nome": original["cliente_nome"],
        "estado": original["cliente_estado"],
        "area": original["area_juridica"],
        "fatos": fatos_completos,
        "token": novo_token,
    })
    await db.commit()

    return {
        "pedido_id": novo_id,
        "token_acesso": novo_token,
        "mensagem": "Pedido de impugnação criado. Realize o pagamento para prosseguir.",
        "valor": 29.90,
    }
