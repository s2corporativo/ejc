"""
EJC — Gerador de Petição Trabalhista
modules/trabalhista/gerador_peticao.py

Ponte entre a calculadora trabalhista e o gerador de peças (redacao).

Fluxo:
  1. Recebe o resultado completo da simulação trabalhista
  2. Monta prompt estruturado com todos os valores calculados
  3. Envia para o LLM com contexto RAG (teses, súmulas CLT do corpus)
  4. Retorna petição em Markdown pronta para exportação PDF/DOCX

A petição inclui:
  - Qualificação das partes
  - Causa de pedir com fatos do usuário
  - Verbas pleiteadas com valores já calculados
  - Fundamentação jurídica (CLT, TST, FGTS)
  - Pedidos itemizados com valores monetários
  - Requerimentos finais
"""
from __future__ import annotations
import logging
from decimal import Decimal

logger = logging.getLogger(__name__)


def _brl(v) -> str:
    """Formata valor em Real."""
    try:
        return f"R$ {float(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except Exception:
        return "R$ 0,00"


def montar_prompt_peticao_trabalhista(
    dados_calculo: dict,
    fatos_usuario: str,
    reclamante: str,
    reclamada: str,
    tipo_rescisao: str,
    data_admissao: str,
    data_demissao: str,
    salario: float,
    cidade_vara: str = "São Paulo",
    uf: str = "SP",
) -> tuple[str, str]:
    """
    Monta (system_prompt, user_prompt) para o LLM gerar a petição trabalhista.
    O user_prompt contém todos os valores calculados embutidos.
    """
    verbas = dados_calculo.get("verbas_rescisorias", {})
    detalhes = verbas.get("detalhes", {})

    # ── Extrai valores calculados ──────────────────────────────────────────
    saldo_sal   = detalhes.get("saldo_salario",    {}).get("valor", 0)
    aviso_prev  = detalhes.get("aviso_previo",     {}).get("valor", 0)
    decimo_3    = detalhes.get("decimo_terceiro",  {}).get("valor", 0)
    ferias_val  = detalhes.get("ferias_proporcionais", {}).get("valor", 0)
    ferias_1_3  = detalhes.get("ferias_um_terco", {}).get("valor", 0)
    multa_fgts  = detalhes.get("multa_fgts_40",   {}).get("valor", 0)
    total_liq   = verbas.get("liquido_estimado", verbas.get("total_bruto", 0))

    # Horas extras (se calculado separadamente)
    he = dados_calculo.get("horas_extras", {})
    he_total = he.get("total_geral", 0) if he else 0

    tipo_label = {
        "sem_justa_causa":  "Dispensado sem justa causa",
        "com_justa_causa":  "Dispensado por justa causa",
        "pedido_demissao":  "Pedido de demissão",
        "rescisao_indireta":"Rescisão indireta (art. 483 CLT)",
        "acordo":           "Acordo entre partes (art. 484-A CLT)",
    }.get(tipo_rescisao, tipo_rescisao)

    verbas_md = f"""
## VERBAS RESCISÓRIAS CALCULADAS

| Verba | Valor Calculado |
|---|---|
| Saldo de salário | {_brl(saldo_sal)} |
| Aviso prévio | {_brl(aviso_prev)} |
| 13º salário proporcional | {_brl(decimo_3)} |
| Férias proporcionais | {_brl(ferias_val)} |
| 1/3 constitucional sobre férias | {_brl(ferias_1_3)} |
| Multa de 40% sobre FGTS | {_brl(multa_fgts)} |
{f"| Horas extras devidas | {_brl(he_total)} |" if he_total > 0 else ""}
| **TOTAL ESTIMADO** | **{_brl(total_liq)}** |

*Valores calculados com base nas informações informadas — sujeitos a revisão pericial.*
"""

    system_prompt = """Você é um advogado trabalhista especializado em reclamações trabalhistas \
na Justiça do Trabalho brasileira. Redija petições iniciais completas, formais e tecnicamente \
precisas, com fundamentação na CLT, CF/88, súmulas do TST e OJs do SDI-I.

ESTRUTURA OBRIGATÓRIA:
1. Endereçamento (Excelentíssimo Senhor Doutor Juiz...)
2. Qualificação do Reclamante
3. Qualificação da Reclamada
4. DOS FATOS (narrativa clara e cronológica)
5. DO DIREITO (fundamentação jurídica artigo por artigo)
6. DAS VERBAS PLEITEADAS (itens com valores calculados)
7. DOS PEDIDOS (itemizados, numerados, com valores monetários)
8. DO VALOR DA CAUSA
9. DOS REQUERIMENTOS (provas, depoimentos, documentos)
10. ENCERRAMENTO E ASSINATURA

REGRAS:
- Use os valores calculados exatamente como fornecidos
- Cite artigos da CLT, CF/88 e súmulas relevantes do TST
- Linguagem jurídica formal e técnica
- Inclua pedido de benefício da justiça gratuita (art. 790 CLT)
- Inclua pedido de inversão do ônus da prova quando aplicável
- Formato Markdown com cabeçalhos e tabelas
"""

    user_prompt = f"""Redija a petição inicial trabalhista com os seguintes dados:

## DADOS DO CASO

**Reclamante:** {reclamante}
**Reclamada:** {reclamada}
**Tipo de rescisão:** {tipo_label}
**Data de admissão:** {data_admissao}
**Data de demissão:** {data_demissao}
**Último salário:** {_brl(salario)}
**Cidade/Vara:** {cidade_vara}/{uf}

## FATOS NARRADOS PELO RECLAMANTE

{fatos_usuario}

{verbas_md}

## INSTRUÇÕES ADICIONAIS

- Inclua TODOS os valores da tabela acima nos pedidos
- Fundamente cada verba com o artigo específico da CLT
- Para multa FGTS: citar art. 18, §1º, Lei 8.036/90
- Para horas extras (se houver): citar art. 59 CLT e Súmula 23 TST
- Para aviso prévio: citar art. 477 e 487 CLT
- Para férias: citar arts. 129 e 130 CLT + art. 7º, XVII, CF/88
- Para 13º: citar Lei 4.090/62
- Valor da causa = soma de todos os pedidos = {_brl(total_liq + he_total)}

Escreva a petição completa agora:
"""

    return system_prompt, user_prompt


async def gerar_peticao_trabalhista(
    dados_calculo: dict,
    fatos_usuario: str,
    reclamante: str,
    reclamada: str,
    tipo_rescisao: str,
    data_admissao: str,
    data_demissao: str,
    salario: float,
    cidade_vara: str = "São Paulo",
    uf: str = "SP",
    db=None,
) -> dict:
    """
    Gera petição trabalhista completa usando o LLM com os valores calculados.
    Retorna dict com: peticao_md, titulo, valor_causa
    """
    from app.core.llm_provider import LLMProvider

    system_p, user_p = montar_prompt_peticao_trabalhista(
        dados_calculo, fatos_usuario, reclamante, reclamada,
        tipo_rescisao, data_admissao, data_demissao,
        salario, cidade_vara, uf,
    )

    # Contexto jurisprudencial via engine v2 (súmulas TST, OJs, temas STJ/STF)
    rag_context = ""
    if db:
        try:
            from app.modules.pesquisa.jurisprudencia_engine import get_engine
            engine = get_engine()
            fatos_resumo = fatos_usuario or ""
            pedidos_resumo = f"rescisão indireta verbas rescisórias FGTS horas extras"
            rag_context = await engine.buscar_para_peticao(
                area="trabalhista",
                fatos=fatos_resumo,
                pedidos=pedidos_resumo,
                db=db,
                max_citacoes=8,
            )
            if rag_context:
                rag_context = "\n\n" + rag_context
        except Exception as e:
            logger.warning(f"[Trabalhista] Jurisprudência falhou: {e}")
            # Fallback: teses do banco
            try:
                from sqlalchemy import text
                rows = await db.execute(text("""
                    SELECT titulo, argumentacao_md FROM teses_customizadas
                    WHERE area='trabalhista' AND ativo=true LIMIT 3
                """))
                teses = [f"**{r['titulo']}**\n{r['argumentacao_md'][:400]}" for r in rows.mappings()]
                if teses:
                    rag_context = "\n\nTESES DISPONÍVEIS NA BASE:\n" + "\n\n".join(teses)
            except: pass

    provider = LLMProvider()
    peticao_md = await provider.generate(
        prompt=user_p,
        system=system_p + rag_context,
        max_tokens=4000,
    )

    # Extrai valor da causa do cálculo
    verbas = dados_calculo.get("verbas_rescisorias", {})
    he = dados_calculo.get("horas_extras", {})
    valor_causa = float(verbas.get("liquido_estimado") or verbas.get("total_bruto") or 0)
    valor_causa += float(he.get("total_geral") or 0) if he else 0

    return {
        "peticao_md":      peticao_md,
        "titulo":          f"Petição Inicial — Reclamação Trabalhista — {reclamante} x {reclamada}",
        "valor_causa":     valor_causa,
        "valor_causa_fmt": _brl(valor_causa),
        "tipo_rescisao":   tipo_rescisao,
        "aviso_legal": (
            "⚠️ Esta petição foi gerada por IA com os valores calculados. "
            "Revise os fatos, verifique os documentos e valide com advogado "
            "antes de protocolar. Os valores são estimados."
        ),
    }
