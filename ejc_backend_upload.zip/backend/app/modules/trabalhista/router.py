"""
EJC — Router Calculadora Trabalhista (modules/trabalhista/router.py)
"""
from __future__ import annotations
from decimal import Decimal
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.trabalhista.calculos import (
    calcular_horas_extras, calcular_13_salario, calcular_ferias,
    calcular_dsr, calcular_verbas_rescisorias, calcular_adicional_noturno,
    calcular_inss, calcular_irrf,
    SALARIO_MINIMO_2025,
)

router = APIRouter(prefix="/trabalhista", tags=["Calculadora Trabalhista Completa"])


class HorasExtrasReq(BaseModel):
    salario: float
    horas_normais_mes: float = 220
    horas_extras_50: float = 0
    horas_extras_100: float = 0
    horas_noturnas: float = 0


class TrezeReq(BaseModel):
    salario: float
    meses_trabalhados: int = Field(..., ge=1, le=12)
    avos_falta: int = 0
    primeira_parcela_paga: bool = False


class FeriasReq(BaseModel):
    salario: float
    meses_trabalhados: int = Field(..., ge=1, le=12)
    ferias_vencidas: bool = False
    dobra: bool = False
    num_dependentes: int = 0


class VerbaRescisReq(BaseModel):
    salario: float
    data_admissao: str
    data_demissao: str
    tipo_rescisao: str = "dispensa_sem_justa"
    aviso_previo_indenizado: bool = True
    saldo_dias: Optional[int] = None
    ferias_vencidas: bool = False
    num_dependentes: int = 0


class INSSReq(BaseModel):
    salario_bruto: float


class IRRFReq(BaseModel):
    salario_bruto: float
    num_dependentes: int = 0
    inss_ja_calculado: Optional[float] = None


async def _log_calculo(db: AsyncSession, tipo: str, entrada: dict, resultado: dict):
    await db.execute(
        text("INSERT INTO calculation_log (id,calc_type,input_data,result_data) VALUES (:id,:t,:i::jsonb,:r::jsonb)"),
        {"id": str(uuid4()), "t": tipo, "i": str(entrada), "r": str(resultado)},
    )


@router.get("/tabelas-vigentes")
async def tabelas_vigentes():
    """Retorna tabelas INSS e IRRF vigentes em 2025."""
    return {
        "salario_minimo_2025": f"R$ {float(SALARIO_MINIMO_2025):,.2f}".replace(",","X").replace(".",",").replace("X","."),
        "inss_2025": [
            {"faixa_ate": "R$ 1.518,00", "aliquota": "7,5%"},
            {"faixa_ate": "R$ 2.793,88", "aliquota": "9%"},
            {"faixa_ate": "R$ 4.190,83", "aliquota": "12%"},
            {"faixa_ate": "R$ 8.157,41", "aliquota": "14%"},
        ],
        "irrf_2025": [
            {"base_ate": "R$ 2.824,00", "aliquota": "isento"},
            {"base_ate": "R$ 3.751,05", "aliquota": "7,5%", "deducao": "R$ 211,80"},
            {"base_ate": "R$ 4.664,68", "aliquota": "15%",  "deducao": "R$ 422,71"},
            {"base_ate": "R$ 6.101,06", "aliquota": "22,5%","deducao": "R$ 692,79"},
            {"base_acima": "R$ 6.101,06","aliquota": "27,5%","deducao": "R$ 1.001,89"},
        ],
        "deducao_dependente": "R$ 189,59",
        "vigencia": "Janeiro/2025",
    }


@router.post("/inss")
async def calcular_inss_endpoint(req: INSSReq, db: AsyncSession = Depends(get_db)):
    r = calcular_inss(Decimal(str(req.salario_bruto)))
    await _log_calculo(db, "inss_2025", req.model_dump(), r)
    return r


@router.post("/irrf")
async def calcular_irrf_endpoint(req: IRRFReq, db: AsyncSession = Depends(get_db)):
    inss = Decimal(str(req.inss_ja_calculado)) if req.inss_ja_calculado else None
    r = calcular_irrf(Decimal(str(req.salario_bruto)), req.num_dependentes, inss)
    await _log_calculo(db, "irrf_2025", req.model_dump(), r)
    return r


@router.post("/horas-extras")
async def horas_extras(req: HorasExtrasReq, db: AsyncSession = Depends(get_db)):
    r = calcular_horas_extras(
        Decimal(str(req.salario)),
        Decimal(str(req.horas_normais_mes)),
        Decimal(str(req.horas_extras_50)),
        Decimal(str(req.horas_extras_100)),
        Decimal(str(req.horas_noturnas)),
    )
    await _log_calculo(db, "horas_extras", req.model_dump(), r)
    return r


@router.post("/adicional-noturno")
async def adicional_noturno(
    salario: float, horas_normais_mes: float = 220, horas_noturnas_mes: float = 0,
    db: AsyncSession = Depends(get_db),
):
    r = calcular_adicional_noturno(Decimal(str(salario)), Decimal(str(horas_normais_mes)), Decimal(str(horas_noturnas_mes)))
    await _log_calculo(db, "adicional_noturno", {"salario": salario}, r)
    return r


@router.post("/decimo-terceiro")
async def decimo_terceiro(req: TrezeReq, db: AsyncSession = Depends(get_db)):
    r = calcular_13_salario(Decimal(str(req.salario)), req.meses_trabalhados, req.avos_falta, req.primeira_parcela_paga)
    await _log_calculo(db, "decimo_terceiro", req.model_dump(), r)
    return r


@router.post("/ferias")
async def ferias(req: FeriasReq, db: AsyncSession = Depends(get_db)):
    r = calcular_ferias(Decimal(str(req.salario)), req.meses_trabalhados, req.ferias_vencidas,
                        True, req.dobra, req.num_dependentes)
    await _log_calculo(db, "ferias", req.model_dump(), r)
    return r


@router.post("/dsr")
async def dsr(salario: float, horas_normais_mes: float = 220,
              horas_extras_mes: float = 0, db: AsyncSession = Depends(get_db)):
    r = calcular_dsr(Decimal(str(salario)), Decimal(str(horas_normais_mes)), Decimal(str(horas_extras_mes)))
    await _log_calculo(db, "dsr", {"salario": salario}, r)
    return r


@router.post("/verbas-rescisorias")
async def verbas_rescisorias(req: VerbaRescisReq, db: AsyncSession = Depends(get_db)):
    try:
        r = calcular_verbas_rescisorias(
            Decimal(str(req.salario)), req.data_admissao, req.data_demissao,
            req.tipo_rescisao, req.aviso_previo_indenizado,
            req.saldo_dias, req.ferias_vencidas, req.num_dependentes,
        )
    except Exception as e:
        raise HTTPException(422, str(e))
    await _log_calculo(db, "verbas_rescisorias", req.model_dump(), r)
    return r


@router.post("/simulacao-completa")
async def simulacao_completa(req: VerbaRescisReq, db: AsyncSession = Depends(get_db)):
    """
    Simulação completa: verbas rescisórias + INSS + IRRF + líquido estimado.
    """
    try:
        verbas = calcular_verbas_rescisorias(
            Decimal(str(req.salario)), req.data_admissao, req.data_demissao,
            req.tipo_rescisao, req.aviso_previo_indenizado,
            req.saldo_dias, req.ferias_vencidas, req.num_dependentes,
        )
    except Exception as e:
        raise HTTPException(422, str(e))

    sal = Decimal(str(req.salario))
    inss = calcular_inss(sal)
    irrf = calcular_irrf(sal, req.num_dependentes, inss["desconto_decimal"])

    return {
        "verbas_rescisorias": verbas,
        "descontos_mensais": {
            "inss": inss,
            "irrf": irrf,
        },
        "aviso": "Valores estimados. Desconto de INSS e IRRF sobre verbas rescisórias tem regras específicas. Consulte o contador.",
    }


# ══════════════════════════════════════════════════════════════════════════════
# GERAÇÃO AUTOMÁTICA DE PETIÇÃO A PARTIR DO CÁLCULO
# ══════════════════════════════════════════════════════════════════════════════

class GerarPeticaoTrabalhistaReq(BaseModel):
    """Dados para gerar petição com valores já calculados."""
    # Identificação das partes
    reclamante:     str = Field(..., min_length=3)
    reclamada:      str = Field(..., min_length=3)
    cidade_vara:    str = "São Paulo"
    uf:             str = "SP"

    # Mesmos campos da VerbaRescisReq (para recalcular internamente)
    salario:            float
    data_admissao:      str
    data_demissao:      str
    tipo_rescisao:      str = "sem_justa_causa"
    aviso_previo_indenizado: bool = True
    saldo_dias:         int = 0
    ferias_vencidas:    bool = False
    num_dependentes:    int = 0

    # Horas extras (opcional)
    horas_extras_50:    float = 0
    horas_extras_100:   float = 0
    horas_normais_mes:  float = 220

    # Fatos narrados pelo usuário
    fatos:  str = Field(..., min_length=50, description="Descreva o que aconteceu")

    # Se quiser passar cálculo já pronto (pula o recálculo)
    calculo_externo: dict | None = None


@router.post("/gerar-peticao", status_code=201)
async def gerar_peticao_trabalhista_endpoint(
    req: GerarPeticaoTrabalhistaReq,
    db: AsyncSession = Depends(get_db),
):
    """
    🔗 PONTE: Calcula verbas rescisórias → Gera petição completa com os valores.

    Fluxo completo:
      1. Calcula todas as verbas rescisórias (saldo, aviso, 13º, férias, multa FGTS)
      2. Calcula horas extras, se informadas
      3. Monta prompt estruturado com valores reais
      4. LLM gera petição com fundamentação jurídica + valores já preenchidos
      5. Retorna Markdown pronto para exportação

    O usuário NÃO precisa saber os valores: ele informa os fatos,
    o sistema calcula e insere tudo na petição automaticamente.
    """
    from decimal import Decimal
    from app.modules.trabalhista.gerador_peticao import gerar_peticao_trabalhista
    from app.modules.trabalhista.calculos import (
        calcular_verbas_rescisorias,
        calcular_horas_extras,
        calcular_inss, calcular_irrf,
    )

    sal = Decimal(str(req.salario))

    # 1. Calcula verbas rescisórias
    try:
        verbas = calcular_verbas_rescisorias(
            sal, req.data_admissao, req.data_demissao,
            req.tipo_rescisao, req.aviso_previo_indenizado,
            req.saldo_dias, req.ferias_vencidas, req.num_dependentes,
        )
    except Exception as e:
        raise HTTPException(422, f"Erro no cálculo rescisório: {e}")

    # 2. Calcula horas extras (se houver)
    horas_extras = {}
    if req.horas_extras_50 > 0 or req.horas_extras_100 > 0:
        try:
            horas_extras = calcular_horas_extras(
                sal, req.horas_normais_mes,
                req.horas_extras_50, req.horas_extras_100
            )
        except Exception:
            pass

    # 3. Desconto INSS/IRRF
    inss = calcular_inss(sal)
    irrf = calcular_irrf(sal, req.num_dependentes, inss["desconto_decimal"])

    dados_calculo = {
        "verbas_rescisorias": verbas,
        "horas_extras":       horas_extras,
        "descontos_mensais":  {"inss": inss, "irrf": irrf},
    }

    # 4. Gera a petição via LLM
    try:
        resultado = await gerar_peticao_trabalhista(
            dados_calculo   = dados_calculo,
            fatos_usuario   = req.fatos,
            reclamante      = req.reclamante,
            reclamada       = req.reclamada,
            tipo_rescisao   = req.tipo_rescisao,
            data_admissao   = req.data_admissao,
            data_demissao   = req.data_demissao,
            salario         = req.salario,
            cidade_vara     = req.cidade_vara,
            uf              = req.uf,
            db              = db,
        )
    except Exception as e:
        raise HTTPException(503, f"Erro na geração via LLM: {e}")

    # 5. Persiste no banco de peças (tabela documents)
    from uuid import uuid4
    from sqlalchemy import text
    doc_id = str(uuid4())
    await db.execute(text("""
        INSERT INTO documents (id, title, filename, content, category, metadata)
        VALUES (:id, :title, :fn, :content, 'peticao_trabalhista', :meta::jsonb)
    """), {
        "id":      doc_id,
        "title":   resultado["titulo"],
        "fn":      f"peticao_trabalhista_{doc_id[:8]}.md",
        "content": resultado["peticao_md"],
        "meta":    __import__('json').dumps({
            "reclamante":   req.reclamante,
            "reclamada":    req.reclamada,
            "valor_causa":  resultado["valor_causa"],
            "tipo_rescisao": req.tipo_rescisao,
        }),
    })
    await db.commit()

    return {
        "document_id":      doc_id,
        "titulo":           resultado["titulo"],
        "valor_causa_fmt":  resultado["valor_causa_fmt"],
        "peticao_md":       resultado["peticao_md"],
        "dados_calculo":    dados_calculo,
        "aviso_legal":      resultado["aviso_legal"],
    }
