"""
EJC — Módulo Trabalhista (modules/trabalhista/calculos.py)

Cálculos trabalhistas completos com precisão Decimal:
  - Horas extras (50% e 100%)
  - Adicional noturno (20% — art. 73 CLT)
  - 13º salário proporcional e integral
  - Férias + 1/3 constitucional + dobra
  - DSR — Descanso Semanal Remunerado
  - Verbas rescisórias completas (aviso prévio, saldo, tudo)
  - INSS empregado — tabela progressiva 2025
  - IRRF — tabela progressiva 2025

Todos os cálculos são funções puras sem efeitos colaterais.
Suporte a histórico de salários variáveis (comissões, variáveis).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP, getcontext
from typing import Optional

getcontext().prec = 28

CENTAVOS   = Decimal("0.01")
brl = lambda v: f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


# ── INSS 2025 — Tabela progressiva (Portaria MPS/MF nº 1, jan/2025) ──────
INSS_FAIXAS_2025 = [
    (Decimal("1518.00"), Decimal("0.075")),
    (Decimal("2793.88"), Decimal("0.09")),
    (Decimal("4190.83"), Decimal("0.12")),
    (Decimal("8157.41"), Decimal("0.14")),
]
INSS_TETO_2025 = Decimal("8157.41")

# ── IRRF 2025 — Tabela progressiva (Decreto nº 12.007/2024) ───────────────
IRRF_FAIXAS_2025 = [
    (Decimal("2824.00"), Decimal("0.0"),   Decimal("0.00")),
    (Decimal("3751.05"), Decimal("0.075"), Decimal("211.80")),
    (Decimal("4664.68"), Decimal("0.15"),  Decimal("422.71")),
    (Decimal("6101.06"), Decimal("0.225"), Decimal("692.79")),
    (Decimal("999999.99"), Decimal("0.275"), Decimal("1001.89")),
]
DEDUCAO_DEPENDENTE_2025 = Decimal("189.59")

# ── Salário mínimo 2025 ───────────────────────────────────────────────────
SALARIO_MINIMO_2025 = Decimal("1518.00")


def calcular_inss(salario_bruto: Decimal) -> dict:
    """Calcula INSS progressivo (tabela 2025)."""
    base = min(salario_bruto, INSS_TETO_2025)
    desconto = Decimal("0")
    anterior = Decimal("0")

    for teto, aliquota in INSS_FAIXAS_2025:
        if base <= teto:
            desconto += (base - anterior) * aliquota
            break
        desconto += (teto - anterior) * aliquota
        anterior = teto

    return {
        "base_calculo":  brl(base),
        "desconto_inss": brl(desconto.quantize(CENTAVOS, ROUND_HALF_UP)),
        "desconto_decimal": desconto.quantize(CENTAVOS, ROUND_HALF_UP),
    }


def calcular_irrf(salario_bruto: Decimal, num_dependentes: int = 0,
                  inss: Optional[Decimal] = None) -> dict:
    """Calcula IRRF progressivo (tabela 2025) com deduções legais."""
    if inss is None:
        inss = calcular_inss(salario_bruto)["desconto_decimal"]
    deducao_dep = DEDUCAO_DEPENDENTE_2025 * num_dependentes
    base = salario_bruto - inss - deducao_dep

    imposto = Decimal("0")
    aliq_efetiva = Decimal("0")
    for teto, aliquota, deducao in IRRF_FAIXAS_2025:
        if base <= teto:
            imposto = max(Decimal("0"), base * aliquota - deducao)
            aliq_efetiva = aliquota
            break

    return {
        "base_calculo":      brl(base),
        "deducao_dependentes": brl(deducao_dep),
        "aliquota":          f"{float(aliq_efetiva*100):.1f}%",
        "irrf":              brl(imposto.quantize(CENTAVOS, ROUND_HALF_UP)),
        "irrf_decimal":      imposto.quantize(CENTAVOS, ROUND_HALF_UP),
    }


def calcular_horas_extras(
    salario: Decimal,
    horas_normais_mes: Decimal = Decimal("220"),
    horas_extras_50: Decimal = Decimal("0"),
    horas_extras_100: Decimal = Decimal("0"),
    horas_noturnas: Decimal = Decimal("0"),
) -> dict:
    """
    Calcula adicional de horas extras e adicional noturno.
    Art. 59 CLT: 50% dias normais, 100% domingos/feriados.
    Art. 73 CLT: adicional noturno de 20% (22h-5h), hora = 52'30''.
    """
    hora_normal = (salario / horas_normais_mes).quantize(CENTAVOS, ROUND_HALF_UP)

    ad_he50  = (hora_normal * Decimal("1.50") * horas_extras_50).quantize(CENTAVOS, ROUND_HALF_UP)
    ad_he100 = (hora_normal * Decimal("2.00") * horas_extras_100).quantize(CENTAVOS, ROUND_HALF_UP)

    # Hora noturna = 52'30'' → equivale a 1h / (60/52.5) = fator 1.142857
    hora_noturna = (hora_normal * Decimal("1.142857")).quantize(CENTAVOS, ROUND_HALF_UP)
    ad_noturno   = (hora_noturna * Decimal("1.20") * horas_noturnas).quantize(CENTAVOS, ROUND_HALF_UP)

    total = ad_he50 + ad_he100 + ad_noturno

    return {
        "valor_hora_normal":    brl(hora_normal),
        "horas_extras_50pct":   brl(ad_he50),
        "horas_extras_100pct":  brl(ad_he100),
        "adicional_noturno":    brl(ad_noturno),
        "total_adicionais":     brl(total),
        "total_decimal":        total,
        "fundamentacao": "Art. 59 e 73 CLT; Súmula 60 TST (adicional noturno)",
    }


def calcular_13_salario(
    salario: Decimal,
    meses_trabalhados: int,
    avos_falta: int = 0,
    primeira_parcela_paga: bool = False,
) -> dict:
    """
    Calcula 13º salário proporcional e integral.
    Mínimo 15 dias para contar o mês (art. 1º Lei 4.090/62).
    """
    avos = max(0, meses_trabalhados - avos_falta)
    valor_integral = salario
    valor_prop = (salario * avos / Decimal("12")).quantize(CENTAVOS, ROUND_HALF_UP)

    primeira = (valor_prop / Decimal("2")).quantize(CENTAVOS, ROUND_HALF_UP)
    segunda  = (valor_prop - (primeira if primeira_parcela_paga else Decimal("0"))).quantize(CENTAVOS, ROUND_HALF_UP)

    inss_13  = calcular_inss(valor_prop)["desconto_decimal"]
    irrf_13  = calcular_irrf(valor_prop, inss=inss_13)["irrf_decimal"]
    liquido  = (valor_prop - inss_13 - irrf_13).quantize(CENTAVOS, ROUND_HALF_UP)

    return {
        "avos":              avos,
        "valor_proporcional": brl(valor_prop),
        "valor_integral":     brl(valor_integral),
        "primeira_parcela":   brl(primeira),
        "segunda_parcela":    brl(segunda),
        "inss_13":            brl(inss_13),
        "irrf_13":            brl(irrf_13),
        "liquido":            brl(liquido),
        "fundamentacao": "Lei 4.090/1962; Lei 4.749/1965; Súmula 157 TST",
    }


def calcular_ferias(
    salario: Decimal,
    meses_trabalhados: int,
    ferias_vencidas: bool = False,
    ferias_proporcionais: bool = True,
    dobra: bool = False,
    num_dependentes: int = 0,
) -> dict:
    """
    Calcula férias + 1/3 constitucional (art. 7º, XVII CF/88).
    Dobra: quando não concedidas no prazo (art. 137 CLT).
    """
    avos = min(12, meses_trabalhados)
    ferias_base = (salario * avos / Decimal("12")).quantize(CENTAVOS, ROUND_HALF_UP)
    um_terco     = (ferias_base / Decimal("3")).quantize(CENTAVOS, ROUND_HALF_UP)
    bruto        = (ferias_base + um_terco).quantize(CENTAVOS, ROUND_HALF_UP)
    bruto_dobra  = (bruto * 2).quantize(CENTAVOS, ROUND_HALF_UP) if dobra else bruto

    inss_f = calcular_inss(ferias_base)["desconto_decimal"]
    irrf_f = calcular_irrf(ferias_base, num_dependentes, inss_f)["irrf_decimal"]
    liquido = (bruto_dobra - inss_f - irrf_f).quantize(CENTAVOS, ROUND_HALF_UP)

    return {
        "avos":              avos,
        "ferias_base":       brl(ferias_base),
        "um_terco":          brl(um_terco),
        "total_bruto":       brl(bruto_dobra),
        "inss":              brl(inss_f),
        "irrf":              brl(irrf_f),
        "liquido":           brl(liquido),
        "dobra_aplicada":    dobra,
        "fundamentacao": "Art. 7º, XVII CF/88; Arts. 129-148 CLT; Súmula 261 TST",
    }


def calcular_dsr(
    salario: Decimal,
    horas_normais_mes: Decimal = Decimal("220"),
    horas_extras_mes: Decimal = Decimal("0"),
) -> dict:
    """
    Calcula DSR sobre horas extras variáveis (Súmula 172 TST).
    """
    if horas_extras_mes == 0:
        return {"dsr": brl(Decimal("0")), "fundamentacao": "Sem horas extras — DSR não aplicável"}

    valor_hora = (salario / horas_normais_mes)
    he_valor = (valor_hora * Decimal("1.50") * horas_extras_mes).quantize(CENTAVOS, ROUND_HALF_UP)
    # DSR = (horas extras × valor_hora_extra) / dias úteis × domingos/feriados
    # Simplificação: 5 domingos/mês em média, 22 dias úteis
    dsr = (he_valor / Decimal("22") * Decimal("5")).quantize(CENTAVOS, ROUND_HALF_UP)

    return {
        "horas_extras_mes":   str(horas_extras_mes),
        "valor_horas_extras": brl(he_valor),
        "dsr_calculado":      brl(dsr),
        "dsr_decimal":        dsr,
        "fundamentacao": "Súmula 172 TST; Lei 605/1949",
    }


def calcular_verbas_rescisorias(
    salario: Decimal,
    data_admissao: str,       # YYYY-MM-DD
    data_demissao: str,        # YYYY-MM-DD
    tipo_rescisao: str,        # "dispensa_sem_justa","dispensa_com_justa",
                               # "pedido_demissao","rescisao_indireta","acordo_mutuo"
    aviso_previo_indenizado: bool = True,
    saldo_dias: Optional[int] = None,
    ferias_vencidas: bool = False,
    num_dependentes: int = 0,
) -> dict:
    """
    Calcula o pacote completo de verbas rescisórias.
    Considera o tipo de rescisão para definir quais verbas são devidas.
    """
    from datetime import datetime
    di = datetime.strptime(data_admissao, "%Y-%m-%d").date()
    df = datetime.strptime(data_demissao, "%Y-%m-%d").date()

    # Tempo de serviço
    anos = (df - di).days // 365
    meses_totais = (df - di).days // 30

    # Aviso prévio proporcional (Lei 12.506/2011): 30 + 3 por ano, máx 90 dias
    dias_aviso = min(90, 30 + (anos * 3))
    aviso_valor = (salario / Decimal("30") * dias_aviso).quantize(CENTAVOS, ROUND_HALF_UP)

    # Saldo de salário
    if saldo_dias is None:
        saldo_dias = df.day
    saldo = (salario / Decimal("30") * saldo_dias).quantize(CENTAVOS, ROUND_HALF_UP)

    # 13º proporcional
    meses_13 = meses_totais % 12
    if aviso_previo_indenizado and tipo_rescisao in ("dispensa_sem_justa", "rescisao_indireta"):
        meses_13 += dias_aviso // 30
    trec_13 = calcular_13_salario(salario, meses_13)

    # Férias proporcionais (meses desde última aquisição)
    meses_ferias = meses_totais % 12
    if aviso_previo_indenizado and tipo_rescisao in ("dispensa_sem_justa", "rescisao_indireta"):
        meses_ferias = min(12, meses_ferias + dias_aviso // 30)
    ferias_prop = calcular_ferias(salario, meses_ferias, num_dependentes=num_dependentes)

    ferias_venc_val = Decimal("0")
    if ferias_vencidas:
        ferias_venc_obj = calcular_ferias(salario, 12, dobra=False, num_dependentes=num_dependentes)
        ferias_venc_val = Decimal(ferias_venc_obj["total_bruto"].replace("R$ ", "").replace(".", "").replace(",", "."))

    # FGTS sobre verbas rescisórias
    base_fgts = saldo + (aviso_valor if aviso_previo_indenizado else Decimal("0"))
    fgts_rescisao = (base_fgts * Decimal("0.08")).quantize(CENTAVOS, ROUND_HALF_UP)

    # Multa FGTS 40% (só em dispensa sem justa causa e rescisão indireta)
    multa_fgts = Decimal("0")
    if tipo_rescisao in ("dispensa_sem_justa", "rescisao_indireta"):
        # Estimativa simples do saldo FGTS (8% × salário × meses)
        saldo_fgts_estimado = (salario * Decimal("0.08") * meses_totais).quantize(CENTAVOS, ROUND_HALF_UP)
        multa_fgts = (saldo_fgts_estimado * Decimal("0.40")).quantize(CENTAVOS, ROUND_HALF_UP)

    # Monta o pacote conforme tipo de rescisão
    verbas = {
        "saldo_salario": saldo,
        "ferias_proporcionais": Decimal(ferias_prop["total_bruto"].replace("R$ ","").replace(".","").replace(",",".")),
        "um_terco_ferias_prop": Decimal(ferias_prop["um_terco"].replace("R$ ","").replace(".","").replace(",",".")),
        "ferias_vencidas": ferias_venc_val,
        "decimo_terceiro_prop": Decimal(trec_13["valor_proporcional"].replace("R$ ","").replace(".","").replace(",",".")),
    }

    if tipo_rescisao in ("dispensa_sem_justa", "rescisao_indireta"):
        verbas["aviso_previo_indenizado"] = aviso_valor if aviso_previo_indenizado else Decimal("0")
        verbas["multa_fgts_40pct"] = multa_fgts
    elif tipo_rescisao == "acordo_mutuo":
        verbas["aviso_previo_indenizado"] = (aviso_valor / Decimal("2")).quantize(CENTAVOS, ROUND_HALF_UP)
        verbas["multa_fgts_20pct"] = (multa_fgts / Decimal("2")).quantize(CENTAVOS, ROUND_HALF_UP)
    elif tipo_rescisao == "pedido_demissao":
        pass  # sem aviso e sem multa se cumpriu aviso

    total_bruto = sum(verbas.values()).quantize(CENTAVOS, ROUND_HALF_UP)

    return {
        "tipo_rescisao":   tipo_rescisao,
        "data_admissao":   data_admissao,
        "data_demissao":   data_demissao,
        "anos_servico":    anos,
        "meses_totais":    meses_totais,
        "dias_aviso_previo": dias_aviso,
        "verbas_detalhadas": {k: brl(v) for k, v in verbas.items()},
        "total_bruto":     brl(total_bruto),
        "fundamentacao": (
            "Arts. 477-484-A CLT; Lei 12.506/2011 (aviso proporcional); "
            "Art. 18 Lei 8.036/1990 (multa FGTS); "
            "Art. 7º, XVII CF/88 (férias + 1/3)"
        ),
    }


def calcular_adicional_noturno(
    salario: Decimal,
    horas_normais_mes: Decimal = Decimal("220"),
    horas_noturnas_mes: Decimal = Decimal("0"),
) -> dict:
    """
    Adicional noturno: 20% sobre hora normal (art. 73 CLT).
    Hora noturna reduzida: 52 min 30 seg = 60 × 7/8.
    """
    valor_hora = salario / horas_normais_mes
    hora_noturna_reduzida = (valor_hora * Decimal("60") / Decimal("52.5")).quantize(CENTAVOS, ROUND_HALF_UP)
    adicional = (hora_noturna_reduzida * Decimal("0.20") * horas_noturnas_mes).quantize(CENTAVOS, ROUND_HALF_UP)

    return {
        "valor_hora_normal":      brl(valor_hora.quantize(CENTAVOS, ROUND_HALF_UP)),
        "valor_hora_noturna":     brl(hora_noturna_reduzida),
        "horas_noturnas_mes":     str(horas_noturnas_mes),
        "adicional_noturno_total": brl(adicional),
        "adicional_decimal":      adicional,
        "fundamentacao": "Art. 73 CLT; Súmula 60 TST",
    }
