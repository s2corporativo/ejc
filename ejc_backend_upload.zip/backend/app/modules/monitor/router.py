"""
EJC — Módulo Monitor de Publicações (modules/monitor/router.py)

Monitora publicações em fontes oficiais em busca de nomes de clientes,
número de processos ou palavras-chave do escritório.

Fontes:
  - Diário Oficial da União (DOU) — API in.gov.br
  - TJSP, TJMG, TJRJ — scraping dos diários eletrônicos
  - DataJud CNJ — movimentações de processos monitorados

Scheduler: job diário às 9h (DOU publica entre 8h-9h)
           job a cada 2h para DataJud

Alertas: Telegram + e-mail (usa módulo notificacoes)
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from typing import Optional
from uuid import uuid4

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/monitor", tags=["Monitor de Publicações — DOU & TJs"])

DOU_BASE = "https://www.in.gov.br/servicos/buscar-no-dou"
DOU_API  = "https://www.in.gov.br/servicos/api-dou"

# ── Schemas ─────────────────────────────────────────────────────────

class PalavraChaveCreate(BaseModel):
    termo: str
    tipo: str = "cliente"       # cliente | processo | advogado | assunto
    caso_id: Optional[str] = None
    fontes: list[str] = ["dou"] # dou | tjsp | tjmg | tjrj | datajud
    ativo: bool = True
    notificar_telegram: bool = True
    notificar_email: bool = True
    email_destino: Optional[str] = None


# ── Cliente DOU ──────────────────────────────────────────────────────

async def buscar_dou(
    termo: str,
    data: Optional[str] = None,      # YYYY-MM-DD
    secao: str = "do1,do2,do3,dou_e", # seções do DOU
) -> list[dict]:
    """
    Busca publicações no Diário Oficial da União.
    API pública: https://www.in.gov.br/servicos/api-dou
    """
    data_busca = data or date.today().strftime("%d-%m-%Y")

    params = {
        "q":      f'"{termo}"',
        "s":      secao,
        "data":   data_busca,
        "rows":   50,
        "start":  0,
    }

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            # Tenta a API pública do DOU
            resp = await client.get(
                "https://www.in.gov.br/servicos/buscar-no-dou",
                params=params,
                headers={"Accept": "application/json"},
            )

            if resp.status_code != 200:
                # Fallback: API alternativa
                resp2 = await client.get(
                    f"https://in.gov.br/web/dou/-/busca/-/asset_publisher/o9ADbd7KmNEa/content/"
                    f"?p_p_auth=&p_p_lifecycle=2&p_p_resource_id=v2_buscarListaDeUrlsDoArquivo"
                    f"&_buscaPortlet_WAR_buscaportlet_query={termo}"
                    f"&_buscaPortlet_WAR_buscaportlet_dataPublicacao={data_busca}",
                    timeout=10.0,
                )
                return _parse_dou_fallback(resp2.text, termo)

            data_json = resp.json()
            resultados = data_json.get("results", data_json.get("items", []))

            return [
                {
                    "fonte":      "DOU",
                    "titulo":     r.get("title", r.get("titulo", "")),
                    "resumo":     r.get("abstract", r.get("resumo", ""))[:500],
                    "secao":      r.get("artType", r.get("secao", "")),
                    "data":       r.get("pubDate", data_busca),
                    "url":        r.get("urlTitle", r.get("url", "")),
                    "termo_encontrado": termo,
                }
                for r in resultados
            ]

    except httpx.RequestError as e:
        logger.warning(f"[Monitor] DOU inacessível: {e}")
        return []


def _parse_dou_fallback(html: str, termo: str) -> list[dict]:
    """Parse básico de fallback quando a API não responde."""
    if not html or termo.lower() not in html.lower():
        return []
    # Retorna indicação de que o termo foi encontrado mas detalhes não disponíveis
    return [{
        "fonte": "DOU",
        "titulo": f"Publicação encontrada para: {termo}",
        "resumo": "Detalhes indisponíveis — acesse www.in.gov.br para visualizar",
        "secao": "N/D",
        "data": date.today().isoformat(),
        "url": f"https://www.in.gov.br/busca#/?q={termo.replace(' ','+')}",
        "termo_encontrado": termo,
    }]


async def buscar_tj(tribunal: str, termo: str, data: Optional[str] = None) -> list[dict]:
    """
    Busca no diário eletrônico de um TJ específico.
    Implementado para TJSP (maior volume) via API pública.
    """
    resultados: list[dict] = []

    if tribunal.upper() == "TJSP":
        # TJSP — portal de publicações
        data_busca = data or date.today().strftime("%d/%m/%Y")
        url = (
            f"https://www.dje.tjsp.jus.br/cdje/consultaSimples.do"
            f"?cdVolume=4&uuidCaptcha=sajcaptcha_"
            f"&dtDiario={data_busca}"
            f"&dadosPesquisa.cdOrgaoJgdr=0"
            f"&dadosPesquisa.txtPesquisa={termo}"
        )
        try:
            async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as c:
                resp = await c.get(url)
                if resp.status_code == 200 and termo.lower() in resp.text.lower():
                    resultados.append({
                        "fonte": "TJSP-DJE",
                        "titulo": f"Publicação TJSP para: {termo}",
                        "resumo": "Verificar no portal TJSP",
                        "secao": "DJE",
                        "data": data_busca,
                        "url": url,
                        "termo_encontrado": termo,
                    })
        except httpx.RequestError:
            pass

    elif tribunal.upper() == "TJMG":
        # TJMG — DJEMG
        url = f"https://www4.tjmg.jus.br/juridico/pesquisaPMF/pesquisaPublicacoes.do?palavraChave={termo}"
        try:
            async with httpx.AsyncClient(timeout=10.0) as c:
                resp = await c.get(url)
                if resp.status_code == 200 and termo.lower() in resp.text.lower():
                    resultados.append({
                        "fonte": "TJMG-DJE",
                        "titulo": f"Publicação TJMG para: {termo}",
                        "resumo": "Verificar no portal TJMG",
                        "secao": "DJE",
                        "data": date.today().isoformat(),
                        "url": url,
                        "termo_encontrado": termo,
                    })
        except httpx.RequestError:
            pass

    return resultados


# ── Job do scheduler ─────────────────────────────────────────────────

async def job_monitorar_publicacoes():
    """
    Executado pelo APScheduler às 9h.
    Verifica todos os termos ativos nas fontes configuradas.
    """
    from app.core.database import AsyncSessionLocal
    from app.modules.notificacoes.router import enviar_telegram, enviar_email

    logger.info("[Monitor] Iniciando varredura de publicações...")

    async with AsyncSessionLocal() as db:
        # Busca palavras-chave ativas
        rows = await db.execute(
            text("""
                SELECT id, termo, tipo, fontes, caso_id,
                       notificar_telegram, notificar_email, email_destino
                FROM monitor_palavras_chave
                WHERE ativo = true
            """)
        )
        termos = [dict(r) for r in rows.mappings()]

        encontrados = 0
        for tc in termos:
            termo  = tc["termo"]
            fontes = tc.get("fontes") or ["dou"]

            resultados: list[dict] = []

            if "dou" in fontes:
                dou = await buscar_dou(termo)
                resultados.extend(dou)

            for tj in ["tjsp", "tjmg", "tjrj"]:
                if tj in fontes:
                    r = await buscar_tj(tj.upper(), termo)
                    resultados.extend(r)

            if not resultados:
                continue

            encontrados += len(resultados)

            # Persiste achados
            for r in resultados:
                pub_id = str(uuid4())
                await db.execute(
                    text("""
                        INSERT INTO monitor_publicacoes
                            (id, palavra_chave_id, caso_id, fonte, titulo,
                             resumo, url, data_publicacao)
                        VALUES (:id,:pkid,:cid,:fonte,:titulo,:res,:url,:dp)
                        ON CONFLICT DO NOTHING
                    """),
                    {
                        "id":    pub_id,
                        "pkid":  tc["id"],
                        "cid":   tc.get("caso_id"),
                        "fonte": r["fonte"],
                        "titulo": r["titulo"][:300],
                        "res":   r["resumo"][:1000],
                        "url":   r.get("url", ""),
                        "dp":    r.get("data", date.today().isoformat()),
                    },
                )

            # Notifica
            msg = (
                f"📰 *EJC Monitor — Publicação Encontrada*\n"
                f"Termo: *{termo}* ({tc['tipo']})\n"
                f"Fontes: {len(resultados)} resultado(s)\n"
                f"Data: {date.today().strftime('%d/%m/%Y')}\n\n"
                + "\n".join(
                    f"• [{r['fonte']}] {r['titulo'][:80]}"
                    for r in resultados[:3]
                )
            )

            if tc.get("notificar_telegram"):
                await enviar_telegram(msg)

            if tc.get("notificar_email") and tc.get("email_destino"):
                html = f"<h2>EJC Monitor</h2><p>{msg.replace(chr(10), '<br>')}</p>"
                await enviar_email(tc["email_destino"],
                    f"[EJC] Publicação: {termo} — {date.today()}", html)

        await db.commit()

    logger.info(f"[Monitor] Varredura concluída. {encontrados} publicações encontradas.")


# ── Endpoints ─────────────────────────────────────────────────────────

@router.post("/palavras-chave", status_code=201)
async def cadastrar_palavra_chave(
    req: PalavraChaveCreate, db: AsyncSession = Depends(get_db)
):
    """Cadastra um termo para monitoramento automático."""
    pkid = str(uuid4())
    await db.execute(
        text("""
            INSERT INTO monitor_palavras_chave
                (id, termo, tipo, caso_id, fontes, ativo,
                 notificar_telegram, notificar_email, email_destino)
            VALUES (:id,:termo,:tipo,:cid,:fontes,:ativo,:ntg,:nem,:email)
        """),
        {
            "id":    pkid, "termo": req.termo, "tipo": req.tipo,
            "cid":   req.caso_id, "fontes": req.fontes, "ativo": req.ativo,
            "ntg":   req.notificar_telegram, "nem": req.notificar_email,
            "email": req.email_destino,
        },
    )
    return {
        "id": pkid, "termo": req.termo, "tipo": req.tipo,
        "fontes": req.fontes, "message": "Monitoramento ativado.",
    }


@router.get("/palavras-chave")
async def listar_palavras_chave(db: AsyncSession = Depends(get_db)):
    """Lista todos os termos monitorados."""
    rows = await db.execute(
        text("""
            SELECT pk.*, COUNT(mp.id) AS total_encontrados
            FROM monitor_palavras_chave pk
            LEFT JOIN monitor_publicacoes mp ON mp.palavra_chave_id = pk.id
            GROUP BY pk.id ORDER BY pk.created_at DESC
        """)
    )
    return {"palavras_chave": [dict(r) for r in rows.mappings()]}


@router.get("/publicacoes")
async def listar_publicacoes(
    fonte: Optional[str] = None,
    caso_id: Optional[str] = None,
    dias: int = Query(7, ge=1, le=90),
    db: AsyncSession = Depends(get_db),
):
    """Lista publicações encontradas pelo monitor nos últimos N dias."""
    filtros = ["mp.created_at >= NOW() - INTERVAL ':dias days'"]
    params: dict = {"dias": dias}

    if fonte:
        filtros.append("mp.fonte = :fonte"); params["fonte"] = fonte
    if caso_id:
        filtros.append("mp.caso_id = :cid"); params["cid"] = caso_id

    where = "WHERE " + " AND ".join(filtros)

    rows = await db.execute(
        text(f"""
            SELECT mp.*, pk.termo, pk.tipo
            FROM monitor_publicacoes mp
            JOIN monitor_palavras_chave pk ON pk.id = mp.palavra_chave_id
            {where}
            ORDER BY mp.created_at DESC LIMIT 100
        """),
        params,
    )
    return {"publicacoes": [dict(r) for r in rows.mappings()]}


@router.post("/buscar-agora")
async def buscar_agora(
    payload: dict, db: AsyncSession = Depends(get_db)
):
    """
    Busca imediata por um termo específico (sem aguardar o scheduler).
    """
    termo  = payload.get("termo", "")
    fontes = payload.get("fontes", ["dou"])
    data   = payload.get("data")

    if not termo:
        raise HTTPException(422, "Campo 'termo' obrigatório.")

    resultados: list[dict] = []
    if "dou" in fontes:
        resultados.extend(await buscar_dou(termo, data))
    for tj in ["tjsp", "tjmg", "tjrj"]:
        if tj in fontes:
            resultados.extend(await buscar_tj(tj.upper(), termo, data))

    return {
        "termo": termo,
        "fontes": fontes,
        "data": data or date.today().isoformat(),
        "total": len(resultados),
        "resultados": resultados,
    }


@router.post("/executar-job")
async def executar_job_manual():
    """Força execução imediata do job de monitoramento (normalmente roda às 9h)."""
    await job_monitorar_publicacoes()
    return {"message": "Job de monitoramento executado."}


@router.delete("/palavras-chave/{pkid}")
async def desativar_monitoramento(pkid: str, db: AsyncSession = Depends(get_db)):
    """Desativa um monitoramento (mantém histórico)."""
    await db.execute(
        text("UPDATE monitor_palavras_chave SET ativo=false WHERE id=:id"),
        {"id": pkid},
    )
    return {"message": "Monitoramento desativado."}
