"""
EJC — Router Análise de Documentos (modules/analise/router.py)
"""
from __future__ import annotations

from typing import Optional
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.analise.service import AnaliseService, CHECKLISTS

router = APIRouter(prefix="/analise", tags=["Análise de Documentos"])
_svc: Optional[AnaliseService] = None

def get_svc() -> AnaliseService:
    global _svc
    if not _svc:
        _svc = AnaliseService()
    return _svc


@router.post("/resumo")
async def resumir_documento(
    file: UploadFile = File(...),
    espaco_id: Optional[str] = Form(None),
    para_cliente: bool = Form(False),
    db: AsyncSession = Depends(get_db),
    svc: AnaliseService = Depends(get_svc),
):
    """
    Gera resumo automático de um documento jurídico.
    Com para_cliente=true, usa linguagem acessível ('Entender Mais').
    """
    content = await file.read()
    texto = svc.extrair_texto(content, file.filename)
    if not texto.strip():
        raise HTTPException(422, "Nenhum texto extraído do arquivo.")
    return await svc.resumir_documento(db, texto, file.filename, espaco_id, para_cliente)


@router.post("/referencias")
async def analisar_referencias(
    file: UploadFile = File(...),
    espaco_id: Optional[str] = Form(None),
    db: AsyncSession = Depends(get_db),
    svc: AnaliseService = Depends(get_svc),
):
    """
    Verifica e valida todas as referências legais do documento.
    Equivalente à 'Análise de Referências' do Jus.ia.
    """
    content = await file.read()
    texto = svc.extrair_texto(content, file.filename)
    if not texto.strip():
        raise HTTPException(422, "Nenhum texto extraído.")
    return await svc.analisar_referencias(db, texto, file.filename, espaco_id)


@router.post("/referencias-texto")
async def analisar_referencias_texto(
    payload: dict,
    db: AsyncSession = Depends(get_db),
    svc: AnaliseService = Depends(get_svc),
):
    """Analisa referências de um texto Markdown enviado diretamente."""
    conteudo = payload.get("conteudo", "")
    filename = payload.get("filename", "documento.txt")
    if not conteudo.strip():
        raise HTTPException(422, "Conteúdo vazio.")
    return await svc.analisar_referencias(db, conteudo, filename)


@router.post("/estrategia")
async def analisar_estrategia(
    file: UploadFile = File(...),
    espaco_id: Optional[str] = Form(None),
    db: AsyncSession = Depends(get_db),
    svc: AnaliseService = Depends(get_svc),
):
    """Analisa estratégia, riscos e pontos de melhoria de uma peça jurídica."""
    content = await file.read()
    texto = svc.extrair_texto(content, file.filename)
    return await svc.analisar_estrategia(db, texto, file.filename, espaco_id)


@router.post("/simplificar")
async def simplificar(
    file: UploadFile = File(...),
    espaco_id: Optional[str] = Form(None),
    db: AsyncSession = Depends(get_db),
    svc: AnaliseService = Depends(get_svc),
):
    """
    Converte linguagem jurídica técnica para linguagem acessível ao cliente.
    Recurso 'Entender Mais' + 'Resultados Enriquecidos' do Jus.ia.
    """
    content = await file.read()
    texto = svc.extrair_texto(content, file.filename)
    return await svc.simplificar_para_cliente(db, texto, file.filename, espaco_id)


@router.post("/simplificar-texto")
async def simplificar_texto(payload: dict, db: AsyncSession = Depends(get_db), svc: AnaliseService = Depends(get_svc)):
    """Simplifica um texto Markdown enviado diretamente."""
    conteudo = payload.get("conteudo", "")
    if not conteudo.strip():
        raise HTTPException(422, "Conteúdo vazio.")
    return await svc.simplificar_para_cliente(db, conteudo, "documento")


@router.post("/clausulas")
async def analisar_clausulas(
    file: UploadFile = File(...),
    espaco_id: Optional[str] = Form(None),
    db: AsyncSession = Depends(get_db),
    svc: AnaliseService = Depends(get_svc),
):
    """Analisa cláusulas de contratos: abusivas, ausentes e riscos."""
    content = await file.read()
    texto = svc.extrair_texto(content, file.filename)
    return await svc.analisar_clausulas(db, texto, file.filename, espaco_id)


@router.get("/checklist/tipos")
async def listar_tipos_checklist():
    """Lista os tipos de ação com checklist pré-definido."""
    return {
        "tipos": list(CHECKLISTS.keys()),
        "descricoes": {
            "trabalhista_reclamacao": "Reclamação trabalhista / rescisão",
            "indenizatoria": "Ação de indenização / danos morais",
            "contrato_revisao": "Revisão contratual",
            "previdenciario": "Benefício previdenciário / INSS",
            "consumidor": "Ação consumerista / CDC",
        }
    }


@router.post("/checklist")
async def gerar_checklist(
    payload: dict,
    db: AsyncSession = Depends(get_db),
    svc: AnaliseService = Depends(get_svc),
):
    """
    Gera checklist de documentos necessários para um tipo de ação.
    Recurso do Jus.ia de 'lista de documentos para cada caso'.
    """
    tipo = payload.get("tipo_acao", "")
    fatos = payload.get("fatos_adicionais")
    return await svc.gerar_checklist(db, tipo, fatos)
