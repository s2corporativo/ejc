"""
EJC — Módulo Análise de Documentos (modules/analise/service.py)

Funcionalidades inspiradas no Jus.ia:
  1. Resumo automático de decisões e processos
  2. Análise de referências (verifica se citações existem e estão corretas)
  3. Extração de estratégia jurídica
  4. Identificação de riscos
  5. Checklist de documentos necessários por tipo de ação
  6. Análise de cláusulas contratuais
  7. Simplificação da linguagem jurídica para cliente
"""
from __future__ import annotations

import io
import logging
from typing import Optional
from uuid import uuid4

import PyPDF2
from docx import Document as DocxDocument
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.redacao.service import LegalDraftService
from app.modules.validacao.validator import LegalValidator

logger = logging.getLogger(__name__)

# Checklists de documentos necessários por tipo de ação
# Inspirado na funcionalidade do Jus.ia de gerar listas de documentos
CHECKLISTS: dict[str, list[str]] = {
    "trabalhista_reclamacao": [
        "Carteira de Trabalho (CTPS) — todas as páginas",
        "Contrato de trabalho (se existente)",
        "Holerites / contracheques dos últimos 3 anos",
        "Extrato FGTS completo",
        "Termo de rescisão (TRCT) ou comunicado de dispensa",
        "Comprovante de seguro-desemprego (se solicitado)",
        "Documentos de identidade (RG/CPF)",
        "Comprovante de residência",
        "Ponto eletrônico ou cartão de ponto (se houver)",
        "E-mails e mensagens relevantes (capturas de tela)",
        "Testemunhas (nome e contato — mínimo 2)",
    ],
    "indenizatoria": [
        "Documentos que comprovem o dano sofrido",
        "Boletim de ocorrência (se for o caso)",
        "Laudos médicos, psicológicos ou periciais",
        "Orçamentos e notas fiscais de gastos",
        "Documentos de identidade (RG/CPF)",
        "Comprovante de residência",
        "Fotografias ou vídeos como evidências",
        "Testemunhas (nome e contato)",
    ],
    "contrato_revisao": [
        "Contrato original completo e assinado",
        "Aditivos e modificações contratuais",
        "Comprovantes de pagamento realizados",
        "Notificações ou comunicações entre as partes",
        "Documentos de identidade de ambas as partes",
        "CNPJ e contrato social (se pessoa jurídica)",
        "Extratos bancários relevantes",
    ],
    "previdenciario": [
        "CNIS — Cadastro Nacional de Informações Sociais",
        "Carteira de Trabalho completa",
        "Carta de indeferimento do INSS (se houver)",
        "Laudos e relatórios médicos (se incapacidade)",
        "Documentos de identidade",
        "CPF",
        "Comprovante de residência",
        "Declarações de contribuições avulsas (se houver)",
    ],
    "consumidor": [
        "Nota fiscal ou comprovante de compra",
        "Contrato de prestação de serviço",
        "Fotos e vídeos do produto com defeito",
        "Protocolos de reclamação (SAC, Procon, Reclame Aqui)",
        "E-mails, mensagens e respostas da empresa",
        "Laudos técnicos (se produto complexo)",
        "Comprovante de tentativa de resolução extrajudicial",
    ],
}


class AnaliseService:
    """
    Serviço de análise inteligente de documentos jurídicos.
    """

    def __init__(self):
        self._llm       = LegalDraftService()
        self._validator = LegalValidator()

    # ──────────────────────────────────────────────────────────────────────
    # 1. RESUMO AUTOMÁTICO
    # ──────────────────────────────────────────────────────────────────────

    async def resumir_documento(
        self,
        db: AsyncSession,
        conteudo: str,
        filename: str,
        espaco_id: Optional[str] = None,
        para_cliente: bool = False,
    ) -> dict:
        """
        Gera resumo executivo de um documento jurídico.
        Se para_cliente=True, usa linguagem acessível (feature 'Entender Mais').
        """
        instrucao = (
            "Resuma este documento em linguagem simples e acessível para o cliente, "
            "evitando termos técnicos. Use bullet points claros."
            if para_cliente else
            "Faça um resumo técnico executivo deste documento para uso do advogado. "
            "Identifique: partes, objeto, fatos principais, pedidos/decisão, "
            "pontos críticos e prazos relevantes."
        )

        prompt = f"""{instrucao}

DOCUMENTO ({filename}):
{conteudo[:8000]}

Formato de saída:
## Resumo Executivo
[resumo em 3-5 parágrafos]

## Pontos Principais
- [lista de pontos]

## Alertas / Prazos
- [datas ou alertas importantes, se houver]"""

        resultado = await self._llm.answer_from_context(
            query=instrucao, context=conteudo[:8000]
        )

        # Extrai referências legais presentes no documento
        refs = self._validator._extract_references(conteudo)

        analise_id = await self._persistir_analise(
            db, espaco_id, filename, "resumo", conteudo, resultado,
            [{"tipo": r["type"], "referencia": r["reference"]} for r in refs]
        )

        return {
            "analise_id": analise_id,
            "filename": filename,
            "tipo": "resumo",
            "para_cliente": para_cliente,
            "resultado_md": resultado,
            "referencias_encontradas": len(refs),
        }

    # ──────────────────────────────────────────────────────────────────────
    # 2. ANÁLISE DE REFERÊNCIAS (feature central do Jus.ia)
    # ──────────────────────────────────────────────────────────────────────

    async def analisar_referencias(
        self, db: AsyncSession, conteudo: str, filename: str,
        espaco_id: Optional[str] = None,
    ) -> dict:
        """
        Verifica se todas as referências legais (leis, artigos, jurisprudências)
        citadas no documento existem, são vigentes e estão sendo usadas
        corretamente no contexto.

        Funcionalidade equivalente à 'Análise de Referências' do Jus.ia.
        """
        # Extrai referências
        refs = self._validator._extract_references(conteudo)

        # Valida vigência de cada uma
        validacao = await self._validator.validate(conteudo)

        # Solicita ao LLM verificação de uso correto no contexto
        referencias_texto = "\n".join(
            f"- {r['reference']} ({r['type']})" for r in refs
        )
        prompt = f"""Analise se as referências legais abaixo estão sendo usadas
CORRETAMENTE no contexto do documento. Para cada uma, indique se o uso
está adequado, se há erro de aplicação, ou se o argumento poderia ser
fortalecido com outras citações.

REFERÊNCIAS ENCONTRADAS:
{referencias_texto if referencias_texto else 'Nenhuma referência legal encontrada.'}

TRECHO DO DOCUMENTO:
{conteudo[:4000]}

Responda em Markdown com análise por referência."""

        analise_uso = await self._llm.answer_from_context(
            query="análise de referências legais", context=conteudo[:4000]
        )

        resultado = {
            "filename": filename,
            "total_referencias": len(refs),
            "referencias_vigentes": sum(
                1 for r in validacao["references_found"] if r["status"] == "vigente"
            ),
            "referencias_problematicas": [
                r for r in validacao["references_found"]
                if r["status"] in ("revogado", "nao_verificado")
            ],
            "score_confiabilidade": validacao["validation_score"],
            "warnings": validacao["warnings"],
            "analise_uso_md": analise_uso,
            "referencias_detalhadas": validacao["references_found"],
        }

        await self._persistir_analise(
            db, espaco_id, filename, "referencias", conteudo,
            analise_uso, validacao["references_found"],
            score=validacao["validation_score"]
        )

        return resultado

    # ──────────────────────────────────────────────────────────────────────
    # 3. ANÁLISE DE ESTRATÉGIA E RISCOS
    # ──────────────────────────────────────────────────────────────────────

    async def analisar_estrategia(
        self, db: AsyncSession, conteudo: str, filename: str,
        espaco_id: Optional[str] = None,
    ) -> dict:
        """
        Analisa o documento e sugere estratégias jurídicas,
        identifica riscos e pontos de melhoria na argumentação.
        """
        prompt = f"""Analise este documento jurídico como um advogado sênior experiente.
Identifique:

1. **Pontos fortes** da argumentação atual
2. **Riscos e vulnerabilidades** que o oponente pode explorar
3. **Argumentos faltantes** que fortaleceriam a peça
4. **Estratégia recomendada** para o caso
5. **Precedentes adicionais** que deveriam ser citados

DOCUMENTO:
{conteudo[:6000]}"""

        resultado = await self._llm.answer_from_context(
            query="análise estratégica do documento", context=conteudo[:6000]
        )

        await self._persistir_analise(
            db, espaco_id, filename, "estrategia", conteudo, resultado
        )

        return {"filename": filename, "tipo": "estrategia", "resultado_md": resultado}

    # ──────────────────────────────────────────────────────────────────────
    # 4. SIMPLIFICAÇÃO PARA CLIENTE (feature 'Entender Mais' do Jus.ia)
    # ──────────────────────────────────────────────────────────────────────

    async def simplificar_para_cliente(
        self, db: AsyncSession, conteudo: str, filename: str,
        espaco_id: Optional[str] = None,
    ) -> dict:
        """
        Converte linguagem jurídica técnica em linguagem acessível
        para o cliente leigo entender o documento.

        Equivalente ao 'Entender Mais' do Jus.ia + 'Resultados Enriquecidos'.
        """
        prompt = f"""Você é um advogado explicando para seu cliente leigo o conteúdo
deste documento. Use linguagem simples, sem jargão jurídico.
Explique: o que aconteceu, o que está sendo pedido, o que isso significa
para o cliente e quais são os próximos passos possíveis.

DOCUMENTO JURÍDICO:
{conteudo[:5000]}

Use parágrafos curtos. Evite completamente termos como 'arguição',
'exordial', 'hodiernamente', 'questionar' no sentido técnico etc.
Quando precisar de termo técnico, explique entre parênteses."""

        resultado = await self._llm.answer_from_context(
            query="simplificar linguagem jurídica", context=conteudo[:5000]
        )

        await self._persistir_analise(
            db, espaco_id, filename, "simplificacao", conteudo, resultado
        )

        return {
            "filename": filename,
            "tipo": "simplificacao",
            "resultado_md": resultado,
            "nota": "Versão simplificada para envio ao cliente",
        }

    # ──────────────────────────────────────────────────────────────────────
    # 5. CHECKLIST DE DOCUMENTOS NECESSÁRIOS
    # ──────────────────────────────────────────────────────────────────────

    async def gerar_checklist(
        self, db: AsyncSession, tipo_acao: str,
        fatos_adicionais: Optional[str] = None,
    ) -> dict:
        """
        Gera lista completa de documentos necessários para a ação.
        Baseado em checklists pré-definidos + personalização via LLM.
        """
        base = CHECKLISTS.get(tipo_acao, [])

        if fatos_adicionais and fatos_adicionais.strip():
            prompt = f"""Com base nos fatos a seguir, complemente a lista de documentos
necessários para a ação '{tipo_acao}'. Adicione apenas itens não óbvios
e específicos para este caso.

FATOS:
{fatos_adicionais}

LISTA BASE JÁ INCLUÍDA:
{chr(10).join('- ' + i for i in base)}

Adicione apenas novos itens relevantes para o caso específico."""

            complemento = await self._llm.answer_from_context(
                query="checklist de documentos", context=fatos_adicionais
            )
        else:
            complemento = None

        return {
            "tipo_acao": tipo_acao,
            "documentos_base": base,
            "documentos_especificos": complemento,
            "total_base": len(base),
        }

    # ──────────────────────────────────────────────────────────────────────
    # 6. ANÁLISE DE CLÁUSULAS CONTRATUAIS
    # ──────────────────────────────────────────────────────────────────────

    async def analisar_clausulas(
        self, db: AsyncSession, conteudo: str, filename: str,
        espaco_id: Optional[str] = None,
    ) -> dict:
        """
        Analisa cláusulas de contratos, identificando:
        - Cláusulas abusivas (CDC)
        - Desequilíbrio contratual
        - Ausência de cláusulas essenciais
        - Riscos para a parte representada
        """
        prompt = f"""Analise este contrato como especialista em Direito Contratual.
Identifique:

## Cláusulas Problemáticas
[liste cláusulas abusivas, ilegais ou desvantajosas — cite o número]

## Cláusulas Ausentes
[o que deveria constar e não consta]

## Risco Geral: [BAIXO/MÉDIO/ALTO/CRÍTICO]

## Recomendações
[sugestões de negociação ou ajuste]

CONTRATO:
{conteudo[:7000]}"""

        resultado = await self._llm.answer_from_context(
            query="análise de cláusulas contratuais", context=conteudo[:7000]
        )

        await self._persistir_analise(
            db, espaco_id, filename, "clausulas", conteudo, resultado
        )

        return {"filename": filename, "tipo": "clausulas", "resultado_md": resultado}

    # ──────────────────────────────────────────────────────────────────────
    # EXTRAÇÃO DE TEXTO
    # ──────────────────────────────────────────────────────────────────────

    def extrair_texto(self, file_bytes: bytes, filename: str) -> str:
        """Extrai texto de PDF, DOCX ou TXT."""
        ext = filename.lower().rsplit(".", 1)[-1]
        if ext == "pdf":
            reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
            return "\n\n".join(
                p.extract_text() or "" for p in reader.pages
            ).strip()
        elif ext in ("docx", "doc"):
            doc = DocxDocument(io.BytesIO(file_bytes))
            return "\n\n".join(p.text.strip() for p in doc.paragraphs if p.text.strip())
        else:
            return file_bytes.decode("utf-8", errors="replace")

    # ── Persistência ──────────────────────────────────────────────────────

    async def _persistir_analise(
        self,
        db: AsyncSession,
        espaco_id: Optional[str],
        filename: str,
        tipo: str,
        conteudo: str,
        resultado: str,
        insights: Optional[list] = None,
        score: Optional[float] = None,
    ) -> str:
        aid = str(uuid4())
        await db.execute(
            text("""
                INSERT INTO analises_documentos
                    (id, espaco_id, filename, tipo_analise,
                     conteudo_original, resultado_md, insights, score_confianca)
                VALUES (:id, :eid, :fn, :tipo, :orig, :res, :ins::jsonb, :score)
            """),
            {
                "id": aid, "eid": espaco_id, "fn": filename, "tipo": tipo,
                "orig": conteudo[:5000], "res": resultado,
                "ins": str(insights or []), "score": score,
            },
        )
        return aid
