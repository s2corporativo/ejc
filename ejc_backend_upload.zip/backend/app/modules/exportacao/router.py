"""
EJC — Módulo Exportação (modules/exportacao/router.py)

Exporta peças jurídicas para DOCX e PDF profissionais:
  - DOCX com formatação jurídica (margens, fonte, numeração)
  - PDF via WeasyPrint (CSS → PDF) ou docx2pdf
  - QR Code embutido no rodapé (Visual Law)
  - Template profissional com cabeçalho e rodapé do escritório
"""
from __future__ import annotations

import io
import base64
import logging
import re
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.auditoria.middleware import auditar

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/exportacao", tags=["Exportação DOCX/PDF"])


def _markdown_para_paragrafos(md: str) -> list[dict]:
    """Converte Markdown jurídico em lista de parágrafos com tipo."""
    paragrafos = []
    for linha in md.split("\n"):
        linha = linha.rstrip()
        if linha.startswith("# "):
            paragrafos.append({"tipo": "titulo1", "texto": linha[2:]})
        elif linha.startswith("## "):
            paragrafos.append({"tipo": "titulo2", "texto": linha[3:]})
        elif linha.startswith("### "):
            paragrafos.append({"tipo": "titulo3", "texto": linha[4:]})
        elif linha.startswith("- ") or linha.startswith("* "):
            paragrafos.append({"tipo": "bullet", "texto": linha[2:]})
        elif linha.strip():
            # Remove marcadores Markdown
            texto = re.sub(r"\*\*(.+?)\*\*", r"\1", linha)
            texto = re.sub(r"\*(.+?)\*", r"\1", texto)
            texto = re.sub(r"__(.+?)__", r"\1", texto)
            paragrafos.append({"tipo": "normal", "texto": texto})
    return [p for p in paragrafos if p["texto"].strip()]


def _gerar_docx(
    titulo: str,
    conteudo_md: str,
    qr_base64: Optional[str] = None,
) -> bytes:
    """Gera arquivo DOCX com formatação jurídica profissional."""
    try:
        from docx import Document
        from docx.shared import Pt, Cm, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement
        import qrcode

        doc = Document()

        # ── Configuração de página (margens ABNT) ──
        section = doc.sections[0]
        section.top_margin    = Cm(3)
        section.bottom_margin = Cm(2)
        section.left_margin   = Cm(3)
        section.right_margin  = Cm(2)

        # ── Estilos ──
        styles = doc.styles
        normal = styles["Normal"]
        normal.font.name = "Arial"
        normal.font.size = Pt(12)

        # ── Título ──
        h = doc.add_heading(titulo, level=0)
        h.alignment = WD_ALIGN_PARAGRAPH.CENTER
        h.runs[0].font.color.rgb = RGBColor(0x0D, 0x11, 0x17)

        doc.add_paragraph("")  # espaço

        # ── Conteúdo ──
        paragrafos = _markdown_para_paragrafos(conteudo_md)
        for p in paragrafos:
            if p["tipo"] == "titulo1":
                par = doc.add_heading(p["texto"], level=1)
                par.runs[0].font.size = Pt(14)
                par.runs[0].bold = True
            elif p["tipo"] == "titulo2":
                par = doc.add_heading(p["texto"], level=2)
                par.runs[0].font.size = Pt(12)
                par.runs[0].bold = True
            elif p["tipo"] == "titulo3":
                par = doc.add_heading(p["texto"], level=3)
                par.runs[0].font.size = Pt(11)
                par.runs[0].italic = True
            elif p["tipo"] == "bullet":
                doc.add_paragraph(p["texto"], style="List Bullet")
            else:
                par = doc.add_paragraph(p["texto"])
                par.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                par.paragraph_format.first_line_indent = Cm(1.25)
                par.paragraph_format.space_after = Pt(6)

        # ── QR Code no rodapé (Visual Law) ──
        if qr_base64:
            doc.add_page_break()
            rodape = doc.sections[0].footer
            rp = rodape.paragraphs[0] if rodape.paragraphs else rodape.add_paragraph()
            rp.alignment = WD_ALIGN_PARAGRAPH.CENTER
            rp.add_run("Documento gerado pelo EJC — Ecossistema Jurídico Clovis | IA Local | LGPD Compliant")
            img_data = base64.b64decode(qr_base64)
            run = doc.add_paragraph().add_run()
            run.add_picture(io.BytesIO(img_data), width=Cm(3))

        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue()

    except ImportError as e:
        raise RuntimeError(f"Dependência não instalada: {e}. Execute: pip install python-docx")


def _gerar_qrcode(conteudo: str) -> str:
    """Gera QR Code e retorna como base64 PNG. Usa Pillow (qrcode[pil])."""
    try:
        import qrcode
        qr_obj = qrcode.QRCode(version=1, box_size=10, border=4)
        qr_obj.add_data(conteudo)
        qr_obj.make(fit=True)
        img = qr_obj.make_image(fill_color="black", back_color="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode()
    except ImportError as e:
        logger.warning(f"[QRCode] Dependência ausente ({e}). Execute: pip install 'qrcode[pil]' Pillow")
        return ""
    except Exception as e:
        logger.warning(f"[QRCode] Erro ao gerar: {e}")
        return ""


@router.get("/{doc_id}/docx")
async def exportar_docx(
    doc_id: str,
    incluir_qrcode: bool = True,
    db: AsyncSession = Depends(get_db),
):
    """
    Exporta uma peça jurídica como arquivo DOCX com formatação profissional.
    Inclui QR Code de validação no rodapé se incluir_qrcode=true (Visual Law).
    """
    row = await db.execute(
        text("SELECT title, content_md, document_type FROM legal_documents WHERE id=:id"),
        {"id": doc_id},
    )
    doc = row.mappings().first()
    if not doc:
        raise HTTPException(404, "Documento não encontrado.")

    qr_b64 = None
    if incluir_qrcode:
        # QR Code aponta para URL de validação do documento
        qr_content = f"EJC-DOC:{doc_id}|TIPO:{doc['document_type']}|VALIDAR:ejc.escritorio.com.br/validar/{doc_id}"
        qr_b64 = _gerar_qrcode(qr_content)

        # Persiste QR Code no banco
        await db.execute(
            text("""
                INSERT INTO qrcodes_gerados (id, documento_id, tipo, conteudo, qr_base64)
                VALUES (gen_random_uuid(), :did, 'validacao', :conteudo, :qr)
                ON CONFLICT DO NOTHING
            """),
            {"did": doc_id, "conteudo": qr_content, "qr": qr_b64},
        )

    try:
        docx_bytes = _gerar_docx(doc["title"], doc["content_md"], qr_b64)
    except RuntimeError as e:
        raise HTTPException(503, str(e))

    await auditar(db, "EXPORTAR_DOCX", "legal_documents", doc_id)

    filename = doc["title"][:50].replace(" ", "_").replace("/", "-") + ".docx"
    return StreamingResponse(
        io.BytesIO(docx_bytes),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/{doc_id}/pdf")
async def exportar_pdf(doc_id: str, db: AsyncSession = Depends(get_db)):
    """
    Exporta peça jurídica como PDF via conversão DOCX→PDF.
    Requer LibreOffice instalado no container.
    """
    import subprocess, tempfile, os

    row = await db.execute(
        text("SELECT title, content_md, document_type FROM legal_documents WHERE id=:id"),
        {"id": doc_id},
    )
    doc = row.mappings().first()
    if not doc:
        raise HTTPException(404, "Documento não encontrado.")

    try:
        docx_bytes = _gerar_docx(doc["title"], doc["content_md"])
    except RuntimeError as e:
        raise HTTPException(503, str(e))

    # Converte DOCX → PDF via LibreOffice
    with tempfile.TemporaryDirectory() as tmpdir:
        docx_path = os.path.join(tmpdir, "doc.docx")
        pdf_path  = os.path.join(tmpdir, "doc.pdf")

        with open(docx_path, "wb") as f:
            f.write(docx_bytes)

        result = subprocess.run(
            ["libreoffice", "--headless", "--convert-to", "pdf",
             "--outdir", tmpdir, docx_path],
            capture_output=True, timeout=30
        )

        if result.returncode != 0 or not os.path.exists(pdf_path):
            raise HTTPException(503,
                "Conversão PDF falhou. Instale o LibreOffice no container backend.")

        with open(pdf_path, "rb") as f:
            pdf_bytes = f.read()

    await auditar(db, "EXPORTAR_PDF", "legal_documents", doc_id)
    filename = doc["title"][:50].replace(" ", "_") + ".pdf"
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/{doc_id}/qrcode")
async def gerar_qrcode_documento(doc_id: str, db: AsyncSession = Depends(get_db)):
    """Gera e retorna QR Code PNG para validação do documento (Visual Law)."""
    row = await db.execute(
        text("SELECT title FROM legal_documents WHERE id=:id"), {"id": doc_id}
    )
    doc = row.mappings().first()
    if not doc:
        raise HTTPException(404, "Documento não encontrado.")

    conteudo = f"EJC-VALIDACAO:{doc_id}|DOC:{doc['title'][:50]}"
    qr_b64 = _gerar_qrcode(conteudo)

    if not qr_b64:
        raise HTTPException(503, "qrcode não instalado. Execute: pip install qrcode[pil]")

    qr_bytes = base64.b64decode(qr_b64)
    return StreamingResponse(io.BytesIO(qr_bytes), media_type="image/png")


# ══════════════════════════════════════════════════════════════════════════
# EXPORTAÇÃO DE PETIÇÕES DE PEDIDOS PÚBLICOS
# ══════════════════════════════════════════════════════════════════════════

@router.get("/pedido/{pedido_id}/docx")
async def exportar_peticao_docx(
    pedido_id: str,
    token_acesso: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """
    Exporta a petição de um pedido público como DOCX formatado.
    Requer token_acesso do pedido OU autenticação admin.
    Inclui: cabeçalho jurídico, corpo formatado, QR Code de validação.
    """
    # Busca o pedido (com ou sem token)
    if token_acesso:
        row = await db.execute(text("""
            SELECT id, numero, cliente_nome, cliente_estado, area_juridica,
                   tipo_documento, objetivo, peticao_md, instrucoes_md, status
            FROM pedidos WHERE id=:id AND token_acesso=:t
        """), {"id": pedido_id, "t": token_acesso})
    else:
        row = await db.execute(text("""
            SELECT id, numero, cliente_nome, cliente_estado, area_juridica,
                   tipo_documento, objetivo, peticao_md, instrucoes_md, status
            FROM pedidos WHERE id=:id
        """), {"id": pedido_id})

    p = row.mappings().first()
    if not p:
        raise HTTPException(404, "Pedido não encontrado ou acesso negado")
    if not p["peticao_md"]:
        raise HTTPException(400, "Petição ainda não foi gerada para este pedido")
    if p["status"] not in ("pronto", "entregue", "pago"):
        raise HTTPException(400, f"Pedido em status '{p['status']}' — aguarde a geração")

    titulo = f"Petição {p['area_juridica']} — {p['cliente_nome']}"
    md = p["peticao_md"]

    qr_content = f"EJC-PEDIDO:{p['numero']}|CLIENTE:{p['cliente_nome']}|VALIDAR:ejc.com.br/validar/{pedido_id}"
    qr_b64 = _gerar_qrcode(qr_content)

    try:
        docx_bytes = _gerar_docx(titulo, md, qr_b64)
    except RuntimeError as e:
        raise HTTPException(503, str(e))

    # Marca como entregue
    await db.execute(text("""
        UPDATE pedidos SET status='entregue', entregue_em=NOW()
        WHERE id=:id AND status='pronto'
    """), {"id": pedido_id})
    await db.commit()

    filename = f"peticao_{p['numero']}_{p['cliente_nome'][:20].replace(' ', '_')}.docx"
    return StreamingResponse(
        io.BytesIO(docx_bytes),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/rascunho/docx")
async def exportar_rascunho_docx(payload: dict):
    """
    Exporta qualquer texto Markdown como DOCX.
    Útil para advogados exportarem petições do chat, cálculos ou relatórios.
    """
    titulo = payload.get("titulo", "Documento Jurídico")
    md = payload.get("conteudo_md", "")
    if not md:
        raise HTTPException(422, "conteudo_md é obrigatório")

    try:
        docx_bytes = _gerar_docx(titulo, md, None)
    except RuntimeError as e:
        raise HTTPException(503, str(e))

    filename = titulo[:50].replace(" ", "_") + ".docx"
    return StreamingResponse(
        io.BytesIO(docx_bytes),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
