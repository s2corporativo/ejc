"""
EJC — Onboarding de Usuários (módulo onboarding/router.py)

Wizard de 4 steps para novos advogados/usuários:
  Step 1: Bem-vindo — overview do sistema
  Step 2: Cadastrar primeiro processo para monitorar
  Step 3: Configurar notificação Telegram
  Step 4: Fazer primeira simulação tributária ou cálculo

Endpoints:
  GET  /onboarding/status      — retorna step atual + % conclusão
  POST /onboarding/step/{n}    — marca step como concluído
  POST /onboarding/ignorar     — pula o onboarding
  GET  /onboarding/checklist   — retorna checklist de configuração do escritório
"""
from __future__ import annotations

import json
import logging
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/onboarding", tags=["Onboarding"])


STEPS = [
    {
        "numero": 1,
        "titulo": "Bem-vindo ao EJC",
        "descricao": "Conheça as principais funcionalidades do sistema",
        "icone": "🎯",
        "acao": None,
        "rota": None,
    },
    {
        "numero": 2,
        "titulo": "Monitorar um processo",
        "descricao": "Cadastre o número CNJ de um processo para receber alertas de novas movimentações",
        "icone": "⚖️",
        "acao": "Cadastrar processo",
        "rota": "/monitor",
    },
    {
        "numero": 3,
        "titulo": "Configurar notificações",
        "descricao": "Conecte seu Telegram para receber alertas em tempo real quando houver movimentações",
        "icone": "🔔",
        "acao": "Configurar Telegram",
        "rota": "/configuracoes",
        "instrucao": "Em Integrações → Telegram → informe seu Chat ID. Use @userinfobot para descobrir seu ID.",
    },
    {
        "numero": 4,
        "titulo": "Explorar as calculadoras",
        "descricao": "Calcule verbas trabalhistas, aposentadoria, atualização monetária e muito mais",
        "icone": "🧮",
        "acao": "Acessar calculadoras",
        "rota": "/calculos",
    },
]


async def _get_usuario_id(authorization: Optional[str] = Header(None)) -> Optional[str]:
    """Extrai user_id do token JWT — simplificado para não depender do módulo auth."""
    if not authorization or not authorization.startswith("Bearer "):
        return None
    try:
        import os, jwt as pyjwt
        token = authorization.split(" ")[1]
        secret = os.getenv("JWT_SECRET", "ejc_secret_dev")
        payload = pyjwt.decode(token, secret, algorithms=["HS256"])
        return str(payload.get("sub", ""))
    except Exception:
        return None


@router.get("/status")
async def status_onboarding(
    authorization: Optional[str] = Header(None),
    db: AsyncSession = Depends(get_db),
):
    """Retorna status atual do onboarding do usuário."""
    usuario_id = await _get_usuario_id(authorization)
    if not usuario_id:
        return {"ativo": False, "motivo": "não autenticado"}

    row = await db.execute(
        text("SELECT * FROM onboarding_usuarios WHERE usuario_id=:uid"),
        {"uid": usuario_id},
    )
    ob = row.mappings().first()

    if not ob:
        # Primeira vez — cria registro
        await db.execute(text("""
            INSERT INTO onboarding_usuarios (usuario_id)
            VALUES (:uid) ON CONFLICT DO NOTHING
        """), {"uid": usuario_id})
        await db.commit()
        steps_completos = []
        step_atual = 1
        concluido = False
        ignorado = False
    else:
        steps_completos = ob["steps_completos"] or []
        step_atual = ob["step_atual"]
        concluido = ob["concluido"]
        ignorado = ob["ignorado"]

    total = len(STEPS)
    feitos = len(steps_completos)
    percentual = int(feitos / total * 100)

    return {
        "ativo": not concluido and not ignorado,
        "step_atual": step_atual,
        "steps_completos": steps_completos,
        "percentual_conclusao": percentual,
        "concluido": concluido,
        "ignorado": ignorado,
        "steps": [
            {
                **s,
                "concluido": s["numero"] in steps_completos,
                "atual": s["numero"] == step_atual,
            }
            for s in STEPS
        ],
    }


@router.post("/step/{numero}")
async def concluir_step(
    numero: int,
    authorization: Optional[str] = Header(None),
    db: AsyncSession = Depends(get_db),
):
    """Marca um step como concluído e avança para o próximo."""
    usuario_id = await _get_usuario_id(authorization)
    if not usuario_id:
        raise HTTPException(401, "Autenticação necessária")

    if numero < 1 or numero > len(STEPS):
        raise HTTPException(422, f"Step inválido (1-{len(STEPS)})")

    row = await db.execute(
        text("SELECT steps_completos, step_atual FROM onboarding_usuarios WHERE usuario_id=:uid"),
        {"uid": usuario_id},
    )
    ob = row.mappings().first()

    steps_completos = list(ob["steps_completos"] or []) if ob else []

    if numero not in steps_completos:
        steps_completos.append(numero)

    proximo_step = numero + 1
    concluido = len(steps_completos) >= len(STEPS)

    await db.execute(text("""
        INSERT INTO onboarding_usuarios (usuario_id, steps_completos, step_atual, concluido)
        VALUES (:uid, :sc::jsonb, :sa, :conc)
        ON CONFLICT (usuario_id) DO UPDATE
          SET steps_completos=:sc::jsonb,
              step_atual=:sa,
              concluido=:conc,
              updated_at=NOW()
    """), {
        "uid": usuario_id,
        "sc": json.dumps(steps_completos),
        "sa": proximo_step if not concluido else len(STEPS),
        "conc": concluido,
    })
    await db.commit()

    return {
        "step": numero,
        "concluido": True,
        "proximo_step": proximo_step if not concluido else None,
        "onboarding_completo": concluido,
        "mensagem": "🎉 Onboarding concluído!" if concluido else f"Step {numero} concluído!",
    }


@router.post("/ignorar")
async def ignorar_onboarding(
    authorization: Optional[str] = Header(None),
    db: AsyncSession = Depends(get_db),
):
    """Permite que o usuário pule o onboarding."""
    usuario_id = await _get_usuario_id(authorization)
    if not usuario_id:
        raise HTTPException(401, "Autenticação necessária")

    await db.execute(text("""
        INSERT INTO onboarding_usuarios (usuario_id, ignorado)
        VALUES (:uid, TRUE)
        ON CONFLICT (usuario_id) DO UPDATE SET ignorado=TRUE, updated_at=NOW()
    """), {"uid": usuario_id})
    await db.commit()

    return {"ignorado": True}


@router.get("/checklist")
async def checklist_escritorio():
    """
    Retorna checklist de configuração recomendada para o escritório.
    Independente de autenticação — é informativo.
    """
    return {
        "titulo": "Checklist de Configuração do Escritório",
        "itens": [
            {
                "categoria": "Essencial",
                "itens": [
                    {"titulo": "Configurar variáveis de ambiente (.env)", "feito": False,
                     "instrucao": "LLM_PROVIDER, GROQ_API_KEY ou OLLAMA_URL"},
                    {"titulo": "Configurar SMTP para envio de e-mails", "feito": False,
                     "instrucao": "SMTP_HOST, SMTP_USER, SMTP_PASS, FROM_EMAIL"},
                    {"titulo": "Configurar Mercado Pago", "feito": False,
                     "instrucao": "MP_ACCESS_TOKEN, MP_WEBHOOK_SECRET, APP_BASE_URL"},
                ]
            },
            {
                "categoria": "Monitoramento",
                "itens": [
                    {"titulo": "Cadastrar processos para monitorar", "feito": False,
                     "rota": "/monitor", "instrucao": "Painel Monitor → Adicionar processo (número CNJ)"},
                    {"titulo": "Configurar Telegram para alertas", "feito": False,
                     "instrucao": "TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID no .env"},
                ]
            },
            {
                "categoria": "Corpus Jurídico",
                "itens": [
                    {"titulo": "Ingerir corpus jurídico (RAG)", "feito": False,
                     "instrucao": "docker exec ejc_backend python scripts/ingerir_corpus_juridico.py"},
                    {"titulo": "Executar seed de súmulas", "feito": False,
                     "instrucao": "docker exec ejc_db psql -U ejc_user -d ejc_db -f /app/sql/seed_sumulas.sql"},
                ]
            },
        ]
    }
