"""
EJC — Painel de Revisão Admin (revisao/router.py)

O admin revisa cada petição gerada antes de enviar ao cliente.

Ações disponíveis:
  aprovar        → envia a petição por e-mail + DOCX ao cliente
  editar         → admin edita o texto antes de aprovar
  indicar_advogado → reembolsa + e-mail ofertando serviços do escritório
  solicitar_info → pausa + pede mais detalhes ao cliente por e-mail
  rejeitar       → cancela sem reembolso automático (com nota)
  reembolsar     → cancela + reembolso (via MP ou manual)

Segurança: todos os endpoints requerem header X-Admin-Key.
"""
from __future__ import annotations

import logging
import os
import secrets
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/admin/revisao", tags=["Admin — Revisão de Pedidos"])

ADMIN_KEY = os.getenv("ADMIN_API_KEY", "ejc_admin_dev_key")


def _verificar_admin(x_admin_key: str = Header(...)):
    if x_admin_key != ADMIN_KEY:
        raise HTTPException(403, "Acesso negado")
    return True


# ── Schemas ───────────────────────────────────────────────────────────────

class AprovarReq(BaseModel):
    peticao_editada: Optional[str] = None  # se None, usa a gerada
    nota_interna: Optional[str] = None


class IndicarAdvogadoReq(BaseModel):
    motivo: str
    reembolsar: bool = True
    # Configurações do escritório (padrão do .env, mas pode sobrescrever)
    nome_escritorio: Optional[str] = None
    whatsapp: Optional[str] = None
    link_agenda: Optional[str] = None


class SolicitarInfoReq(BaseModel):
    pergunta: str
    nota_interna: Optional[str] = None


class RejeitarReq(BaseModel):
    motivo: str
    reembolsar: bool = False


# ── Endpoints ─────────────────────────────────────────────────────────────

@router.get("/fila")
async def listar_fila(
    status: str = "em_revisao",
    db: AsyncSession = Depends(get_db),
    admin: bool = Depends(_verificar_admin),
):
    """Lista pedidos aguardando revisão, com dados completos para análise."""
    rows = await db.execute(text("""
        SELECT
            p.id, p.numero, p.status, p.cliente_nome, p.cliente_email,
            p.cliente_estado, p.area_juridica, p.tipo_documento,
            p.objetivo, p.fatos, p.parte_contraria, p.valor_causa,
            p.plano_id, p.peticao_md, p.pago_em, p.created_at,
            LENGTH(p.peticao_md) AS tamanho_peticao,
            r.acao AS ultima_acao, r.created_at AS ultima_revisao
        FROM pedidos p
        LEFT JOIN LATERAL (
            SELECT acao, created_at FROM revisoes_pedido
            WHERE pedido_id = p.id ORDER BY created_at DESC LIMIT 1
        ) r ON true
        WHERE p.status = :status
        ORDER BY p.pago_em ASC NULLS LAST
    """), {"status": status})

    pedidos = [dict(r) for r in rows.mappings()]

    # KPIs de fila
    counts = {}
    for s in ("em_revisao", "solicitando_info", "aprovado", "indicado_advogado"):
        c = await db.execute(
            text("SELECT COUNT(*) FROM pedidos WHERE status=:s"), {"s": s}
        )
        counts[s] = c.scalar()

    return {
        "pedidos": pedidos,
        "total": len(pedidos),
        "kpis": counts,
    }


@router.get("/pedido/{pedido_id}")
async def detalhe_revisao(
    pedido_id: str,
    db: AsyncSession = Depends(get_db),
    admin: bool = Depends(_verificar_admin),
):
    """Detalhe completo de um pedido para o admin revisar."""
    row = await db.execute(
        text("SELECT * FROM pedidos WHERE id=:id"), {"id": pedido_id}
    )
    p = row.mappings().first()
    if not p:
        raise HTTPException(404, "Pedido não encontrado")

    revisoes = await db.execute(text("""
        SELECT * FROM revisoes_pedido WHERE pedido_id=:id ORDER BY created_at DESC
    """), {"id": pedido_id})

    sol_info = await db.execute(text("""
        SELECT * FROM solicitacoes_info WHERE pedido_id=:id ORDER BY created_at DESC
    """), {"id": pedido_id})

    return {
        "pedido": dict(p),
        "revisoes": [dict(r) for r in revisoes.mappings()],
        "solicitacoes_info": [dict(r) for r in sol_info.mappings()],
    }


@router.post("/pedido/{pedido_id}/aprovar")
async def aprovar_pedido(
    pedido_id: str,
    req: AprovarReq,
    db: AsyncSession = Depends(get_db),
    admin: bool = Depends(_verificar_admin),
):
    """
    Aprova a petição e envia ao cliente por e-mail.
    Se peticao_editada for informado, usa o texto editado.
    """
    row = await db.execute(
        text("SELECT * FROM pedidos WHERE id=:id"), {"id": pedido_id}
    )
    p = dict(row.mappings().first() or {})
    if not p:
        raise HTTPException(404, "Pedido não encontrado")

    if p["status"] not in ("em_revisao", "solicitando_info"):
        raise HTTPException(400, f"Pedido em status '{p['status']}' — não pode ser aprovado")

    peticao_final = req.peticao_editada or p.get("peticao_md", "")
    if not peticao_final:
        raise HTTPException(400, "Petição não foi gerada ainda")

    # Atualiza com texto final (editado ou original)
    await db.execute(text("""
        UPDATE pedidos
        SET peticao_md=:pm, status='aprovado', updated_at=NOW()
        WHERE id=:id
    """), {"pm": peticao_final, "id": pedido_id})

    # Registra revisão
    await db.execute(text("""
        INSERT INTO revisoes_pedido (id, pedido_id, acao, nota_interna, peticao_editada)
        VALUES (:id, :pid, 'aprovar', :nota, :pe)
    """), {
        "id": str(uuid4()), "pid": pedido_id,
        "nota": req.nota_interna,
        "pe": req.peticao_editada,
    })
    await db.commit()

    # Envia e-mail ao cliente
    from app.modules.pagamento.router import _montar_email_aprovacao, get_mp
    from app.modules.notificacoes.router import enviar_email

    html = _montar_email_aprovacao(p, peticao_final)
    await enviar_email(
        destinatario=p["cliente_email"],
        assunto=f"[EJC] Sua petição está pronta — Pedido {p['numero']}",
        corpo_html=html,
    )

    # Marca como entregue
    await db.execute(text("""
        UPDATE pedidos SET status='entregue', entregue_em=NOW() WHERE id=:id
    """), {"id": pedido_id})
    await db.commit()

    logger.info(f"[Revisão] Pedido {p['numero']} APROVADO → enviado para {p['cliente_email']}")
    return {"acao": "aprovado", "numero": p["numero"], "enviado_para": p["cliente_email"]}


@router.post("/pedido/{pedido_id}/indicar-advogado")
async def indicar_advogado(
    pedido_id: str,
    req: IndicarAdvogadoReq,
    db: AsyncSession = Depends(get_db),
    admin: bool = Depends(_verificar_admin),
):
    """
    Indica ao cliente que seu caso precisa de advogado e oferta o escritório.
    Opcionalmente reembolsa o pagamento.
    Cria lead no CRM interno do escritório.
    """
    row = await db.execute(
        text("SELECT * FROM pedidos WHERE id=:id"), {"id": pedido_id}
    )
    p = dict(row.mappings().first() or {})
    if not p:
        raise HTTPException(404, "Pedido não encontrado")

    # Configurações do escritório
    nome_esc = req.nome_escritorio or os.getenv("ESCRITORIO_NOME", "Nosso Escritório")
    whatsapp = req.whatsapp or os.getenv("ESCRITORIO_WHATSAPP", "")
    agenda   = req.link_agenda or os.getenv("ESCRITORIO_LINK_AGENDA", "")
    base_url = os.getenv("APP_BASE_URL", "https://ejc.com.br")

    # Atualiza status
    await db.execute(text("""
        UPDATE pedidos SET status='indicado_advogado', updated_at=NOW() WHERE id=:id
    """), {"id": pedido_id})

    # Registra revisão
    await db.execute(text("""
        INSERT INTO revisoes_pedido (id, pedido_id, acao, nota_interna, mensagem_cliente)
        VALUES (:id, :pid, 'indicar_advogado', :nota, :msg)
    """), {
        "id": str(uuid4()), "pid": pedido_id,
        "nota": req.motivo, "msg": req.motivo,
    })

    # Cria lead no CRM
    await db.execute(text("""
        INSERT INTO leads_escritorio
            (id, pedido_id, nome, email, area_juridica, resumo_caso, status_lead)
        VALUES (:id, :pid, :nome, :email, :area, :resumo, 'novo')
    """), {
        "id": str(uuid4()),
        "pid": pedido_id,
        "nome": p["cliente_nome"],
        "email": p["cliente_email"],
        "area": p["area_juridica"],
        "resumo": p.get("objetivo", "")[:500],
    })

    await db.commit()

    # Envia e-mail com oferta do escritório
    from app.modules.pagamento.router import _montar_email_indicacao_advogado
    from app.modules.notificacoes.router import enviar_email

    html = _montar_email_indicacao_advogado(p, req.motivo, nome_esc, whatsapp, agenda)
    await enviar_email(
        destinatario=p["cliente_email"],
        assunto=f"[EJC] Importante sobre seu caso — Pedido {p['numero']}",
        corpo_html=html,
    )

    # Reembolso via MP (se solicitado)
    reembolsado = False
    if req.reembolsar and p.get("mp_payment_id"):
        try:
            import httpx, json
            mp_key = os.getenv("MP_ACCESS_TOKEN", "")
            if mp_key:
                async with httpx.AsyncClient(timeout=10.0) as client:
                    resp = await client.post(
                        f"https://api.mercadopago.com/v1/payments/{p['mp_payment_id']}/refunds",
                        headers={"Authorization": f"Bearer {mp_key}"},
                        json={},
                    )
                    reembolsado = resp.status_code in (200, 201)
                    if reembolsado:
                        await db.execute(text("""
                            UPDATE pedidos SET status='reembolsado', updated_at=NOW() WHERE id=:id
                        """), {"id": pedido_id})
                        await db.commit()
        except Exception as e:
            logger.error(f"[Revisão] Falha no reembolso MP: {e}")

    logger.info(f"[Revisão] Pedido {p['numero']} → indicado advogado | reembolsado={reembolsado}")
    return {
        "acao": "indicado_advogado",
        "lead_criado": True,
        "reembolsado": reembolsado,
        "enviado_para": p["cliente_email"],
    }


@router.post("/pedido/{pedido_id}/solicitar-info")
async def solicitar_informacoes(
    pedido_id: str,
    req: SolicitarInfoReq,
    db: AsyncSession = Depends(get_db),
    admin: bool = Depends(_verificar_admin),
):
    """
    Pausa o pedido e pede mais informações ao cliente por e-mail.
    O cliente responde via link → voltando para a fila de revisão.
    """
    row = await db.execute(
        text("SELECT * FROM pedidos WHERE id=:id"), {"id": pedido_id}
    )
    p = dict(row.mappings().first() or {})
    if not p:
        raise HTTPException(404, "Pedido não encontrado")

    token_resp = secrets.token_hex(16)

    await db.execute(text("""
        INSERT INTO solicitacoes_info (id, pedido_id, pergunta, token_resposta)
        VALUES (:id, :pid, :q, :t)
    """), {"id": str(uuid4()), "pid": pedido_id, "q": req.pergunta, "t": token_resp})

    await db.execute(text("""
        UPDATE pedidos SET status='solicitando_info', updated_at=NOW() WHERE id=:id
    """), {"id": pedido_id})

    await db.execute(text("""
        INSERT INTO revisoes_pedido (id, pedido_id, acao, nota_interna)
        VALUES (:id, :pid, 'solicitar_info', :nota)
    """), {"id": str(uuid4()), "pid": pedido_id, "nota": req.nota_interna})

    await db.commit()

    from app.modules.pagamento.router import _montar_email_solicitar_info
    from app.modules.notificacoes.router import enviar_email

    base_url = os.getenv("APP_BASE_URL", "https://ejc.com.br")
    html = _montar_email_solicitar_info(p, req.pergunta, token_resp, base_url)
    await enviar_email(
        destinatario=p["cliente_email"],
        assunto=f"[EJC] Precisamos de mais informações — Pedido {p['numero']}",
        corpo_html=html,
    )

    logger.info(f"[Revisão] Pedido {p['numero']} → solicitando info ao cliente")
    return {"acao": "solicitar_info", "token_resposta": token_resp}


@router.post("/info/{token}/responder")
async def responder_informacao(
    token: str,
    payload: dict,
    db: AsyncSession = Depends(get_db),
):
    """
    Endpoint público chamado pelo cliente ao responder a solicitação de informação.
    Não requer autenticação — o token é o acesso.
    """
    row = await db.execute(text("""
        SELECT s.*, p.numero FROM solicitacoes_info s
        JOIN pedidos p ON p.id = s.pedido_id
        WHERE s.token_resposta=:t AND s.respondido_em IS NULL
    """), {"t": token})
    s = row.mappings().first()
    if not s:
        raise HTTPException(404, "Solicitação não encontrada ou já respondida")

    resposta = payload.get("resposta", "").strip()
    if not resposta:
        raise HTTPException(422, "Resposta não pode estar vazia")

    await db.execute(text("""
        UPDATE solicitacoes_info
        SET resposta=:r, respondido_em=NOW() WHERE token_resposta=:t
    """), {"r": resposta, "t": token})

    # Volta o pedido para fila de revisão
    await db.execute(text("""
        UPDATE pedidos
        SET status='em_revisao',
            fatos=fatos || :extra,
            updated_at=NOW()
        WHERE id=:id
    """), {
        "extra": f"\n\n[INFORMAÇÃO ADICIONAL DO CLIENTE]\n{resposta}",
        "id": s["pedido_id"],
    })

    await db.commit()

    # Notifica admin
    from app.modules.pagamento.router import _notificar_admin_revisao
    import asyncio
    row2 = await db.execute(
        text("SELECT * FROM pedidos WHERE id=:id"), {"id": s["pedido_id"]}
    )
    pedido = dict(row2.mappings().first() or {})
    asyncio.create_task(_notificar_admin_revisao(pedido))

    logger.info(f"[Revisão] Cliente respondeu info do pedido {s['numero']}")
    return {
        "mensagem": "Informação recebida! Daremos continuidade ao seu pedido em breve.",
        "numero": s["numero"],
    }


@router.post("/pedido/{pedido_id}/rejeitar")
async def rejeitar_pedido(
    pedido_id: str,
    req: RejeitarReq,
    db: AsyncSession = Depends(get_db),
    admin: bool = Depends(_verificar_admin),
):
    """Rejeita o pedido com motivo. Reembolso opcional."""
    row = await db.execute(
        text("SELECT * FROM pedidos WHERE id=:id"), {"id": pedido_id}
    )
    p = dict(row.mappings().first() or {})
    if not p:
        raise HTTPException(404, "Pedido não encontrado")

    novo_status = "reembolsado" if req.reembolsar else "cancelado"

    await db.execute(text("""
        UPDATE pedidos SET status=:s, updated_at=NOW() WHERE id=:id
    """), {"s": novo_status, "id": pedido_id})

    await db.execute(text("""
        INSERT INTO revisoes_pedido (id, pedido_id, acao, nota_interna)
        VALUES (:id, :pid, 'rejeitar', :nota)
    """), {"id": str(uuid4()), "pid": pedido_id, "nota": req.motivo})

    await db.commit()

    return {"acao": "rejeitado", "status": novo_status, "reembolso_solicitado": req.reembolsar}


@router.get("/leads")
async def listar_leads(
    status_lead: str = "novo",
    db: AsyncSession = Depends(get_db),
    admin: bool = Depends(_verificar_admin),
):
    """Lista leads do escritório captados via indicação."""
    rows = await db.execute(text("""
        SELECT l.*, p.numero as pedido_numero
        FROM leads_escritorio l
        LEFT JOIN pedidos p ON p.id = l.pedido_id
        WHERE l.status_lead=:s
        ORDER BY l.created_at DESC
    """), {"s": status_lead})

    return {"leads": [dict(r) for r in rows.mappings()]}


@router.patch("/leads/{lead_id}")
async def atualizar_lead(
    lead_id: str,
    payload: dict,
    db: AsyncSession = Depends(get_db),
    admin: bool = Depends(_verificar_admin),
):
    """Atualiza status e observação de um lead."""
    permitidos = {"status_lead", "observacao", "telefone"}
    sets = {k: v for k, v in payload.items() if k in permitidos}
    if not sets:
        raise HTTPException(422, "Nenhum campo válido para atualizar")

    set_sql = ", ".join(f"{k}=:{k}" for k in sets)
    sets["id"] = lead_id
    sets["updated_at"] = "NOW()"

    await db.execute(
        text(f"UPDATE leads_escritorio SET {set_sql}, updated_at=NOW() WHERE id=:id"),
        sets,
    )
    await db.commit()
    return {"atualizado": True}
