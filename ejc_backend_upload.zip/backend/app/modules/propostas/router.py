"""EJC — Propostas, Contratos de Honorários e CRM Jurídico"""
from __future__ import annotations
import logging, json
from typing import Optional
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.modules.auth.router import verificar_token, exigir_role
from app.core.llm_provider import LLMProvider

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/propostas", tags=["Propostas e CRM"])


# ══ PROPOSTAS ══════════════════════════════════════════════

class PropostaCreate(BaseModel):
    titulo: str
    escopo: str
    cliente_id: Optional[str] = None
    caso_id: Optional[str] = None
    tipo_honorario: str = "fixo"
    valor_fixo: Optional[float] = None
    valor_exito_pct: Optional[float] = None
    forma_pagamento: Optional[str] = None
    condicoes: Optional[str] = None
    exclusoes: Optional[str] = None
    validade_dias: int = 15


@router.post("/", status_code=201)
async def criar_proposta(
    req: PropostaCreate,
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio","advogado"])
    pid = str(uuid4())
    vt = req.valor_fixo or 0
    await db.execute(text("""
        INSERT INTO propostas (id,titulo,escopo,exclusoes,cliente_id,caso_id,tipo_honorario,
            valor_fixo,valor_exito_pct,valor_total,forma_pagamento,condicoes,validade_dias,
            criado_por_id,status)
        VALUES (:id,:tit,:esc,:excl,:cli,:caso,:th,:vf,:vpct,:vt,:fp,:cond,:val,:usr,'rascunho')
    """), {
        "id":pid,"tit":req.titulo,"esc":req.escopo,"excl":req.exclusoes,
        "cli":req.cliente_id,"caso":req.caso_id,"th":req.tipo_honorario,
        "vf":req.valor_fixo,"vpct":req.valor_exito_pct,"vt":vt,
        "fp":req.forma_pagamento,"cond":req.condicoes,"val":req.validade_dias,
        "usr":usuario.get("id"),
    })
    await db.commit()
    return {"id": pid, "status": "rascunho"}


@router.get("/")
async def listar_propostas(
    status: Optional[str] = Query(None),
    cliente_id: Optional[str] = Query(None),
    limit: int = Query(50),
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio","advogado","financeiro"])
    filtros = []; params: dict = {"lim": limit}
    if status:     filtros.append("p.status=:status");    params["status"] = status
    if cliente_id: filtros.append("p.cliente_id=:cli");   params["cli"] = cliente_id
    where = "WHERE " + " AND ".join(filtros) if filtros else ""
    rows = await db.execute(text(f"""
        SELECT p.*, c.nome as cliente_nome, c.razao_social as cliente_razao
        FROM propostas p LEFT JOIN clientes c ON c.id=p.cliente_id
        {where} ORDER BY p.created_at DESC LIMIT :lim
    """), params)
    return {"propostas": [dict(r) for r in rows.mappings()]}


@router.put("/{pid}/status")
async def atualizar_status_proposta(
    pid: str, payload: dict,
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio","advogado"])
    novo = payload.get("status")
    if novo not in ("rascunho","enviada","em_negociacao","aceita","recusada","expirada","convertida"):
        raise HTTPException(422, "Status inválido")
    extra = ", aceito_em=NOW(), aceito_por=:ap" if novo == "aceita" else ""
    params = {"id":pid,"st":novo}
    if novo == "aceita": params["ap"] = payload.get("aceito_por","")
    await db.execute(text(f"UPDATE propostas SET status=:st, updated_at=NOW(){extra} WHERE id=:id"), params)
    await db.commit()
    return {"mensagem": f"Proposta → {novo}"}


@router.post("/{pid}/gerar-contrato")
async def gerar_contrato(
    pid: str,
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    """Gera contrato de honorários via LLM a partir da proposta aprovada."""
    exigir_role(usuario, ["admin","socio","advogado"])
    row = await db.execute(text("""
        SELECT p.*, c.nome as cnome, c.cpf, c.razao_social, c.cnpj
        FROM propostas p LEFT JOIN clientes c ON c.id=p.cliente_id WHERE p.id=:id
    """), {"id": pid})
    p = row.mappings().first()
    if not p: raise HTTPException(404, "Proposta não encontrada")
    if p["status"] not in ("aceita","em_negociacao"):
        raise HTTPException(422, "Proposta deve estar aceita ou em negociação")

    cliente_id = p["cliente_id"] or ""
    cliente_nome = p["cnome"] or p["razao_social"] or "CLIENTE"
    doc_id = p.get("cnpj") or p.get("cpf") or ""

    llm = LLMProvider()
    prompt = f"""Redija CONTRATO DE HONORÁRIOS ADVOCATÍCIOS completo e formal.

PARTES:
  CONTRATANTE: {cliente_nome} — CPF/CNPJ: {doc_id}
  CONTRATADO:  Escritório de Advocacia (a preencher)

OBJETO: {p['titulo']}
ESCOPO: {p['escopo']}
{f"EXCLUSÕES: {p['exclusoes']}" if p.get('exclusoes') else ''}
HONORÁRIOS: {p['tipo_honorario']}
{f"Valor fixo: R$ {p['valor_fixo']:,.2f}" if p.get('valor_fixo') else ''}
{f"Êxito: {p['valor_exito_pct']}%" if p.get('valor_exito_pct') else ''}
PAGAMENTO: {p.get('forma_pagamento','A combinar')}
CONDIÇÕES: {p.get('condicoes','Padrão OAB')}

Inclua: das partes, do objeto, dos honorários, das obrigações, da rescisão, do foro.
Formato Markdown profissional. Fundamente no Estatuto da OAB e CPC."""

    conteudo = await llm.generate(prompt=prompt,
        system="Você é advogado especialista em contratos de honorários. Redija com precisão jurídica.",
        max_tokens=3000)

    cid = str(uuid4())
    await db.execute(text("""
        INSERT INTO contratos_honorarios (id,proposta_id,cliente_id,caso_id,conteudo_md,
            valor_total,status,criado_por_id)
        VALUES (:id,:pid,:cli,:caso,:cont,:vt,'ativo',:usr)
    """), {"id":cid,"pid":pid,"cli":p.get("cliente_id"),"caso":p.get("caso_id"),
           "cont":conteudo,"vt":p.get("valor_total"),"usr":usuario.get("id")})
    await db.execute(text("UPDATE propostas SET status='convertida', updated_at=NOW() WHERE id=:id"),{"id":pid})
    await db.commit()
    return {"id": cid, "conteudo_md": conteudo, "mensagem": "Contrato gerado — revise antes de assinar."}


# ══ CRM ════════════════════════════════════════════════════

class LeadCreate(BaseModel):
    nome: str
    email: Optional[str] = None
    telefone: Optional[str] = None
    whatsapp: Optional[str] = None
    area_interesse: Optional[str] = None
    descricao: Optional[str] = None
    origem: str = "site"
    prioridade: str = "media"
    proxima_acao: Optional[str] = None
    proxima_data: Optional[str] = None

crm = APIRouter(prefix="/crm", tags=["CRM Jurídico"])

@crm.post("/leads", status_code=201)
async def criar_lead(
    req: LeadCreate,
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio","advogado","atendimento"])
    lid = str(uuid4())
    await db.execute(text("""
        INSERT INTO crm_leads (id,nome,email,telefone,whatsapp,area_interesse,descricao,
            origem,prioridade,responsavel_id,proxima_acao,proxima_data)
        VALUES (:id,:nm,:em,:tel,:wpp,:area,:desc,:orig,:prio,:resp,:pacao,:pdata)
    """), {"id":lid,"nm":req.nome,"em":req.email,"tel":req.telefone,"wpp":req.whatsapp,
           "area":req.area_interesse,"desc":req.descricao,"orig":req.origem,
           "prio":req.prioridade,"resp":usuario.get("id"),
           "pacao":req.proxima_acao,"pdata":req.proxima_data})
    await db.commit()
    return {"id": lid, "status": "novo"}


@crm.get("/leads")
async def listar_leads(
    status: Optional[str] = Query(None),
    responsavel_id: Optional[str] = Query(None),
    limit: int = Query(100),
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio","advogado","atendimento"])
    filtros = []; params: dict = {"lim": limit}
    if status:         filtros.append("l.status=:st");  params["st"] = status
    if responsavel_id: filtros.append("l.responsavel_id=:resp"); params["resp"] = responsavel_id
    where = "WHERE " + " AND ".join(filtros) if filtros else ""
    rows = await db.execute(text(f"""
        SELECT l.*, u.nome as responsavel_nome,
               COUNT(i.id) as total_interacoes
        FROM crm_leads l
        LEFT JOIN usuarios u ON u.id=l.responsavel_id
        LEFT JOIN crm_interacoes i ON i.lead_id=l.id
        {where} GROUP BY l.id, u.nome
        ORDER BY l.created_at DESC LIMIT :lim
    """), params)
    leads = [dict(r) for r in rows.mappings()]

    # Kanban: contagem por status
    cnt = await db.execute(text("SELECT status, COUNT(*) as n FROM crm_leads GROUP BY status"))
    kanban = {r["status"]: r["n"] for r in cnt.mappings()}
    return {"leads": leads, "kanban": kanban}


@crm.put("/leads/{lid}/status")
async def mover_lead(lid: str, payload: dict,
                     usuario=Depends(verificar_token), db: AsyncSession = Depends(get_db)):
    exigir_role(usuario, ["admin","socio","advogado","atendimento"])
    novo = payload.get("status")
    validos = ("novo","contato_feito","aguardando_docs","em_analise","proposta_enviada",
               "follow_up","contratado","recusado","arquivado")
    if novo not in validos: raise HTTPException(422, "Status inválido")
    conv = ", converted_at=NOW()" if novo == "contratado" else ""
    await db.execute(text(f"UPDATE crm_leads SET status=:st, updated_at=NOW(){conv}, notas=COALESCE(:n,notas) WHERE id=:id"),
                     {"id":lid,"st":novo,"n":payload.get("nota")})
    # Registra interação
    await db.execute(text("INSERT INTO crm_interacoes (id,lead_id,tipo,descricao,usuario_id) VALUES (:id,:lid,'status_change',:desc,:usr)"),
                     {"id":str(uuid4()),"lid":lid,"desc":f"Status → {novo}","usr":usuario.get("id")})
    await db.commit()
    return {"mensagem": f"Lead → {novo}"}


@crm.post("/leads/{lid}/interacoes")
async def registrar_interacao(lid: str, payload: dict,
                               usuario=Depends(verificar_token), db: AsyncSession = Depends(get_db)):
    exigir_role(usuario, ["admin","socio","advogado","atendimento"])
    await db.execute(text("INSERT INTO crm_interacoes (id,lead_id,tipo,descricao,usuario_id) VALUES (:id,:lid,:tipo,:desc,:usr)"),
                     {"id":str(uuid4()),"lid":lid,"tipo":payload.get("tipo","nota"),
                      "desc":payload.get("descricao",""),"usr":usuario.get("id")})
    await db.commit()
    return {"mensagem": "Interação registrada"}


@crm.get("/leads/{lid}/historico")
async def historico_lead(lid: str, usuario=Depends(verificar_token), db: AsyncSession = Depends(get_db)):
    exigir_role(usuario, ["admin","socio","advogado","atendimento"])
    rows = await db.execute(text("""
        SELECT i.*, u.nome as usuario_nome FROM crm_interacoes i
        LEFT JOIN usuarios u ON u.id=i.usuario_id
        WHERE i.lead_id=:id ORDER BY i.created_at DESC
    """), {"id": lid})
    return {"historico": [dict(r) for r in rows.mappings()]}
