"""
EJC — Extração Estruturada de Documentos Jurídicos (ocr/router.py)

Funcionalidades:
  - extractPDFDocument  — extrai partes, datas, valores, riscos de PDF jurídico
  - analyzePDFContent   — análise jurídica completa do conteúdo
  - compareDocuments    — compara múltiplos documentos e detecta conflitos
  - validateExtractedPDF — valida confiança dos dados extraídos

Retorna JSON estruturado com confiança (0-100) e rastreabilidade.
"""
from __future__ import annotations
import json, logging, os, base64
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.llm_provider import LLMProvider

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/documentos", tags=["Extração de Documentos"])


# ── Utilitário: extrai texto de PDF ──────────────────────────────────────

def _extrair_texto_pdf(dados: bytes, max_chars: int = 8000) -> tuple[str, int]:
    """Extrai texto de PDF. Retorna (texto, num_paginas)."""
    try:
        import fitz
        doc = fitz.open(stream=dados, filetype="pdf")
        paginas = len(doc)
        texto = "\n\n".join(p.get_text() for p in doc)
        return texto[:max_chars], paginas
    except ImportError:
        return "[PyMuPDF não instalado — pip install pymupdf]", 0
    except Exception as e:
        return f"[Erro na extração: {e}]", 0


def _conf(valor: any) -> int:
    """Confidence score: 0 se vazio, 90 se preenchido."""
    if valor is None: return 0
    if isinstance(valor, str): return 90 if valor.strip() and valor != "Não identificado" else 0
    if isinstance(valor, list): return 85 if valor else 0
    if isinstance(valor, (int, float)): return 90 if valor > 0 else 0
    return 50


# ── SCHEMA DE EXTRAÇÃO ─────────────────────────────────────────────────

SCHEMA_EXTRACAO = """{
  "tipo_documento": "petição | sentença | contrato | acórdão | despacho | decisão | edital | outro",
  "partes": {
    "autor": "nome completo ou 'Não identificado'",
    "reu": "nome completo ou 'Não identificado'",
    "advogados": ["lista de advogados com OAB"],
    "terceiros": ["outras partes ou intervenientes"]
  },
  "datas": {
    "protocolo": "DD/MM/AAAA ou null",
    "sentenca": "DD/MM/AAAA ou null",
    "prazos": ["lista de prazos identificados com descrição"]
  },
  "valores": {
    "principal": 0.00,
    "moeda": "BRL",
    "descricao": "descrição do valor principal",
    "outros_valores": [{"descricao": "...", "valor": 0.00}]
  },
  "fundamentacao_legal": {
    "artigos": ["Art. X da Lei Y", "..."],
    "sumulas": ["Súmula N do STJ/STF", "..."],
    "jurisprudencias": ["REsp NNNN/UF — ..."]
  },
  "resumo_executivo": "resumo objetivo em 3-4 frases",
  "pontos_chave": ["lista dos argumentos/fatos principais"],
  "riscos_legais": [
    {"risco": "descrição", "nivel": "alto|medio|baixo", "recomendacao": "ação sugerida"}
  ],
  "recomendacoes": ["lista de próximas ações recomendadas"],
  "numero_processo": "NNNNNNN-NN.NNNN.N.NN.NNNN ou null",
  "vara_comarca": "identificação da vara/comarca ou null"
}"""

SYSTEM_EXTRACAO = """Você é especialista em extração de dados de documentos jurídicos brasileiros.
Extraia APENAS o que está explicitamente no documento — nunca invente.
Se um campo não estiver presente, use null ou 'Não identificado'.
Retorne APENAS o JSON, sem explicações, sem blocos de código, sem preamble."""


# ── ENDPOINT 1: extractPDFDocument ───────────────────────────────────────

@router.post("/extrair")
async def extract_pdf_document(
    arquivo: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    """
    Extrai dados estruturados de documento jurídico em PDF.
    Retorna JSON com partes, datas, valores, riscos e confiança (0-100).
    """
    if not arquivo.filename.lower().endswith(".pdf"):
        raise HTTPException(415, "Apenas PDF aceito neste endpoint")

    dados = await arquivo.read()
    if len(dados) > 15_000_000:
        raise HTTPException(413, "PDF muito grande. Máximo: 15 MB")

    texto, n_paginas = _extrair_texto_pdf(dados)
    if "[PyMuPDF" in texto or "[Erro" in texto:
        raise HTTPException(422, texto)

    # Chama LLM para extração estruturada
    llm = LLMProvider()
    prompt = f"""Documento jurídico — {n_paginas} página(s).

TEXTO EXTRAÍDO:
{texto}

Extraia os dados no formato JSON exato abaixo. Retorne SOMENTE o JSON:
{SCHEMA_EXTRACAO}"""

    try:
        resposta_raw = await llm.generate(prompt=prompt, system=SYSTEM_EXTRACAO, max_tokens=2000)
        # Limpa possíveis marcadores de código
        resposta_raw = resposta_raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        dados_extraidos = json.loads(resposta_raw)
    except json.JSONDecodeError:
        # Tenta extrair o JSON da resposta mesmo que tenha texto ao redor
        import re
        match = re.search(r'\{.*\}', resposta_raw, re.DOTALL)
        if match:
            dados_extraidos = json.loads(match.group())
        else:
            raise HTTPException(500, "LLM não retornou JSON válido")
    except Exception as e:
        raise HTTPException(500, f"Erro na extração: {e}")

    # Calcula confiança por campo
    campos_conf = {
        "tipo_documento": _conf(dados_extraidos.get("tipo_documento")),
        "partes": _conf(dados_extraidos.get("partes", {}).get("autor")),
        "datas": _conf(dados_extraidos.get("datas", {}).get("protocolo") or dados_extraidos.get("datas", {}).get("sentenca")),
        "valores": _conf(dados_extraidos.get("valores", {}).get("principal")),
        "fundamentacao": _conf(dados_extraidos.get("fundamentacao_legal", {}).get("artigos")),
        "riscos": _conf(dados_extraidos.get("riscos_legais")),
    }
    confianca_geral = int(sum(campos_conf.values()) / len(campos_conf))

    # Persiste no banco para auditoria
    doc_id = str(uuid4())
    try:
        await db.execute(text("""
            INSERT INTO documentos_analisados
                (id, nome_arquivo, paginas, texto_extraido, dados_estruturados, confianca, tipo_documento)
            VALUES (:id,:nome,:pag,:txt,:dados::jsonb,:conf,:tipo)
            ON CONFLICT DO NOTHING
        """), {
            "id": doc_id, "nome": arquivo.filename, "pag": n_paginas,
            "txt": texto[:2000], "dados": json.dumps(dados_extraidos, ensure_ascii=False),
            "conf": confianca_geral, "tipo": dados_extraidos.get("tipo_documento",""),
        })
        await db.commit()
    except Exception as e:
        logger.debug(f"[ExtractPDF] Persist: {e}")

    return {
        "id": doc_id,
        "nome_arquivo": arquivo.filename,
        "paginas": n_paginas,
        "dados": dados_extraidos,
        "confianca": confianca_geral,
        "confianca_por_campo": campos_conf,
        "requires_human_review": True,
        "aviso_juridico": True,
    }


# ── ENDPOINT 2: analyzePDFContent ────────────────────────────────────────

@router.post("/analisar")
async def analyze_pdf_content(
    arquivo: UploadFile = File(...),
    area_juridica: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """
    Análise jurídica profunda do conteúdo do PDF.
    Além da extração, gera estratégia, pontos fortes/fracos e argumentos contrários.
    """
    dados = await arquivo.read()
    texto, n_paginas = _extrair_texto_pdf(dados)
    llm = LLMProvider()

    prompt = f"""Analise profundamente este documento jurídico brasileiro.
{"Área: " + area_juridica if area_juridica else ""}

TEXTO:
{texto}

Responda em JSON com esta estrutura exata:
{{
  "tipo_documento": "...",
  "resumo": "...",
  "estrategia_identificada": "qual estratégia jurídica o documento adota",
  "pontos_fortes": ["lista de argumentos ou fatos favoráveis"],
  "pontos_fracos": ["lista de vulnerabilidades ou argumentos frágeis"],
  "argumentos_contrarios": ["argumentos que a parte contrária provavelmente usará"],
  "teses_juridicas": ["teses de direito aplicadas ou aplicáveis"],
  "probabilidade_exito": {{"estimativa": "alta|media|baixa", "fundamentacao": "..."}},
  "proximas_acoes": ["lista priorizada de próximas etapas processuais"],
  "prazos_criticos": ["prazos urgentes identificados"],
  "requires_human_review": true
}}"""

    try:
        raw = await llm.generate(prompt=prompt, system=SYSTEM_EXTRACAO, max_tokens=2500)
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        analise = json.loads(raw)
    except Exception:
        import re
        match = re.search(r'\{.*\}', raw, re.DOTALL) if 'raw' in dir() else None
        analise = json.loads(match.group()) if match else {"erro": "Parsing falhou", "texto_bruto": raw[:500] if 'raw' in dir() else ""}

    analise["requires_human_review"] = True
    analise["aviso_juridico"] = True
    analise["paginas_analisadas"] = n_paginas
    return analise


# ── ENDPOINT 3: compareDocuments ─────────────────────────────────────────

class CompareRequest(BaseModel):
    ids_documentos: list[str]  # IDs de docs já extraídos

@router.post("/comparar")
async def compare_documents(req: CompareRequest, db: AsyncSession = Depends(get_db)):
    """
    Compara múltiplos documentos jurídicos já extraídos.
    Identifica partes comuns, conflitos, inconsistências e valor total.
    """
    if len(req.ids_documentos) < 2:
        raise HTTPException(422, "Informe pelo menos 2 IDs de documentos")
    if len(req.ids_documentos) > 5:
        raise HTTPException(422, "Máximo 5 documentos por comparação")

    # Busca dados dos documentos
    rows = await db.execute(text("""
        SELECT id, nome_arquivo, dados_estruturados, tipo_documento, confianca
        FROM documentos_analisados WHERE id = ANY(:ids::uuid[])
    """), {"ids": req.ids_documentos})
    docs = [dict(r) for r in rows.mappings()]

    if len(docs) < 2:
        raise HTTPException(404, f"Apenas {len(docs)} documento(s) encontrado(s)")

    # Extrai dados de cada doc
    resumos = []
    for d in docs:
        dados = d.get("dados_estruturados") or {}
        if isinstance(dados, str):
            try: dados = json.loads(dados)
            except: dados = {}
        resumos.append({
            "id": d["id"], "nome": d["nome_arquivo"],
            "tipo": d.get("tipo_documento"),
            "partes": dados.get("partes", {}),
            "datas": dados.get("datas", {}),
            "valores": dados.get("valores", {}),
            "riscos": dados.get("riscos_legais", []),
            "resumo": dados.get("resumo_executivo",""),
        })

    # Análise de partes comuns
    todos_autores = [r["partes"].get("autor","") for r in resumos if r["partes"].get("autor")]
    todos_reus = [r["partes"].get("reu","") for r in resumos if r["partes"].get("reu")]
    partes_comuns = list(set(todos_autores) & set(todos_reus)) or list(set(todos_autores))

    # Valor total
    valor_total = sum(
        float(r["valores"].get("principal",0) or 0) for r in resumos
        if r.get("valores") and r["valores"].get("principal")
    )

    # Manda para o LLM detectar conflitos
    llm = LLMProvider()
    prompt_comp = f"""Compare estes {len(docs)} documentos jurídicos e identifique conflitos, inconsistências e recomendações.

DOCUMENTOS:
{json.dumps(resumos, ensure_ascii=False, indent=2)}

Responda APENAS em JSON:
{{
  "partes_comuns": ["partes que aparecem em múltiplos documentos"],
  "periodo_documentos": {{"inicio": "data mais antiga", "fim": "data mais recente"}},
  "valor_total": {valor_total},
  "conflitos": [
    {{"tipo": "conflito ou inconsistência", "documentos_envolvidos": ["id1","id2"], "descricao": "..."}}
  ],
  "recomendacoes_comparativas": ["recomendações baseadas na análise conjunta"],
  "parecer_geral": "análise consolidada em 2-3 frases"
}}"""

    try:
        raw = await llm.generate(prompt=prompt_comp, system=SYSTEM_EXTRACAO, max_tokens=1500)
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        comp = json.loads(raw)
    except Exception:
        comp = {
            "partes_comuns": partes_comuns,
            "valor_total": valor_total,
            "conflitos": [],
            "recomendacoes_comparativas": ["Análise automática parcialmente disponível"],
        }

    comp["documentos_analisados"] = len(docs)
    comp["requires_human_review"] = True
    comp["aviso_juridico"] = True
    return comp


# ── ENDPOINT 4: validateExtractedPDF ─────────────────────────────────────

@router.get("/validar/{doc_id}")
async def validate_extracted_pdf(doc_id: str, db: AsyncSession = Depends(get_db)):
    """
    Valida os dados extraídos de um documento específico.
    Verifica completude, consistência e retorna score de confiança por campo.
    """
    row = await db.execute(
        text("SELECT * FROM documentos_analisados WHERE id=:id"), {"id": doc_id}
    )
    doc = row.mappings().first()
    if not doc:
        raise HTTPException(404, "Documento não encontrado")

    dados = doc.get("dados_estruturados") or {}
    if isinstance(dados, str):
        try: dados = json.loads(dados)
        except: dados = {}

    # Validação campo a campo
    validacoes = []
    campos = {
        "tipo_documento": dados.get("tipo_documento"),
        "parte_autora": dados.get("partes", {}).get("autor"),
        "parte_ré": dados.get("partes", {}).get("reu"),
        "valor_principal": dados.get("valores", {}).get("principal"),
        "data_documento": dados.get("datas", {}).get("protocolo") or dados.get("datas", {}).get("sentenca"),
        "fundamentação_legal": dados.get("fundamentacao_legal", {}).get("artigos"),
        "riscos_identificados": dados.get("riscos_legais"),
        "resumo_executivo": dados.get("resumo_executivo"),
    }

    for campo, valor in campos.items():
        conf = _conf(valor)
        validacoes.append({
            "campo": campo,
            "valor": str(valor)[:100] if valor else None,
            "confianca": conf,
            "status": "ok" if conf >= 70 else ("parcial" if conf > 0 else "ausente"),
        })

    confianca_geral = int(sum(v["confianca"] for v in validacoes) / len(validacoes))
    campos_ausentes = [v["campo"] for v in validacoes if v["status"] == "ausente"]
    campos_parciais = [v["campo"] for v in validacoes if v["status"] == "parcial"]

    return {
        "id": doc_id,
        "nome_arquivo": doc.get("nome_arquivo"),
        "confianca_geral": confianca_geral,
        "validacoes": validacoes,
        "campos_ausentes": campos_ausentes,
        "campos_parciais": campos_parciais,
        "aprovado_para_uso": confianca_geral >= 70 and len(campos_ausentes) <= 2,
        "recomendacao": (
            "✅ Extração confiável" if confianca_geral >= 80
            else "⚠ Extração parcial — revise campos ausentes" if confianca_geral >= 50
            else "❌ Extração com baixa confiança — revise o documento manualmente"
        ),
        "requires_human_review": True,
    }


@router.get("/historico")
async def historico_documentos(
    limit: int = 20,
    db: AsyncSession = Depends(get_db),
):
    """Lista documentos extraídos recentemente."""
    try:
        rows = await db.execute(text("""
            SELECT id, nome_arquivo, paginas, confianca, tipo_documento, created_at
            FROM documentos_analisados ORDER BY created_at DESC LIMIT :lim
        """), {"lim": limit})
        return {"documentos": [dict(r) for r in rows.mappings()]}
    except Exception:
        return {"documentos": []}
