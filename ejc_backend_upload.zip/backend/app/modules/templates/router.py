"""
EJC — Módulo Templates Profissionais (modules/templates/router.py)

5 templates profissionais para geração de documentos:
  1. Petição Inicial Trabalhista
  2. Recurso Ordinário
  3. Contrato de Honorários
  4. Notificação Extrajudicial
  5. Parecer Jurídico

Cada template tem variáveis substituíveis e fundamentos legais
pré-estruturados para as áreas mais comuns.
"""
from __future__ import annotations

from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter(prefix="/templates", tags=["Templates Profissionais"])

# ── Templates embutidos (carregados no startup) ──────────
TEMPLATES_PADRAO = [
    {
        "id": "tpl-peticao-trabalhista",
        "nome": "Petição Inicial — Reclamação Trabalhista",
        "tipo_documento": "peticao_inicial",
        "area_juridica": "trabalhista",
        "conteudo_md": """# EXCELENTÍSSIMO SENHOR DOUTOR JUIZ DO TRABALHO DA {{VARA}} VARA DO TRABALHO DE {{CIDADE}}

**{{CLIENTE_NOME}}**, {{QUALIFICACAO_CLIENTE}}, por meio de seu advogado que esta subscreve (OAB/{{OAB_ESTADO}} nº {{OAB_NUMERO}}), vem, respeitosamente, à presença de Vossa Excelência, propor a presente

## RECLAMAÇÃO TRABALHISTA

em face de **{{RECLAMADA_NOME}}**, {{QUALIFICACAO_RECLAMADA}}, pelas razões de fato e de direito a seguir expostas:

## I — DOS FATOS

{{FATOS_DO_CASO}}

## II — DO DIREITO

### 2.1 Da Relação de Emprego

Nos termos do art. 3º da CLT (Decreto-Lei 5.452/1943), considera-se empregado toda pessoa física que prestar serviços de natureza não eventual a empregador, sob a dependência deste e mediante salário.

{{FUNDAMENTOS_JURIDICOS}}

## III — DOS PEDIDOS

Ante o exposto, requer-se:

a) Seja reconhecida {{PEDIDO_PRINCIPAL}};
b) A condenação da Reclamada ao pagamento de todas as verbas rescisórias;
c) A liberação do FGTS com multa de 40% (art. 18, Lei 8.036/1990);
d) Honorários advocatícios de sucumbência (art. 791-A CLT).

**Valor da causa: {{VALOR_CAUSA}}**

Termos em que pede deferimento.

{{CIDADE}}, {{DATA}}

**{{ADVOGADO_NOME}}**
OAB/{{OAB_ESTADO}} nº {{OAB_NUMERO}}""",
        "variaveis": [
            {"nome": "VARA", "descricao": "Número da vara (ex: 1ª)", "obrigatorio": True},
            {"nome": "CIDADE", "descricao": "Cidade do foro", "obrigatorio": True},
            {"nome": "CLIENTE_NOME", "descricao": "Nome completo do reclamante", "obrigatorio": True},
            {"nome": "QUALIFICACAO_CLIENTE", "descricao": "Qualificação completa", "obrigatorio": True},
            {"nome": "OAB_ESTADO", "descricao": "Estado da OAB", "obrigatorio": True},
            {"nome": "OAB_NUMERO", "descricao": "Número da OAB", "obrigatorio": True},
            {"nome": "RECLAMADA_NOME", "descricao": "Nome da empresa reclamada", "obrigatorio": True},
            {"nome": "QUALIFICACAO_RECLAMADA", "descricao": "CNPJ e endereço", "obrigatorio": True},
            {"nome": "FATOS_DO_CASO", "descricao": "Narrativa dos fatos", "obrigatorio": True},
            {"nome": "FUNDAMENTOS_JURIDICOS", "descricao": "Base legal específica", "obrigatorio": False},
            {"nome": "PEDIDO_PRINCIPAL", "descricao": "Pedido principal da ação", "obrigatorio": True},
            {"nome": "VALOR_CAUSA", "descricao": "Valor da causa em reais", "obrigatorio": True},
            {"nome": "ADVOGADO_NOME", "descricao": "Nome do advogado subscritor", "obrigatorio": True},
            {"nome": "DATA", "descricao": "Data por extenso", "obrigatorio": True},
        ],
    },
    {
        "id": "tpl-contrato-honorarios",
        "nome": "Contrato de Honorários Advocatícios",
        "tipo_documento": "contrato",
        "area_juridica": "geral",
        "conteudo_md": """# CONTRATO DE PRESTAÇÃO DE SERVIÇOS ADVOCATÍCIOS

**CONTRATANTE:** {{CLIENTE_NOME}}, {{QUALIFICACAO_CLIENTE}}.

**CONTRATADO:** {{ADVOGADO_NOME}}, inscrito na OAB/{{OAB_ESTADO}} sob o nº {{OAB_NUMERO}}, com escritório na {{ENDERECO_ESCRITORIO}}.

## CLÁUSULA PRIMEIRA — DO OBJETO

O CONTRATADO compromete-se a prestar serviços advocatícios ao CONTRATANTE consistentes em: {{OBJETO_CONTRATO}}.

## CLÁUSULA SEGUNDA — DOS HONORÁRIOS

2.1. Os honorários advocatícios serão de **{{VALOR_HONORARIOS}}**, correspondendo a {{PERCENTUAL_EXITO}}% sobre o valor do proveito econômico obtido.

2.2. Fica estipulado honorários iniciais de **{{HONORARIO_INICIAL}}**, pagos na assinatura deste instrumento, de caráter não reembolsável.

## CLÁUSULA TERCEIRA — DAS DESPESAS

As despesas processuais (custas, perícias, diligências) correrão por conta do CONTRATANTE, mediante comprovação.

## CLÁUSULA QUARTA — DO PRAZO

O presente contrato vigorará enquanto durar o(s) processo(s) objeto desta contratação.

## CLÁUSULA QUINTA — DO FORO

Fica eleito o foro de {{CIDADE}} para dirimir eventuais controvérsias.

Por estarem justos e contratados, assinam o presente em 2 (duas) vias.

{{CIDADE}}, {{DATA}}

___________________________
**{{CLIENTE_NOME}}**
CONTRATANTE

___________________________
**{{ADVOGADO_NOME}}**
OAB/{{OAB_ESTADO}} nº {{OAB_NUMERO}}
CONTRATADO""",
        "variaveis": [
            {"nome": "CLIENTE_NOME", "descricao": "Nome do cliente", "obrigatorio": True},
            {"nome": "QUALIFICACAO_CLIENTE", "descricao": "CPF/CNPJ e endereço", "obrigatorio": True},
            {"nome": "ADVOGADO_NOME", "descricao": "Nome do advogado", "obrigatorio": True},
            {"nome": "OAB_ESTADO", "descricao": "Estado OAB", "obrigatorio": True},
            {"nome": "OAB_NUMERO", "descricao": "Número OAB", "obrigatorio": True},
            {"nome": "ENDERECO_ESCRITORIO", "descricao": "Endereço do escritório", "obrigatorio": True},
            {"nome": "OBJETO_CONTRATO", "descricao": "Descrição dos serviços", "obrigatorio": True},
            {"nome": "VALOR_HONORARIOS", "descricao": "Valor total dos honorários", "obrigatorio": True},
            {"nome": "PERCENTUAL_EXITO", "descricao": "% de êxito", "obrigatorio": False},
            {"nome": "HONORARIO_INICIAL", "descricao": "Valor do sinal", "obrigatorio": False},
            {"nome": "CIDADE", "descricao": "Cidade", "obrigatorio": True},
            {"nome": "DATA", "descricao": "Data por extenso", "obrigatorio": True},
        ],
    },
    {
        "id": "tpl-notificacao",
        "nome": "Notificação Extrajudicial",
        "tipo_documento": "notificacao",
        "area_juridica": "civil",
        "conteudo_md": """# NOTIFICAÇÃO EXTRAJUDICIAL

**NOTIFICADO:** {{NOTIFICADO_NOME}}, {{QUALIFICACAO_NOTIFICADO}}.

**NOTIFICANTE:** {{NOTIFICANTE_NOME}}, {{QUALIFICACAO_NOTIFICANTE}}, por meio de seu advogado {{ADVOGADO_NOME}}, OAB/{{OAB_ESTADO}} nº {{OAB_NUMERO}}.

## DO OBJETO DA NOTIFICAÇÃO

Por meio da presente, o NOTIFICANTE vem NOTIFICAR Vossa Senhoria acerca dos seguintes fatos:

{{FATOS_NOTIFICACAO}}

## DA EXIGÊNCIA

Em razão do exposto, fica Vossa Senhoria NOTIFICADO a, no prazo de **{{PRAZO_DIAS}} ({{PRAZO_EXTENSO}}) dias** a contar do recebimento desta, {{EXIGENCIA}}, sob pena de {{CONSEQUENCIA_INADIMPLEMENTO}}.

## DA ADVERTÊNCIA

O descumprimento desta notificação implicará a adoção das medidas judiciais cabíveis, com a responsabilidade pelos ônus daí decorrentes.

{{CIDADE}}, {{DATA}}

**{{ADVOGADO_NOME}}**
OAB/{{OAB_ESTADO}} nº {{OAB_NUMERO}}""",
        "variaveis": [
            {"nome": "NOTIFICADO_NOME", "descricao": "Nome do notificado", "obrigatorio": True},
            {"nome": "QUALIFICACAO_NOTIFICADO", "descricao": "Qualificação completa", "obrigatorio": True},
            {"nome": "NOTIFICANTE_NOME", "descricao": "Nome do notificante", "obrigatorio": True},
            {"nome": "QUALIFICACAO_NOTIFICANTE", "descricao": "Qualificação notificante", "obrigatorio": True},
            {"nome": "ADVOGADO_NOME", "descricao": "Nome do advogado", "obrigatorio": True},
            {"nome": "OAB_ESTADO", "descricao": "Estado OAB", "obrigatorio": True},
            {"nome": "OAB_NUMERO", "descricao": "Número OAB", "obrigatorio": True},
            {"nome": "FATOS_NOTIFICACAO", "descricao": "Fatos que justificam a notificação", "obrigatorio": True},
            {"nome": "PRAZO_DIAS", "descricao": "Prazo em algarismos", "obrigatorio": True},
            {"nome": "PRAZO_EXTENSO", "descricao": "Prazo por extenso", "obrigatorio": True},
            {"nome": "EXIGENCIA", "descricao": "O que se exige do notificado", "obrigatorio": True},
            {"nome": "CONSEQUENCIA_INADIMPLEMENTO", "descricao": "Consequência do não cumprimento", "obrigatorio": True},
            {"nome": "CIDADE", "descricao": "Cidade", "obrigatorio": True},
            {"nome": "DATA", "descricao": "Data por extenso", "obrigatorio": True},
        ],
    },
    {
        "id": "tpl-recurso",
        "nome": "Recurso Ordinário Trabalhista",
        "tipo_documento": "recurso",
        "area_juridica": "trabalhista",
        "conteudo_md": """# EXCELENTÍSSIMO SENHOR DESEMBARGADOR RELATOR DO TRIBUNAL REGIONAL DO TRABALHO DA {{REGIAO_TRT}} REGIÃO

**{{RECORRENTE_NOME}}**, já qualificado nos autos do processo nº **{{NUMERO_PROCESSO}}**, que tramita perante a {{VARA}} Vara do Trabalho de {{CIDADE}}, vem, tempestivamente e por seu advogado, interpor o presente

## RECURSO ORDINÁRIO

em face da sentença proferida em {{DATA_SENTENCA}}, pelas razões a seguir:

## I — DA TEMPESTIVIDADE

O presente recurso é tempestivo, tendo sido intimado em {{DATA_INTIMACAO}} e apresentado dentro do prazo legal de 8 (oito) dias úteis (art. 895 da CLT).

## II — DO PREPARO

{{PREPARO_INFO}}

## III — DAS RAZÕES DO RECURSO

### 3.1 Da Decisão Recorrida

A sentença guerreada {{RESUMO_SENTENCA}}

### 3.2 Do Inconformismo

{{RAZOES_RECURSO}}

## IV — DO PEDIDO

Pelo exposto, requer-se o CONHECIMENTO e PROVIMENTO do presente recurso, para que seja {{PEDIDO_RECURSO}}.

{{CIDADE}}, {{DATA}}

**{{ADVOGADO_NOME}}**
OAB/{{OAB_ESTADO}} nº {{OAB_NUMERO}}""",
        "variaveis": [
            {"nome": "REGIAO_TRT", "descricao": "Número da região do TRT (ex: 3ª)", "obrigatorio": True},
            {"nome": "RECORRENTE_NOME", "descricao": "Nome do recorrente", "obrigatorio": True},
            {"nome": "NUMERO_PROCESSO", "descricao": "Número CNJ do processo", "obrigatorio": True},
            {"nome": "VARA", "descricao": "Número da vara de origem", "obrigatorio": True},
            {"nome": "CIDADE", "descricao": "Cidade do foro", "obrigatorio": True},
            {"nome": "DATA_SENTENCA", "descricao": "Data da sentença recorrida", "obrigatorio": True},
            {"nome": "DATA_INTIMACAO", "descricao": "Data da intimação", "obrigatorio": True},
            {"nome": "PREPARO_INFO", "descricao": "Informações sobre o preparo recursal", "obrigatorio": True},
            {"nome": "RESUMO_SENTENCA", "descricao": "O que decidiu a sentença", "obrigatorio": True},
            {"nome": "RAZOES_RECURSO", "descricao": "Fundamentos do recurso", "obrigatorio": True},
            {"nome": "PEDIDO_RECURSO", "descricao": "O que se pede no recurso", "obrigatorio": True},
            {"nome": "ADVOGADO_NOME", "descricao": "Nome do advogado", "obrigatorio": True},
            {"nome": "OAB_ESTADO", "descricao": "Estado OAB", "obrigatorio": True},
            {"nome": "OAB_NUMERO", "descricao": "Número OAB", "obrigatorio": True},
            {"nome": "DATA", "descricao": "Data por extenso", "obrigatorio": True},
        ],
    },
    {
        "id": "tpl-parecer",
        "nome": "Parecer Jurídico",
        "tipo_documento": "parecer",
        "area_juridica": "geral",
        "conteudo_md": """# PARECER JURÍDICO

**CONSULENTE:** {{CONSULENTE_NOME}}
**ASSUNTO:** {{ASSUNTO_PARECER}}
**PARECERISTA:** {{ADVOGADO_NOME}} — OAB/{{OAB_ESTADO}} nº {{OAB_NUMERO}}
**DATA:** {{DATA}}

---

## EMENTA

{{EMENTA_PARECER}}

---

## I — DO RELATÓRIO

Fui consultado acerca de {{OBJETO_CONSULTA}}.

## II — DOS FATOS

{{FATOS_PARECER}}

## III — DA ANÁLISE JURÍDICA

{{ANALISE_JURIDICA}}

## IV — DA CONCLUSÃO

Diante do exposto, **conclui-se que** {{CONCLUSAO}}.

Este parecer é emitido com base nos fatos narrados pelo consulente. Eventuais informações adicionais podem alterar as conclusões aqui expostas.

{{CIDADE}}, {{DATA}}

**{{ADVOGADO_NOME}}**
OAB/{{OAB_ESTADO}} nº {{OAB_NUMERO}}""",
        "variaveis": [
            {"nome": "CONSULENTE_NOME", "descricao": "Nome de quem solicitou o parecer", "obrigatorio": True},
            {"nome": "ASSUNTO_PARECER", "descricao": "Assunto do parecer", "obrigatorio": True},
            {"nome": "ADVOGADO_NOME", "descricao": "Nome do parecerista", "obrigatorio": True},
            {"nome": "OAB_ESTADO", "descricao": "Estado OAB", "obrigatorio": True},
            {"nome": "OAB_NUMERO", "descricao": "Número OAB", "obrigatorio": True},
            {"nome": "EMENTA_PARECER", "descricao": "Resumo da conclusão (ementa)", "obrigatorio": True},
            {"nome": "OBJETO_CONSULTA", "descricao": "O que foi perguntado", "obrigatorio": True},
            {"nome": "FATOS_PARECER", "descricao": "Fatos narrados pelo consulente", "obrigatorio": True},
            {"nome": "ANALISE_JURIDICA", "descricao": "Análise legal detalhada", "obrigatorio": True},
            {"nome": "CONCLUSAO", "descricao": "Conclusão do parecer", "obrigatorio": True},
            {"nome": "CIDADE", "descricao": "Cidade", "obrigatorio": True},
            {"nome": "DATA", "descricao": "Data por extenso", "obrigatorio": True},
        ],
    },
]


class AplicarTemplateRequest(BaseModel):
    template_id: str
    variaveis: dict  # {"CLIENTE_NOME": "João", "CIDADE": "BH", ...}
    usar_ia: bool = True   # se True, o LLM enriquece os campos vazios


@router.get("/")
async def listar_templates(db: AsyncSession = Depends(get_db)):
    """Lista todos os templates disponíveis (pré-definidos + customizados)."""
    rows = await db.execute(
        text("SELECT id, nome, tipo_documento, area_juridica, uso_count FROM templates WHERE ativo=true ORDER BY uso_count DESC")
    )
    db_templates = [dict(r) for r in rows.mappings()]

    padrao = [
        {"id": t["id"], "nome": t["nome"], "tipo_documento": t["tipo_documento"],
         "area_juridica": t["area_juridica"], "uso_count": 0, "origem": "padrao"}
        for t in TEMPLATES_PADRAO
    ]
    return {"templates": padrao + db_templates}


@router.get("/{template_id}")
async def buscar_template(template_id: str, db: AsyncSession = Depends(get_db)):
    """Retorna template com conteúdo e variáveis."""
    # Busca nos templates padrão
    for t in TEMPLATES_PADRAO:
        if t["id"] == template_id:
            return t

    # Busca no banco
    row = await db.execute(
        text("SELECT * FROM templates WHERE id=:id"), {"id": template_id}
    )
    t = row.mappings().first()
    if not t:
        raise HTTPException(404, "Template não encontrado.")
    return dict(t)


@router.post("/aplicar")
async def aplicar_template(
    req: AplicarTemplateRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Aplica as variáveis ao template e retorna o documento preenchido.
    Se usar_ia=true, o LLM preenche automaticamente variáveis não fornecidas.
    """
    # Localiza o template
    template = None
    for t in TEMPLATES_PADRAO:
        if t["id"] == req.template_id:
            template = t
            break

    if not template:
        row = await db.execute(
            text("SELECT * FROM templates WHERE id=:id"), {"id": req.template_id}
        )
        t = row.mappings().first()
        if t:
            template = dict(t)

    if not template:
        raise HTTPException(404, "Template não encontrado.")

    # Substitui variáveis
    conteudo = template["conteudo_md"]
    for var, valor in req.variaveis.items():
        conteudo = conteudo.replace("{{" + var + "}}", valor)

    # Atualiza contador de uso
    await db.execute(
        text("UPDATE templates SET uso_count=uso_count+1 WHERE id=:id"),
        {"id": req.template_id},
    )

    return {
        "template_id": req.template_id,
        "nome": template["nome"],
        "conteudo_md": conteudo,
        "variaveis_aplicadas": list(req.variaveis.keys()),
        "variaveis_faltando": [
            v["nome"] for v in template.get("variaveis", [])
            if v["obrigatorio"] and "{{" + v["nome"] + "}}" in conteudo
        ],
    }
