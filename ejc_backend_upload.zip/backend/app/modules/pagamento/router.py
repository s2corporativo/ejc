"""
EJC — Módulo Pagamento (modules/pagamento/router.py)

Integração com Mercado Pago para cobrança de pedidos públicos.
Fluxo:
  1. Cliente preenche o formulário no site
  2. POST /pagamento/criar-preferencia → retorna link MP
  3. Cliente paga (Pix ou cartão) no site do MP
  4. MP chama POST /pagamento/webhook com o resultado
  5. Webhook atualiza o pedido e dispara geração da petição

Configuração no .env:
  MP_ACCESS_TOKEN=APP_USR-xxx  (Produção)
  MP_ACCESS_TOKEN=TEST-xxx     (Sandbox para testes)
  MP_WEBHOOK_SECRET=xxx        (assinatura do webhook)
  MP_NOTIFICATION_URL=https://seudominio.com.br/api/v1/pagamento/webhook

Obtenha as credenciais em:
  https://www.mercadopago.com.br/developers/panel/credentials
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks
from pydantic import BaseModel
from pydantic_settings import BaseSettings
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/pagamento", tags=["Pagamento — Mercado Pago"])

MP_API = "https://api.mercadopago.com"


class MPSettings(BaseSettings):
    mp_access_token: str = ""
    mp_webhook_secret: str = ""
    mp_notification_url: str = ""
    app_base_url: str = "http://localhost:3000"

    class Config:
        env_file = ".env"
        case_sensitive = False
        extra = "ignore"


_mp_cfg: Optional[MPSettings] = None


def get_mp() -> MPSettings:
    global _mp_cfg
    if not _mp_cfg:
        _mp_cfg = MPSettings()
    return _mp_cfg


def _mp_headers(token: str) -> dict:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "X-Idempotency-Key": "",  # gerado por pedido
    }


async def criar_preferencia_mp(
    pedido_id: str,
    numero: str,
    plano_nome: str,
    valor: float,
    email_cliente: str,
    nome_cliente: str,
    cfg: MPSettings,
) -> dict:
    """
    Cria uma preferência de pagamento no Mercado Pago.
    Retorna o link de checkout (init_point) e o ID da preferência.
    Suporta: Pix, cartão de crédito, cartão de débito.
    """
    if not cfg.mp_access_token:
        raise RuntimeError(
            "MP_ACCESS_TOKEN não configurado no .env. "
            "Obtenha em https://www.mercadopago.com.br/developers/panel/credentials"
        )

    base = cfg.app_base_url.rstrip("/")
    payload = {
        "items": [{
            "id":          pedido_id,
            "title":       f"EJC — {plano_nome}",
            "description": "Petição jurídica gerada por IA",
            "quantity":    1,
            "currency_id": "BRL",
            "unit_price":  round(valor, 2),
        }],
        "payer": {
            "name":  nome_cliente,
            "email": email_cliente,
        },
        "payment_methods": {
            "excluded_payment_types": [],
            "installments": 1,
        },
        "back_urls": {
            "success": f"{base}/pedido/{numero}/sucesso",
            "failure": f"{base}/pedido/{numero}/falha",
            "pending": f"{base}/pedido/{numero}/pendente",
        },
        "auto_return": "approved",
        "notification_url": cfg.mp_notification_url or f"{base}/api/v1/pagamento/webhook",
        "external_reference": pedido_id,
        "expires": False,
        "metadata": {
            "pedido_id": pedido_id,
            "numero":    numero,
        },
    }

    headers = _mp_headers(cfg.mp_access_token)
    headers["X-Idempotency-Key"] = pedido_id

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.post(
            f"{MP_API}/checkout/preferences",
            headers=headers,
            json=payload,
        )

        if resp.status_code not in (200, 201):
            logger.error(f"[MP] Erro ao criar preferência: {resp.status_code} {resp.text[:300]}")
            raise RuntimeError(f"Mercado Pago retornou erro {resp.status_code}: {resp.text[:200]}")

        data = resp.json()
        return {
            "preference_id": data["id"],
            "init_point":    data["init_point"],      # produção
            "sandbox_point": data.get("sandbox_init_point", ""),  # testes
        }


async def consultar_pagamento_mp(payment_id: str, cfg: MPSettings) -> dict:
    """Consulta o status de um pagamento específico no MP."""
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(
            f"{MP_API}/v1/payments/{payment_id}",
            headers=_mp_headers(cfg.mp_access_token),
        )
        if resp.status_code != 200:
            raise RuntimeError(f"MP retornou {resp.status_code}")
        return resp.json()


def _verificar_assinatura_webhook(
    body: bytes, signature_header: str, secret: str
) -> bool:
    """Verifica a assinatura HMAC-SHA256 do webhook do MP."""
    if not secret:
        return True  # sem secret configurado, aceita (desenvolvimento)
    try:
        expected = hmac.new(
            secret.encode(), body, hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(expected, signature_header)
    except Exception:
        return False


# ── Background task: gera petição após pagamento ────────────────

async def _gerar_e_entregar_peticao(pedido_id: str):
    """
    Executado em background após confirmação do pagamento.
    1. Busca dados do pedido
    2. Gera a petição via LLM
    3. Adiciona guia JE se plano premium
    4. Envia por e-mail + salva para download
    5. Marca pedido como entregue
    """
    from app.core.database import AsyncSessionLocal
    from app.modules.redacao.service import LegalDraftService
    from app.modules.juizados.router import get_guia_estado
    from app.modules.notificacoes.router import enviar_email

    async with AsyncSessionLocal() as db:
        row = await db.execute(
            text("SELECT * FROM pedidos WHERE id=:id"), {"id": pedido_id}
        )
        pedido = row.mappings().first()
        if not pedido:
            logger.error(f"[Pedido] {pedido_id} não encontrado para geração")
            return

        await db.execute(
            text("UPDATE pedidos SET status='gerando', updated_at=NOW() WHERE id=:id"),
            {"id": pedido_id}
        )
        await db.commit()

        try:
            svc = LegalDraftService()

            # ── Busca jurisprudência em tempo real ──
            juris_contexto = ""
            try:
                from app.modules.pesquisa.jurisprudencia_engine import get_engine
                engine = get_engine()
                juris_contexto = await engine.buscar_para_peticao(
                    area=pedido["area_juridica"],
                    fatos=pedido.get("fatos", ""),
                    pedidos=pedido.get("objetivo", ""),
                    db=db,
                    max_citacoes=6,
                )
                if juris_contexto:
                    logger.info(f"[Pedido] Jurisprudência injetada: {len(juris_contexto)} chars")
            except Exception as e:
                logger.warning(f"[Pedido] Jurisprudência em tempo real falhou: {e}")

            rag_ctx = (
                f"Área: {pedido['area_juridica']}. "
                f"Parte contrária: {pedido.get('parte_contraria','não informada')}. "
                f"Valor da causa: R$ {pedido.get('valor_causa','a calcular')}."
            )
            if juris_contexto:
                rag_ctx += f"\n\nJURISPRUDÊNCIA APLICÁVEL AO CASO:\n{juris_contexto}"

            # Gera petição com RAG + jurisprudência real
            peticao_md = await svc.generate_draft(
                title=f"Petição — {pedido['area_juridica'].title()}",
                document_type=pedido["tipo_documento"],
                facts=pedido["fatos"],
                objective=pedido["objetivo"],
                rag_context=rag_ctx,
                client_name=pedido["cliente_nome"],
                opposing_party=pedido.get("parte_contraria"),
            )

            # Guia JE (plano premium)
            instrucoes_md = None
            if pedido["plano_id"] == "peticao_instrucoes":
                instrucoes_md = await get_guia_estado(
                    estado=pedido["cliente_estado"],
                    area=pedido["area_juridica"],
                )

            # ── NOVO FLUXO: vai para revisão manual, não entrega direto ──
            await db.execute(
                text("""
                    UPDATE pedidos
                    SET peticao_md=:pm, instrucoes_md=:im,
                        status='em_revisao', updated_at=NOW()
                    WHERE id=:id
                """),
                {"pm": peticao_md, "im": instrucoes_md, "id": pedido_id},
            )
            await db.commit()

            # Avisa o cliente que a petição está em análise (não envia ainda)
            html_aguardo = _montar_email_aguardo_revisao(pedido)
            await enviar_email(
                destinatario=pedido["cliente_email"],
                assunto=f"[EJC] Pedido {pedido['numero']} recebido — em análise",
                corpo_html=html_aguardo,
            )

            # Notifica o admin (Telegram + e-mail interno)
            await _notificar_admin_revisao(pedido)

            logger.info(f"[Pedido] {pedido['numero']} gerado → aguardando revisão manual")

        except Exception as e:
            logger.error(f"[Pedido] Erro ao gerar petição {pedido_id}: {e}")
            await db.execute(
                text("UPDATE pedidos SET status='pago', updated_at=NOW() WHERE id=:id"),
                {"id": pedido_id}
            )
            await db.commit()


def _montar_email_entrega(pedido: dict, peticao_md: str, instrucoes_md: Optional[str]) -> str:
    instrucoes_html = ""
    if instrucoes_md:
        instrucoes_html = f"""
        <div style="margin-top:24px;padding:20px;background:#f8f9fa;border-radius:8px;border-left:4px solid #c9960a">
          <h3 style="color:#c9960a;margin:0 0 12px">📋 Instruções para o Juizado Especial — {pedido['cliente_estado']}</h3>
          <pre style="white-space:pre-wrap;font-size:13px;color:#333">{instrucoes_md[:3000]}</pre>
        </div>"""

    return f"""
<html><body style="font-family:Arial,sans-serif;max-width:680px;margin:0 auto;padding:20px;color:#333">
  <div style="background:#0d1117;padding:24px;border-radius:12px;text-align:center;margin-bottom:24px">
    <h1 style="color:#c9960a;margin:0;font-size:22px">⚖️ Sua Petição Está Pronta!</h1>
    <p style="color:#8896a8;margin:8px 0 0;font-size:13px">Pedido {pedido['numero']}</p>
  </div>

  <p>Olá, <strong>{pedido['cliente_nome']}</strong>!</p>
  <p>Sua petição foi gerada com sucesso e está disponível abaixo.</p>

  <div style="background:#f8f9fa;border:1px solid #dee2e6;border-radius:8px;padding:20px;margin:20px 0">
    <h3 style="margin:0 0 12px;color:#0d1117">📄 Sua Petição</h3>
    <pre style="white-space:pre-wrap;font-size:13px;line-height:1.6;color:#333">{peticao_md[:4000]}</pre>
  </div>

  {instrucoes_html}

  <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:8px;padding:16px;margin:20px 0;font-size:13px">
    <strong>⚠️ Aviso Legal Obrigatório:</strong> Esta petição foi gerada por inteligência artificial
    e tem caráter informativo. Recomendamos revisão por advogado habilitado antes do protocolo.
    O EJC não presta consultoria jurídica. LGPD: seus dados são protegidos e não compartilhados.
  </div>

  <div style="text-align:center;margin-top:24px">
    <a href="{{}}" style="background:#c9960a;color:#fff;padding:12px 28px;
       border-radius:8px;text-decoration:none;font-weight:bold;display:inline-block">
      Baixar Petição em PDF →
    </a>
  </div>

  <p style="font-size:12px;color:#999;margin-top:24px;border-top:1px solid #eee;padding-top:12px">
    EJC — Ecossistema Jurídico Clovis | Petições geradas por IA | LGPD Compliant
  </p>
</body></html>"""


# ── Endpoints ──────────────────────────────────────────────────

@router.post("/webhook")
async def webhook_mercadopago(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """
    Webhook do Mercado Pago — versão com fila e idempotência.

    Fluxo:
      1. Valida assinatura HMAC (segurança)
      2. Extrai payment_id e enfileira na webhook_queue (idempotente por UNIQUE payment_id)
      3. Retorna 200 imediatamente (~50ms) — o MP não reenvia
      4. Worker do scheduler processa a fila a cada 30s com retry exponencial

    Garante: sem petição duplicada mesmo se o MP disparar o webhook múltiplas vezes.
    """
    from app.modules.pagamento.webhook_queue import enfileirar_webhook, processar_fila

    body = await request.body()
    cfg  = get_mp()

    sig = request.headers.get("x-signature", "")
    if cfg.mp_webhook_secret and not _verificar_assinatura_webhook(body, sig, cfg.mp_webhook_secret):
        logger.warning("[MP Webhook] Assinatura inválida")
        raise HTTPException(400, "Assinatura inválida")

    try:
        data = json.loads(body)
    except Exception:
        raise HTTPException(400, "Payload inválido")

    action     = data.get("action", "")
    payment_id = str(data.get("data", {}).get("id", ""))

    logger.info(f"[MP Webhook] action={action} payment_id={payment_id}")

    if action not in ("payment.created", "payment.updated") or not payment_id:
        return {"status": "ignored"}

    # Enfileira (idempotente — segundo webhook para mesmo payment_id é ignorado)
    resultado = await enfileirar_webhook(db, payment_id, action, data)

    # Eager execution: tenta processar imediatamente em background
    if resultado.get("enfileirado"):
        import asyncio
        asyncio.create_task(processar_fila(db))

    return {"status": "ok", **resultado}


@router.get("/status/{pedido_id}")
async def status_pagamento(pedido_id: str, db: AsyncSession = Depends(get_db)):
    """Retorna status atual do pedido (polling pelo frontend)."""
    row = await db.execute(
        text("""
            SELECT id, numero, status, plano_id, cliente_nome, cliente_email,
                   pago_em, entregue_em, peticao_md IS NOT NULL AS tem_peticao,
                   instrucoes_md IS NOT NULL AS tem_instrucoes
            FROM pedidos WHERE id=:id
        """),
        {"id": pedido_id},
    )
    p = row.mappings().first()
    if not p:
        raise HTTPException(404, "Pedido não encontrado")
    return dict(p)


# ══════════════════════════════════════════════════════════════════════════
# FUNÇÕES DE REVISÃO MANUAL — v11
# ══════════════════════════════════════════════════════════════════════════

def _montar_email_aguardo_revisao(pedido: dict) -> str:
    """E-mail enviado ao cliente imediatamente após geração — avisa que está em análise."""
    return f"""
<html><body style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;color:#333">
  <div style="background:#0d1117;padding:24px;border-radius:12px;text-align:center;margin-bottom:24px">
    <h1 style="color:#c9960a;margin:0;font-size:20px">⚖️ Pedido Recebido!</h1>
    <p style="color:#8896a8;margin:8px 0 0;font-size:13px">Pedido {pedido['numero']}</p>
  </div>

  <p>Olá, <strong>{pedido['cliente_nome']}</strong>!</p>

  <p>Recebemos seu pedido e a petição está sendo <strong>revisada por nossa equipe</strong> antes de ser enviada.</p>

  <div style="background:#f0f7ff;border:1px solid #b8daff;border-radius:8px;padding:16px;margin:20px 0">
    <strong>📋 O que acontece agora:</strong>
    <ol style="margin:8px 0 0;padding-left:20px;line-height:1.8">
      <li>Nossa equipe revisa a petição gerada</li>
      <li>Em alguns casos podemos entrar em contato pedindo mais detalhes</li>
      <li>Assim que aprovada, você recebe a petição por e-mail</li>
    </ol>
  </div>

  <p style="color:#555">⏱ Prazo estimado: <strong>até 24 horas úteis</strong></p>

  <p style="font-size:13px;color:#888;border-top:1px solid #eee;padding-top:12px;margin-top:24px">
    EJC — Ecossistema Jurídico Clovis | Pedido {pedido['numero']}
  </p>
</body></html>"""


def _montar_email_aprovacao(pedido: dict, peticao_final: str) -> str:
    """E-mail enviado quando o admin aprova e libera a petição."""
    instrucoes = pedido.get('instrucoes_md', '')
    instrucoes_html = f"""
    <div style="margin-top:20px;padding:16px;background:#fffbeb;border:1px solid #f59e0b;border-radius:8px">
      <strong style="color:#92400e">📋 Instruções para o Juizado — {pedido.get('cliente_estado','')}</strong>
      <pre style="margin:8px 0 0;font-size:12px;white-space:pre-wrap">{instrucoes[:2000]}</pre>
    </div>""" if instrucoes else ""

    return f"""
<html><body style="font-family:Arial,sans-serif;max-width:680px;margin:0 auto;padding:20px;color:#333">
  <div style="background:#0d1117;padding:24px;border-radius:12px;text-align:center;margin-bottom:24px">
    <h1 style="color:#c9960a;margin:0;font-size:22px">✅ Sua Petição Está Pronta!</h1>
    <p style="color:#8896a8;margin:8px 0 0;font-size:13px">Pedido {pedido['numero']}</p>
  </div>

  <p>Olá, <strong>{pedido['cliente_nome']}</strong>!</p>
  <p>Sua petição foi revisada e aprovada pela nossa equipe. Confira abaixo:</p>

  <div style="background:#f8f9fa;border:1px solid #dee2e6;border-radius:8px;padding:20px;margin:20px 0">
    <pre style="white-space:pre-wrap;font-size:13px;line-height:1.7;color:#333">{peticao_final[:5000]}</pre>
  </div>

  {instrucoes_html}

  <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:8px;padding:14px;margin:20px 0;font-size:13px">
    <strong>⚠️ Aviso Legal:</strong> Esta petição foi preparada com auxílio de inteligência artificial
    e revisada por nossa equipe. Recomendamos revisão por advogado habilitado antes do protocolo.
  </div>

  <p style="font-size:12px;color:#999;margin-top:24px;border-top:1px solid #eee;padding-top:12px">
    EJC — Ecossistema Jurídico Clovis | Pedido {pedido['numero']}
  </p>
</body></html>"""


def _montar_email_indicacao_advogado(pedido: dict, motivo: str, nome_escritorio: str, whatsapp: str, link_agenda: str) -> str:
    """
    E-mail enviado quando o admin indica que o caso precisa de advogado.
    CTA principal: link de agendamento de consulta.
    Whatsapp aparece apenas como contato secundário em texto, não como botão.
    """
    contato_whatsapp = f'<p style="font-size:13px;color:#555;margin-top:12px">Prefere falar antes? Entre em contato pelo WhatsApp: <strong>{whatsapp}</strong></p>' if whatsapp else ''
    botao_agenda = f'<a href="{link_agenda}" style="display:inline-block;background:#c9960a;color:#0d1117;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:bold;font-size:15px">📅 Agendar minha consulta</a>' if link_agenda else f'<p style="color:#8896a8">Entre em contato pelo e-mail ou WhatsApp acima para agendar.</p>'

    return f"""
<html><body style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;color:#333">
  <div style="background:#0d1117;padding:24px;border-radius:12px;text-align:center;margin-bottom:24px">
    <h1 style="color:#c9960a;margin:0;font-size:20px">⚖️ Seu caso merece atenção especial</h1>
    <p style="color:#8896a8;margin:8px 0 0;font-size:13px">Pedido {pedido['numero']}</p>
  </div>

  <p>Olá, <strong>{pedido['cliente_nome']}</strong>!</p>

  <p>Nossa equipe analisou o seu caso com cuidado e identificou algo importante:</p>

  <div style="background:#fef3c7;border-left:4px solid #f59e0b;padding:16px;margin:20px 0;border-radius:0 8px 8px 0">
    <p style="margin:0;color:#78350f">{motivo}</p>
  </div>

  <p>Por isso, <strong>recomendamos que você tenha acompanhamento jurídico personalizado</strong>
  para garantir os melhores resultados no seu caso.</p>

  <div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:12px;padding:24px;margin:24px 0;text-align:center">
    <p style="font-size:13px;color:#6b7280;margin:0 0 6px">Atendimento especializado por</p>
    <h2 style="color:#111827;margin:0 0 6px;font-size:20px">{nome_escritorio}</h2>
    <p style="font-size:13px;color:#6b7280;margin:0 0 20px">Consulta inicial para entender seu caso e orientá-lo</p>
    {botao_agenda}
    {contato_whatsapp}
  </div>

  <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:14px;margin:20px 0;font-size:13px;color:#166534">
    <strong>💳 Seu reembolso:</strong> O valor pago foi reembolsado integralmente.
    O crédito retorna ao seu cartão/conta em até 5 dias úteis.
  </div>

  <p style="font-size:12px;color:#9ca3af;border-top:1px solid #f3f4f6;padding-top:12px;margin-top:24px;text-align:center">
    EJC — Ecossistema Jurídico Clovis | Pedido {pedido['numero']}
  </p>
</body></html>"""


def _montar_email_solicitar_info(pedido: dict, pergunta: str, token_resposta: str, base_url: str) -> str:
    """E-mail enviado quando o admin precisa de mais informações antes de revisar."""
    link = f"{base_url}/responder-info?token={token_resposta}"
    return f"""
<html><body style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;color:#333">
  <div style="background:#0d1117;padding:20px;border-radius:12px;text-align:center;margin-bottom:24px">
    <h1 style="color:#c9960a;margin:0;font-size:18px">📝 Precisamos de mais informações</h1>
    <p style="color:#8896a8;margin:6px 0 0;font-size:12px">Pedido {pedido['numero']}</p>
  </div>

  <p>Olá, <strong>{pedido['cliente_nome']}</strong>!</p>
  <p>Estamos revisando sua petição e precisamos de um detalhe adicional para finalizá-la:</p>

  <div style="background:#f0f4ff;border:1px solid #c3dafe;border-radius:8px;padding:16px;margin:20px 0">
    <strong style="color:#3730a3">❓ Pergunta da nossa equipe:</strong>
    <p style="margin:8px 0 0;color:#1e3a5f">{pergunta}</p>
  </div>

  <div style="text-align:center;margin:24px 0">
    <a href="{link}" style="background:#c9960a;color:#0d1117;padding:12px 28px;
       border-radius:8px;text-decoration:none;font-weight:bold;display:inline-block">
      Responder Agora →
    </a>
  </div>

  <p style="font-size:12px;color:#999">Sua petição ficará pausada até recebermos sua resposta.</p>
</body></html>"""


async def _notificar_admin_revisao(pedido: dict):
    """Envia alerta ao admin quando chega novo pedido para revisar."""
    import os
    telegram_token = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_chat  = os.getenv("TELEGRAM_CHAT_ID", "")

    if telegram_token and telegram_chat:
        try:
            import httpx
            msg = (
                f"🔔 *Novo pedido para revisão*\n"
                f"━━━━━━━━━━━━━━\n"
                f"📋 *Pedido:* {pedido['numero']}\n"
                f"👤 *Cliente:* {pedido['cliente_nome']}\n"
                f"⚖️ *Área:* {pedido['area_juridica']}\n"
                f"💰 *Plano:* {pedido['plano_id']}\n"
                f"━━━━━━━━━━━━━━\n"
                f"Acesse o painel para revisar e aprovar."
            )
            async with httpx.AsyncClient(timeout=5.0) as client:
                await client.post(
                    f"https://api.telegram.org/bot{telegram_token}/sendMessage",
                    json={"chat_id": telegram_chat, "text": msg, "parse_mode": "Markdown"},
                )
            logger.info(f"[Admin] Telegram notificado — pedido {pedido['numero']}")
        except Exception as e:
            logger.warning(f"[Admin] Falha Telegram: {e}")

    # E-mail para admin
    admin_email = os.getenv("ADMIN_EMAIL", "")
    if admin_email:
        try:
            from app.modules.notificacoes.router import enviar_email
            await enviar_email(
                destinatario=admin_email,
                assunto=f"[EJC Admin] Novo pedido para revisar — {pedido['numero']}",
                corpo_html=f"""<p>Novo pedido aguardando revisão:</p>
                <ul><li>Número: {pedido['numero']}</li>
                <li>Cliente: {pedido['cliente_nome']}</li>
                <li>Área: {pedido['area_juridica']}</li></ul>
                <p><a href="/admin/revisao">Acessar painel de revisão →</a></p>""",
            )
        except Exception as e:
            logger.warning(f"[Admin] Falha e-mail admin: {e}")
