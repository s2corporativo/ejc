"""
EJC — Fila de Webhook Mercado Pago (webhook_queue.py)

Problema resolvido:
  O MP reenvia o webhook se não receber 200 em <500ms.
  Gerar a petição via LLM leva 5-30s → timeout → duplicata.

Solução:
  1. Webhook recebe payload → insere na fila (200ms) → retorna 200 imediatamente
  2. Worker assíncrono processa a fila: consulta MP → gera petição → entrega
  3. Idempotência: UNIQUE(payment_id) — segundo webhook para o mesmo pagamento é ignorado
  4. Retry automático com backoff exponencial (até 5 tentativas)
  5. Status rastreável: pendente → processando → concluido | erro

Execução do worker:
  - Scheduler: job a cada 30s chama processar_fila()
  - Também chamado diretamente após enfileiramento (eager execution)
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta
from uuid import uuid4

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)

# Backoff: 30s, 2min, 10min, 30min, 2h
BACKOFF_MINUTOS = [0.5, 2, 10, 30, 120]


async def enfileirar_webhook(
    db: AsyncSession,
    payment_id: str,
    action: str,
    payload: dict,
) -> dict:
    """
    Insere um webhook na fila de processamento.
    Idempotente: segundo webhook com mesmo payment_id é ignorado.

    Returns:
        {"enfileirado": True} ou {"duplicata": True, "status": "..."}
    """
    # Verifica se já existe
    row = await db.execute(
        text("SELECT status, tentativas FROM webhook_queue WHERE payment_id=:pid"),
        {"pid": payment_id},
    )
    existente = row.mappings().first()

    if existente:
        logger.info(f"[WebhookQueue] payment_id={payment_id} já existe ({existente['status']}) — ignorado")
        return {"duplicata": True, "status": existente["status"]}

    await db.execute(text("""
        INSERT INTO webhook_queue (id, payment_id, action, payload, status, proximo_retry)
        VALUES (:id, :pid, :action, :payload::jsonb, 'pendente', NOW())
        ON CONFLICT (payment_id) DO NOTHING
    """), {
        "id": str(uuid4()),
        "pid": payment_id,
        "action": action,
        "payload": json.dumps(payload),
    })
    await db.commit()
    logger.info(f"[WebhookQueue] Enfileirado payment_id={payment_id} action={action}")
    return {"enfileirado": True}


async def processar_fila(db: AsyncSession) -> dict:
    """
    Worker: processa até 10 itens pendentes da fila por execução.
    Chamado pelo scheduler a cada 30s.
    """
    # Busca itens prontos para processar
    rows = await db.execute(text("""
        SELECT id, payment_id, action, payload, tentativas
        FROM webhook_queue
        WHERE status IN ('pendente', 'erro')
          AND tentativas < max_tentativas
          AND proximo_retry <= NOW()
        ORDER BY created_at ASC
        LIMIT 10
        FOR UPDATE SKIP LOCKED
    """))
    itens = list(rows.mappings())

    processados = 0
    erros = 0

    for item in itens:
        wq_id = item["id"]
        payment_id = item["payment_id"]
        tentativa = item["tentativas"] + 1

        # Marca como processando
        await db.execute(text("""
            UPDATE webhook_queue
            SET status='processando', tentativas=:t
            WHERE id=:id
        """), {"t": tentativa, "id": wq_id})
        await db.commit()

        try:
            sucesso = await _processar_item(db, payment_id, item["action"])

            if sucesso:
                await db.execute(text("""
                    UPDATE webhook_queue
                    SET status='concluido', processado_em=NOW(), erro_msg=NULL
                    WHERE id=:id
                """), {"id": wq_id})
                processados += 1
                logger.info(f"[WebhookQueue] ✓ payment_id={payment_id} (tentativa {tentativa})")
            else:
                # Pagamento não aprovado — marca como ignorado
                await db.execute(text("""
                    UPDATE webhook_queue SET status='ignorado' WHERE id=:id
                """), {"id": wq_id})

        except Exception as e:
            erros += 1
            proximo = _calcular_proximo_retry(tentativa)
            novo_status = "erro" if tentativa < 5 else "erro"  # mantém para diagnóstico
            await db.execute(text("""
                UPDATE webhook_queue
                SET status=:st, erro_msg=:msg, proximo_retry=:pr
                WHERE id=:id
            """), {
                "st": novo_status,
                "msg": str(e)[:500],
                "pr": proximo,
                "id": wq_id,
            })
            logger.error(f"[WebhookQueue] ✗ payment_id={payment_id} tentativa={tentativa}: {e}")

        await db.commit()

    return {"processados": processados, "erros": erros, "total": len(itens)}


async def _processar_item(db: AsyncSession, payment_id: str, action: str) -> bool:
    """
    Processa um item da fila: consulta o MP e executa a lógica de negócio.
    Retorna True se processado, False se pagamento não aprovado.
    """
    from app.modules.pagamento.router import consultar_pagamento_mp, get_mp, _gerar_e_entregar_peticao

    cfg = get_mp()
    pagamento = await consultar_pagamento_mp(payment_id, cfg)

    mp_status = pagamento.get("status", "")
    pedido_id = pagamento.get("external_reference", "")
    valor_pago = pagamento.get("transaction_amount", 0)
    metodo = pagamento.get("payment_type_id", "")

    if mp_status != "approved" or not pedido_id:
        logger.info(f"[WebhookQueue] payment_id={payment_id} status={mp_status} — não aprovado")
        return False

    # Verifica se o pedido já foi processado (proteção extra)
    row = await db.execute(
        text("SELECT status FROM pedidos WHERE id=:id"),
        {"id": pedido_id},
    )
    pedido = row.mappings().first()

    if not pedido:
        raise ValueError(f"Pedido {pedido_id} não encontrado")

    if pedido["status"] not in ("aguardando_pagamento", "pago"):
        logger.info(f"[WebhookQueue] Pedido {pedido_id} já está em status={pedido['status']} — skip")
        return True  # já processado

    # Atualiza status e gera token de acesso do cliente
    import secrets
    token = secrets.token_urlsafe(32)

    await db.execute(text("""
        UPDATE pedidos
        SET status='pago',
            mp_payment_id=:mpid,
            valor_pago=:vp,
            metodo_pagamento=:mp,
            pago_em=NOW(),
            token_acesso=:token,
            updated_at=NOW()
        WHERE id=:id AND status='aguardando_pagamento'
    """), {"mpid": payment_id, "vp": valor_pago, "mp": metodo, "token": token, "id": pedido_id})

    # Atualiza referência na fila
    await db.execute(text("""
        UPDATE webhook_queue SET pedido_id=:pid WHERE payment_id=:mpid
    """), {"pid": pedido_id, "mpid": payment_id})

    await db.commit()

    # Dispara geração da petição (assíncrono)
    import asyncio
    asyncio.create_task(_gerar_e_entregar_peticao(pedido_id))
    logger.info(f"[WebhookQueue] Pedido {pedido_id} → geração iniciada (token={token[:8]}...)")
    return True


def _calcular_proximo_retry(tentativa: int) -> datetime:
    minutos = BACKOFF_MINUTOS[min(tentativa - 1, len(BACKOFF_MINUTOS) - 1)]
    return datetime.utcnow() + timedelta(minutes=minutos)
