"""
EJC — Cadastro Completo de Clientes (clientes/router.py)

Pessoa física e jurídica. Vinculado a casos, propostas, documentos.
Permissão: admin, socio, advogado, assistente.
"""
from __future__ import annotations
import logging, json
from typing import Optional
from uuid import uuid4
from fastapi import APIRouter, Depends, Header, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.sql_safe import construir_set, validar_coluna
from app.core.database import get_db
from app.modules.auth.router import verificar_token, exigir_role

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/clientes", tags=["Cadastro de Clientes"])


class ClienteCreate(BaseModel):
    tipo: str = "pf"             # pf | pj
    nome: Optional[str] = None
    cpf: Optional[str] = None
    rg: Optional[str] = None
    data_nascimento: Optional[str] = None
    razao_social: Optional[str] = None
    cnpj: Optional[str] = None
    nome_fantasia: Optional[str] = None
    email: Optional[str] = None
    telefone: Optional[str] = None
    whatsapp: Optional[str] = None
    cep: Optional[str] = None
    logradouro: Optional[str] = None
    numero: Optional[str] = None
    complemento: Optional[str] = None
    bairro: Optional[str] = None
    cidade: Optional[str] = None
    estado: Optional[str] = None
    origem: str = "indicacao"
    area_interesse: Optional[str] = None
    tipo_cliente: str = "comum"
    observacoes: Optional[str] = None
    sigilo: bool = False

class ClienteUpdate(BaseModel):
    nome: Optional[str] = None
    razao_social: Optional[str] = None
    email: Optional[str] = None
    telefone: Optional[str] = None
    whatsapp: Optional[str] = None
    cidade: Optional[str] = None
    estado: Optional[str] = None
    origem: Optional[str] = None
    area_interesse: Optional[str] = None
    tipo_cliente: Optional[str] = None
    status: Optional[str] = None
    observacoes: Optional[str] = None
    sigilo: Optional[bool] = None


@router.post("/", status_code=201)
async def criar_cliente(
    req: ClienteCreate,
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio","advogado","assistente","atendimento"])
    if req.tipo == "pf" and not req.nome:
        raise HTTPException(422, "nome obrigatório para pessoa física")
    if req.tipo == "pj" and not req.razao_social:
        raise HTTPException(422, "razao_social obrigatória para pessoa jurídica")

    cid = str(uuid4())
    display = req.nome or req.razao_social or "Cliente"
    await db.execute(text("""
        INSERT INTO clientes (id,tipo,nome,cpf,rg,data_nascimento,razao_social,cnpj,nome_fantasia,
            email,telefone,whatsapp,cep,logradouro,numero,complemento,bairro,cidade,estado,
            origem,area_interesse,tipo_cliente,observacoes,sigilo,responsavel_id)
        VALUES (:id,:tipo,:nome,:cpf,:rg,:dn,:rs,:cnpj,:nf,:email,:tel,:wpp,:cep,
                :log,:num,:comp,:bairro,:cid,:est,:orig,:area,:tcliente,:obs,:sig,:resp)
    """), {
        "id":cid,"tipo":req.tipo,"nome":req.nome,"cpf":req.cpf,"rg":req.rg,
        "dn":req.data_nascimento,"rs":req.razao_social,"cnpj":req.cnpj,
        "nf":req.nome_fantasia,"email":req.email,"tel":req.telefone,
        "wpp":req.whatsapp,"cep":req.cep,"log":req.logradouro,
        "num":req.numero,"comp":req.complemento,"bairro":req.bairro,
        "cid":req.cidade,"est":req.estado,"orig":req.origem,
        "area":req.area_interesse,"tcliente":req.tipo_cliente,
        "obs":req.observacoes,"sig":req.sigilo,
        "resp": usuario.get("id") if usuario else None,
    })
    await db.commit()
    logger.info(f"[Cliente] Criado: {display} ({req.tipo}) por {usuario.get('email','?')}")
    return {"id": cid, "nome": display, "tipo": req.tipo}


@router.get("/")
async def listar_clientes(
    busca: Optional[str] = Query(None),
    tipo: Optional[str] = Query(None),
    status: str = Query("ativo"),
    origem: Optional[str] = Query(None),
    area: Optional[str] = Query(None),
    limit: int = Query(50, le=200),
    offset: int = Query(0),
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio","advogado","assistente","atendimento","financeiro"])
    filtros = ["status=:status"]; params: dict = {"status": status, "lim": limit, "off": offset}
    if tipo:    filtros.append("tipo=:tipo");          params["tipo"] = tipo
    if origem:  filtros.append("origem=:origem");      params["origem"] = origem
    if area:    filtros.append("area_interesse=:area");params["area"] = area
    if busca:
        filtros.append("(LOWER(nome) LIKE :b OR LOWER(razao_social) LIKE :b OR cpf LIKE :b OR cnpj LIKE :b OR email LIKE :b)")
        params["b"] = f"%{busca.lower()}%"

    where = "WHERE " + " AND ".join(filtros)
    rows = await db.execute(text(f"""
        SELECT c.*, u.nome as responsavel_nome,
               COUNT(ca.id) as total_casos
        FROM clientes c
        LEFT JOIN usuarios u ON u.id = c.responsavel_id
        LEFT JOIN casos ca ON ca.cliente_id = c.id
        {where} GROUP BY c.id, u.nome
        ORDER BY c.created_at DESC LIMIT :lim OFFSET :off
    """), params)
    clientes = [dict(r) for r in rows.mappings()]

    cnt = await db.execute(text(f"SELECT COUNT(*) FROM clientes {where}"),
                           {k:v for k,v in params.items() if k not in ("lim","off")})
    total = cnt.scalar() or 0
    return {"clientes": clientes, "total": total, "limit": limit, "offset": offset}


@router.get("/{cliente_id}")
async def obter_cliente(
    cliente_id: str,
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio","advogado","assistente","atendimento","financeiro"])
    row = await db.execute(text("SELECT * FROM clientes WHERE id=:id"), {"id": cliente_id})
    c = row.mappings().first()
    if not c: raise HTTPException(404, "Cliente não encontrado")
    cliente = dict(c)

    # Casos vinculados
    casos = await db.execute(text("""
        SELECT id, numero_caso, titulo, area_juridica, status, prioridade, created_at
        FROM casos WHERE cliente_id=:id ORDER BY created_at DESC LIMIT 10
    """), {"id": cliente_id})
    cliente["casos"] = [dict(r) for r in casos.mappings()]

    # Propostas
    props = await db.execute(text("""
        SELECT id, numero, titulo, valor_total, status, created_at
        FROM propostas WHERE cliente_id=:id ORDER BY created_at DESC LIMIT 5
    """), {"id": cliente_id})
    cliente["propostas"] = [dict(r) for r in props.mappings()]

    return cliente


@router.put("/{cliente_id}")
async def atualizar_cliente(
    cliente_id: str,
    req: ClienteUpdate,
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio","advogado","assistente"])
    sets = []; params = {"id": cliente_id}
    for campo, val in req.model_dump(exclude_none=True).items():
        sets.append(f"{campo}=:{campo}"); params[campo] = val
    if not sets: raise HTTPException(422, "Nenhum campo")
    sets.append("updated_at=NOW()")
    r = await db.execute(text(f"UPDATE clientes SET {','.join(sets)} WHERE id=:id RETURNING id"), params)
    if not r.first(): raise HTTPException(404, "Cliente não encontrado")
    await db.commit()
    return {"mensagem": "Atualizado", "id": cliente_id}


@router.delete("/{cliente_id}")
async def arquivar_cliente(
    cliente_id: str,
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio"])
    await db.execute(text("UPDATE clientes SET status='arquivado', updated_at=NOW() WHERE id=:id"),
                     {"id": cliente_id})
    await db.commit()
    return {"mensagem": "Cliente arquivado"}


@router.get("/{cliente_id}/historico")
async def historico_cliente(
    cliente_id: str,
    usuario=Depends(verificar_token),
    db: AsyncSession = Depends(get_db),
):
    exigir_role(usuario, ["admin","socio","advogado"])
    rows = await db.execute(text("""
        SELECT acao, modulo, registro_id, criado_em
        FROM audit_log WHERE registro_id=:id ORDER BY criado_em DESC LIMIT 50
    """), {"id": cliente_id})
    return {"historico": [dict(r) for r in rows.mappings()]}
