"""EJC Público — informações gerais do serviço de petições online."""
from fastapi import APIRouter
router = APIRouter(prefix="/publico", tags=["Site Público"])

@router.get("/ping")
async def ping():
    return {"status": "ok", "servico": "EJC Petições Online"}
