"""
EJC — Streaming (modules/streaming/router.py)
Usa LLMProvider — funciona com Ollama e Groq via SSE.
"""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.llm_provider import get_llm_provider
from app.modules.redacao.service import EJC_SYSTEM_PROMPT
from app.modules.rag.knowledge_base import LegalKnowledgeBase
from app.modules.auditoria.middleware import AVISO_CURTO

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/streaming", tags=["Streaming — Respostas em Tempo Real"])

_kb: Optional[LegalKnowledgeBase] = None

def get_kb():
    global _kb
    if not _kb:
        _kb = LegalKnowledgeBase()
    return _kb


class StreamChatRequest(BaseModel):
    mensagem: str
    prompt_tipo: str = "geral"
    usar_rag: bool = True
    top_k: int = 5


class StreamRedacaoRequest(BaseModel):
    titulo: str
    document_type: str = "peticao_inicial"
    facts: str
    objective: str
    client_name: Optional[str] = None
    opposing_party: Optional[str] = None


class StreamAnaliseRequest(BaseModel):
    conteudo: str
    tipo_analise: str = "resumo"


async def _sse_com_aviso(generator):
    """Appenda o aviso jurídico ao final do stream."""
    async for chunk in generator:
        yield chunk
    yield f"data: {{\"token\": \"{AVISO_CURTO.replace(chr(10), ' ')}\", \"done\": false}}\n\n"
    yield "data: {\"token\": \"\", \"done\": true}\n\n"


SSE_HEADERS = {
    "Cache-Control":    "no-cache",
    "Connection":       "keep-alive",
    "X-Accel-Buffering": "no",
}


@router.post("/chat")
async def stream_chat(
    req: StreamChatRequest,
    db: AsyncSession = Depends(get_db),
    kb: LegalKnowledgeBase = Depends(get_kb),
):
    """Chat jurídico em tempo real — tokens chegam conforme são gerados."""
    llm = get_llm_provider()
    rag_ctx = ""
    if req.usar_rag:
        chunks = await kb.semantic_search(db=db, query=req.mensagem, top_k=req.top_k)
        rag_ctx = "\n\n---\n\n".join(c["content"] for c in chunks)

    from app.modules.chat.router import PROMPTS_ESPECIALIZADOS
    system = PROMPTS_ESPECIALIZADOS.get(req.prompt_tipo, EJC_SYSTEM_PROMPT)
    prompt = f"Contexto RAG:\n{rag_ctx or '(sem contexto)'}\n\nPergunta: {req.mensagem}"

    return StreamingResponse(
        _sse_com_aviso(llm.stream(prompt, system=system)),
        media_type="text/event-stream", headers=SSE_HEADERS,
    )


@router.post("/redigir")
async def stream_redigir(
    req: StreamRedacaoRequest,
    db: AsyncSession = Depends(get_db),
    kb: LegalKnowledgeBase = Depends(get_kb),
):
    """Geração de peça jurídica em streaming."""
    llm = get_llm_provider()
    chunks = await kb.semantic_search(db=db, query=f"{req.document_type} {req.objective}", top_k=8)
    rag = "\n\n---\n\n".join(c["content"] for c in chunks) or "Use direito positivo vigente."

    TIPOS = {
        "peticao_inicial": "Redija uma PETIÇÃO INICIAL completa.",
        "recurso":         "Redija um RECURSO ORDINÁRIO completo.",
        "contrato":        "Redija um CONTRATO completo.",
        "parecer":         "Redija um PARECER JURÍDICO completo.",
        "defesa":          "Redija uma CONTESTAÇÃO completa.",
    }
    instrucao = TIPOS.get(req.document_type, f"Redija um {req.document_type} completo.")
    partes = ""
    if req.client_name:
        partes += f"\nREQUERENTE: {req.client_name}"
    if req.opposing_party:
        partes += f"\nREQUERIDO: {req.opposing_party}"

    prompt = f"""{instrucao}
TÍTULO: {req.titulo}
PARTES: {partes or 'não especificadas'}
FATOS: {req.facts}
OBJETIVO: {req.objective}
BASE JURÍDICA (RAG): ---\n{rag}\n---
Produza a peça COMPLETA em Markdown, mínimo 10 páginas."""

    return StreamingResponse(
        _sse_com_aviso(llm.stream(prompt, system=EJC_SYSTEM_PROMPT, max_tokens=8192)),
        media_type="text/event-stream", headers=SSE_HEADERS,
    )


@router.post("/analisar")
async def stream_analisar(req: StreamAnaliseRequest):
    """Análise de documento em streaming."""
    llm = get_llm_provider()
    PROMPTS = {
        "resumo":        "Faça um resumo técnico executivo do documento.",
        "estrategia":    "Analise pontos fortes, vulnerabilidades e estratégia recomendada.",
        "clausulas":     "Identifique cláusulas abusivas, ausentes e riscos contratuais.",
        "simplificacao": "Explique em linguagem simples para o cliente leigo.",
    }
    instrucao = PROMPTS.get(req.tipo_analise, PROMPTS["resumo"])
    prompt = f"{instrucao}\n\nDOCUMENTO:\n{req.conteudo[:8000]}"

    return StreamingResponse(
        _sse_com_aviso(llm.stream(prompt, system=EJC_SYSTEM_PROMPT)),
        media_type="text/event-stream", headers=SSE_HEADERS,
    )


@router.get("/provider")
async def info_provider():
    """Retorna qual provedor de LLM está ativo."""
    llm = get_llm_provider()
    saude = await llm.check_health()
    return {"provider_ativo": llm.provider, **saude}
