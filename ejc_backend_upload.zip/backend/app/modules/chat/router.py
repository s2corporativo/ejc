"""
EJC — Módulo Chat Especializado (modules/chat/router.py)

Equivalente ao ChatAdv:
  - Upload de PDF/DOCX para análise contextual em chat
  - Prompts especializados pré-configurados por área do direito
  - Histórico de conversas persistente
  - Integração com jurisprudências salvas
  - Aviso jurídico obrigatório em todas as respostas
"""
from __future__ import annotations

import logging
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.redacao.service import LegalDraftService
from app.modules.rag.knowledge_base import LegalKnowledgeBase
from app.modules.analise.service import AnaliseService
from app.modules.auditoria.middleware import adicionar_aviso, auditar

logger = logging.getLogger(__name__)

# ── Prompts especializados pré-configurados ────────────────
PROMPTS_ESPECIALIZADOS = {
    "geral": (
        "Você é um assistente jurídico especializado no Direito brasileiro. "
        "Responda com precisão técnica, citando dispositivos legais e jurisprudência. "
        "Nunca invente dados."
    ),
    "trabalhista": (
        "Você é especialista em Direito do Trabalho brasileiro (CLT, TST, TRTs). "
        "Ao responder, sempre cite: artigos da CLT, súmulas do TST, Orientações "
        "Jurisprudenciais da SDI-1 e SDI-2 quando aplicável. "
        "Considere a reforma trabalhista (Lei 13.467/2017) e seus impactos."
    ),
    "civil": (
        "Você é especialista em Direito Civil brasileiro (CC/2002, CPC/2015, STJ). "
        "Priorize: Código Civil (Lei 10.406/2002), jurisprudência do STJ e "
        "princípios da função social dos contratos e boa-fé objetiva."
    ),
    "consumidor": (
        "Você é especialista em Direito do Consumidor (CDC, STJ, TJs). "
        "Base: Lei 8.078/1990, súmulas do STJ sobre relações de consumo, "
        "PROCON e tutela coletiva. Enfoque na responsabilidade objetiva."
    ),
    "tributario": (
        "Você é especialista em Direito Tributário (CTN, CF/88, STJ, STF). "
        "Cite: Código Tributário Nacional, leis específicas (ICMS, ISS, PIS, COFINS, "
        "IR, CSLL), súmulas vinculantes tributárias e jurisprudência do CARF."
    ),
    "previdenciario": (
        "Você é especialista em Direito Previdenciário (INSS, TRFs, TNU). "
        "Base: Lei 8.213/1991, Lei 8.212/1991, Instrução Normativa INSS, "
        "teses do STJ e STF sobre benefícios previdenciários."
    ),
    "processual": (
        "Você é especialista em Direito Processual Civil (CPC/2015). "
        "Cite artigos do CPC (Lei 13.105/2015), jurisprudência do STJ sobre "
        "processo civil, temas repetitivos e incidentes processuais."
    ),
}

router = APIRouter(prefix="/chat", tags=["Chat Especializado"])

_llm: Optional[LegalDraftService] = None
_kb: Optional[LegalKnowledgeBase] = None
_analise: Optional[AnaliseService] = None


def get_llm() -> LegalDraftService:
    global _llm
    if not _llm:
        _llm = LegalDraftService()
    return _llm

def get_kb() -> LegalKnowledgeBase:
    global _kb
    if not _kb:
        _kb = LegalKnowledgeBase()
    return _kb

def get_analise() -> AnaliseService:
    global _analise
    if not _analise:
        _analise = AnaliseService()
    return _analise


class MensagemRequest(BaseModel):
    mensagem: str
    session_id: Optional[str] = None
    prompt_tipo: str = "geral"
    caso_id: Optional[str] = None


@router.post("/mensagem")
async def enviar_mensagem(
    req: MensagemRequest,
    db: AsyncSession = Depends(get_db),
    llm: LegalDraftService = Depends(get_llm),
    kb: LegalKnowledgeBase = Depends(get_kb),
):
    """
    Envia mensagem ao chat especializado.
    Usa RAG para enriquecer a resposta com documentos da base.
    Aviso jurídico obrigatório em todas as respostas.
    """
    # Recupera histórico se session_id fornecido
    historico_ctx = ""
    if req.session_id:
        row = await db.execute(
            text("SELECT mensagens FROM chat_sessions WHERE id=:id"),
            {"id": req.session_id},
        )
        sess = row.mappings().first()
        if sess and sess["mensagens"]:
            import json
            msgs = json.loads(sess["mensagens"]) if isinstance(sess["mensagens"], str) else sess["mensagens"]
            historico_ctx = "\n".join(
                f"[{m['role'].upper()}] {m['content'][:300]}"
                for m in msgs[-6:]
            )

    # Busca contexto RAG
    chunks = await kb.semantic_search(db=db, query=req.mensagem, top_k=5)
    rag_ctx = "\n\n---\n\n".join(c["content"] for c in chunks) if chunks else ""

    # Prompt especializado + contexto
    system = PROMPTS_ESPECIALIZADOS.get(req.prompt_tipo, PROMPTS_ESPECIALIZADOS["geral"])
    prompt = f"""{system}

{'Histórico recente:' + chr(10) + historico_ctx if historico_ctx else ''}

Contexto jurídico recuperado da base de conhecimento:
{rag_ctx if rag_ctx else '(base de conhecimento sem documentos para este tema)'}

Pergunta:
{req.mensagem}"""

    resposta = await llm.answer_from_context(query=req.mensagem, context=rag_ctx or req.mensagem)
    resposta_com_aviso = adicionar_aviso(resposta, curto=True)

    # Persiste na sessão — upsert correto para UUID PK
    session_id = req.session_id or str(uuid4())
    import json
    nova_msg = [{"role": "user", "content": req.mensagem},
                {"role": "assistant", "content": resposta_com_aviso}]

    row_exists = await db.execute(
        text("SELECT id FROM chat_sessions WHERE id=:id"), {"id": session_id}
    )
    if row_exists.mappings().first():
        await db.execute(
            text("""
                UPDATE chat_sessions
                SET mensagens = mensagens || :msgs::jsonb, updated_at=NOW()
                WHERE id=:id
            """),
            {"id": session_id, "msgs": json.dumps(nova_msg)},
        )
    else:
        await db.execute(
            text("""
                INSERT INTO chat_sessions (id, prompt_tipo, caso_id, mensagens)
                VALUES (:id, :tipo, :cid, :msgs::jsonb)
            """),
            {"id": session_id, "tipo": req.prompt_tipo,
             "cid": req.caso_id, "msgs": json.dumps(nova_msg)},
        )

    return {
        "session_id": session_id,
        "resposta": resposta_com_aviso,
        "fontes": [{"filename": c["filename"], "similarity": c["similarity"]} for c in chunks[:3]],
        "prompt_tipo": req.prompt_tipo,
        "aviso_juridico": True,
        "requires_human_review": True,
    }


@router.post("/upload-documento")
async def upload_e_analisar(
    file: UploadFile = File(...),
    pergunta: str = Form("Faça um resumo e análise estratégica deste documento."),
    session_id: Optional[str] = Form(None),
    prompt_tipo: str = Form("geral"),
    db: AsyncSession = Depends(get_db),
    analise: AnaliseService = Depends(get_analise),
    llm: LegalDraftService = Depends(get_llm),
):
    """
    Upload de PDF/DOCX para análise contextual em chat.
    Extrai o texto, analisa com IA e responde à pergunta do advogado.
    Aviso jurídico obrigatório na resposta.
    """
    content = await file.read()
    texto = analise.extrair_texto(content, file.filename)
    if not texto.strip():
        raise HTTPException(422, "Não foi possível extrair texto do arquivo.")

    system = PROMPTS_ESPECIALIZADOS.get(prompt_tipo, PROMPTS_ESPECIALIZADOS["geral"])
    prompt = f"""{system}

DOCUMENTO ANALISADO ({file.filename}):
{texto[:8000]}

PERGUNTA DO ADVOGADO:
{pergunta}"""

    resposta = await llm.answer_from_context(query=pergunta, context=texto[:8000])
    resposta_com_aviso = adicionar_aviso(resposta, curto=True)

    await auditar(db, "UPLOAD_DOCUMENTO_CHAT", "chat", dados_depois={"filename": file.filename})

    return {
        "session_id": session_id or str(uuid4()),
        "filename": file.filename,
        "caracteres_extraidos": len(texto),
        "resposta": resposta_com_aviso,
        "aviso_juridico": True,
        "requires_human_review": True,
    }


@router.get("/sessoes")
async def listar_sessoes(
    caso_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """Lista sessões de chat com histórico persistente."""
    filtro = "WHERE caso_id=:cid" if caso_id else ""
    params = {"cid": caso_id} if caso_id else {}
    rows = await db.execute(
        text(f"""
            SELECT id, titulo, prompt_tipo, caso_id, created_at, updated_at,
                   jsonb_array_length(mensagens) AS total_mensagens
            FROM chat_sessions {filtro}
            ORDER BY updated_at DESC LIMIT 50
        """),
        params,
    )
    return {"sessoes": [dict(r) for r in rows.mappings()]}


@router.get("/sessoes/{session_id}")
async def buscar_sessao(session_id: str, db: AsyncSession = Depends(get_db)):
    """Retorna histórico completo de uma sessão."""
    row = await db.execute(
        text("SELECT * FROM chat_sessions WHERE id=:id"), {"id": session_id}
    )
    sess = row.mappings().first()
    if not sess:
        raise HTTPException(404, "Sessão não encontrada.")
    return dict(sess)


@router.get("/prompts-disponiveis")
async def listar_prompts():
    """Lista os prompts especializados disponíveis por área do direito."""
    return {
        "prompts": [
            {"id": k, "descricao": v[:120] + "..."}
            for k, v in PROMPTS_ESPECIALIZADOS.items()
        ]
    }
