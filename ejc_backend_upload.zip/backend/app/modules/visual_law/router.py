"""
EJC — Módulo Visual Law (modules/visual_law/router.py)

QR Codes dinâmicos e validação visual de documentos jurídicos:
  - Geração de QR Code para qualquer conteúdo
  - Validação de documentos via QR Code
  - Listagem de QR Codes gerados
"""
from __future__ import annotations

import base64
import io
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/visual-law", tags=["Visual Law — QR Codes"])


def _gerar_qr_png(conteudo: str) -> bytes:
    """Gera QR Code PNG. Requer qrcode[pil] e Pillow."""
    try:
        import qrcode
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(conteudo)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()
    except ImportError:
        raise HTTPException(503, "qrcode[pil] não instalado. Execute: pip install 'qrcode[pil]' Pillow")


class QRRequest(BaseModel):
    conteudo: str
    tipo: str = "url"   # url | processo | validacao | documento
    documento_id: Optional[str] = None


@router.post("/gerar")
async def gerar_qrcode(req: QRRequest, db: AsyncSession = Depends(get_db)):
    """Gera QR Code e persiste no banco. Retorna base64 PNG."""
    png_bytes = _gerar_qr_png(req.conteudo)
    qr_b64 = base64.b64encode(png_bytes).decode()

    from uuid import uuid4
    qid = str(uuid4())
    await db.execute(
        text("""
            INSERT INTO qrcodes_gerados (id, documento_id, tipo, conteudo, qr_base64)
            VALUES (:id,:did,:tipo,:cont,:qr)
        """),
        {"id": qid, "did": req.documento_id, "tipo": req.tipo,
         "cont": req.conteudo, "qr": qr_b64},
    )
    return {"id": qid, "qr_base64": qr_b64, "conteudo": req.conteudo}


@router.get("/gerar-png")
async def gerar_qrcode_png(conteudo: str):
    """Retorna QR Code diretamente como imagem PNG."""
    try:
        png = _gerar_qr_png(conteudo)
        return StreamingResponse(io.BytesIO(png), media_type="image/png")
    except HTTPException:
        raise


@router.get("/validar/{doc_id}")
async def validar_documento(doc_id: str, db: AsyncSession = Depends(get_db)):
    """Valida um documento jurídico via ID (escaneado pelo QR Code)."""
    row = await db.execute(
        text("SELECT id, title, document_type, status, created_at FROM legal_documents WHERE id=:id"),
        {"id": doc_id},
    )
    doc = row.mappings().first()
    if not doc:
        return {"valido": False, "mensagem": "Documento não encontrado no sistema EJC."}

    return {
        "valido": True,
        "documento": dict(doc),
        "sistema": "EJC — Ecossistema Jurídico Clovis",
        "verificado_em": "via QR Code Visual Law",
    }


@router.get("/historico")
async def historico_qrcodes(db: AsyncSession = Depends(get_db)):
    """Lista QR Codes gerados."""
    rows = await db.execute(
        text("SELECT id, documento_id, tipo, conteudo, created_at FROM qrcodes_gerados ORDER BY created_at DESC LIMIT 50")
    )
    return {"qrcodes": [dict(r) for r in rows.mappings()]}
