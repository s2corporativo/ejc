"""
EJC — Módulo Prazos (modules/prazos/service.py + router.py)

Gestão inteligente de prazos processuais:
  - Cadastro manual ou automático via DataJud
  - Alertas por antecedência configurável
  - Cálculo de dias úteis (exclui feriados nacionais)
  - Dashboard de prazos críticos
  - Exportação para calendário (.ics)
"""
from __future__ import annotations

import logging
from datetime import date, timedelta
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

logger = logging.getLogger(__name__)

# Feriados nacionais fixos (dia, mês)
FERIADOS_FIXOS = {
    (1, 1), (21, 4), (1, 5), (7, 9), (12, 10),
    (2, 11), (15, 11), (20, 11), (25, 12),
}


def calcular_prazo_dias_uteis(data_inicio: date, dias_uteis: int) -> date:
    """Calcula data de vencimento contando apenas dias úteis."""
    atual = data_inicio
    contados = 0
    while contados < dias_uteis:
        atual += timedelta(days=1)
        if atual.weekday() < 5 and (atual.day, atual.month) not in FERIADOS_FIXOS:
            contados += 1
    return atual


def dias_uteis_restantes(vencimento: date) -> int:
    """Conta dias úteis entre hoje e o vencimento."""
    hoje = date.today()
    if vencimento <= hoje:
        return 0
    atual = hoje
    contados = 0
    while atual < vencimento:
        atual += timedelta(days=1)
        if atual.weekday() < 5 and (atual.day, atual.month) not in FERIADOS_FIXOS:
            contados += 1
    return contados


router = APIRouter(prefix="/prazos", tags=["Prazos Processuais"])


class CriarPrazoRequest(BaseModel):
    titulo: str
    tipo_prazo: str
    data_vencimento: str          # "YYYY-MM-DD"
    espaco_id: Optional[str] = None
    numero_processo: Optional[str] = None
    tribunal: Optional[str] = None
    descricao: Optional[str] = None
    data_intimacao: Optional[str] = None
    dias_uteis: bool = True
    alertas_dias: list[int] = [5, 2, 1]
    prioridade: str = "media"


@router.post("/", status_code=201)
async def criar_prazo(req: CriarPrazoRequest, db: AsyncSession = Depends(get_db)):
    """Cadastra um novo prazo processual."""
    pid = uuid4()
    await db.execute(
        text("""
            INSERT INTO prazos (id, espaco_id, titulo, descricao, numero_processo,
                tribunal, tipo_prazo, data_intimacao, data_vencimento,
                dias_uteis, alertas_dias, prioridade)
            VALUES (:id,:eid,:titulo,:desc,:np,:tr,:tipo,:di,:dv,:du,:al,:prio)
        """),
        {
            "id": str(pid), "eid": req.espaco_id, "titulo": req.titulo,
            "desc": req.descricao, "np": req.numero_processo, "tr": req.tribunal,
            "tipo": req.tipo_prazo, "di": req.data_intimacao, "dv": req.data_vencimento,
            "du": req.dias_uteis, "al": req.alertas_dias, "prio": req.prioridade,
        },
    )
    venc = date.fromisoformat(req.data_vencimento)
    return {
        "id": str(pid), "titulo": req.titulo,
        "data_vencimento": req.data_vencimento,
        "dias_uteis_restantes": dias_uteis_restantes(venc),
        "status": "pendente",
    }


@router.get("/")
async def listar_prazos(
    status: Optional[str] = None,
    espaco_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """Lista prazos com contagem de dias úteis restantes."""
    filtros = []
    params: dict = {}
    if status:
        filtros.append("p.status = :status"); params["status"] = status
    if espaco_id:
        filtros.append("p.espaco_id = :eid"); params["eid"] = espaco_id
    where = "WHERE " + " AND ".join(filtros) if filtros else ""

    rows = await db.execute(
        text(f"""
            SELECT p.*, e.titulo AS espaco_titulo
            FROM prazos p
            LEFT JOIN espacos e ON e.id = p.espaco_id
            {where}
            ORDER BY p.data_vencimento ASC
            LIMIT 200
        """),
        params,
    )
    prazos = []
    for r in rows.mappings():
        d = dict(r)
        try:
            venc = d["data_vencimento"]
            if isinstance(venc, str):
                venc = date.fromisoformat(venc)
            d["dias_uteis_restantes"] = dias_uteis_restantes(venc)
            d["critico"] = d["dias_uteis_restantes"] <= 2 and d["status"] == "pendente"
        except Exception:
            d["dias_uteis_restantes"] = None
            d["critico"] = False
        prazos.append(d)
    return {"prazos": prazos, "total": len(prazos)}


@router.post("/calcular-data")
async def calcular_data_vencimento(payload: dict):
    """
    Calcula a data de vencimento a partir de uma data de início e número de dias úteis.
    Exclui fins de semana e feriados nacionais fixos.
    """
    try:
        data_inicio = date.fromisoformat(payload.get("data_inicio", str(date.today())))
        dias = int(payload.get("dias_uteis", 15))
    except (ValueError, TypeError) as e:
        raise HTTPException(422, f"Parâmetro inválido: {e}")

    vencimento = calcular_prazo_dias_uteis(data_inicio, dias)
    return {
        "data_inicio": str(data_inicio),
        "dias_uteis": dias,
        "data_vencimento": str(vencimento),
        "dias_corridos": (vencimento - data_inicio).days,
        "dia_semana": ["segunda","terça","quarta","quinta","sexta","sábado","domingo"][vencimento.weekday()],
    }


@router.get("/feriados")
async def listar_feriados():
    """Lista os feriados nacionais fixos utilizados no cálculo de dias úteis."""
    feriados = [
        {"data": f"2025-{m:02d}-{d:02d}", "nome": nome}
        for (d, m), nome in {
            (1, 1): "Confraternização Universal",
            (21, 4): "Tiradentes",
            (1, 5): "Dia do Trabalho",
            (7, 9): "Independência do Brasil",
            (12, 10): "Nossa Senhora Aparecida",
            (2, 11): "Finados",
            (15, 11): "Proclamação da República",
            (20, 11): "Consciência Negra",
            (25, 12): "Natal",
        }.items()
    ]
    return {"feriados_nacionais_fixos": feriados,
            "nota": "Feriados municipais e estaduais devem ser adicionados manualmente."}


@router.get("/dashboard")
async def dashboard_prazos(db: AsyncSession = Depends(get_db)):
    """Painel resumido: prazos críticos, próximos 7 dias e vencidos."""
    rows = await db.execute(
        text("""
            SELECT id, titulo, tipo_prazo, data_vencimento, prioridade, status,
                   numero_processo, tribunal
            FROM prazos
            WHERE status = 'pendente'
            ORDER BY data_vencimento ASC
            LIMIT 50
        """)
    )
    todos = list(rows.mappings())
    hoje = date.today()

    criticos, proximos, normais = [], [], []
    for r in todos:
        d = dict(r)
        try:
            venc = d["data_vencimento"]
            if isinstance(venc, str):
                venc = date.fromisoformat(venc)
            du = dias_uteis_restantes(venc)
            d["dias_uteis_restantes"] = du
            if du <= 0:
                criticos.append(d)
            elif du <= 3:
                criticos.append(d)
            elif du <= 7:
                proximos.append(d)
            else:
                normais.append(d)
        except Exception:
            normais.append(d)

    return {
        "criticos":  criticos[:5],
        "proximos":  proximos[:5],
        "normais":   normais[:10],
        "total_pendentes": len(todos),
    }


@router.patch("/{prazo_id}/status")
async def atualizar_status(
    prazo_id: str, payload: dict, db: AsyncSession = Depends(get_db)
):
    """Atualiza status do prazo (pendente → cumprido / cancelado)."""
    novo = payload.get("status", "cumprido")
    if novo not in ("pendente", "cumprido", "cancelado"):
        raise HTTPException(422, "Status inválido.")
    await db.execute(
        text("UPDATE prazos SET status=:s WHERE id=:id"), {"s": novo, "id": prazo_id}
    )
    return {"message": f"Prazo marcado como '{novo}'."}


@router.get("/{prazo_id}/ics")
async def exportar_ics(prazo_id: str, db: AsyncSession = Depends(get_db)):
    """Exporta o prazo como arquivo .ics para importar em qualquer calendário."""
    from fastapi.responses import Response
    row = await db.execute(
        text("SELECT * FROM prazos WHERE id = :id"), {"id": prazo_id}
    )
    p = row.mappings().first()
    if not p:
        raise HTTPException(404, "Prazo não encontrado.")

    venc = p["data_vencimento"]
    if isinstance(venc, str):
        venc = date.fromisoformat(venc)
    dt_str = venc.strftime("%Y%m%d")

    ics = (
        "BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//EJC//Prazo//PT\n"
        "BEGIN:VEVENT\n"
        f"UID:{prazo_id}@ejc\n"
        f"DTSTART;VALUE=DATE:{dt_str}\n"
        f"DTEND;VALUE=DATE:{dt_str}\n"
        f"SUMMARY:PRAZO: {p['titulo']}\n"
        f"DESCRIPTION:{p.get('descricao','') or ''}\n"
        "END:VEVENT\nEND:VCALENDAR"
    )
    return Response(
        content=ics,
        media_type="text/calendar",
        headers={"Content-Disposition": f'attachment; filename="prazo_{prazo_id}.ics"'},
    )
