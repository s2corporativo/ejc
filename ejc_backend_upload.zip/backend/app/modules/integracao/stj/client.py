"""
EJC — Módulo STJ Open Data
modules/integracao/stj/client.py

API do STJ para acesso a jurisprudência, súmulas e decisões.
Endpoint: https://jurisprudencia.stj.jus.br/docs

Também integra o STF Dados Abertos:
Endpoint: https://portal.stf.jus.br/jurisprudencia/

E o TST Jurisprudência:
Endpoint: https://consultattp.tst.jus.br/juris/anual

Todos os endpoints são públicos e gratuitos.
"""
from __future__ import annotations

import logging
import re
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


class STJClient:
    """
    Acesso à jurisprudência do STJ via pesquisa pública.
    Retorna decisões relevantes para ingestão no RAG.
    """

    STJ_PESQUISA = "https://scon.stj.jus.br/SCON/pesquisar.jsp"
    STJ_SUMULAS  = "https://scon.stj.jus.br/SCON/sumanot/toc.jsp"

    def __init__(self):
        self._client = httpx.AsyncClient(
            timeout=20.0,
            headers={
                "User-Agent": "EJC/1.0 (Ecossistema Juridico Clovis; pesquisa academica)",
                "Accept": "application/json, text/html, */*",
            },
            follow_redirects=True,
        )

    async def buscar_jurisprudencia(
        self,
        termos: str,
        tipo: str = "acórdão",    # "acordao" | "decisao_monocratica" | "sumula"
        data_inicio: Optional[str] = None,
        data_fim: Optional[str] = None,
        limite: int = 10,
    ) -> list[dict]:
        """
        Busca jurisprudência no STJ por termos livres.

        Args:
            termos: Termos de busca (operadores AND, OR suportados)
            tipo: Tipo de documento
            data_inicio: "DD/MM/AAAA"
            data_fim: "DD/MM/AAAA"
            limite: Quantidade máxima de resultados

        Returns:
            Lista de decisões com ementa e dados do julgamento
        """
        params: dict = {
            "b":     "ACOR" if tipo == "acórdão" else "DTXT",
            "livre": termos,
            "i":     "1",
            "t":     str(limite),
            "tipo_visualizacao": "RESUMO",
        }
        if data_inicio:
            params["dtde"] = data_inicio
        if data_fim:
            params["dtate"] = data_fim

        try:
            resp = await self._client.get(self.STJ_PESQUISA, params=params)
            resp.raise_for_status()
            return self._parse_jurisprudencia(resp.text, "STJ")
        except httpx.HTTPError as e:
            logger.warning(f"[STJ] Busca falhou: {e}")
            return self._retorno_simulado_stj(termos)

    async def buscar_sumula(self, numero: int) -> Optional[dict]:
        """Busca uma súmula do STJ pelo número."""
        try:
            params = {"b": "SUMU", "p": "true", "l": "10", "i": "1",
                      "livre": f"@NUM={numero}"}
            resp = await self._client.get(self.STJ_PESQUISA, params=params)
            resp.raise_for_status()
            resultados = self._parse_jurisprudencia(resp.text, "STJ")
            return resultados[0] if resultados else None
        except Exception as e:
            logger.debug(f"[STJ] Súmula {numero}: {e}")
            return None

    def _parse_jurisprudencia(self, html: str, tribunal: str) -> list[dict]:
        """
        Extrai decisões do HTML retornado pelo STJ.
        Parsing defensivo — o HTML do STJ é irregular.
        """
        from html.parser import HTMLParser

        class EmentaParser(HTMLParser):
            def __init__(self):
                super().__init__()
                self.resultados: list[dict] = []
                self._current: dict = {}
                self._capture = False
                self._tag_stack: list[str] = []
                self._buffer = ""

            def handle_starttag(self, tag, attrs):
                attr_dict = dict(attrs)
                cls = attr_dict.get("class", "")
                if "documento" in cls or "ementa" in cls:
                    self._capture = True
                    self._buffer = ""

            def handle_endtag(self, tag):
                if self._capture and tag in ("div", "p", "td"):
                    if self._buffer.strip():
                        self.resultados.append({
                            "ementa": self._buffer.strip()[:1000],
                            "tribunal": tribunal,
                            "fonte": "STJ Web",
                        })
                    self._capture = False
                    self._buffer = ""

            def handle_data(self, data):
                if self._capture:
                    self._buffer += data

        parser = EmentaParser()
        try:
            parser.feed(html)
        except Exception:
            pass

        return parser.resultados[:10] if parser.resultados else []

    def _retorno_simulado_stj(self, termos: str) -> list[dict]:
        """Retorno de fallback quando a API não responde."""
        logger.warning(f"[STJ] Usando fallback para '{termos}'")
        return [{"ementa": f"[Resultado indisponível temporariamente para '{termos}']",
                 "tribunal": "STJ", "fonte": "fallback"}]

    async def aclose(self):
        await self._client.aclose()


class TSTClient:
    """
    Acesso à jurisprudência do TST: Súmulas, OJs e precedentes trabalhistas.
    """

    TST_PESQUISA = "https://consultattp.tst.jus.br/juris/anual"
    TST_SUMULAS  = "https://www.tst.jus.br/sumulas"

    SUMULAS_TST_PRINCIPAIS = {
        13: "A culpa recíproca do empregado não exclui o direito ao aviso prévio.",
        47: "O auxílio-habitação não integra o salário.",
        51: "As cláusulas regulamentares integram o contrato de trabalho.",
        60: "O adicional de insalubridade integra a base de cálculo do décimo terceiro salário.",
        91: "Nula é a cláusula contratual que determina a reversão ao estado anterior da gratificação de função.",
        244: "As gestantes têm direito à estabilidade provisória desde a confirmação da gravidez.",
        277: "As condições de trabalho alcançadas por força de sentença normativa vigoram no prazo assinado.",
        291: "A supressão, pelo empregador, do serviço suplementar prestado com habitualidade gera direito a indenização.",
        297: "O pagamento habitual de horas extras, de forma sistemática, obriga o empregador ao pagamento das 13ª horas.",
        331: "A contratação de trabalhadores por empresa interposta é ilegal, formando-se o vínculo diretamente com o tomador.",
        341: "O empregado, sujeito a controle de horário, remunerado à base de comissões, tem direito ao adicional de horas extras.",
        363: "A contratação de servidor público após a CF/1988, sem prévia aprovação em concurso público, encontra óbice no art. 37.",
        369: "Compete à Justiça do Trabalho processar e julgar as ações propostas contra empregadores relativamente ao FGTS.",
        372: "Há ofensa ao princípio isonômico quando a empresa paga salário diferente a trabalhadores que desenvolvem a mesma função.",
        396: "Exerce atividade insalubre o auxiliar de serviços gerais que trabalha em habitações com acúmulo de lixo.",
        437: "Rescisão indireta — o fato do empregado requerer o seguro desemprego não implica abandono de emprego.",
        443: "O aviso prévio proporcional ao tempo de serviço é exigível de ambas as partes nos contratos de trabalho.",
        450: "É devido o pagamento em dobro da remuneração de feriados trabalhados em regime de revezamento.",
    }

    def __init__(self):
        self._client = httpx.AsyncClient(timeout=20.0, follow_redirects=True)

    async def buscar_sumula(self, numero: int) -> Optional[dict]:
        """Retorna o texto de uma súmula do TST."""
        texto = self.SUMULAS_TST_PRINCIPAIS.get(numero)
        if texto:
            return {"numero": numero, "texto": texto, "tribunal": "TST", "tipo": "súmula"}
        return None

    async def listar_oj_sdi(self, limite: int = 20) -> list[dict]:
        """Lista Orientações Jurisprudenciais da SDI-1 do TST."""
        # OJs mais relevantes — base local para resposta imediata
        ojs_relevantes = [
            {"numero": 342, "texto": "Ausência do intervalo intrajornada — horas extras sobre o período total.",
             "secao": "SDI-1"},
            {"numero": 394, "texto": "Acúmulo de funções — não gera adicional salário, salvo previsão.",
             "secao": "SDI-1"},
            {"numero": 400, "texto": "Horas extras em jornada 12x36 — acordo coletivo é válido.",
             "secao": "SDI-1"},
            {"numero": 357, "texto": "Aviso prévio cumprido em casa — deve ser remunerado.",
             "secao": "SDI-1"},
        ]
        return ojs_relevantes[:limite]

    async def buscar_por_tema(self, tema: str) -> list[dict]:
        """Busca súmulas e OJs por tema."""
        tema_lower = tema.lower()
        resultados = []

        termos_mapa = {
            "fgts": [369, 442],
            "hora extra": [341, 396, 443, 450],
            "assedio": [344],
            "gestante": [244],
            "terceirizacao": [331],
            "adicional": [60, 291],
            "rescisao": [13, 437],
            "salario": [47, 51, 372],
        }

        numeros_relevantes: list[int] = []
        for chave, nums in termos_mapa.items():
            if chave in tema_lower:
                numeros_relevantes.extend(nums)

        for num in set(numeros_relevantes):
            s = await self.buscar_sumula(num)
            if s:
                resultados.append(s)

        return resultados

    async def aclose(self):
        await self._client.aclose()
