"""
EJC — Módulo Receita Federal
modules/integracao/receita/client.py

Consulta de CNPJ e situação cadastral via API pública da Receita Federal.
Endpoints utilizados (sem custo, sem cadastro):
  - https://receitaws.com.br/v1/cnpj/{cnpj}  (mirror público da RF)
  - https://brasilapi.com.br/api/cnpj/v1/{cnpj}  (Brasil API — CNPJ)
  - https://brasilapi.com.br/api/cep/v2/{cep}     (Brasil API — CEP)

Útil para:
  - Verificar dados cadastrais de parte contrária
  - Validar existência de empresa antes de ajuizar
  - Preencher qualificação da parte em peças geradas
"""
from __future__ import annotations

import logging
import re
from typing import Optional

import httpx

logger = logging.getLogger(__name__)

BRASILAPI_BASE = "https://brasilapi.com.br/api"
RECEITAWS_BASE = "https://receitaws.com.br/v1"


class ReceitaFederalClient:
    """
    Consulta de CNPJ e dados cadastrais via APIs públicas da Receita Federal.
    """

    def __init__(self):
        self._client = httpx.AsyncClient(
            timeout=15.0,
            headers={"Accept": "application/json"},
            follow_redirects=True,
        )

    async def consultar_cnpj(self, cnpj: str) -> dict:
        """
        Consulta dados cadastrais de uma empresa pelo CNPJ.
        Tenta BrasilAPI primeiro, fallback para ReceitaWS.

        Args:
            cnpj: CNPJ com ou sem formatação (14 dígitos)

        Returns:
            Dados cadastrais: razão social, situação, endereço, sócios, etc.
        """
        cnpj_limpo = self._limpar_cnpj(cnpj)
        if len(cnpj_limpo) != 14:
            raise ValueError(f"CNPJ inválido: '{cnpj}'. Esperado 14 dígitos.")

        # Tenta BrasilAPI
        try:
            resp = await self._client.get(f"{BRASILAPI_BASE}/cnpj/v1/{cnpj_limpo}")
            if resp.status_code == 200:
                return self._formatar_cnpj_brasilapi(resp.json(), cnpj_limpo)
        except httpx.HTTPError as e:
            logger.debug(f"[Receita] BrasilAPI falhou: {e}")

        # Fallback: ReceitaWS
        try:
            resp = await self._client.get(f"{RECEITAWS_BASE}/cnpj/{cnpj_limpo}")
            if resp.status_code == 200:
                return self._formatar_cnpj_receitaws(resp.json(), cnpj_limpo)
        except httpx.HTTPError as e:
            logger.debug(f"[Receita] ReceitaWS falhou: {e}")

        raise RuntimeError(
            f"Não foi possível consultar o CNPJ {self._formatar_cnpj(cnpj_limpo)}. "
            "Verifique sua conexão ou tente novamente."
        )

    async def consultar_cep(self, cep: str) -> dict:
        """Consulta endereço por CEP via BrasilAPI."""
        cep_limpo = re.sub(r"[^\d]", "", cep)
        if len(cep_limpo) != 8:
            raise ValueError(f"CEP inválido: '{cep}'")
        try:
            resp = await self._client.get(f"{BRASILAPI_BASE}/cep/v2/{cep_limpo}")
            resp.raise_for_status()
            data = resp.json()
            return {
                "cep": cep_limpo,
                "logradouro": data.get("street", ""),
                "bairro": data.get("neighborhood", ""),
                "municipio": data.get("city", ""),
                "uf": data.get("state", ""),
            }
        except httpx.HTTPError as e:
            raise RuntimeError(f"CEP não encontrado: {e}")

    def gerar_qualificacao_parte(self, dados: dict) -> str:
        """
        Gera texto de qualificação da parte para uso em peças jurídicas.
        Formato padrão utilizado em petições brasileiras.
        """
        razao = dados.get("razao_social", "N/D")
        cnpj  = dados.get("cnpj_formatado", "N/D")
        end   = dados.get("logradouro", "")
        num   = dados.get("numero", "")
        bairro = dados.get("bairro", "")
        municipio = dados.get("municipio", "")
        uf    = dados.get("uf", "")
        situacao = dados.get("situacao", "ATIVA")

        qualificacao = (
            f"{razao}, pessoa jurídica de direito privado, "
            f"CNPJ/MF nº {cnpj}, "
            f"com sede na {end}, nº {num}, {bairro}, {municipio}/{uf}"
        )
        if situacao and situacao != "ATIVA":
            qualificacao += f" (situação cadastral: {situacao})"

        return qualificacao

    def _formatar_cnpj_brasilapi(self, data: dict, cnpj_limpo: str) -> dict:
        endereco = (
            f"{data.get('logradouro','')}, {data.get('numero','')}"
            f" — {data.get('bairro','')}, {data.get('municipio','')}/{data.get('uf','')}"
        )
        socios = [
            {
                "nome": s.get("nome_socio", ""),
                "qualificacao": s.get("qualificacao_socio", ""),
                "cpf_representante": s.get("cpf_representante_legal", ""),
            }
            for s in data.get("qsa", [])
        ]
        return {
            "cnpj": cnpj_limpo,
            "cnpj_formatado": self._formatar_cnpj(cnpj_limpo),
            "razao_social": data.get("razao_social", ""),
            "nome_fantasia": data.get("nome_fantasia", ""),
            "situacao": data.get("descricao_situacao_cadastral", ""),
            "data_abertura": data.get("data_inicio_atividade", ""),
            "natureza_juridica": data.get("descricao_natureza_juridica", ""),
            "porte": data.get("descricao_porte", ""),
            "atividade_principal": data.get("cnae_fiscal_descricao", ""),
            "logradouro": data.get("logradouro", ""),
            "numero": data.get("numero", ""),
            "complemento": data.get("complemento", ""),
            "bairro": data.get("bairro", ""),
            "municipio": data.get("municipio", ""),
            "uf": data.get("uf", ""),
            "cep": data.get("cep", ""),
            "email": data.get("email", ""),
            "telefone": data.get("ddd_telefone_1", ""),
            "socios": socios,
            "endereco_formatado": endereco,
            "fonte": "BrasilAPI/Receita Federal",
        }

    def _formatar_cnpj_receitaws(self, data: dict, cnpj_limpo: str) -> dict:
        socios = [
            {"nome": s.get("nome", ""), "qualificacao": s.get("qual", "")}
            for s in data.get("qsa", [])
        ]
        return {
            "cnpj": cnpj_limpo,
            "cnpj_formatado": self._formatar_cnpj(cnpj_limpo),
            "razao_social": data.get("nome", ""),
            "nome_fantasia": data.get("fantasia", ""),
            "situacao": data.get("situacao", ""),
            "data_abertura": data.get("abertura", ""),
            "natureza_juridica": data.get("natureza_juridica", ""),
            "porte": data.get("porte", ""),
            "atividade_principal": data.get("atividade_principal", [{}])[0].get("text", ""),
            "logradouro": data.get("logradouro", ""),
            "numero": data.get("numero", ""),
            "bairro": data.get("bairro", ""),
            "municipio": data.get("municipio", ""),
            "uf": data.get("uf", ""),
            "cep": data.get("cep", ""),
            "email": data.get("email", ""),
            "telefone": data.get("telefone", ""),
            "socios": socios,
            "fonte": "ReceitaWS",
        }

    def _limpar_cnpj(self, cnpj: str) -> str:
        return re.sub(r"[^\d]", "", cnpj)

    def _formatar_cnpj(self, cnpj: str) -> str:
        if len(cnpj) == 14:
            return f"{cnpj[:2]}.{cnpj[2:5]}.{cnpj[5:8]}/{cnpj[8:12]}-{cnpj[12:]}"
        return cnpj

    async def aclose(self):
        await self._client.aclose()
