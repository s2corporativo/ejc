"""
EJC — Módulo LexML
modules/integracao/lexml/client.py

LexML é o portal oficial de legislação brasileira do Senado Federal.
Cobre: leis federais, estaduais, municipais, decretos, medidas provisórias,
       resoluções, instruções normativas — texto integral atualizado.

API pública: https://www.lexml.gov.br/busca/SRU
Documentação: https://lexml.gov.br/documentacao
"""
from __future__ import annotations

import logging
import re
from typing import Optional
from xml.etree import ElementTree as ET

import httpx

logger = logging.getLogger(__name__)

LEXML_SRU_URL  = "https://www.lexml.gov.br/busca/SRU"
LEXML_BASE_URL = "https://www.lexml.gov.br"

# Namespaces do LexML
NS = {
    "srw":    "http://www.loc.gov/zing/srw/",
    "lexml":  "http://www.lexml.gov.br/oai/lexml",
    "dc":     "http://purl.org/dc/elements/1.1/",
    "dcterms":"http://purl.org/dc/terms/",
}


class LexMLClient:
    """
    Cliente para busca de legislação no portal LexML (Senado Federal).

    Permite:
    - Busca por número de lei/decreto
    - Busca por texto/ementa
    - Download do texto integral em XML ou HTML
    - Verificação de vigência
    """

    def __init__(self):
        self._client = httpx.AsyncClient(
            timeout=20.0,
            headers={"Accept": "application/xml, text/xml, */*"},
        )

    async def buscar_legislacao(
        self,
        query: str,
        tipo: Optional[str] = None,     # "lei", "decreto", "medida_provisoria"
        esfera: str = "federal",
        limite: int = 10,
        pagina: int = 1,
    ) -> list[dict]:
        """
        Busca legislação no LexML por texto, número ou ementa.

        Args:
            query: Termo de busca (ex: "8036 FGTS" ou "rescisão contrato trabalho")
            tipo: Filtro de tipo normativo
            esfera: "federal" | "estadual" | "municipal"
            limite: Número máximo de resultados

        Returns:
            Lista de normas encontradas com metadados
        """
        cql_parts = [f'dc.title any "{query}" OR dc.description any "{query}"']

        if tipo:
            tipo_map = {
                "lei": "lei.ordinaria",
                "lei_complementar": "lei.complementar",
                "decreto": "decreto",
                "medida_provisoria": "medida.provisoria",
                "resolucao": "resolucao",
                "instrucao_normativa": "instrucao.normativa",
            }
            tipo_lexml = tipo_map.get(tipo, tipo)
            cql_parts.append(f'lexml.tipoNorma = "{tipo_lexml}"')

        cql = " AND ".join(cql_parts)

        params = {
            "operation": "searchRetrieve",
            "version": "1.1",
            "query": cql,
            "maximumRecords": str(limite),
            "startRecord": str((pagina - 1) * limite + 1),
            "recordSchema": "info:srw/schema/1/dc-v1.1",
        }

        try:
            resp = await self._client.get(LEXML_SRU_URL, params=params)
            resp.raise_for_status()
            return self._parse_sru_response(resp.text)
        except httpx.HTTPError as e:
            logger.error(f"[LexML] Erro HTTP: {e}")
            raise RuntimeError(f"LexML indisponível: {e}")

    async def buscar_por_numero(
        self,
        numero: str,
        ano: Optional[str] = None,
        tipo: str = "lei",
    ) -> Optional[dict]:
        """
        Busca uma norma pelo número e ano.
        Ex: buscar_por_numero("8036", "1990", "lei")
        """
        query = f"{tipo} {numero}"
        if ano:
            query += f" {ano}"

        resultados = await self.buscar_legislacao(query, tipo=tipo, limite=5)
        if not resultados:
            return None

        # Prioriza resultado com número exato
        for r in resultados:
            if numero in r.get("numero", "") or numero in r.get("titulo", ""):
                return r
        return resultados[0]

    async def verificar_vigencia(self, referencia: str) -> dict:
        """
        Verifica se uma referência legal está em vigor.
        Extrai número e tipo da string e consulta o LexML.

        Args:
            referencia: Ex: "Lei 8.036/1990" ou "art. 15 da Lei 8.036"

        Returns:
            Dict com status: "vigente" | "revogado" | "nao_encontrado"
        """
        numero, tipo, ano = self._extrair_identificadores(referencia)
        if not numero:
            return {"status": "nao_verificado", "referencia": referencia}

        try:
            norma = await self.buscar_por_numero(numero, ano, tipo)
            if not norma:
                return {"status": "nao_encontrado", "referencia": referencia}

            return {
                "status": "vigente",
                "referencia": referencia,
                "titulo": norma.get("titulo"),
                "numero": norma.get("numero"),
                "data": norma.get("data"),
                "url": norma.get("url"),
            }
        except Exception as e:
            logger.debug(f"[LexML] Verificação falhou para '{referencia}': {e}")
            return {"status": "nao_verificado", "referencia": referencia, "erro": str(e)}

    def _parse_sru_response(self, xml_text: str) -> list[dict]:
        """Parseia a resposta XML do protocolo SRU."""
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError:
            return []

        resultados = []
        records = root.findall(".//srw:record", NS)

        for record in records:
            data_el = record.find(".//srw:recordData", NS)
            if data_el is None:
                continue

            titulo   = self._get_text(data_el, "dc:title")
            descricao = self._get_text(data_el, "dc:description")
            data_pub  = self._get_text(data_el, "dc:date")
            identifier = self._get_text(data_el, "dc:identifier")

            numero = self._extrair_numero_norma(titulo or "")

            resultados.append({
                "titulo": titulo or "",
                "numero": numero,
                "descricao": descricao or "",
                "data": data_pub or "",
                "url": self._montar_url(identifier),
                "fonte": "LexML",
            })

        return resultados

    def _get_text(self, el: ET.Element, tag: str) -> Optional[str]:
        """Busca texto de elemento com namespace."""
        prefix, local = tag.split(":")
        ns_uri = NS.get(prefix, "")
        found = el.find(f"{{{ns_uri}}}{local}")
        if found is not None and found.text:
            return found.text.strip()
        return None

    def _extrair_numero_norma(self, titulo: str) -> str:
        m = re.search(r"\b(\d{1,6}(?:\.\d{3})*)\b", titulo)
        return m.group(1) if m else ""

    def _extrair_identificadores(self, ref: str) -> tuple[str, str, Optional[str]]:
        """Extrai número, tipo e ano de uma referência legal."""
        tipo = "lei"
        if re.search(r"decreto", ref, re.I):
            tipo = "decreto"
        elif re.search(r"complementar", ref, re.I):
            tipo = "lei_complementar"
        elif re.search(r"medida provisória|mp\b", ref, re.I):
            tipo = "medida_provisoria"

        num_match = re.search(r"(\d{3,6}(?:\.\d{3})*)", ref)
        numero = num_match.group(1).replace(".", "") if num_match else ""

        ano_match = re.search(r"\/(\d{4})", ref)
        ano = ano_match.group(1) if ano_match else None

        return numero, tipo, ano

    def _montar_url(self, identifier: Optional[str]) -> str:
        if not identifier:
            return ""
        if identifier.startswith("http"):
            return identifier
        return f"{LEXML_BASE_URL}{identifier}"

    async def aclose(self):
        await self._client.aclose()
