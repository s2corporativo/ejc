"""
EJC — Módulo DataJud (CNJ)
modules/integracao/datajud/client.py

API oficial do CNJ para consulta de processos judiciais em tempo real.
Cobre TODOS os tribunais brasileiros: TJs, TRFs, TRTs, STJ, STF, TST, TSE, STM.

Documentação oficial: https://datajud-wiki.cnj.jus.br/api-publica/
Endpoint base: https://api-publica.datajud.cnj.jus.br/api_publica_<tribunal>/_search

Autenticação: API Key pública (ApiKey cDZHYzlZa0JadVREZDJCendFbXNpTTk=)
Sem custo, sem cadastro necessário — chave pública da documentação CNJ.
"""
from __future__ import annotations

import logging
from typing import Optional
from datetime import date, datetime

import httpx

logger = logging.getLogger(__name__)

# ── Chave pública da documentação oficial do CNJ ──────────────────────────
DATAJUD_API_KEY = "cDZHYzlZa0JadVREZDJCendFbXNpTTk="
DATAJUD_BASE    = "https://api-publica.datajud.cnj.jus.br"

# ── Mapa de tribunais → índice DataJud ────────────────────────────────────
# Fonte: https://datajud-wiki.cnj.jus.br/api-publica/endpoints
TRIBUNAIS: dict[str, str] = {
    # Tribunais de Justiça Estaduais
    "TJAC": "api_publica_tjac", "TJAL": "api_publica_tjal",
    "TJAM": "api_publica_tjam", "TJAP": "api_publica_tjap",
    "TJBA": "api_publica_tjba", "TJCE": "api_publica_tjce",
    "TJDFT": "api_publica_tjdft", "TJES": "api_publica_tjes",
    "TJGO": "api_publica_tjgo", "TJMA": "api_publica_tjma",
    "TJMG": "api_publica_tjmg", "TJMS": "api_publica_tjms",
    "TJMT": "api_publica_tjmt", "TJPA": "api_publica_tjpa",
    "TJPB": "api_publica_tjpb", "TJPE": "api_publica_tjpe",
    "TJPI": "api_publica_tjpi", "TJPR": "api_publica_tjpr",
    "TJRJ": "api_publica_tjrj", "TJRN": "api_publica_tjrn",
    "TJRO": "api_publica_tjro", "TJRR": "api_publica_tjrr",
    "TJRS": "api_publica_tjrs", "TJSC": "api_publica_tjsc",
    "TJSE": "api_publica_tjse", "TJSP": "api_publica_tjsp",
    "TJTO": "api_publica_tjto",
    # Tribunais Regionais Federais
    "TRF1": "api_publica_trf1", "TRF2": "api_publica_trf2",
    "TRF3": "api_publica_trf3", "TRF4": "api_publica_trf4",
    "TRF5": "api_publica_trf5", "TRF6": "api_publica_trf6",
    # Tribunais Regionais do Trabalho
    "TRT1": "api_publica_trt1",   "TRT2": "api_publica_trt2",
    "TRT3": "api_publica_trt3",   "TRT4": "api_publica_trt4",
    "TRT5": "api_publica_trt5",   "TRT6": "api_publica_trt6",
    "TRT7": "api_publica_trt7",   "TRT8": "api_publica_trt8",
    "TRT9": "api_publica_trt9",   "TRT10": "api_publica_trt10",
    "TRT11": "api_publica_trt11", "TRT12": "api_publica_trt12",
    "TRT13": "api_publica_trt13", "TRT14": "api_publica_trt14",
    "TRT15": "api_publica_trt15", "TRT16": "api_publica_trt16",
    "TRT17": "api_publica_trt17", "TRT18": "api_publica_trt18",
    "TRT19": "api_publica_trt19", "TRT20": "api_publica_trt20",
    "TRT21": "api_publica_trt21", "TRT22": "api_publica_trt22",
    "TRT23": "api_publica_trt23", "TRT24": "api_publica_trt24",
    # Superiores
    "STJ":  "api_publica_stj",
    "STF":  "api_publica_stf",
    "TST":  "api_publica_tst",
    "TSE":  "api_publica_tse",
    "STM":  "api_publica_stm",
    "CJF":  "api_publica_cjf",
}


class DataJudClient:
    """
    Cliente assíncrono para a API Pública do DataJud (CNJ).

    Permite:
    - Consultar processo por número (CNJ unificado)
    - Buscar processos por CPF/CNPJ das partes
    - Buscar por classe processual, assunto, orgão julgador
    - Listar movimentações (andamentos) de um processo
    - Ingerir resultado automaticamente na base RAG
    """

    def __init__(self):
        self._client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "Authorization": f"ApiKey {DATAJUD_API_KEY}",
                "Content-Type": "application/json",
            },
        )

    # ──────────────────────────────────────────────────────────────────────
    # CONSULTA POR NÚMERO DO PROCESSO (padrão CNJ: NNNNNNN-DD.AAAA.J.TT.OOOO)
    # ──────────────────────────────────────────────────────────────────────

    async def buscar_por_numero(
        self,
        numero_processo: str,
        tribunal: Optional[str] = None,
    ) -> dict:
        """
        Busca um processo pelo número unificado CNJ.
        Se o tribunal não for informado, tenta detectar pelo número.

        Args:
            numero_processo: Número no formato CNJ (ex: 0001234-56.2023.8.26.0001)
            tribunal: Sigla (ex: TJSP). Se None, detecta automaticamente.

        Returns:
            Dicionário com dados completos do processo.
        """
        numero_limpo = self._normalizar_numero(numero_processo)
        tribunal_key = tribunal or self._detectar_tribunal(numero_limpo)

        if not tribunal_key or tribunal_key not in TRIBUNAIS:
            raise ValueError(
                f"Tribunal '{tribunal_key}' não reconhecido. "
                f"Informe o tribunal manualmente (ex: tribunal='TJSP')."
            )

        indice = TRIBUNAIS[tribunal_key]
        query = {
            "query": {
                "match": {"numeroProcesso": numero_limpo}
            }
        }

        resp = await self._post(indice, query)
        hits = resp.get("hits", {}).get("hits", [])

        if not hits:
            return {"encontrado": False, "numero": numero_limpo, "tribunal": tribunal_key}

        processo = hits[0]["_source"]
        return self._formatar_processo(processo, tribunal_key)

    # ──────────────────────────────────────────────────────────────────────
    # BUSCA POR CPF/CNPJ DAS PARTES
    # ──────────────────────────────────────────────────────────────────────

    async def buscar_por_parte(
        self,
        cpf_cnpj: str,
        tribunal: str,
        polo: str = "ambos",  # "ativo" | "passivo" | "ambos"
        limite: int = 20,
    ) -> list[dict]:
        """
        Busca todos os processos em que um CPF ou CNPJ figura como parte.

        Útil para: due diligence, localização de processos de cliente,
        verificação de passivo judicial de empresa.
        """
        doc_limpo = self._limpar_documento(cpf_cnpj)
        indice = TRIBUNAIS.get(tribunal.upper())
        if not indice:
            raise ValueError(f"Tribunal '{tribunal}' não encontrado.")

        # Monta filtro de polo
        polo_filter: list[dict] = []
        if polo in ("ativo", "ambos"):
            polo_filter.append({"match": {"partes.polo": "ATIVO"}})
        if polo in ("passivo", "ambos"):
            polo_filter.append({"match": {"partes.polo": "PASSIVO"}})

        query = {
            "size": limite,
            "query": {
                "bool": {
                    "must": [
                        {"nested": {
                            "path": "partes",
                            "query": {
                                "bool": {
                                    "must": [
                                        {"match": {"partes.documento": doc_limpo}},
                                    ],
                                    "should": polo_filter,
                                }
                            }
                        }}
                    ]
                }
            },
            "sort": [{"dataAjuizamento": {"order": "desc"}}],
        }

        resp = await self._post(indice, query)
        hits = resp.get("hits", {}).get("hits", [])
        return [self._formatar_processo(h["_source"], tribunal) for h in hits]

    # ──────────────────────────────────────────────────────────────────────
    # BUSCA POR ASSUNTO / CLASSE PROCESSUAL
    # ──────────────────────────────────────────────────────────────────────

    async def buscar_por_assunto(
        self,
        tribunal: str,
        codigo_assunto: Optional[int] = None,
        codigo_classe: Optional[int] = None,
        orgao_julgador: Optional[str] = None,
        data_inicio: Optional[str] = None,   # "YYYY-MM-DD"
        data_fim: Optional[str] = None,
        limite: int = 20,
    ) -> list[dict]:
        """
        Busca processos por assunto CNJ (Tabela Unificada de Assuntos),
        classe processual ou órgão julgador.

        Exemplos de códigos de assunto frequentes:
          1723 — Rescisão Indireta (Trabalhista)
          1541 — FGTS
          7660 — Assédio Moral (Trabalhista)
          3749 — Responsabilidade Civil
          7786 — Dano Moral

        Fonte: https://www.cnj.jus.br/sgt/consulta_publica_assuntos.php
        """
        indice = TRIBUNAIS.get(tribunal.upper())
        if not indice:
            raise ValueError(f"Tribunal '{tribunal}' não encontrado.")

        must_clauses: list[dict] = []

        if codigo_assunto:
            must_clauses.append({
                "nested": {
                    "path": "assuntos",
                    "query": {"match": {"assuntos.codigo": codigo_assunto}}
                }
            })

        if codigo_classe:
            must_clauses.append({
                "nested": {
                    "path": "classe",
                    "query": {"match": {"classe.codigo": codigo_classe}}
                }
            })

        if orgao_julgador:
            must_clauses.append({
                "nested": {
                    "path": "orgaoJulgador",
                    "query": {"match": {"orgaoJulgador.nome": orgao_julgador}}
                }
            })

        if data_inicio or data_fim:
            date_filter: dict = {"range": {"dataAjuizamento": {}}}
            if data_inicio:
                date_filter["range"]["dataAjuizamento"]["gte"] = data_inicio
            if data_fim:
                date_filter["range"]["dataAjuizamento"]["lte"] = data_fim
            must_clauses.append(date_filter)

        query = {
            "size": limite,
            "query": {"bool": {"must": must_clauses}} if must_clauses else {"match_all": {}},
            "sort": [{"dataAjuizamento": {"order": "desc"}}],
        }

        resp = await self._post(indice, query)
        hits = resp.get("hits", {}).get("hits", [])
        return [self._formatar_processo(h["_source"], tribunal) for h in hits]

    # ──────────────────────────────────────────────────────────────────────
    # MOVIMENTAÇÕES DO PROCESSO
    # ──────────────────────────────────────────────────────────────────────

    async def buscar_movimentacoes(
        self,
        numero_processo: str,
        tribunal: str,
        limite: int = 50,
    ) -> list[dict]:
        """
        Retorna todos os andamentos/movimentações de um processo.
        Retorno ordenado do mais recente para o mais antigo.
        """
        processo = await self.buscar_por_numero(numero_processo, tribunal)
        if not processo.get("encontrado", True):
            return []

        movimentos = processo.get("movimentos", [])
        movimentos_ordenados = sorted(
            movimentos,
            key=lambda m: m.get("dataHora", ""),
            reverse=True,
        )
        return movimentos_ordenados[:limite]

    # ──────────────────────────────────────────────────────────────────────
    # GERAÇÃO DE TEXTO PARA INGESTÃO NO RAG
    # ──────────────────────────────────────────────────────────────────────

    def formatar_para_rag(self, processo: dict) -> str:
        """
        Converte os dados de um processo em texto estruturado
        adequado para ingestão na base RAG (LegalKnowledgeBase).

        O texto segue padrão jurídico para maximizar a recuperação
        semântica em consultas sobre o caso.
        """
        linhas = [
            f"PROCESSO: {processo.get('numero', 'N/D')}",
            f"TRIBUNAL: {processo.get('tribunal', 'N/D')}",
            f"CLASSE: {processo.get('classe', 'N/D')}",
            f"ASSUNTOS: {', '.join(processo.get('assuntos', []))}",
            f"DATA AJUIZAMENTO: {processo.get('dataAjuizamento', 'N/D')}",
            f"GRAU: {processo.get('grau', 'N/D')}",
            f"ÓRGÃO JULGADOR: {processo.get('orgaoJulgador', 'N/D')}",
            "",
            "PARTES:",
        ]

        for parte in processo.get("partes", []):
            linhas.append(
                f"  [{parte.get('polo','?')}] {parte.get('nome','N/D')} "
                f"— {parte.get('tipoPessoa','?')}"
            )

        if processo.get("movimentos"):
            linhas += ["", "MOVIMENTAÇÕES RECENTES:"]
            for mov in processo["movimentos"][:10]:
                linhas.append(
                    f"  {mov.get('dataHora','')[:10]} — {mov.get('nome','')}"
                )

        return "\n".join(linhas)

    # ──────────────────────────────────────────────────────────────────────
    # HELPERS PRIVADOS
    # ──────────────────────────────────────────────────────────────────────

    async def _post(self, indice: str, query: dict) -> dict:
        url = f"{DATAJUD_BASE}/{indice}/_search"
        try:
            resp = await self._client.post(url, json=query)
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"[DataJud] HTTP {e.response.status_code} — {e.response.text[:300]}")
            raise RuntimeError(f"DataJud retornou erro {e.response.status_code}: {e.response.text[:200]}")
        except httpx.RequestError as e:
            logger.error(f"[DataJud] Conexão falhou: {e}")
            raise RuntimeError("Falha de conexão com a API do DataJud/CNJ.")

    def _normalizar_numero(self, numero: str) -> str:
        """Remove formatação e retorna apenas dígitos e separadores padrão."""
        import re
        # Aceita: 0001234-56.2023.8.26.0001 ou 00012345620238260001
        n = re.sub(r"[^\d\-\.]", "", numero).strip()
        return n

    def _detectar_tribunal(self, numero: str) -> Optional[str]:
        """
        Detecta o tribunal a partir dos segmentos do número CNJ.
        Formato: NNNNNNN-DD.AAAA.J.TT.OOOO
        Segmento J: 1=STF, 2=CNJ, 3=STJ, 4=JF, 5=TRT, 6=TRE, 7=TM, 8=TJXX
        Segmento TT: código do tribunal dentro do ramo
        """
        import re
        m = re.search(r"\.(\d)\.(\d{1,2})\.", numero)
        if not m:
            return None

        ramo, codigo = m.group(1), m.group(2).zfill(2)

        mapa = {
            "1": "STF",
            "3": "STJ",
            "5": {  # TRTs
                "01": "TRT1",  "02": "TRT2",  "03": "TRT3",  "04": "TRT4",
                "05": "TRT5",  "06": "TRT6",  "07": "TRT7",  "08": "TRT8",
                "09": "TRT9",  "10": "TRT10", "11": "TRT11", "12": "TRT12",
                "13": "TRT13", "14": "TRT14", "15": "TRT15", "16": "TRT16",
                "17": "TRT17", "18": "TRT18", "19": "TRT19", "20": "TRT20",
                "21": "TRT21", "22": "TRT22", "23": "TRT23", "24": "TRT24",
            },
            "4": {  # TRFs
                "01": "TRF1", "02": "TRF2", "03": "TRF3",
                "04": "TRF4", "05": "TRF5", "06": "TRF6",
            },
            "8": {  # TJs estaduais — código = UF
                "01": "TJAC", "02": "TJAL", "03": "TJAM", "04": "TJAP",
                "05": "TJBA", "06": "TJCE", "07": "TJDFT", "08": "TJES",
                "09": "TJGO", "10": "TJMA", "11": "TJMG", "12": "TJMS",
                "13": "TJMT", "14": "TJPA", "15": "TJPB", "16": "TJPE",
                "17": "TJPI", "18": "TJPR", "19": "TJRJ", "20": "TJRN",
                "21": "TJRO", "22": "TJRR", "23": "TJRS", "24": "TJSC",
                "25": "TJSE", "26": "TJSP", "27": "TJTO",
            },
        }

        resultado = mapa.get(ramo)
        if isinstance(resultado, str):
            return resultado
        if isinstance(resultado, dict):
            return resultado.get(codigo)
        return None

    def _limpar_documento(self, doc: str) -> str:
        import re
        return re.sub(r"[^\d]", "", doc)

    def _formatar_processo(self, source: dict, tribunal: str) -> dict:
        """Normaliza a estrutura retornada pelo ElasticSearch do DataJud."""
        partes = []
        for p in source.get("partes", []):
            partes.append({
                "nome": p.get("nome", "N/D"),
                "polo": p.get("polo", "?"),
                "tipoPessoa": p.get("tipoPessoa", "?"),
                "documento": p.get("documento", ""),
            })

        assuntos = [
            a.get("nome", str(a.get("codigo", "")))
            for a in source.get("assuntos", [])
        ]

        movimentos = []
        for m in source.get("movimentos", []):
            movimentos.append({
                "dataHora": m.get("dataHora", ""),
                "nome": m.get("nome", ""),
                "complemento": m.get("complementosTabelados", []),
            })

        classe_info = source.get("classe", {})
        orgao_info  = source.get("orgaoJulgador", {})

        return {
            "encontrado": True,
            "numero": source.get("numeroProcesso", ""),
            "tribunal": tribunal,
            "classe": classe_info.get("nome", str(classe_info.get("codigo", ""))),
            "assuntos": assuntos,
            "dataAjuizamento": source.get("dataAjuizamento", "")[:10] if source.get("dataAjuizamento") else "",
            "grau": source.get("grau", ""),
            "sistema": source.get("sistema", {}).get("nome", ""),
            "formato": source.get("formato", {}).get("nome", ""),
            "orgaoJulgador": orgao_info.get("nome", ""),
            "partes": partes,
            "movimentos": movimentos,
            "valor_causa": source.get("valorCausa", None),
            "situacao": source.get("nivelSigilo", "publico"),
        }

    async def listar_tribunais(self) -> list[str]:
        """Retorna lista de todos os tribunais suportados."""
        return sorted(TRIBUNAIS.keys())

    async def aclose(self):
        await self._client.aclose()
