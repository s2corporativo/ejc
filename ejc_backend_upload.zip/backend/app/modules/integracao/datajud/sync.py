"""
EJC — DataJud Sync Service
modules/integracao/datajud/sync.py

Sincroniza processos do DataJud com a base RAG do EJC.

Fluxo:
  1. Busca processos por número, CPF/CNPJ ou critério (assunto/classe)
  2. Formata como documento jurídico estruturado
  3. Ingere automaticamente no pgvector via LegalKnowledgeBase
  4. Armazena metadados na tabela `processos_monitorados`
  5. Agendamento: verifica movimentações novas a cada N horas
"""
from __future__ import annotations

import logging
from uuid import uuid4
from typing import Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.integracao.datajud.client import DataJudClient
from app.modules.rag.knowledge_base import LegalKnowledgeBase

logger = logging.getLogger(__name__)


class DataJudSyncService:
    """
    Orquestra a importação de processos do DataJud para o RAG.
    """

    def __init__(self):
        self._dj  = DataJudClient()
        self._kb  = LegalKnowledgeBase()

    # ──────────────────────────────────────────────────────────────────────
    # IMPORTAR UM PROCESSO ESPECÍFICO
    # ──────────────────────────────────────────────────────────────────────

    async def importar_processo(
        self,
        db: AsyncSession,
        numero_processo: str,
        tribunal: Optional[str] = None,
        monitorar: bool = True,
    ) -> dict:
        """
        Importa um processo do DataJud e ingere na base RAG.

        Args:
            numero_processo: Número CNJ do processo
            tribunal: Sigla do tribunal (opcional — auto-detectado)
            monitorar: Se True, adiciona à lista de monitoramento contínuo

        Returns:
            Resultado da operação com número de chunks criados
        """
        logger.info(f"[DataJud] Importando processo {numero_processo}")
        processo = await self._dj.buscar_por_numero(numero_processo, tribunal)

        if not processo.get("encontrado", True):
            return {
                "sucesso": False,
                "mensagem": f"Processo {numero_processo} não encontrado no DataJud.",
                "numero": numero_processo,
            }

        texto_rag = self._dj.formatar_para_rag(processo)
        filename  = f"datajud_{processo['numero'].replace('/', '_')}.txt"

        resultado = await self._kb.ingest_file(
            db=db,
            file_bytes=texto_rag.encode("utf-8"),
            filename=filename,
            category="processo_judicial",
            metadata={
                "fonte": "datajud",
                "tribunal": processo["tribunal"],
                "numero": processo["numero"],
                "classe": processo.get("classe", ""),
                "assuntos": processo.get("assuntos", []),
            },
        )

        if monitorar:
            await self._registrar_monitoramento(db, processo)

        logger.info(f"[DataJud] Processo {numero_processo} → {resultado['chunks_created']} chunks")
        return {
            "sucesso": True,
            "numero": processo["numero"],
            "tribunal": processo["tribunal"],
            "classe": processo.get("classe"),
            "assuntos": processo.get("assuntos"),
            "partes": processo.get("partes"),
            "movimentos_total": len(processo.get("movimentos", [])),
            "chunks_criados": resultado["chunks_created"],
            "document_id": str(resultado["document_id"]),
        }

    # ──────────────────────────────────────────────────────────────────────
    # IMPORTAR TODOS OS PROCESSOS DE UM CPF/CNPJ
    # ──────────────────────────────────────────────────────────────────────

    async def importar_por_parte(
        self,
        db: AsyncSession,
        cpf_cnpj: str,
        tribunal: str,
        polo: str = "ambos",
        limite: int = 50,
    ) -> dict:
        """
        Importa todos os processos em que o CPF/CNPJ figura como parte.
        Ideal para: onboarding de cliente, due diligence, passivo judicial.
        """
        logger.info(f"[DataJud] Importando processos de {cpf_cnpj} no {tribunal}")
        processos = await self._dj.buscar_por_parte(cpf_cnpj, tribunal, polo, limite)

        importados = 0
        erros = 0
        detalhes = []

        for proc in processos:
            try:
                res = await self.importar_processo(
                    db=db,
                    numero_processo=proc["numero"],
                    tribunal=tribunal,
                    monitorar=True,
                )
                if res["sucesso"]:
                    importados += 1
                    detalhes.append({
                        "numero": proc["numero"],
                        "classe": proc.get("classe"),
                        "chunks": res["chunks_criados"],
                    })
            except Exception as e:
                erros += 1
                logger.warning(f"[DataJud] Erro ao importar {proc.get('numero')}: {e}")

        return {
            "cpf_cnpj": cpf_cnpj,
            "tribunal": tribunal,
            "total_encontrados": len(processos),
            "importados": importados,
            "erros": erros,
            "detalhes": detalhes,
        }

    # ──────────────────────────────────────────────────────────────────────
    # SINCRONIZAÇÃO CONTÍNUA — verifica novos andamentos
    # ──────────────────────────────────────────────────────────────────────

    async def sincronizar_monitorados(self, db: AsyncSession) -> dict:
        """
        Verifica todos os processos monitorados e atualiza o RAG
        com novos andamentos. Executar via scheduler (APScheduler ou Cron).
        """
        rows = await db.execute(
            text("""
                SELECT numero_processo, tribunal, document_id
                FROM processos_monitorados
                WHERE ativo = true
                ORDER BY ultima_sync ASC
                LIMIT 50
            """)
        )
        processos = list(rows.mappings())
        atualizados = 0

        for proc in processos:
            try:
                res = await self.importar_processo(
                    db=db,
                    numero_processo=proc["numero_processo"],
                    tribunal=proc["tribunal"],
                    monitorar=False,
                )
                if res["sucesso"]:
                    await db.execute(
                        text("""
                            UPDATE processos_monitorados
                            SET ultima_sync = NOW(), movimentos_count = :mc
                            WHERE numero_processo = :np
                        """),
                        {"mc": res["movimentos_total"], "np": proc["numero_processo"]},
                    )
                    atualizados += 1
            except Exception as e:
                logger.warning(f"[DataJud] Sync falhou para {proc['numero_processo']}: {e}")

        return {
            "processados": len(processos),
            "atualizados": atualizados,
        }

    # ──────────────────────────────────────────────────────────────────────
    # MONITORAMENTO
    # ──────────────────────────────────────────────────────────────────────

    async def _registrar_monitoramento(self, db: AsyncSession, processo: dict):
        await db.execute(
            text("""
                INSERT INTO processos_monitorados
                    (id, numero_processo, tribunal, classe, ativo, ultima_sync, movimentos_count)
                VALUES (:id, :np, :tr, :cl, true, NOW(), :mc)
                ON CONFLICT (numero_processo) DO UPDATE
                SET ultima_sync = NOW(), movimentos_count = :mc
            """),
            {
                "id": str(uuid4()),
                "np": processo["numero"],
                "tr": processo["tribunal"],
                "cl": processo.get("classe", ""),
                "mc": len(processo.get("movimentos", [])),
            },
        )

    async def listar_monitorados(self, db: AsyncSession) -> list[dict]:
        rows = await db.execute(
            text("""
                SELECT numero_processo, tribunal, classe, ativo,
                       ultima_sync, movimentos_count, created_at
                FROM processos_monitorados
                ORDER BY ultima_sync DESC
            """)
        )
        return [dict(r) for r in rows.mappings()]

    async def toggle_monitoramento(
        self, db: AsyncSession, numero_processo: str, ativo: bool
    ):
        await db.execute(
            text("UPDATE processos_monitorados SET ativo=:a WHERE numero_processo=:np"),
            {"a": ativo, "np": numero_processo},
        )
