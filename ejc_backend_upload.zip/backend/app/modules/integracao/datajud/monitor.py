"""
EJC — Monitor de Movimentações Processuais (DataJud/CNJ)

Detecta novas movimentações em processos cadastrados e dispara alertas.

Fluxo:
  1. Busca processo atual no DataJud
  2. Compara movimentos_count com movimentos_count_anterior no banco
  3. Se houver delta > 0 → gera alerta_processual + notifica Telegram
  4. Atualiza snapshots no banco para próxima comparação

Executado automaticamente pelo scheduler a cada hora.
Também pode ser chamado manualmente via POST /integracao/datajud/monitorados/sincronizar
"""
from __future__ import annotations

import logging
from datetime import datetime
from uuid import uuid4

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.integracao.datajud.client import DataJudClient

logger = logging.getLogger(__name__)


class MonitorMovimentacoes:
    def __init__(self):
        self._dj = DataJudClient()

    async def sincronizar_com_alertas(self, db: AsyncSession) -> dict:
        """
        Versão aprimorada da sincronização: compara movimentos antes/depois
        e gera alertas reais quando detecta novidades.
        """
        rows = await db.execute(text("""
            SELECT numero_processo, tribunal, classe, apelido,
                   parte_cliente, movimentos_count, movimentos_count_anterior,
                   notificar_telegram, email_notificacao,
                   ultimo_movimento_titulo
            FROM processos_monitorados
            WHERE ativo = true
            ORDER BY ultima_sync ASC NULLS FIRST
            LIMIT 50
        """))
        processos = list(rows.mappings())

        atualizados = 0
        alertas_gerados = 0
        erros = 0

        for proc in processos:
            try:
                resultado = await self._verificar_processo(db, dict(proc))
                if resultado["atualizado"]:
                    atualizados += 1
                if resultado["alerta_gerado"]:
                    alertas_gerados += 1
            except Exception as e:
                erros += 1
                logger.error(f"[Monitor] Erro em {proc['numero_processo']}: {e}")

        await db.commit()
        logger.info(f"[Monitor] Sync: {atualizados} atualizados, {alertas_gerados} alertas, {erros} erros")

        return {
            "processados":    len(processos),
            "atualizados":    atualizados,
            "alertas_novos":  alertas_gerados,
            "erros":          erros,
        }

    async def _verificar_processo(self, db: AsyncSession, proc: dict) -> dict:
        numero = proc["numero_processo"]
        tribunal = proc["tribunal"]

        # Busca estado atual no DataJud
        dados_atuais = await self._dj.buscar_por_numero(numero, tribunal)
        if not dados_atuais or not dados_atuais.get("encontrado", True):
            return {"atualizado": False, "alerta_gerado": False}

        movimentos = dados_atuais.get("movimentos", [])
        count_atual = len(movimentos)
        count_anterior = proc.get("movimentos_count") or 0

        novos = count_atual - count_anterior
        alerta_gerado = False

        # Último movimento disponível
        ultimo_mv = movimentos[0] if movimentos else {}
        ultimo_titulo = (
            ultimo_mv.get("complementosTabelados", [{}])[0].get("descricao")
            or ultimo_mv.get("nome")
            or "Movimentação registrada"
        ) if ultimo_mv else proc.get("ultimo_movimento_titulo", "")
        ultimo_data_str = ultimo_mv.get("dataHora", "") if ultimo_mv else ""
        try:
            ultimo_data = datetime.fromisoformat(ultimo_data_str.replace("Z", "+00:00")) if ultimo_data_str else None
        except Exception:
            ultimo_data = None

        # ── Detectou novidade ──────────────────────────────────────────────
        if novos > 0:
            alerta_gerado = True
            await self._criar_alerta(db, proc, novos, ultimo_titulo, ultimo_data)
            logger.info(f"[Monitor] ⚡ {numero}: +{novos} movimentações → alerta gerado")

            # Notifica via Telegram
            if proc.get("notificar_telegram"):
                await self._notificar_telegram(proc, novos, ultimo_titulo)

        # Atualiza snapshot no banco
        await db.execute(text("""
            UPDATE processos_monitorados
            SET ultima_sync               = NOW(),
                movimentos_count_anterior = movimentos_count,
                movimentos_count          = :mc,
                ultimo_movimento_data     = :ud,
                ultimo_movimento_titulo   = :ut
            WHERE numero_processo = :np
        """), {
            "mc": count_atual,
            "ud": ultimo_data,
            "ut": ultimo_titulo[:300] if ultimo_titulo else None,
            "np": numero,
        })

        return {"atualizado": True, "alerta_gerado": alerta_gerado, "novos": novos}

    async def _criar_alerta(
        self,
        db: AsyncSession,
        proc: dict,
        novos: int,
        ultimo_titulo: str,
        ultimo_data: datetime | None,
    ):
        apelido = proc.get("apelido") or proc["numero_processo"]
        parte   = proc.get("parte_cliente") or ""

        titulo = f"Nova movimentação — {apelido}"
        descricao = (
            f"{novos} nova(s) movimentação(ões) detectada(s) no processo {proc['numero_processo']}."
            f"\nTribunal: {proc['tribunal']}"
            f"\nÚltimo andamento: {ultimo_titulo}"
        )
        if parte:
            descricao += f"\nCliente: {parte}"

        await db.execute(text("""
            INSERT INTO alertas_processuais
              (id, numero_processo, tribunal, tipo_alerta, titulo, descricao,
               data_movimentacao, movimentos_novos)
            VALUES (:id, :np, :tr, 'nova_movimentacao', :tit, :desc, :dt, :mn)
        """), {
            "id":  str(uuid4()),
            "np":  proc["numero_processo"],
            "tr":  proc["tribunal"],
            "tit": titulo,
            "desc": descricao,
            "dt":  ultimo_data,
            "mn":  novos,
        })

    async def _notificar_telegram(self, proc: dict, novos: int, titulo: str):
        try:
            from app.modules.notificacoes.router import enviar_telegram
            apelido = proc.get("apelido") or proc["numero_processo"]
            msg = (
                f"⚖️ *EJC Monitor — Nova Movimentação*\n\n"
                f"📋 Processo: {apelido}\n"
                f"🏛 Tribunal: {proc['tribunal']}\n"
                f"📌 Movimentações novas: {novos}\n"
                f"📝 Último andamento: {titulo[:200]}"
            )
            await enviar_telegram(msg)
        except Exception as e:
            logger.warning(f"[Monitor] Telegram falhou: {e}")

    async def listar_alertas(
        self,
        db: AsyncSession,
        apenas_nao_lidos: bool = True,
        limite: int = 50,
    ) -> list[dict]:
        where = "WHERE lido = false" if apenas_nao_lidos else ""
        rows = await db.execute(text(f"""
            SELECT * FROM alertas_processuais
            {where}
            ORDER BY created_at DESC
            LIMIT :lim
        """), {"lim": limite})
        return [dict(r) for r in rows.mappings()]

    async def marcar_lido(self, db: AsyncSession, alerta_id: str):
        await db.execute(
            text("UPDATE alertas_processuais SET lido=true WHERE id=:id"),
            {"id": alerta_id}
        )
        await db.commit()

    async def marcar_todos_lidos(self, db: AsyncSession):
        await db.execute(text("UPDATE alertas_processuais SET lido=true WHERE lido=false"))
        await db.commit()


async def _notificar_whatsapp_movimentacoes(db, processos_ids: list):
    """Envia alertas de movimentação via WhatsApp para o advogado configurado."""
    import os
    from sqlalchemy import text as _text
    from app.modules.notificacoes.router import enviar_whatsapp

    whatsapp_adv = os.getenv("ADVOGADO_WHATSAPP", "")
    if not whatsapp_adv:
        return

    for pid in processos_ids[:5]:
        try:
            row = await db.execute(
                _text("SELECT numero_processo, ultima_movimentacao, cliente_nome FROM processos_monitorados WHERE id=:id"),
                {"id": pid}
            )
            p = row.mappings().first()
            if p:
                msg = (
                    f"⚖️ *Movimentação processual*\n"
                    f"Processo: {p['numero_processo']}\n"
                    f"Cliente: {p.get('cliente_nome', '—')}\n"
                    f"{p.get('ultima_movimentacao', 'Nova movimentação detectada')}"
                )
                await enviar_whatsapp(whatsapp_adv, msg)
        except Exception as e:
            import logging
            logging.getLogger(__name__).debug(f"[WhatsApp Monitor] {e}")
