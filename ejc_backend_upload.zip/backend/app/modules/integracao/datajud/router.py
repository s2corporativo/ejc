"""
EJC — Router Integração DataJud
modules/integracao/datajud/router.py
"""
from __future__ import annotations

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.integracao.datajud.client import DataJudClient, TRIBUNAIS
from app.modules.integracao.datajud.sync import DataJudSyncService

router = APIRouter(prefix="/datajud", tags=["DataJud — CNJ"])

_client: Optional[DataJudClient] = None
_sync:   Optional[DataJudSyncService] = None

def get_client() -> DataJudClient:
    global _client
    if not _client:
        _client = DataJudClient()
    return _client

def get_sync() -> DataJudSyncService:
    global _sync
    if not _sync:
        _sync = DataJudSyncService()
    return _sync


# ── Schemas ────────────────────────────────────────────────────────────────

class ImportarProcessoRequest(BaseModel):
    numero_processo: str
    tribunal: Optional[str] = None
    monitorar: bool = True

class ImportarParteRequest(BaseModel):
    cpf_cnpj: str
    tribunal: str
    polo: str = "ambos"
    limite: int = 20

class BuscarAssuntoRequest(BaseModel):
    tribunal: str
    codigo_assunto: Optional[int] = None
    codigo_classe: Optional[int] = None
    orgao_julgador: Optional[str] = None
    data_inicio: Optional[str] = None
    data_fim: Optional[str] = None
    limite: int = 20


# ── Endpoints ──────────────────────────────────────────────────────────────

@router.get("/tribunais")
async def listar_tribunais():
    """Lista todos os tribunais disponíveis no DataJud."""
    return {
        "tribunais": sorted(TRIBUNAIS.keys()),
        "total": len(TRIBUNAIS),
        "grupos": {
            "TJs (Estaduais)": [t for t in TRIBUNAIS if t.startswith("TJ")],
            "TRFs (Federais)": [t for t in TRIBUNAIS if t.startswith("TRF")],
            "TRTs (Trabalho)": [t for t in TRIBUNAIS if t.startswith("TRT")],
            "Superiores":      ["STJ", "STF", "TST", "TSE", "STM", "CJF"],
        },
    }


@router.get("/processo/{numero}")
async def consultar_processo(
    numero: str,
    tribunal: Optional[str] = Query(None, description="Ex: TJSP, TRT2, STJ"),
    client: DataJudClient = Depends(get_client),
):
    """
    Consulta um processo pelo número CNJ.
    Tribunal é detectado automaticamente se não informado.
    """
    try:
        return await client.buscar_por_numero(numero, tribunal)
    except (ValueError, RuntimeError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.get("/processo/{numero}/movimentacoes")
async def movimentacoes_processo(
    numero: str,
    tribunal: str = Query(..., description="Sigla do tribunal"),
    limite: int = Query(50, ge=1, le=200),
    client: DataJudClient = Depends(get_client),
):
    """Retorna os andamentos/movimentações de um processo."""
    try:
        return {"movimentos": await client.buscar_movimentacoes(numero, tribunal, limite)}
    except (ValueError, RuntimeError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.post("/processo/buscar-parte")
async def buscar_por_parte(
    req: ImportarParteRequest,
    client: DataJudClient = Depends(get_client),
):
    """
    Busca todos os processos de um CPF ou CNPJ em um tribunal.
    """
    try:
        processos = await client.buscar_por_parte(
            req.cpf_cnpj, req.tribunal, req.polo, req.limite
        )
        return {"processos": processos, "total": len(processos)}
    except (ValueError, RuntimeError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.post("/processo/buscar-assunto")
async def buscar_por_assunto(
    req: BuscarAssuntoRequest,
    client: DataJudClient = Depends(get_client),
):
    """
    Busca processos por assunto CNJ, classe processual ou órgão julgador.
    Códigos de assunto: https://www.cnj.jus.br/sgt/consulta_publica_assuntos.php
    """
    try:
        processos = await client.buscar_por_assunto(
            tribunal=req.tribunal,
            codigo_assunto=req.codigo_assunto,
            codigo_classe=req.codigo_classe,
            orgao_julgador=req.orgao_julgador,
            data_inicio=req.data_inicio,
            data_fim=req.data_fim,
            limite=req.limite,
        )
        return {"processos": processos, "total": len(processos)}
    except (ValueError, RuntimeError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.post("/importar/processo")
async def importar_processo_rag(
    req: ImportarProcessoRequest,
    db: AsyncSession = Depends(get_db),
    svc: DataJudSyncService = Depends(get_sync),
):
    """
    Importa processo do DataJud e ingere automaticamente na base RAG.
    O processo fica disponível para consultas semânticas imediatamente.
    """
    try:
        return await svc.importar_processo(db, req.numero_processo, req.tribunal, req.monitorar)
    except (ValueError, RuntimeError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.post("/importar/parte")
async def importar_parte_rag(
    req: ImportarParteRequest,
    db: AsyncSession = Depends(get_db),
    svc: DataJudSyncService = Depends(get_sync),
):
    """
    Importa TODOS os processos de um CPF/CNPJ para o RAG.
    Útil para onboarding completo de um cliente.
    """
    try:
        return await svc.importar_por_parte(
            db, req.cpf_cnpj, req.tribunal, req.polo, req.limite
        )
    except (ValueError, RuntimeError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.get("/monitorados")
async def listar_monitorados(
    db: AsyncSession = Depends(get_db),
    svc: DataJudSyncService = Depends(get_sync),
):
    """Lista todos os processos em monitoramento contínuo."""
    return {"processos": await svc.listar_monitorados(db)}


@router.post("/monitorados/{numero}/toggle")
async def toggle_monitoramento(
    numero: str,
    ativo: bool = Query(True),
    db: AsyncSession = Depends(get_db),
    svc: DataJudSyncService = Depends(get_sync),
):
    """Ativa ou desativa o monitoramento de um processo."""
    await svc.toggle_monitoramento(db, numero, ativo)
    return {"message": f"Monitoramento {'ativado' if ativo else 'pausado'} para {numero}"}


@router.post("/sincronizar")
async def sincronizar_monitorados(
    db: AsyncSession = Depends(get_db),
    svc: DataJudSyncService = Depends(get_sync),
):
    """
    Força sincronização de todos os processos monitorados.
    Em produção, executar via scheduler (cron ou APScheduler).
    """
    return await svc.sincronizar_monitorados(db)

# ── Importa o monitor real ──────────────────────────────────────────────────
from app.modules.integracao.datajud.monitor import MonitorMovimentacoes

_monitor: MonitorMovimentacoes | None = None
def get_monitor() -> MonitorMovimentacoes:
    global _monitor
    if not _monitor:
        _monitor = MonitorMovimentacoes()
    return _monitor


class ConfigurarMonitorReq(BaseModel):
    numero_processo:    str
    apelido:            str | None = None
    parte_cliente:      str | None = None
    notificar_telegram: bool = True
    notificar_email:    bool = False
    email_notificacao:  str | None = None


@router.post("/monitorados/configurar")
async def configurar_monitoramento(
    req: ConfigurarMonitorReq,
    db: AsyncSession = Depends(get_db),
):
    """Configura apelido, parte e preferências de notificação de um processo."""
    from sqlalchemy import text
    await db.execute(text("""
        UPDATE processos_monitorados
        SET apelido            = :ap,
            parte_cliente      = :pc,
            notificar_telegram = :nt,
            notificar_email    = :ne,
            email_notificacao  = :em
        WHERE numero_processo = :np
    """), {
        "ap": req.apelido,
        "pc": req.parte_cliente,
        "nt": req.notificar_telegram,
        "ne": req.notificar_email,
        "em": req.email_notificacao,
        "np": req.numero_processo,
    })
    await db.commit()
    return {"ok": True, "numero_processo": req.numero_processo}


@router.post("/monitorados/sincronizar-real")
async def sincronizar_real(
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
):
    """
    Sincronização REAL: detecta novas movimentações e gera alertas.
    Substitui /monitorados/sincronizar (que apenas atualiza RAG).
    """
    monitor = get_monitor()
    resultado = await monitor.sincronizar_com_alertas(db)
    return resultado


@router.get("/alertas")
async def listar_alertas(
    apenas_nao_lidos: bool = True,
    limite: int = 50,
    db: AsyncSession = Depends(get_db),
):
    """Lista alertas de novas movimentações processuais."""
    monitor = get_monitor()
    alertas = await monitor.listar_alertas(db, apenas_nao_lidos, limite)
    return {"alertas": alertas, "total": len(alertas)}


@router.patch("/alertas/{alerta_id}/lido")
async def marcar_alerta_lido(alerta_id: str, db: AsyncSession = Depends(get_db)):
    monitor = get_monitor()
    await monitor.marcar_lido(db, alerta_id)
    return {"ok": True}


@router.post("/alertas/marcar-todos-lidos")
async def marcar_todos_lidos(db: AsyncSession = Depends(get_db)):
    monitor = get_monitor()
    await monitor.marcar_todos_lidos(db)
    return {"ok": True}


@router.get("/monitorados/resumo")
async def resumo_monitorados(db: AsyncSession = Depends(get_db)):
    """Painel de resumo: total de processos, alertas pendentes, última sync."""
    from sqlalchemy import text
    r1 = await db.execute(text("""
        SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE ativo) as ativos,
               MAX(ultima_sync) as ultima_sync
        FROM processos_monitorados
    """))
    r2 = await db.execute(text("SELECT COUNT(*) as pendentes FROM alertas_processuais WHERE lido=false"))
    r3 = await db.execute(text("""
        SELECT numero_processo, apelido, parte_cliente, tribunal,
               movimentos_count, movimentos_count_anterior,
               ultimo_movimento_titulo, ultima_sync, ativo
        FROM processos_monitorados
        ORDER BY ultima_sync DESC NULLS LAST
        LIMIT 20
    """))
    s = dict(r1.mappings().first())
    p = dict(r2.mappings().first())
    return {
        **s,
        "alertas_pendentes": p["pendentes"],
        "processos": [dict(r) for r in r3.mappings()],
    }
