"""
EJC — Router de Integrações (redes públicas)
modules/integracao/router.py

Agrega DataJud, LexML, STJ/TST e Receita Federal em um único ponto de entrada.
"""
from __future__ import annotations

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.modules.integracao.datajud.router import router as datajud_router
from app.modules.integracao.lexml.client import LexMLClient
from app.modules.integracao.stj.client import STJClient, TSTClient
from app.modules.integracao.receita.client import ReceitaFederalClient
from app.modules.rag.knowledge_base import LegalKnowledgeBase

router = APIRouter(prefix="/integracao", tags=["Integrações — Redes Públicas"])
router.include_router(datajud_router)   # monta /integracao/datajud/...

# ── Singletons ────────────────────────────────────────────────────────────
_lexml:   Optional[LexMLClient]          = None
_stj:     Optional[STJClient]            = None
_tst:     Optional[TSTClient]            = None
_receita: Optional[ReceitaFederalClient] = None
_kb:      Optional[LegalKnowledgeBase]   = None

def get_lexml()   -> LexMLClient:          global _lexml;   _lexml   = _lexml   or LexMLClient();   return _lexml
def get_stj()     -> STJClient:            global _stj;     _stj     = _stj     or STJClient();     return _stj
def get_tst()     -> TSTClient:            global _tst;     _tst     = _tst     or TSTClient();     return _tst
def get_receita() -> ReceitaFederalClient: global _receita; _receita = _receita or ReceitaFederalClient(); return _receita
def get_kb()      -> LegalKnowledgeBase:   global _kb;      _kb      = _kb      or LegalKnowledgeBase();   return _kb


# ════════════════════════════════════════════════════════════════════════════
# LEXML — LEGISLAÇÃO
# ════════════════════════════════════════════════════════════════════════════

@router.get("/lexml/buscar")
async def buscar_legislacao(
    q:          str = Query(..., description="Termos de busca"),
    tipo:       Optional[str] = Query(None, description="lei|decreto|medida_provisoria"),
    limite:     int = Query(10, ge=1, le=50),
    lexml: LexMLClient = Depends(get_lexml),
):
    """Busca legislação no LexML (Senado Federal)."""
    try:
        resultados = await lexml.buscar_legislacao(q, tipo=tipo, limite=limite)
        return {"resultados": resultados, "total": len(resultados), "fonte": "LexML"}
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))


@router.get("/lexml/lei/{numero}")
async def buscar_lei(
    numero: str,
    ano:    Optional[str] = Query(None),
    tipo:   str = Query("lei"),
    lexml: LexMLClient = Depends(get_lexml),
):
    """Busca uma lei específica pelo número e ano."""
    result = await lexml.buscar_por_numero(numero, ano, tipo)
    if not result:
        raise HTTPException(status_code=404, detail=f"Norma {numero}/{ano} não encontrada no LexML.")
    return result


@router.get("/lexml/vigencia")
async def verificar_vigencia(
    referencia: str = Query(..., description="Ex: 'Lei 8.036/1990'"),
    lexml: LexMLClient = Depends(get_lexml),
):
    """Verifica a vigência de uma referência legal."""
    return await lexml.verificar_vigencia(referencia)


@router.post("/lexml/ingerir-lei")
async def ingerir_lei_rag(
    numero: str = Query(...),
    ano:    Optional[str] = Query(None),
    tipo:   str = Query("lei"),
    db: AsyncSession = Depends(get_db),
    lexml: LexMLClient = Depends(get_lexml),
    kb:   LegalKnowledgeBase = Depends(get_kb),
):
    """Ingere uma lei do LexML diretamente na base RAG."""
    norma = await lexml.buscar_por_numero(numero, ano, tipo)
    if not norma:
        raise HTTPException(status_code=404, detail="Norma não encontrada.")

    texto = f"""NORMA: {norma.get('titulo','')}
NÚMERO: {norma.get('numero','')}
DATA: {norma.get('data','')}
DESCRIÇÃO: {norma.get('descricao','')}
FONTE: {norma.get('url','')}
"""
    resultado = await kb.ingest_file(
        db=db,
        file_bytes=texto.encode("utf-8"),
        filename=f"lexml_{tipo}_{numero}_{ano or 'sd'}.txt",
        category="legislacao",
        metadata={"fonte": "lexml", "tipo": tipo, "numero": numero, "ano": ano},
    )
    return {**norma, "chunks_criados": resultado["chunks_created"],
            "document_id": str(resultado["document_id"])}


# ════════════════════════════════════════════════════════════════════════════
# STJ / TST — JURISPRUDÊNCIA
# ════════════════════════════════════════════════════════════════════════════

@router.get("/stj/jurisprudencia")
async def buscar_stj(
    q:     str = Query(..., description="Termos de busca"),
    tipo:  str = Query("acórdão"),
    limite: int = Query(10, ge=1, le=30),
    stj: STJClient = Depends(get_stj),
):
    """Busca jurisprudência no STJ."""
    try:
        resultados = await stj.buscar_jurisprudencia(q, tipo=tipo, limite=limite)
        return {"resultados": resultados, "total": len(resultados), "fonte": "STJ"}
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))


@router.get("/stj/sumula/{numero}")
async def buscar_sumula_stj(numero: int, stj: STJClient = Depends(get_stj)):
    """Busca uma Súmula do STJ pelo número."""
    result = await stj.buscar_sumula(numero)
    if not result:
        raise HTTPException(status_code=404, detail=f"Súmula STJ {numero} não encontrada.")
    return result


@router.get("/tst/sumula/{numero}")
async def buscar_sumula_tst(numero: int, tst: TSTClient = Depends(get_tst)):
    """Busca uma Súmula do TST pelo número."""
    result = await tst.buscar_sumula(numero)
    if not result:
        raise HTTPException(status_code=404, detail=f"Súmula TST {numero} não encontrada.")
    return result


@router.get("/tst/buscar-tema")
async def buscar_tema_tst(
    tema: str = Query(..., description="Ex: FGTS, hora extra, assédio"),
    tst: TSTClient = Depends(get_tst),
):
    """Busca Súmulas e OJs do TST por tema."""
    resultados = await tst.buscar_por_tema(tema)
    return {"resultados": resultados, "total": len(resultados), "fonte": "TST"}


@router.post("/tst/ingerir-jurisprudencia")
async def ingerir_jurisprudencia_tst(
    tema: str = Query(...),
    db: AsyncSession = Depends(get_db),
    tst: TSTClient = Depends(get_tst),
    kb: LegalKnowledgeBase = Depends(get_kb),
):
    """Ingere súmulas do TST sobre um tema diretamente no RAG."""
    sumulas = await tst.buscar_por_tema(tema)
    if not sumulas:
        return {"mensagem": f"Nenhuma súmula TST encontrada para '{tema}'.", "chunks_criados": 0}

    texto = f"JURISPRUDÊNCIA TST — TEMA: {tema}\n\n"
    for s in sumulas:
        texto += f"Súmula TST nº {s['numero']}: {s['texto']}\n\n"

    resultado = await kb.ingest_file(
        db=db,
        file_bytes=texto.encode("utf-8"),
        filename=f"tst_sumulas_{tema.replace(' ','_')}.txt",
        category="jurisprudencia",
        metadata={"fonte": "tst", "tema": tema},
    )
    return {
        "tema": tema, "sumulas_encontradas": len(sumulas),
        "chunks_criados": resultado["chunks_created"],
    }


# ════════════════════════════════════════════════════════════════════════════
# RECEITA FEDERAL — CNPJ
# ════════════════════════════════════════════════════════════════════════════

@router.get("/receita/cnpj/{cnpj}")
async def consultar_cnpj(
    cnpj: str,
    receita: ReceitaFederalClient = Depends(get_receita),
):
    """
    Consulta dados cadastrais de empresa pelo CNPJ.
    Retorna razão social, situação, sócios e endereço.
    """
    try:
        return await receita.consultar_cnpj(cnpj)
    except (ValueError, RuntimeError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.get("/receita/cnpj/{cnpj}/qualificacao")
async def qualificacao_parte(
    cnpj: str,
    receita: ReceitaFederalClient = Depends(get_receita),
):
    """
    Retorna texto de qualificação da parte pronto para inserção em petição.
    Ex: 'EMPRESA XYZ LTDA, CNPJ nº 00.000.000/0001-00, com sede na...'
    """
    try:
        dados = await receita.consultar_cnpj(cnpj)
        return {
            "qualificacao": receita.gerar_qualificacao_parte(dados),
            "dados": dados,
        }
    except (ValueError, RuntimeError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.get("/receita/cep/{cep}")
async def consultar_cep(
    cep: str,
    receita: ReceitaFederalClient = Depends(get_receita),
):
    """Consulta endereço por CEP."""
    try:
        return await receita.consultar_cep(cep)
    except (ValueError, RuntimeError) as e:
        raise HTTPException(status_code=422, detail=str(e))


# ════════════════════════════════════════════════════════════════════════════
# PAINEL DE STATUS DAS INTEGRAÇÕES
# ════════════════════════════════════════════════════════════════════════════

@router.get("/status")
async def status_integracoes():
    """Retorna status de conectividade de todas as integrações."""
    import httpx as _httpx

    resultados = {}
    urls = {
        "DataJud/CNJ":  "https://api-publica.datajud.cnj.jus.br",
        "LexML":        "https://www.lexml.gov.br",
        "BrasilAPI":    "https://brasilapi.com.br/api/cnpj/v1/00000000000191",
        "ReceitaWS":    "https://receitaws.com.br",
    }

    async with _httpx.AsyncClient(timeout=5.0) as client:
        for nome, url in urls.items():
            try:
                resp = await client.get(url)
                resultados[nome] = {
                    "status": "online" if resp.status_code < 500 else "degraded",
                    "http": resp.status_code,
                }
            except Exception as e:
                resultados[nome] = {"status": "offline", "erro": str(e)[:80]}

    return {"integracoes": resultados}
