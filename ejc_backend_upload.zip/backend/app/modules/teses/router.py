"""
EJC — Módulo Teses Jurídicas (modules/teses/router.py)

Banco de teses pré-estruturadas com fundamentação legal.
O advogado seleciona, adapta e insere na peça com um clique.
Aprende com as peças aprovadas do próprio escritório (RAG reverso).

Organização:
  - Por área do direito
  - Por tema específico
  - Por tribunal de referência
  - Por resultado esperado (procedente/improcedente)
"""
from __future__ import annotations

from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter(prefix="/teses", tags=["Banco de Teses Jurídicas"])

# ── Base de teses embutidas ────────────────────────────────
TESES_BASE = [
    # ─── TRABALHISTA ───────────────────────────────────────
    {
        "id": "tese-rescisao-indireta-fgts",
        "titulo": "Rescisão Indireta — Não Recolhimento do FGTS",
        "area": "trabalhista",
        "tema": "rescisao_indireta",
        "tribunal_ref": "TST/TRTs",
        "argumentacao_md": """## Tese: Rescisão Indireta por Descumprimento do FGTS

### Fundamentos Legais
O não recolhimento do FGTS pelo empregador por período superior a **3 (três) meses consecutivos** configura falta grave patronal, ensejadora da rescisão indireta do contrato de trabalho, nos termos do art. 483, alínea *d*, da CLT.

### Argumentação Jurídica
Conforme entendimento consolidado do C. TST (Súmula 13 e Tema Repetitivo 0039), a omissão sistemática do empregador no recolhimento do FGTS viola obrigação essencial do contrato de trabalho, tornando insustentável a continuação da relação empregatícia.

O FGTS é direito fundamental do trabalhador (art. 7º, III, CF/88), e seu não recolhimento causa prejuízo imediato e direto, independentemente de qualquer interpelação prévia.

### Pedidos Decorrentes
1. Reconhecimento da rescisão indireta (art. 483, *d*, CLT)
2. Aviso prévio indenizado proporcional (Lei 12.506/2011)
3. 13º salário proporcional
4. Férias proporcionais + 1/3
5. Levantamento do FGTS + multa de 40% (art. 18, Lei 8.036/90)

### Jurisprudência de Apoio
- TST, Súmula 13
- TST, Tema Repetitivo 39
- TST-RR-1001497-46.2018.5.02.0087 (referência)""",
        "tags": ["FGTS", "rescisão indireta", "art 483 CLT", "multa 40%"],
        "probabilidade_exito": 0.88,
    },
    {
        "id": "tese-horas-extras-supressao",
        "titulo": "Supressão de Horas Extras Habituais — Indenização",
        "area": "trabalhista",
        "tema": "horas_extras",
        "tribunal_ref": "TST",
        "argumentacao_md": """## Tese: Indenização por Supressão de Horas Extras Habituais

### Fundamento Legal
Nos termos da Súmula 291 do C. TST, a supressão pelo empregador do serviço suplementar prestado com habitualidade, durante pelo menos **1 (um) ano**, assegura ao empregado o direito à indenização correspondente ao valor de **1 (um) mês das horas suprimidas** para cada ano ou fração igual ou superior a seis meses de prestação de serviço acima da jornada normal.

### Argumentação
O reclamante prestou horas extras de forma habitual por período superior a X anos. A supressão abrupta dessas horas extras incorporadas ao salário configura alteração contratual lesiva (art. 468 CLT), gerando direito à indenização compensatória.

### Cálculo da Indenização
- Média de horas extras mensais × valor da hora extra (50% ou 100%) × N meses de indenização

### Jurisprudência
- TST, Súmula 291
- OJ 372 SDI-1 TST""",
        "tags": ["horas extras", "Súmula 291 TST", "supressão", "habitualidade"],
        "probabilidade_exito": 0.75,
    },
    {
        "id": "tese-assedio-moral-dano",
        "titulo": "Assédio Moral — Dano Moral Indenizável",
        "area": "trabalhista",
        "tema": "dano_moral",
        "tribunal_ref": "TST/TRTs",
        "argumentacao_md": """## Tese: Assédio Moral e Dano Moral Trabalhista

### Conceito Jurídico
Assédio moral consiste na exposição do trabalhador a situações vexatórias, humilhantes e constrangedoras de forma reiterada e prolongada durante a jornada de trabalho, em razão de vínculo hierárquico ou funcional.

### Fundamentos
- Art. 1º, III, CF/88 (dignidade da pessoa humana)
- Art. 5º, X, CF/88 (inviolabilidade da honra e imagem)
- Art. 186 CC/2002 (ato ilícito)
- Art. 927 CC/2002 (responsabilidade civil)

### Elementos Configuradores (conforme OJ 342 SDI-1 TST)
1. **Habitualidade**: condutas repetitivas, não episódicas
2. **Intencionalidade**: dolo ou culpa grave do agressor
3. **Dano psicológico**: comprovado por laudo ou testemunhas

### Quantum Indenizatório
Critérios: gravidade da conduta, extensão do dano, capacidade econômica do ofensor, caráter pedagógico.
Referência: TRT-MG costuma fixar entre R$ 5.000 e R$ 30.000.

### Prova
- Testemunhal (mínimo 2 testemunhas)
- Documental (e-mails, mensagens, comunicados)
- Pericial psicológica (recomendada para casos graves)""",
        "tags": ["assédio moral", "dano moral", "dignidade", "OJ 342 TST"],
        "probabilidade_exito": 0.62,
    },
    # ─── CONSUMIDOR ────────────────────────────────────────
    {
        "id": "tese-dano-moral-consumidor",
        "titulo": "Dano Moral por Inscrição Indevida no SPC/Serasa",
        "area": "consumidor",
        "tema": "dano_moral",
        "tribunal_ref": "STJ/TJs",
        "argumentacao_md": """## Tese: Dano Moral — Negativação Indevida

### Fundamento
O STJ pacificou o entendimento (Súmula 385) de que a negativação indevida de consumidor, que não possui outros registros negativos, configura dano moral *in re ipsa* (presumido), dispensando prova do efetivo dano.

### Requisitos
1. Inexistência de dívida ou débito já quitado
2. Ausência de outros registros negativos preexistentes
3. Comprovação da inscrição indevida (extrato do SPC/Serasa)

### Responsabilidade
O credor que solicita a negativação sem lastro válido responde objetivamente (art. 14 CDC). A entidade de proteção ao crédito responde se não notificou o devedor (art. 43, §2º, CDC).

### Valores de Referência (STJ — REsp)
- Negativação simples: R$ 5.000 a R$ 15.000
- Com outros danos demonstrados: R$ 15.000 a R$ 50.000

### Jurisprudências
- STJ, Súmula 385
- STJ, REsp 1.061.134/RS (repetitivo — negativação indevida)""",
        "tags": ["negativação indevida", "SPC", "Serasa", "Súmula 385 STJ", "CDC"],
        "probabilidade_exito": 0.72,
    },
    # ─── CIVIL ─────────────────────────────────────────────
    {
        "id": "tese-responsabilidade-civil-objetiva",
        "titulo": "Responsabilidade Civil Objetiva — Atividade de Risco",
        "area": "civil",
        "tema": "responsabilidade_civil",
        "tribunal_ref": "STJ",
        "argumentacao_md": """## Tese: Responsabilidade Civil Objetiva (art. 927, § único, CC)

### Regra Geral
O art. 927, parágrafo único, do CC/2002 estabelece que haverá obrigação de reparar o dano, independentemente de culpa, quando a atividade normalmente desenvolvida pelo autor do dano implicar, por sua natureza, risco para os direitos de outrem.

### Elementos da Responsabilidade Objetiva
1. Conduta (ação ou omissão)
2. Dano (material ou moral)
3. Nexo de causalidade
**Dispensa-se a prova de culpa.**

### Excludentes do Nexo Causal
- Caso fortuito ou força maior
- Culpa exclusiva da vítima
- Fato de terceiro

### Atividades de Risco Reconhecidas pelo STJ
- Transporte de passageiros e cargas
- Atividade minerária e petrolífera
- Fornecimento de energia elétrica
- Estacionamento remunerado
- Internet banking

### Referências
- Art. 927, §único, CC/2002
- STJ, REsp 1.291.247/RJ (atividade de risco — leading case)
- STJ, Súmula 130 (furto em estacionamento)""",
        "tags": ["responsabilidade objetiva", "art 927 CC", "atividade de risco", "nexo causal"],
        "probabilidade_exito": 0.70,
    },
    # ─── PREVIDENCIÁRIO ────────────────────────────────────
    {
        "id": "tese-aposentadoria-especial",
        "titulo": "Aposentadoria Especial — Agentes Nocivos",
        "area": "previdenciario",
        "tema": "aposentadoria",
        "tribunal_ref": "TRFs/TNU",
        "argumentacao_md": """## Tese: Aposentadoria Especial por Exposição a Agentes Nocivos

### Fundamento Legal
O segurado que tiver trabalhado em condições especiais que prejudiquem a saúde ou a integridade física durante 15, 20 ou 25 anos tem direito à aposentadoria especial (art. 57 da Lei 8.213/91).

### Agentes Nocivos (Decreto 3.048/99 — Anexo IV)
- Físicos: ruído (acima de 85 dB), calor, radiação
- Químicos: solventes, benzeno, amianto, poeira mineral
- Biológicos: bactérias, vírus, fungos (agentes de saúde)

### Prova Exigida
1. **PPP** — Perfil Profissiográfico Previdenciário (obrigatório pós 1997)
2. **LTCAT** — Laudo Técnico das Condições Ambientais de Trabalho
3. Para período anterior: documentos da época + prova testemunhal

### Conversão de Tempo Especial em Comum
Possível mesmo que o segurado não complete o tempo mínimo para aposentadoria especial:
- 25 anos especiais → multiplicar por 1,4 (masc.) ou 1,2 (fem.)
- 20 anos especiais → multiplicar por 1,75 (masc.) ou 1,5 (fem.)
- 15 anos especiais → multiplicar por 2,33 (masc.) ou 2,0 (fem.)

### Jurisprudências
- TNU, Súmula 9 (uso de EPI não descaracteriza atividade especial)
- STJ, REsp 1.306.113 (repetitivo — PPP)
- TNU, PUIL 0006680-45.2012 (ruído)""",
        "tags": ["aposentadoria especial", "PPP", "LTCAT", "agentes nocivos", "art 57 Lei 8213"],
        "probabilidade_exito": 0.65,
    },
]


class SalvarTeseReq(BaseModel):
    titulo: str
    area: str
    tema: str
    argumentacao_md: str
    tribunal_ref: Optional[str] = None
    tags: Optional[list[str]] = None
    probabilidade_exito: Optional[float] = None


@router.get("/")
async def listar_teses(
    area: Optional[str] = Query(None, description="trabalhista|civil|consumidor|previdenciario|tributario"),
    tema: Optional[str] = Query(None),
    busca: Optional[str] = Query(None, description="Busca por título ou tag"),
    db: AsyncSession = Depends(get_db),
):
    """Lista teses disponíveis com filtros por área e tema."""
    # Teses embutidas
    teses = list(TESES_BASE)

    if area:
        teses = [t for t in teses if t["area"] == area]
    if tema:
        teses = [t for t in teses if t["tema"] == tema]
    if busca:
        q = busca.lower()
        teses = [t for t in teses if q in t["titulo"].lower() or any(q in tag.lower() for tag in t.get("tags", []))]

    # Teses customizadas do banco
    filtros = []
    params: dict = {}
    if area:
        filtros.append("area=:area"); params["area"] = area
    if busca:
        filtros.append("titulo ILIKE :q"); params["q"] = f"%{busca}%"
    where = "WHERE " + " AND ".join(filtros) if filtros else ""
    rows = await db.execute(
        text(f"SELECT id,titulo,area,tema,tribunal_ref,tags,probabilidade_exito FROM teses_customizadas {where} ORDER BY uso_count DESC LIMIT 50"),
        params,
    )
    teses_custom = [{"origem": "custom", **dict(r)} for r in rows.mappings()]

    return {
        "total": len(teses) + len(teses_custom),
        "teses_base": [{"id": t["id"], "titulo": t["titulo"], "area": t["area"],
                        "tema": t["tema"], "tribunal_ref": t.get("tribunal_ref"),
                        "tags": t.get("tags", []),
                        "probabilidade_exito": t.get("probabilidade_exito"),
                        "origem": "base"} for t in teses],
        "teses_customizadas": teses_custom,
    }


@router.get("/{tese_id}")
async def buscar_tese(tese_id: str, db: AsyncSession = Depends(get_db)):
    """Retorna tese completa com argumentação em Markdown."""
    for t in TESES_BASE:
        if t["id"] == tese_id:
            await db.execute(
                text("UPDATE teses_customizadas SET uso_count=uso_count+1 WHERE id=:id"),
                {"id": tese_id}
            )
            return {**t, "origem": "base"}

    row = await db.execute(
        text("SELECT * FROM teses_customizadas WHERE id=:id"), {"id": tese_id}
    )
    t = row.mappings().first()
    if not t:
        raise HTTPException(404, "Tese não encontrada")
    await db.execute(
        text("UPDATE teses_customizadas SET uso_count=uso_count+1 WHERE id=:id"), {"id": tese_id}
    )
    return {**dict(t), "origem": "custom"}


@router.post("/", status_code=201)
async def salvar_tese(req: SalvarTeseReq, db: AsyncSession = Depends(get_db)):
    """Salva uma tese customizada do escritório."""
    tid = str(uuid4())
    await db.execute(
        text("""
            INSERT INTO teses_customizadas
                (id, titulo, area, tema, argumentacao_md, tribunal_ref, tags, probabilidade_exito)
            VALUES (:id,:titulo,:area,:tema,:arg,:tr,:tags,:prob)
        """),
        {"id": tid, "titulo": req.titulo, "area": req.area, "tema": req.tema,
         "arg": req.argumentacao_md, "tr": req.tribunal_ref,
         "tags": req.tags, "prob": req.probabilidade_exito},
    )
    return {"id": tid, "titulo": req.titulo, "message": "Tese salva no banco do escritório."}


@router.get("/areas")
async def listar_areas():
    areas = list({t["area"] for t in TESES_BASE})
    temas = {}
    for t in TESES_BASE:
        temas.setdefault(t["area"], set()).add(t["tema"])
    return {"areas": sorted(areas), "temas_por_area": {k: sorted(v) for k, v in temas.items()}}
