"""
EJC — Ecossistema Jurídico Clovis
Entry point FastAPI (main.py) — versão completa com 13 módulos
"""
from __future__ import annotations
import logging, os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.rate_limiter   import RateLimitMiddleware
from app.core.auth_middleware import AuthMiddleware
from app.core.config import get_settings
from app.core.scheduler import start_scheduler, stop_scheduler
# Originais
from app.modules.rag.router         import router as rag_router
from app.modules.redacao.router     import router as redacao_router
from app.modules.validacao.router   import router as validacao_router
from app.modules.calculos.router    import router as calculos_router
from app.modules.integracao.router  import router as integracao_router
# Jus.ia
from app.modules.espacos.router     import router as espacos_router
from app.modules.analise.router     import router as analise_router
from app.modules.prazos.router      import router as prazos_router
from app.modules.jurimetria.router  import router as jurimetria_router
# Doc especificação
from app.modules.casos.router       import router as casos_router
from app.modules.casos.dossie        import router as dossie_router
from app.modules.chat.router        import router as chat_router
from app.modules.auditoria.middleware import router as auditoria_router
from app.modules.exportacao.router  import router as exportacao_router
from app.modules.templates.router   import router as templates_router

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("ejc.main")
settings = get_settings()

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("="*65)
    logger.info(f"  {settings.app_name} v{settings.app_version} | {settings.environment}")
    logger.info(f"  LLM: {settings.ollama_model} | Embeddings: {settings.embedding_model}")
    logger.info(f"  Módulos: 13 | LGPD: ON | IA local: ON")
    logger.info("="*65)
    os.makedirs(settings.upload_dir, exist_ok=True)
    start_scheduler()
    yield
    stop_scheduler()
    logger.info("EJC encerrado.")

app = FastAPI(
    title=settings.app_name, version=settings.app_version,
    description=(
        "EJC — Plataforma IA Jurídica 100% local.\n"
        "13 módulos: RAG · Redação · Validação · Cálculos · Integrações · "
        "Espaços · Análise · Prazos · Jurimetria · Casos · Chat · Auditoria · "
        "Exportação DOCX/PDF · Templates\n"
        "LGPD Compliant · Ollama local · Soberania de dados total"
    ),
    docs_url="/docs", redoc_url="/redoc", lifespan=lifespan,
)


import os
from fastapi import Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

# ── Validação de segurança na inicialização ─────────────────────────────
_secret = settings.secret_key
if _secret == "change_me_in_production" and settings.environment == "production":
    raise RuntimeError(
        "ERRO CRÍTICO: SECRET_KEY com valor padrão em produção. "
        "Defina SECRET_KEY no arquivo .env antes de iniciar."
    )
if _secret == "change_me_in_production":
    import logging as _lg
    _lg.getLogger(__name__).warning(
        "[SEGURANÇA] SECRET_KEY usando valor padrão. Defina no .env antes de ir para produção."
    )

# ── Exception handlers padronizados ────────────────────────────────────
@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"erro": str(exc.detail), "status": exc.status_code, "rota": request.url.path},
    )

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    erros = [{"campo": ".".join(str(l) for l in e["loc"]), "mensagem": e["msg"]} for e in exc.errors()]
    return JSONResponse(
        status_code=422,
        content={"erro": "dados_invalidos", "detalhes": erros, "rota": request.url.path},
    )

@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    import logging as _lg
    _lg.getLogger(__name__).error(f"[500] {request.method} {request.url.path}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"erro": "erro_interno", "mensagem": "Erro interno do servidor. Tente novamente."},
    )

app.add_middleware(RateLimitMiddleware)
app.add_middleware(AuthMiddleware, secret_key=settings.secret_key)
_cors_origins = ["http://localhost:3000","http://localhost:5173","http://frontend:3000"]
if os.getenv("CORS_ORIGIN"):
    _cors_origins.append(os.getenv("CORS_ORIGIN"))
app.add_middleware(CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

API = "/api/v1"
# Originais
app.include_router(rag_router,         prefix=API)
app.include_router(redacao_router,     prefix=API)
app.include_router(validacao_router,   prefix=API)
app.include_router(calculos_router,    prefix=API)
app.include_router(integracao_router,  prefix=API)
# Jus.ia
app.include_router(espacos_router,     prefix=API)
app.include_router(analise_router,     prefix=API)
app.include_router(prazos_router,      prefix=API)
app.include_router(jurimetria_router,  prefix=API)
# Especificação
app.include_router(casos_router,       prefix=API)
app.include_router(dossie_router,      prefix=API)
app.include_router(chat_router,        prefix=API)
app.include_router(auditoria_router,   prefix=API)
app.include_router(exportacao_router,  prefix=API)
app.include_router(templates_router,   prefix=API)

@app.get("/health", tags=["Sistema"])
async def health_check():
    from app.modules.redacao.service import LegalDraftService
    svc = LegalDraftService()
    ollama = await svc.check_health()
    return {
        "status": "ok", "app": settings.app_name,
        "version": settings.app_version, "ollama": ollama,
        "modulos_ativos": 13, "lgpd_compliance": True, "ia_local": True,
    }

@app.get("/", tags=["Sistema"])
async def root():
    return {"message": f"Bem-vindo ao {settings.app_name}",
            "docs": "/docs", "health": "/health", "modulos": 13}

# ── Novos módulos (fix pente fino) ────────────────────────
from app.modules.agente.router    import router as agente_router
from app.modules.pesquisa.router  import router as pesquisa_router
from app.modules.visual_law.router import router as visual_law_router

app.include_router(agente_router,    prefix=API)
app.include_router(pesquisa_router,  prefix=API)
app.include_router(visual_law_router, prefix=API)

# ── Módulos das sugestões implementadas ──────────────────
from app.modules.streaming.router    import router as streaming_router
from app.modules.bacen.router        import router as bacen_router
from app.modules.trabalhista.router  import router as trabalhista_router
from app.modules.notificacoes.router import router as notificacoes_router
from app.modules.auth.router         import router as auth_router
from app.modules.ocr.router          import router as ocr_router
from app.modules.teses.router        import router as teses_router
from app.modules.portal.router       import router as portal_router
from app.modules.whisper.router      import router as whisper_router
from app.modules.financeiro.router   import router as financeiro_router

app.include_router(streaming_router,    prefix=API)
app.include_router(bacen_router,        prefix=API)
app.include_router(trabalhista_router,  prefix=API)
app.include_router(notificacoes_router, prefix=API)
app.include_router(auth_router,         prefix=API)
app.include_router(ocr_router,          prefix=API)
app.include_router(teses_router,        prefix=API)
app.include_router(portal_router,       prefix=API)
app.include_router(whisper_router,      prefix=API)
app.include_router(financeiro_router,   prefix=API)

# Registra job de notificações de prazos no scheduler existente
from app.modules.notificacoes.router import job_alertar_prazos_criticos as _notif_job
from apscheduler.triggers.cron import CronTrigger as _Cron
from app.core.scheduler import get_scheduler as _get_sched

def _registrar_notif():
    s = _get_sched()
    if s.running:
        s.add_job(_notif_job, _Cron(hour=7, minute=0),
                  id="notif_prazos", replace_existing=True,
                  name="Alertas diários de prazos críticos")

import asyncio as _asyncio
_asyncio.get_event_loop().call_later(3, _registrar_notif)

# ── Módulos FAZER AGORA ───────────────────────────────────
from app.modules.monitor.router import router as monitor_router
from app.modules.diff.router    import router as diff_router
from app.modules.bi.router      import router as bi_router

app.include_router(monitor_router, prefix=API)
app.include_router(diff_router,    prefix=API)
app.include_router(bi_router,      prefix=API)

# ── Alias/wrappers (compatibilidade) ─────────────────────
# REMOVIDO (wrapper vazio): from app.modules.resumo.router
# REMOVIDO (wrapper vazio): from app.modules.simplificacao.router

# REMOVIDO (wrapper vazio): app.include_router(resumo_router,       prefix=API)
# REMOVIDO (wrapper vazio): app.include_router(simplificacao_router, prefix=API)

# ── Módulo Público (site de vendas) ───────────────────────
from app.modules.publico.router   import router as publico_router   # noqa (criado abaixo)
from app.modules.pagamento.router import router as pagamento_router
from app.modules.pedidos.router   import router as pedidos_router
from app.modules.juizados.router  import router as juizados_router

app.include_router(pagamento_router, prefix=API)
app.include_router(pedidos_router,   prefix=API)
app.include_router(publico_router,   prefix=API)   # site público de petições
app.include_router(juizados_router,  prefix=API)

# ── Módulo Tributário ──────────────────────────────────────
from app.modules.tributario.router import router as tributario_router
from app.modules.cliente.router import router as cliente_router
from app.modules.onboarding.router import router as onboarding_router
from app.modules.upload.router import router as upload_router
from app.modules.triagem.router import router as triagem_router
from app.modules.revisao.router    import router as revisao_router
from app.modules.upload.router     import router as upload_router
from app.modules.triagem.router    import router as triagem_router
from app.modules.agentes.router    import router as agentes_router
from app.modules.indice.router      import router as indice_router
from app.modules.clientes.router   import router as clientes_router
from app.modules.propostas.router  import router as propostas_router
from app.modules.propostas.router  import crm as crm_router
from app.modules.tarefas.router    import router as tarefas_router
app.include_router(tributario_router, prefix=API)
app.include_router(cliente_router, prefix=API)
app.include_router(onboarding_router, prefix=API)
app.include_router(upload_router, prefix=API)
app.include_router(triagem_router, prefix=API)
app.include_router(revisao_router,  prefix=API)
app.include_router(agentes_router,   prefix=API)
app.include_router(indice_router,     prefix=API)
app.include_router(clientes_router,  prefix=API)
app.include_router(propostas_router, prefix=API)
app.include_router(crm_router,       prefix=API)
app.include_router(tarefas_router,   prefix=API)
