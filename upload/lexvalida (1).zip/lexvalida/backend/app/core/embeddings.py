"""Embeddings (portado do EJC: backend/app/services/embedding_service.py).

Mantém o mesmo contrato do EJC para que vetores sejam intercambiáveis entre os sistemas:
- modelo padrão intfloat/multilingual-e5-large, 1024 dimensões;
- protocolo E5 com prefixos "query: " e "passage: " (só para modelos E5);
- fastembed (ONNX, sem torch) local, ou serviço HTTP interno;
- lote limitado (EMBEDDINGS_BATCH) como contenção de memória;
- validação de dimensão: vetor com dimensão diferente da coluna é descartado;
- tudo-ou-nada por lote; qualquer falha devolve None e a busca cai para o modo textual.

Provider adicional "hash" (sem modelo) apenas para desenvolvimento e testes: gera vetores na
mesma dimensão configurada, sem semântica real. Nunca usar em produção.
"""
from __future__ import annotations

import hashlib
import logging
import math
import threading
from collections import OrderedDict

import httpx

from ..config import get_config
from .texto import normalizar, tokenizar

logger = logging.getLogger("lexvalida.embeddings")

POOLING_ESPERADO = "mean"  # contrato E5 garantido pelo fastembed pinado (igual ao EJC)

_model = None
_model_lock = threading.Lock()
_cache: "OrderedDict[tuple[str, str], list[float]]" = OrderedDict()
_CACHE_MAX = 256


def _cfg():
    return get_config()


def provider() -> str:
    return (_cfg().embeddings_provider or "local").strip().lower()


def dimensao() -> int:
    return int(_cfg().embeddings_dim or 1024)


def validar_modelo_local() -> tuple[bool, str]:
    cfg = _cfg()
    if provider() != "local":
        return True, f"provider {provider()}"
    try:
        from fastembed import TextEmbedding  # type: ignore
        modelos = {m["model"]: int(m["dim"]) for m in TextEmbedding.list_supported_models()}
    except Exception as exc:  # noqa: BLE001
        return False, f"fastembed indisponível: {exc}"
    d = modelos.get(cfg.embeddings_model)
    if d is None:
        return False, f"modelo não suportado pelo fastembed instalado: {cfg.embeddings_model}"
    if d != dimensao():
        return False, f"dimensão declarada {dimensao()} != dimensão do modelo {d}"
    return True, f"{cfg.embeddings_model} ({d}d)"


def disponivel() -> bool:
    p = provider()
    if p in ("hash", "http"):
        return True
    ok, detalhe = validar_modelo_local()
    if not ok:
        logger.error("Embeddings locais indisponíveis: %s", detalhe)
    return ok


def _get_model():
    global _model
    if _model is None:
        with _model_lock:
            if _model is None:
                from fastembed import TextEmbedding  # type: ignore
                _model = TextEmbedding(model_name=_cfg().embeddings_model)
    return _model


def _prefixo(modo: str) -> str:
    return f"{modo}: " if "e5" in (_cfg().embeddings_model or "").lower() else ""


def vetor_hash(texto: str, dim: int | None = None) -> list[float]:
    dim = dim or dimensao()
    vec = [0.0] * dim
    compacto = " ".join(normalizar(texto).split())
    feats = [f"w:{t}" for t in tokenizar(texto)]
    for n in (3, 4, 5):
        feats.extend(f"c{n}:{compacto[i:i + n]}" for i in range(max(0, len(compacto) - n + 1)))
    for f in feats:
        h = hashlib.md5(f.encode()).digest()
        vec[int.from_bytes(h[:4], "little") % dim] += 1.0 if h[4] & 1 else -1.0
    mod = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [round(v / mod, 6) for v in vec]


def _validar(vetores: list[list[float]] | None, n: int) -> list[list[float]] | None:
    if not vetores or len(vetores) != n:
        if vetores is not None:
            logger.warning("Provider devolveu %s vetores para %s textos; lote descartado.", len(vetores), n)
        return None
    if len(vetores[0]) != dimensao():
        logger.warning("Embedding com dimensão %s != %s configurada; descartado.", len(vetores[0]), dimensao())
        return None
    return vetores


def gerar(textos: list[str], modo: str = "passage") -> list[list[float]] | None:
    """modo: "passage" (ingestão) | "query" (consulta). Nunca levanta exceção."""
    if not textos:
        return None
    cacheavel = modo == "query" and len(textos) == 1
    if cacheavel and (modo, textos[0]) in _cache:
        _cache.move_to_end((modo, textos[0]))
        return [_cache[(modo, textos[0])]]
    p = provider()
    try:
        if p == "hash":
            vetores = [vetor_hash(t) for t in textos]
        elif p == "http":
            cfg = _cfg()
            r = httpx.post(cfg.embeddings_api_url, json={"textos": textos, "modo": modo}, timeout=cfg.embeddings_timeout)
            r.raise_for_status()
            vetores = r.json().get("embeddings")
        else:
            if not disponivel():
                return None
            lote = max(1, _cfg().embeddings_batch)
            vetores = [v.tolist() for v in _get_model().embed([_prefixo(modo) + t for t in textos], batch_size=lote)]
    except Exception as e:  # noqa: BLE001
        logger.warning("Falha ao gerar embeddings: %s", e)
        return None
    vetores = _validar(vetores, len(textos))
    if cacheavel and vetores:
        _cache[(modo, textos[0])] = vetores[0]
        while len(_cache) > _CACHE_MAX:
            _cache.popitem(last=False)
    return vetores
