"""Pré-checagem de arquivos para peticionamento eletrônico.

Verifica: PDF válido, proteção por senha ou criptografia, camada de texto pesquisável por página,
tamanho frente ao limite do tribunal (configurável: varia por sistema e tribunal, conferir a norma
local; o PJe é regulamentado pela Res. CNJ 185/2013), JavaScript e arquivos embutidos, texto oculto
com instrução a IA (reaproveita a Camada 1) e nome de arquivo seguro.
"""
from __future__ import annotations

import re

try:
    import pymupdf as fitz
except ImportError:  # pragma: no cover
    import fitz

from .ingestao import inspecionar_pagina

RX_NOME_SEGURO = re.compile(r"^[A-Za-z0-9._ -]{1,120}\.pdf$")


def checar(dados: bytes, nome: str, limite_mb: float = 0) -> dict:
    res = {"arquivo": nome, "tamanho_mb": round(len(dados) / 1048576, 2), "problemas": [], "alertas": []}
    if not RX_NOME_SEGURO.match(nome or ""):
        res["alertas"].append("Nome de arquivo com acentos ou caracteres especiais: renomeie (letras, números, ponto, hífen).")
    if limite_mb and res["tamanho_mb"] > limite_mb:
        res["problemas"].append(f"Arquivo com {res['tamanho_mb']} MB acima do limite configurado de {limite_mb} MB: dividir ou otimizar.")
    elif not limite_mb:
        res["alertas"].append("Limite de tamanho do tribunal não configurado (PETICIONAMENTO_LIMITE_MB).")
    try:
        doc = fitz.open(stream=dados, filetype="pdf")
    except Exception as e:  # noqa: BLE001
        res["problemas"].append(f"Arquivo não é um PDF válido: {e}")
        res["apto"] = False
        return res
    res["paginas"] = doc.page_count
    if doc.needs_pass or doc.is_encrypted:
        res["problemas"].append("PDF protegido por senha ou criptografado: os sistemas processuais costumam rejeitar.")
        if doc.needs_pass:
            doc.close()
            res["paginas_sem_texto"] = []
            res["apto"] = False
            return res
    sem_texto, ocultos = [], []
    for i, p in enumerate(doc, start=1):
        if not p.get_text("text").strip():
            sem_texto.append(i)
        ocultos += [c for c in inspecionar_pagina(p, i) if c.risco == "alto"]
    if sem_texto:
        res["alertas"].append(f"Páginas sem texto pesquisável (aplicar OCR): {sem_texto[:30]}{'...' if len(sem_texto) > 30 else ''}")
    if ocultos:
        res["problemas"].append(f"{len(ocultos)} trecho(s) de texto oculto com instrução a IA: remover antes de protocolar.")
    if doc.embfile_count():
        res["alertas"].append(f"{doc.embfile_count()} arquivo(s) embutido(s) no PDF.")
    js = False
    for x in range(1, min(doc.xref_length(), 5000)):
        try:
            obj = doc.xref_object(x, compressed=False)
        except Exception:  # noqa: BLE001
            continue
        if "/JavaScript" in obj or "/JS " in obj or "/JS(" in obj:
            js = True
            break
    if js:
        res["problemas"].append("PDF contém JavaScript: remover (risco de rejeição e de segurança).")
    doc.close()
    res["paginas_sem_texto"] = sem_texto
    res["apto"] = not res["problemas"]
    return res
