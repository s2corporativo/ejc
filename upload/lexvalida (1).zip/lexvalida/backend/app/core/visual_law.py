"""Visual Law: elementos visuais a partir de dados VERIFICÁVEIS do caso.

- Linha do tempo: fatos datados extraídos dos autos (com referência à página) ou informados pelo
  advogado; nunca datas inventadas.
- Quadro-resumo: dados cadastrais e processuais do caso.
Saídas: estrutura de dados (para DOCX e HTML) e HTML autocontido para a interface.
"""
from __future__ import annotations

import html
from datetime import date

from .contradicoes import extrair

ROTULOS = {"contratacao": "Contratação", "vencimento": "Vencimento", "inscricao_cadastro": "Inscrição em cadastro",
           "notificacao": "Notificação", "evento_danoso": "Evento danoso", "entrega": "Entrega",
           "admissao": "Admissão", "dispensa": "Dispensa", "citacao": "Citação"}


def eventos_dos_autos(paginas: list[dict]) -> list[dict]:
    vistos, ev = set(), []
    for p in paginas:
        for a in extrair(p["texto"]):
            if a["tipo"] != "data":
                continue
            chave = (a["rotulo"], a["valor"])
            if chave in vistos:
                continue
            vistos.add(chave)
            ref = f"{p['documento_nome']}, p. {p['pagina']}" + (f" ({p['numeracao_autos']})" if p.get("numeracao_autos") else "")
            ev.append({"data": a["valor"], "fato": ROTULOS.get(a["rotulo"], a["rotulo"]), "referencia": ref,
                       "marcador": f"[[autos:{p['documento_id']}:{p['pagina']}]]", "origem": "autos"})
    return ev


def linha_do_tempo(eventos: list[dict]) -> list[dict]:
    validos = []
    for e in eventos:
        try:
            date.fromisoformat(str(e["data"]))
        except (KeyError, ValueError):
            continue
        validos.append(e)
    return sorted(validos, key=lambda e: e["data"])


def quadro_resumo(caso: dict) -> list[tuple[str, str]]:
    classe = (caso.get("classe_tpu") or {}).get("nome") if isinstance(caso.get("classe_tpu"), dict) else caso.get("classe_tpu")
    assuntos = ", ".join(a.get("nome", str(a.get("codigo"))) if isinstance(a, dict) else str(a)
                         for a in caso.get("assuntos_tpu") or [])
    linhas = [("Processo", caso.get("numero_processo")), ("Tribunal", caso.get("tribunal")),
              ("Órgão julgador", caso.get("orgao_julgador")), ("Classe", classe), ("Assuntos", assuntos),
              ("Parte contrária", caso.get("parte_contraria")),
              ("Data dos fatos", caso["data_fatos"].strftime("%d/%m/%Y") if caso.get("data_fatos") else None)]
    return [(k, str(v)) for k, v in linhas if v]


def _br(d: str) -> str:
    return date.fromisoformat(d).strftime("%d/%m/%Y")


def html_visual(titulo: str, quadro: list[tuple[str, str]], linha: list[dict]) -> str:
    q = "".join(f"<tr><th>{html.escape(k)}</th><td>{html.escape(v)}</td></tr>" for k, v in quadro)
    t = "".join(f'<li><span class="d">{_br(e["data"])}</span><span class="f">{html.escape(e["fato"])}</span>'
                f'<span class="r">{html.escape(e.get("referencia") or "informado pelo advogado")}</span></li>' for e in linha)
    return f"""<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>{html.escape(titulo)}</title>
<style>body{{font:15px/1.5 Georgia,serif;color:#1d2329;max-width:820px;margin:24px auto;padding:0 16px}}
h2{{font-size:17px;border-bottom:2px solid #1f4e79;padding-bottom:4px}}table{{border-collapse:collapse;width:100%}}
th,td{{text-align:left;padding:6px 8px;border-bottom:1px solid #dcd9d2}}th{{width:32%;color:#5d6873;font-weight:normal}}
ol{{list-style:none;padding:0;border-left:3px solid #1f4e79;margin-left:8px}}li{{margin:0 0 12px 14px;position:relative}}
li:before{{content:"";position:absolute;left:-21px;top:6px;width:11px;height:11px;border-radius:50%;background:#1f4e79}}
.d{{font-weight:bold;margin-right:10px}}.r{{display:block;color:#5d6873;font-size:13px}}</style></head><body>
<h2>Quadro-resumo</h2><table>{q or '<tr><td>Sem dados cadastrados.</td></tr>'}</table>
<h2>Linha do tempo</h2><ol>{t or '<li>Nenhum fato datado identificado.</li>'}</ol></body></html>"""
