"""Cálculo de prescrição com memória e base legal.

Somente prazos de previsão legal expressa e incontroversa estão catalogados. Para qualquer
outra pretensão, informe o prazo e a base legal manualmente (parâmetro `prazo_anos` +
`base_legal`). Termo inicial (actio nata) e causas suspensivas/interruptivas são fatos que
o advogado deve fixar: o sistema não os presume.
"""
from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import date

CATALOGO: dict[str, dict] = {
    "geral": {"anos": 10, "base": "CC, art. 205", "descricao": "Prazo geral, quando a lei não fixar prazo menor"},
    "reparacao_civil": {"anos": 3, "base": "CC, art. 206, § 3º, V", "descricao": "Pretensão de reparação civil"},
    "enriquecimento_sem_causa": {"anos": 3, "base": "CC, art. 206, § 3º, IV", "descricao": "Ressarcimento de enriquecimento sem causa"},
    "divida_liquida_instrumento": {"anos": 5, "base": "CC, art. 206, § 5º, I", "descricao": "Cobrança de dívida líquida constante de instrumento público ou particular"},
    "cdc_fato_do_produto": {"anos": 5, "base": "CDC, art. 27", "descricao": "Reparação por fato do produto ou do serviço"},
    "fazenda_publica": {"anos": 5, "base": "Decreto 20.910/1932, art. 1º", "descricao": "Dívidas passivas da Fazenda Pública"},
    "trabalhista": {"anos": 5, "base": "CF, art. 7º, XXIX; CLT, art. 11", "descricao": "Créditos trabalhistas (quinquenal, limitada a 2 anos após a extinção do contrato)"},
}


def somar_anos(d: date, anos: int) -> date:
    """CC, art. 132, § 3º: prazos de anos expiram no dia de igual número do de início, ou no
    imediato, se faltar exata correspondência (29/02 -> 01/03)."""
    alvo = d.year + anos
    if d.month == 2 and d.day == 29 and not calendar.isleap(alvo):
        return date(alvo, 3, 1)
    return d.replace(year=alvo)


@dataclass
class ResultadoPrescricao:
    termo_inicial: date
    termo_final: date
    prescrito: bool
    data_referencia: date
    memoria: list[str]
    alertas: list[str]

    def as_dict(self) -> dict:
        return {
            "termo_inicial": self.termo_inicial.isoformat(),
            "termo_final": self.termo_final.isoformat(),
            "prescrito": self.prescrito,
            "data_referencia": self.data_referencia.isoformat(),
            "memoria": self.memoria,
            "alertas": self.alertas,
        }


def calcular_prescricao(
    termo_inicial: date,
    data_referencia: date,
    tipo: str | None = None,
    prazo_anos: int | None = None,
    base_legal: str | None = None,
    data_interrupcao: date | None = None,
    data_extincao_contrato: date | None = None,
) -> ResultadoPrescricao:
    memoria, alertas = [], [
        "O termo inicial e as causas suspensivas/interruptivas são juízos jurídicos do advogado.",
    ]
    if tipo:
        if tipo not in CATALOGO:
            raise ValueError(f"Tipo não catalogado: {tipo}. Informe prazo_anos e base_legal.")
        prazo_anos, base_legal = CATALOGO[tipo]["anos"], CATALOGO[tipo]["base"]
    if not prazo_anos or not base_legal:
        raise ValueError("Informe `tipo` catalogado ou `prazo_anos` + `base_legal`.")

    inicio = termo_inicial
    memoria.append(f"Termo inicial informado: {inicio:%d/%m/%Y}. Prazo: {prazo_anos} anos ({base_legal}).")
    if data_interrupcao:
        if data_interrupcao < inicio:
            raise ValueError("A interrupção não pode ser anterior ao termo inicial.")
        memoria.append(
            f"Interrupção em {data_interrupcao:%d/%m/%Y}: o prazo recomeça a correr dessa data "
            f"(CC, art. 202, parágrafo único). A interrupção só pode ocorrer uma vez (art. 202, caput)."
        )
        inicio = data_interrupcao

    final = somar_anos(inicio, prazo_anos)
    memoria.append(f"Termo final: {final:%d/%m/%Y} (CC, art. 132, § 3º).")

    if tipo == "trabalhista" and data_extincao_contrato:
        bienal = somar_anos(data_extincao_contrato, 2)
        memoria.append(f"Limite bienal após a extinção do contrato: {bienal:%d/%m/%Y} (CF, art. 7º, XXIX).")
        if bienal < final:
            final = bienal
            memoria.append("Prevalece o limite bienal.")

    prescrito = data_referencia > final
    memoria.append(
        f"Em {data_referencia:%d/%m/%Y}: {'PRESCRITA' if prescrito else 'NÃO prescrita'} a pretensão."
    )
    if not prescrito and (final - data_referencia).days <= 90:
        alertas.append(f"Faltam {(final - data_referencia).days} dias para o termo final.")
    return ResultadoPrescricao(termo_inicial, final, prescrito, data_referencia, memoria, alertas)


def calcular_intercorrente(
    rito: str,
    data_ciencia_tentativa_infrutifera: date,
    data_referencia: date,
    prazo_anos: int,
    base_prazo: str,
    data_interrupcao: date | None = None,
) -> ResultadoPrescricao:
    """Prescrição intercorrente.

    rito "cpc": CPC, art. 921, §§ 1º, 4º, 4º-A e 5º (redação da Lei 14.195/2021). Termo inicial na
      ciência da primeira tentativa infrutífera de localização do devedor ou de bens; suspensão do
      curso por uma única vez, pelo prazo máximo de 1 ano; a efetiva citação, intimação ou constrição
      interrompe. O prazo é o da pretensão executada (STF, Súmula 150).
    rito "lef": Lei 6.830/1980, art. 40, caput e §§ 2º e 4º; STJ, Súmula 314: suspensão por 1 ano e,
      findo esse prazo, início da prescrição quinquenal intercorrente.
    """
    memoria, alertas = [], ["Conferir as teses repetitivas aplicáveis e eventuais causas de interrupção não informadas."]
    if rito not in ("cpc", "lef"):
        raise ValueError("rito deve ser 'cpc' ou 'lef'")
    if rito == "lef":
        prazo_anos, base_prazo = 5, "Lei 6.830/1980, art. 40, § 4º; STJ, Súmula 314"
    if not prazo_anos or not base_prazo:
        raise ValueError("Informe o prazo da pretensão executada e a base legal (STF, Súmula 150).")
    inicio_susp = data_ciencia_tentativa_infrutifera
    fim_susp = somar_anos(inicio_susp, 1)
    base_susp = "CPC, art. 921, §§ 1º e 4º" if rito == "cpc" else "Lei 6.830/1980, art. 40, caput e § 2º; STJ, Súmula 314"
    memoria.append(f"Ciência da primeira tentativa infrutífera: {inicio_susp:%d/%m/%Y}.")
    memoria.append(f"Suspensão de 1 ano (única) até {fim_susp:%d/%m/%Y} ({base_susp}).")
    inicio_prazo = fim_susp
    if data_interrupcao:
        if data_interrupcao < inicio_susp:
            raise ValueError("Interrupção anterior ao termo inicial.")
        base_int = "CPC, art. 921, § 4º-A" if rito == "cpc" else "causa interruptiva informada"
        memoria.append(f"Interrupção em {data_interrupcao:%d/%m/%Y} ({base_int}): o prazo recomeça dessa data, sem nova suspensão.")
        inicio_prazo = max(data_interrupcao, inicio_susp)
    final = somar_anos(inicio_prazo, prazo_anos)
    memoria.append(f"Prazo de {prazo_anos} anos ({base_prazo}) contado de {inicio_prazo:%d/%m/%Y}: termo final {final:%d/%m/%Y}.")
    prescrito = data_referencia > final
    memoria.append(f"Em {data_referencia:%d/%m/%Y}: {'CONSUMADA' if prescrito else 'NÃO consumada'} a prescrição intercorrente.")
    if prescrito:
        alertas.append("Reconhecimento exige oitiva prévia das partes (CPC, art. 921, § 5º; Lei 6.830/1980, art. 40, § 4º).")
    return ResultadoPrescricao(data_ciencia_tentativa_infrutifera, final, prescrito, data_referencia, memoria, alertas)
