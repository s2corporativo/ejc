"""Licitações (Lei 14.133/2021): prazos e matriz de habilitação.

Prazos (dias úteis = dias de expediente do órgão; contagem do art. 183: exclui o dia do começo e
inclui o do vencimento). Feriados e pontos facultativos do órgão devem ser informados no calendário.
- Impugnação e pedido de esclarecimento: até 3 dias úteis antes da abertura (art. 164, caput);
  resposta da Administração até o último dia útil anterior à abertura (art. 164, parágrafo único).
- Recurso: 3 dias úteis da intimação ou da lavratura da ata (art. 165, I).
- Contrarrazões: mesmo prazo, da intimação pessoal ou da divulgação da interposição (art. 165, § 4º).

Habilitação: arts. 62 a 70. Restrição em cadastro privado de crédito (Serasa/SPC) não integra o rol
legal de regularidade fiscal (art. 68); exigência desse tipo é sinalizada para avaliação de impugnação.
"""
from __future__ import annotations

import re
from datetime import date, timedelta

from .prazos import Calendario
from .texto import normalizar


def _cal(cal: Calendario | None) -> Calendario:
    c = cal or Calendario()
    c.aplicar_suspensao_art_220 = False  # CPC, art. 220 não se aplica ao processo licitatório
    return c


def _util_anterior(c: Calendario, d: date) -> date:
    d -= timedelta(days=1)
    while not c.eh_util(d):
        d -= timedelta(days=1)
    return d


def prazo_impugnacao(data_abertura: date, cal: Calendario | None = None) -> dict:
    c = _cal(cal)
    d, mem = data_abertura, [f"Abertura do certame: {data_abertura:%d/%m/%Y}."]
    for i in range(1, 4):
        d = _util_anterior(c, d)
        mem.append(f"{i}º dia útil anterior: {d:%d/%m/%Y}.")
    resposta = _util_anterior(c, data_abertura)
    mem.append(f"Limite para protocolo da impugnação ou do pedido de esclarecimento: {d:%d/%m/%Y} (Lei 14.133/2021, art. 164, caput).")
    mem.append(f"Resposta da Administração até {resposta:%d/%m/%Y}, último dia útil anterior à abertura (art. 164, parágrafo único).")
    return {"limite_protocolo": d.isoformat(), "limite_resposta_administracao": resposta.isoformat(), "memoria": mem,
            "alertas": ["Confirme no edital horário-limite e canal de protocolo; inclua feriados e pontos facultativos do órgão."]}


def _contar_uteis(c: Calendario, inicio_evento: date, dias: int) -> tuple[date, list[str]]:
    d, n, mem = inicio_evento, 0, []
    while n < dias:
        d += timedelta(days=1)
        if c.eh_util(d):
            n += 1
            mem.append(f"{n}º dia útil: {d:%d/%m/%Y}.")
    return d, mem


def prazo_recurso(data_intimacao: date, cal: Calendario | None = None, contrarrazoes: bool = False) -> dict:
    c = _cal(cal)
    venc, mem = _contar_uteis(c, data_intimacao, 3)
    base = "Lei 14.133/2021, art. 165, § 4º (contrarrazões)" if contrarrazoes else "Lei 14.133/2021, art. 165, I"
    mem.insert(0, f"Termo inicial: {data_intimacao:%d/%m/%Y} (exclui-se o dia do começo, art. 183).")
    mem.append(f"Vencimento: {venc:%d/%m/%Y} ({base}).")
    return {"vencimento": venc.isoformat(), "memoria": mem,
            "alertas": ["Verifique no edital a exigência de manifestação imediata da intenção de recorrer, quando prevista."]}


REQUISITOS = [
    # (chave, rótulo, base legal, padrões no edital, sinônimos de documento da empresa)
    ("ato_constitutivo", "Ato constitutivo, estatuto ou contrato social", "art. 66", r"contrato social|ato constitutivo|estatuto social", ["contrato social", "ato constitutivo", "estatuto"]),
    ("cnpj", "Inscrição no CNPJ", "art. 68, I", r"\bcnpj\b|cadastro nacional da pessoa juridica", ["cnpj"]),
    ("inscricao_estadual_municipal", "Inscrição no cadastro de contribuintes estadual ou municipal", "art. 68, II", r"inscricao (estadual|municipal)|cadastro de contribuintes", ["inscricao estadual", "inscricao municipal"]),
    ("fazenda_federal", "Regularidade com a Fazenda federal (certidão conjunta PGFN/RFB)", "art. 68, III", r"fazenda federal|receita federal|pgfn|divida ativa da uniao|certidao conjunta", ["pgfn", "certidao conjunta", "receita federal"]),
    ("fazenda_estadual", "Regularidade com a Fazenda estadual", "art. 68, III", r"fazenda estadual|tributos estaduais|cnd estadual", ["fazenda estadual", "cnd estadual"]),
    ("fazenda_municipal", "Regularidade com a Fazenda municipal", "art. 68, III", r"fazenda municipal|tributos municipais|cnd municipal", ["fazenda municipal", "cnd municipal"]),
    ("fgts", "Regularidade com o FGTS (CRF)", "art. 68, IV", r"\bfgts\b|\bcrf\b", ["fgts", "crf"]),
    ("trabalhista", "Regularidade trabalhista (CNDT)", "art. 68, V", r"cndt|debitos trabalhistas|justica do trabalho", ["cndt"]),
    ("menor", "Cumprimento do art. 7º, XXXIII, da Constituição", "art. 68, VI", r"7o?,? xxxiii|trabalho (noturno|perigoso|insalubre).{0,40}menor", ["declaracao menor", "art. 7"]),
    ("balanco", "Balanço patrimonial e demonstrações contábeis", "art. 69, I", r"balanco patrimonial|demonstracoes contabeis", ["balanco"]),
    ("falencia", "Certidão negativa de falência", "art. 69, II", r"falencia|recuperacao judicial", ["falencia"]),
    ("atestado_tecnico", "Atestados de capacidade técnica", "art. 67, II", r"atestado.{0,30}capacidade tecnica|capacidade tecnico", ["atestado"]),
    ("registro_conselho", "Registro ou inscrição na entidade profissional competente", "art. 67, V", r"crea|cau\b|crmv|crq|conselho (regional|profissional)|entidade profissional", ["crea", "cau", "crmv", "crq", "conselho"]),
]
EXIGENCIAS_SEM_PREVISAO = [
    (r"serasa|spc\b|scpc|protecao ao credito|boa vista", "Certidão ou consulta a cadastro privado de crédito (Serasa/SPC)"),
    (r"protesto", "Certidão negativa de protesto"),
]


def matriz_habilitacao(texto_edital: str, documentos: list[dict], data_sessao: date) -> dict:
    """documentos: [{"tipo": "CNDT", "validade": "2026-12-01"}]. Compara exigências do edital com os
    documentos disponíveis e suas validades na data da sessão."""
    ed = normalizar(texto_edital)
    docs = [{**d, "_n": normalizar(d.get("tipo", ""))} for d in documentos]
    linhas, pendencias = [], []
    for chave, rotulo, base, padrao, sinonimos in REQUISITOS:
        if not re.search(padrao, ed):
            continue
        doc = next((d for d in docs if any(s in d["_n"] for s in sinonimos)), None)
        if not doc:
            situacao = "ausente"
        elif doc.get("validade") and date.fromisoformat(doc["validade"]) < data_sessao:
            situacao = "vencido_na_sessao"
        else:
            situacao = "ok"
        linhas.append({"requisito": rotulo, "base": f"Lei 14.133/2021, {base}", "situacao": situacao,
                       "documento": doc.get("tipo") if doc else None, "validade": doc.get("validade") if doc else None})
        if situacao != "ok":
            pendencias.append(f"{rotulo}: {situacao.replace('_', ' ')}")
    sem_previsao = [{"exigencia": r, "orientacao": "Exigência sem previsão nos arts. 62 a 70 da Lei 14.133/2021; avaliar impugnação (art. 164)."}
                    for p, r in EXIGENCIAS_SEM_PREVISAO if re.search(p, ed)]
    return {"data_sessao": data_sessao.isoformat(), "linhas": linhas, "pendencias": pendencias,
            "exigencias_sem_previsao_legal": sem_previsao,
            "nota": "Identificação por palavras-chave do edital: confira o item de habilitação integralmente."}
