"""Mapa do caso: contradições entre documentos dos autos.

Extração determinística de fatos ROTULADOS (data ou valor associado a uma palavra-chave próxima) em
cada página. Mesmo rótulo com valores distintos em documentos ou páginas diferentes vira INDÍCIO de
contradição, com a localização de cada ocorrência para conferência humana. Valores distintos podem
ser legítimos (várias parcelas, aditivos): o sistema aponta, o advogado decide.
"""
from __future__ import annotations

import re
from datetime import date
from decimal import Decimal, InvalidOperation

from .texto import normalizar

JANELA = 90
ROTULOS_DATA = {
    "contratacao": r"contrat\w*|assinatura|celebrad\w*|firmad\w*",
    "vencimento": r"vencimento|vencid\w*",
    "inscricao_cadastro": r"inscri\w*|negativ\w*|apontament\w*",
    "notificacao": r"notifica\w*|comunica\w*\s+previa",
    "evento_danoso": r"acidente|sinistro|colisao|ocorrido|fato\s+ocorreu",
    "entrega": r"entreg\w*",
    "admissao": r"admiss\w*|admitid\w*",
    "dispensa": r"dispensa|demiss\w*|rescisao|desligament\w*",
    "citacao": r"citad\w*|citacao",
}
ROTULOS_VALOR = {
    "valor_contrato": r"valor\s+do\s+contrato|preco|valor\s+total",
    "debito": r"debito|divida|valor\s+cobrado|valor\s+devido|saldo\s+devedor",
    "salario": r"salario|remuneracao",
    "parcela": r"parcela|prestacao\s+mensal",
    "indenizacao": r"indeniza\w*|danos?\s+mora\w*",
}
MESES = ["janeiro", "fevereiro", "marco", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro",
         "novembro", "dezembro"]
RX_DATA = re.compile(r"\b(\d{1,2})(?:o|º)?(?:[/.-](\d{1,2})[/.-]|\s+de\s+(" + "|".join(MESES) + r")\s+de\s+)(\d{4})\b")
RX_VALOR = re.compile(r"r\$\s*([\d.]+,\d{2}|\d+(?:\.\d{3})*)")


def _data(m: re.Match) -> str | None:
    mes = int(m.group(2)) if m.group(2) else MESES.index(m.group(3)) + 1
    try:
        return date(int(m.group(4)), mes, int(m.group(1))).isoformat()
    except ValueError:
        return None


def _valor(s: str) -> str | None:
    try:
        return str(Decimal(s.replace(".", "").replace(",", ".")).quantize(Decimal("0.01")))
    except InvalidOperation:
        return None


RX_NEGACAO = re.compile(r"(sem|nao|nunca|ausencia\s+de|falta\s+de)\s+(\w+\s+)?$")


def _chaves(t: str, rotulos: dict) -> list[tuple[int, int, str]]:
    """(início, fim, rótulo) das palavras-chave não negadas ("sem notificação" não rotula data)."""
    out = []
    for rot, rx in rotulos.items():
        for k in re.finditer(rx, t):
            if not RX_NEGACAO.search(t[max(0, k.start() - 25): k.start()]):
                out.append((k.start(), k.end(), rot))
    return out


def extrair(texto: str) -> list[dict]:
    """[{rotulo, tipo, valor, trecho}] de uma página. Cada data ou valor é atribuído à palavra-chave
    não negada mais próxima que o antecede, dentro da janela."""
    t = normalizar(texto or "")
    achados = []
    for tipo, rx, rotulos, conv in (("data", RX_DATA, ROTULOS_DATA, _data),
                                    ("valor", RX_VALOR, ROTULOS_VALOR, lambda m: _valor(m.group(1)))):
        chaves = _chaves(t, rotulos)
        for m in rx.finditer(t):
            antes = [c for c in chaves if c[1] <= m.start() and m.start() - c[1] <= JANELA]
            if not antes:
                continue
            ini, fim, rot = max(antes, key=lambda c: c[1])
            v = conv(m)
            if v:
                achados.append({"rotulo": rot, "tipo": tipo, "valor": v, "trecho": t[max(0, ini - 20): m.end() + 5].strip()})
    return achados


def detectar(paginas: list[dict]) -> dict:
    """paginas: [{documento_id, documento_nome, pagina, numeracao_autos, texto}]."""
    por_rotulo: dict[str, list[dict]] = {}
    vistos: set = set()
    for p in paginas:
        for a in extrair(p["texto"]):
            chave = (a["rotulo"], p["documento_id"], p["pagina"], a["valor"])
            if chave in vistos:
                continue
            vistos.add(chave)
            por_rotulo.setdefault(a["rotulo"], []).append({**a, "documento_id": p["documento_id"],
                                                           "documento_nome": p["documento_nome"], "pagina": p["pagina"],
                                                           "numeracao_autos": p.get("numeracao_autos") or "",
                                                           "marcador": f"[[autos:{p['documento_id']}:{p['pagina']}]]"})
    contradicoes, consistentes = [], []
    for rot, ocs in por_rotulo.items():
        valores = sorted({o["valor"] for o in ocs})
        docs = {o["documento_id"] for o in ocs}
        item = {"rotulo": rot, "tipo": ocs[0]["tipo"], "valores": valores, "ocorrencias": ocs[:30]}
        if len(valores) > 1 and len(docs) > 1:
            item["mensagem"] = (f"'{rot.replace('_', ' ')}' aparece com {len(valores)} valores distintos em "
                                f"{len(docs)} documentos: {', '.join(valores[:6])}. Indício a conferir.")
            contradicoes.append(item)
        elif len(valores) > 1:
            item["mensagem"] = f"'{rot.replace('_', ' ')}' com valores distintos no mesmo documento (podem ser legítimos)."
            consistentes.append(item)
        else:
            consistentes.append(item)
    return {"contradicoes": contradicoes, "demais_fatos_rotulados": consistentes,
            "nota": "Extração por palavras-chave e proximidade: indícios para conferência, não conclusão."}
