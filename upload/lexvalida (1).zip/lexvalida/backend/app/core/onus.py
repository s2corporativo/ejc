"""Matriz fato x prova x ônus.

Regras de distribuição implementadas:
- Processo civil: CPC, art. 373, I (autor: fato constitutivo) e II (réu: fato impeditivo,
  modificativo ou extintivo); § 1º (distribuição dinâmica, por decisão fundamentada).
- Consumidor: CDC, art. 6º, VIII (inversão ope judicis, depende de decisão judicial).
- Trabalho: CLT, art. 818, I e II; § 1º (distribuição diversa por decisão).
A identificação da natureza do fato (constitutivo etc.) é juízo jurídico: o sistema aplica a
regra a partir da natureza informada ou sugerida e sinaliza quando a sugestão foi automática.
"""
from __future__ import annotations

from dataclasses import dataclass, field

NATUREZAS = {"constitutivo", "impeditivo", "modificativo", "extintivo"}

REGRAS = {
    "civel": {"constitutivo": ("autor", "CPC, art. 373, I"), "outros": ("reu", "CPC, art. 373, II")},
    "consumidor": {"constitutivo": ("autor", "CPC, art. 373, I"), "outros": ("reu", "CPC, art. 373, II")},
    "trabalhista": {"constitutivo": ("autor", "CLT, art. 818, I"), "outros": ("reu", "CLT, art. 818, II")},
}


@dataclass
class LinhaMatriz:
    alegacao: str
    parte_que_alega: str
    natureza: str
    onus: str
    base_legal: str
    provas: list[dict] = field(default_factory=list)
    situacao: str = "sem_prova_localizada"
    risco: str = "alto"
    observacoes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return self.__dict__.copy()


def distribuir_onus(natureza: str, rito: str = "civel", inversao_deferida: bool = False,
                    distribuicao_dinamica: str | None = None) -> tuple[str, str, list[str]]:
    rito = rito if rito in REGRAS else "civel"
    if natureza not in NATUREZAS:
        raise ValueError(f"Natureza inválida: {natureza}")
    obs = []
    regra = REGRAS[rito]["constitutivo" if natureza == "constitutivo" else "outros"]
    onus, base = regra
    if distribuicao_dinamica in ("autor", "reu"):
        base_din = "CLT, art. 818, § 1º" if rito == "trabalhista" else "CPC, art. 373, § 1º"
        return distribuicao_dinamica, f"{base_din} (decisão de distribuição diversa)", obs
    if rito == "consumidor" and natureza == "constitutivo":
        if inversao_deferida:
            return "reu", "CDC, art. 6º, VIII (inversão deferida)", obs
        obs.append("Inversão do ônus (CDC, art. 6º, VIII) depende de decisão judicial; enquanto não deferida, vale a regra do art. 373, I.")
    return onus, base, obs


def montar_matriz(alegacoes: list[dict], rito: str, buscar_provas, inversao_deferida: bool = False,
                  limiar_relevancia: float = 0.02) -> dict:
    """`alegacoes`: [{alegacao, parte ('autor'|'reu'), natureza, distribuicao_dinamica?}].
    `buscar_provas(texto)` devolve trechos dos autos com relevância (RRF)."""
    linhas = []
    for a in alegacoes:
        natureza = a.get("natureza") or ("constitutivo" if a.get("parte", "autor") == "autor" else "impeditivo")
        onus, base, obs = distribuir_onus(natureza, rito, inversao_deferida, a.get("distribuicao_dinamica"))
        if not a.get("natureza"):
            obs.append("Natureza do fato sugerida automaticamente pela posição da parte: confirmar.")
        provas = [p for p in buscar_provas(a["alegacao"]) if p.get("relevancia", 0) >= limiar_relevancia][:3]
        linha = LinhaMatriz(a["alegacao"], a.get("parte", "autor"), natureza, onus, base, provas, observacoes=obs)
        if provas:
            linha.situacao = "prova_candidata_localizada"
            linha.risco = "medio"
            linha.observacoes.append("Prova localizada por similaridade: confirmar se demonstra o fato.")
        else:
            linha.risco = "alto" if onus == a.get("parte", "autor") else "baixo"
            if linha.risco == "alto":
                linha.observacoes.append(f"Ônus de quem alega ({onus}) e nenhuma prova localizada nos autos.")
        linhas.append(linha)
    criticos = [l.alegacao for l in linhas if l.risco == "alto"]
    return {"rito": rito, "linhas": [l.as_dict() for l in linhas], "pontos_criticos": criticos,
            "nota": "A matriz indica provas candidatas; a valoração da prova é do advogado e do juízo (CPC, art. 371)."}
