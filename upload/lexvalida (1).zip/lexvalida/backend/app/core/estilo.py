"""Perfil de estilo extraído de modelos do próprio escritório.

Métricas determinísticas (sem IA) transformadas em instruções EDITÁVEIS. A IA, quando disponível,
complementa com observações; o texto final das instruções é do usuário. Não há fine-tuning: o perfil
entra como instrução de redação, e a aderência é conferível nas métricas da peça gerada.
"""
from __future__ import annotations

import re
import statistics

from .texto import normalizar

RX_VOCATIVO = re.compile(r"^\s*(EXCELENT[ÍI]SSIM[OA]\S*|EXMO\.?|EXMA\.?|MERIT[ÍI]SSIM[OA]|ILUSTR[ÍI]SSIM[OA])[^\n]{0,160}", re.IGNORECASE | re.MULTILINE)
RX_FECHO = re.compile(r"(termos\s+em\s+que|nestes\s+termos|nesses\s+termos)[^\n]{0,40}\n?[^\n]{0,40}(pede|espera)\s+deferimento", re.IGNORECASE)
RX_TITULO_ROMANO = re.compile(r"^\s*[IVXL]{1,6}\s*[-.–)]\s+\S", re.MULTILINE)
RX_TITULO_NUM = re.compile(r"^\s*\d{1,2}(\.\d{1,2})*\s*[-.)]\s+[A-ZÁÉÍÓÚÂÊÔÃÕÇ]", re.MULTILINE)
LATINISMOS = ["data venia", "ad argumentandum", "in casu", "ex vi", "mutatis mutandis", "periculum in mora",
              "fumus boni iuris", "in verbis", "ab initio", "ipsis litteris"]


def _paragrafos(t: str) -> list[str]:
    return [p.strip() for p in re.split(r"\n\s*\n|\n(?=\s{2,}|\t)", t) if len(p.strip()) > 40]


def metricas(textos: list[str]) -> dict:
    todos = "\n\n".join(textos)
    n = normalizar(todos)
    pars = [p for t in textos for p in _paragrafos(t)]
    frases = [f for f in re.split(r"(?<=[.!?])\s+", todos) if len(f.split()) > 3]
    linhas = [l.strip() for l in todos.splitlines() if l.strip()]
    titulos_caixa = [l for l in linhas if l.isupper() and 3 <= len(l) <= 90]
    terceira = len(re.findall(r"\b(requer|vem|postula|pleiteia|aduz)\b", n))
    primeira = len(re.findall(r"\b(requeremos|vimos|postulamos|pleiteamos|entendemos)\b", n))
    vocativos = [m.group(0).strip() for m in RX_VOCATIVO.finditer(todos)]
    return {
        "modelos": len(textos),
        "palavras_por_paragrafo": round(statistics.mean(len(p.split()) for p in pars), 1) if pars else None,
        "palavras_por_frase": round(statistics.mean(len(f.split()) for f in frases), 1) if frases else None,
        "pessoa_verbal": "terceira_pessoa" if terceira >= primeira else "primeira_plural",
        "vocativo": max(set(vocativos), key=vocativos.count) if vocativos else None,
        "titulos_caixa_alta": len(titulos_caixa) >= max(2, len(textos)),
        "numeracao_titulos": "romana" if len(RX_TITULO_ROMANO.findall(todos)) >= 2 else
                             ("arabica" if len(RX_TITULO_NUM.findall(todos)) >= 2 else "sem_numeracao"),
        "fecho_tradicional": bool(RX_FECHO.search(todos)),
        "usa_travessao": "—" in todos,
        "latinismos": sorted({l for l in LATINISMOS if l in n}),
    }


def instrucoes(m: dict, ia: dict | None = None) -> str:
    linhas = ["PERFIL DE ESTILO DO ESCRITÓRIO (aplique na forma; nunca altere fatos, fontes ou pedidos):"]
    if m.get("vocativo"):
        linhas.append(f"- Endereçamento no padrão: \"{m['vocativo'][:120]}\".")
    if m.get("pessoa_verbal") == "terceira_pessoa":
        linhas.append("- Redija na terceira pessoa (\"a parte requer\", \"vem\").")
    else:
        linhas.append("- Redija na primeira pessoa do plural (\"requeremos\").")
    if m.get("palavras_por_paragrafo"):
        linhas.append(f"- Parágrafos com cerca de {int(m['palavras_por_paragrafo'])} palavras; frases com cerca de {int(m.get('palavras_por_frase') or 25)}.")
    if m.get("titulos_caixa_alta"):
        linhas.append("- Títulos de seção em CAIXA ALTA.")
    if m.get("numeracao_titulos") == "romana":
        linhas.append("- Numere os títulos em algarismos romanos (I, II, III).")
    elif m.get("numeracao_titulos") == "arabica":
        linhas.append("- Numere os títulos em algarismos arábicos.")
    if m.get("fecho_tradicional"):
        linhas.append("- Encerre com \"Termos em que, pede deferimento.\"")
    if not m.get("usa_travessao"):
        linhas.append("- Não use travessão (—); use vírgula, dois-pontos ou frases separadas.")
    if m.get("latinismos"):
        linhas.append(f"- Latinismos admitidos com moderação: {', '.join(m['latinismos'])}.")
    else:
        linhas.append("- Evite latinismos.")
    for k in ("tom", "formalidade", "paragrafos"):
        if ia and ia.get(k):
            linhas.append(f"- {k.capitalize()}: {ia[k]}")
    for r in (ia or {}).get("restricoes_linguagem", [])[:8]:
        linhas.append(f"- {r}")
    return "\n".join(linhas)


def aderencia(texto: str, m: dict) -> dict:
    """Confere métricas da peça gerada contra o perfil (auditável)."""
    g = metricas([texto])
    desvios = []
    if m.get("usa_travessao") is False and g["usa_travessao"]:
        desvios.append("Peça contém travessão, ausente nos modelos do escritório.")
    if m.get("pessoa_verbal") and g["pessoa_verbal"] != m["pessoa_verbal"]:
        desvios.append(f"Pessoa verbal diverge do perfil ({g['pessoa_verbal']} x {m['pessoa_verbal']}).")
    if m.get("palavras_por_paragrafo") and g.get("palavras_por_paragrafo") \
            and g["palavras_por_paragrafo"] > 1.8 * m["palavras_por_paragrafo"]:
        desvios.append("Parágrafos bem mais longos que o padrão do escritório.")
    return {"metricas_peca": g, "desvios": desvios}
