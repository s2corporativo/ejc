"""Pseudonimização reversível com cofre e correferência de nomes.

Arquitetura: no endpoint /api/anonimizar o servidor é sem estado: o cofre (marcador -> valor
real) é devolvido ao cliente e não é persistido. No agente (opção anonimizar_autos), o cofre fica
no banco do próprio servidor (auto-hospedado), nunca trafega pela API nem segue ao provedor de
IA, e é usado só para restaurar os dados na verificação. Só os marcadores chegam à IA.

Limitação declarada: a detecção de nomes é heurística (sem modelo NER treinado). Por isso o
resultado deve ser revisado e o usuário pode acrescentar entradas manuais ao cofre. Também
são sinalizados identificadores indiretos (profissão, estado civil, idade, bairro, datas),
que isoladamente não identificam, mas combinados podem reidentificar o titular
(LGPD, art. 12: dado anonimizado reversível por meios razoáveis volta a ser dado pessoal).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .texto import sem_acento

PADROES: list[tuple[str, str]] = [
    ("CNJ", r"\b\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}\b"),
    ("CNPJ", r"\b\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}\b"),
    ("CPF", r"\b\d{3}\.\d{3}\.\d{3}-\d{2}\b"),
    ("EMAIL", r"\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b"),
    ("OAB", r"\bOAB\s*/?\s*[A-Z]{2}\s*(?:n[º°o]\.?\s*)?\d{1,3}(?:\.\d{3})*(?:-?[A-Z])?\b"),
    ("CEP", r"\b\d{5}-\d{3}\b"),
    ("TELEFONE", r"(?:\+55\s?)?\(?\b\d{2}\)?\s?9?\d{4}-?\d{4}\b"),
    ("CONTA", r"\b(?:ag[êe]ncia|ag\.)\s*\d{3,5}(?:-\d)?\s*,?\s*(?:conta(?:\s+corrente)?|c/c|cc)\s*n?[º°o]?\.?\s*\d{3,12}-?[\dxX]?\b"),
    ("ENDERECO", r"\b(?:Rua|R\.|Avenida|Av\.|Travessa|Tv\.|Alameda|Al\.|Praça|Rodovia|Estrada|Largo)\s+[^\n,;]{2,60},?\s*(?:n[º°o]\.?\s*)?\d{1,6}(?:[^\n;.]{0,50}?(?:apto?\.?|apartamento|casa|bloco|sala)\s*\d+[A-Za-z]?)?"),
]
_RX = [(cat, re.compile(p, re.IGNORECASE if cat in {"EMAIL", "ENDERECO", "CONTA"} else 0)) for cat, p in PADROES]

CONECTORES = {"de", "da", "do", "dos", "das", "e"}
NAO_NOMES = {
    sem_acento(w).lower()
    for w in """Tribunal Justiça Juiz Juíza Juízo Vara Comarca Estado Federal União Ministério Público
    Superior Supremo Código Civil Processo Penal Lei Constituição República Excelentíssimo Senhor Senhora
    Doutor Doutora Autor Autora Réu Ré Requerente Requerido Requerida Reclamante Reclamada Banco Caixa
    Econômica Instituto Nacional Seguro Social Fazenda Pública Municipal Estadual Defensoria Procuradoria
    Contestação Petição Inicial Sentença Acórdão Recurso Apelação Agravo Embargos Turma Câmara Seção
    Brasil Brasileiro Brasileira Minas Gerais São Paulo Rio Janeiro Belo Horizonte Distrito Dos Fatos Direito
    Pedidos Termos Nestes Pede Deferimento Ltda Eireli Ação Cível Trabalho Consumidor Defesa Notificação
    Janeiro Fevereiro Março Abril Maio Junho Julho Agosto Setembro Outubro Novembro Dezembro Súmula Tema
    STJ STF TST TJMG Art Parágrafo Inciso Alínea Item Cláusula Contrato Anexo Documento Doc Fls Folha""".split()
}

INDIRETOS = [
    ("estado_civil", r"\b(solteir[oa]|casad[oa]|divorciad[oa]|vi[uú]v[oa]|separad[oa]|em uni[aã]o est[aá]vel)\b"),
    ("profissao", r"\b(profiss[aã]o|ocupa[cç][aã]o)\s*:?\s*\w+"),
    ("idade", r"\b\d{1,3}\s+anos\s+de\s+idade\b"),
    ("nascimento", r"\bnascid[oa]\s+em\s+\d{1,2}[/.]\d{1,2}[/.]\d{2,4}\b"),
    ("bairro", r"\bbairro\s+[A-ZÀ-Ú][\wÀ-ú]+(?:\s+[A-ZÀ-Ú][\wÀ-ú]+)*"),
    ("parentesco", r"\b(filh[oa]|m[aã]e|pai|irm[aã]o?|c[oô]njuge|esposa|marido|companheir[oa])\s+de\s+[A-ZÀ-Ú]"),
]
_RX_IND = [(c, re.compile(p, re.IGNORECASE)) for c, p in INDIRETOS]

_RX_NOME = re.compile(
    r"\b([A-ZÀ-Ý][a-zà-ÿ]+|[A-ZÀ-Ý]\.|[A-ZÀ-Ý]{2,})"
    r"(?:\s+(?:(?:de|da|do|dos|das|e)\s+)?(?:[A-ZÀ-Ý][a-zà-ÿ]+|[A-ZÀ-Ý]\.|[A-ZÀ-Ý]{2,})){1,6}\b"
)


def _chave(nome: str) -> list[str]:
    return [t for t in sem_acento(nome).lower().replace(".", " ").split() if t not in CONECTORES]


@dataclass
class Cofre:
    entradas: dict[str, str] = field(default_factory=dict)       # marcador -> valor principal
    variantes: dict[str, str] = field(default_factory=dict)      # valor (qualquer forma) -> marcador
    contadores: dict[str, int] = field(default_factory=dict)

    def marcador_para(self, categoria: str, valor: str) -> str:
        if valor in self.variantes:
            return self.variantes[valor]
        if categoria == "NOME":
            existente = self._correferencia(valor)
            if existente:
                self.variantes[valor] = existente
                return existente
        self.contadores[categoria] = self.contadores.get(categoria, 0) + 1
        marcador = f"[{categoria}_{self.contadores[categoria]:04d}]"
        self.entradas[marcador] = valor
        self.variantes[valor] = marcador
        return marcador

    def _correferencia(self, nome: str) -> str | None:
        """Mesma pessoa: tokens da forma curta contidos na forma longa, com 1º nome compatível
        (aceita iniciais). Ex.: 'Maria Silva' e 'M. A. da Silva' -> 'Maria Aparecida da Silva'."""
        curto = _chave(nome)
        if not curto:
            return None
        for marcador, longo_txt in self.entradas.items():
            if not marcador.startswith("[NOME_"):
                continue
            longo = _chave(longo_txt)
            if len(curto) > len(longo):
                continue
            primeiro_ok = curto[0] == longo[0] or (len(curto[0]) == 1 and longo[0].startswith(curto[0]))
            ultimo_ok = curto[-1] == longo[-1]
            restantes_ok = all(
                any(t == l or (len(t) == 1 and l.startswith(t)) for l in longo) for t in curto
            )
            if primeiro_ok and ultimo_ok and restantes_ok and len(curto) >= 2:
                return marcador
        return None

    def adicionar_manual(self, categoria: str, valor: str) -> str:
        return self.marcador_para(categoria.upper(), valor)

    def as_dict(self) -> dict:
        return {"entradas": self.entradas, "variantes": self.variantes, "contadores": self.contadores}

    @classmethod
    def from_dict(cls, d: dict) -> "Cofre":
        return cls(dict(d.get("entradas", {})), dict(d.get("variantes", {})), dict(d.get("contadores", {})))


def _eh_nome(cand: str) -> bool:
    toks = [t for t in re.split(r"\s+", cand) if t]
    reais = [t for t in toks if sem_acento(t).lower() not in CONECTORES]
    if len(reais) < 2:
        return False
    if any(sem_acento(t.strip(".")).lower() in NAO_NOMES for t in reais):
        return False
    # Rejeita siglas puras (ex.: "STJ TJMG")
    if all(t.isupper() and len(t) <= 5 for t in reais):
        return False
    return True


def anonimizar(texto: str, cofre: Cofre | None = None, nomes_adicionais: list[str] | None = None) -> dict:
    cofre = cofre or Cofre()
    achados: list[tuple[int, int, str, str]] = []

    def livre(i: int, j: int) -> bool:
        return all(j <= a or i >= b for a, b, _, _ in achados)

    for cat, rx in _RX:
        for m in rx.finditer(texto):
            if livre(m.start(), m.end()):
                achados.append((m.start(), m.end(), cat, m.group(0).strip()))

    for nome in nomes_adicionais or []:
        for m in re.finditer(re.escape(nome), texto):
            if livre(m.start(), m.end()):
                achados.append((m.start(), m.end(), "NOME", nome))

    candidatos = []
    for m in _RX_NOME.finditer(texto):
        if livre(m.start(), m.end()) and _eh_nome(m.group(0)):
            candidatos.append((m.start(), m.end(), "NOME", m.group(0)))
    # Formas mais longas primeiro, para que a correferência ancore no nome completo
    for c in sorted(candidatos, key=lambda x: -len(_chave(x[3]))):
        cofre.marcador_para("NOME", c[3])
    achados.extend(candidatos)

    achados.sort()
    saida, pos = [], 0
    for ini, fim, cat, valor in achados:
        saida.append(texto[pos:ini])
        saida.append(cofre.marcador_para(cat, valor))
        pos = fim
    saida.append(texto[pos:])
    anonimo = "".join(saida)

    indiretos = []
    for cat, rx in _RX_IND:
        for m in rx.finditer(anonimo):
            indiretos.append({"tipo": cat, "trecho": m.group(0)})
    return {
        "texto": anonimo,
        "cofre": cofre.as_dict(),
        "total_substituicoes": len(achados),
        "identificadores_indiretos": indiretos,
        "alertas": (["Há identificadores indiretos que, combinados, podem permitir reidentificação. Revise antes de enviar."]
                    if len(indiretos) >= 2 else []),
    }


_RX_MARCADOR = re.compile(r"\[[A-Z]+_\d{4}\]")


def desanonimizar(texto: str, cofre: Cofre | dict) -> dict:
    c = cofre if isinstance(cofre, Cofre) else Cofre.from_dict(cofre)
    desconhecidos = sorted({m for m in _RX_MARCADOR.findall(texto) if m not in c.entradas})
    resultado = _RX_MARCADOR.sub(lambda m: c.entradas.get(m.group(0), m.group(0)), texto)
    return {
        "texto": resultado,
        "marcadores_sem_correspondencia": desconhecidos,
        "alertas": (["A minuta contém marcadores inexistentes no cofre: possível alteração indevida pela IA."]
                    if desconhecidos else []),
    }
