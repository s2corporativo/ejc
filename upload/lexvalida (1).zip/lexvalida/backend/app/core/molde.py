"""Modo Molde: o modelo do usuário é EDITADO por operações pontuais, nunca reescrito.

A IA devolve uma lista de operações JSON:
  {"op": "substituir", "localizar": "...", "por": "...", "motivo": "..."}
  {"op": "inserir_apos", "ancora": "...", "texto": "...", "motivo": "..."}
  {"op": "remover", "localizar": "...", "motivo": "..."}
Cada `localizar`/`ancora` deve ocorrer EXATAMENTE uma vez no texto corrente; caso contrário a
operação é rejeitada (sem efeito colateral). O resultado traz diff e percentual preservado.
"""
from __future__ import annotations

import difflib
from dataclasses import dataclass, field


@dataclass
class ResultadoMolde:
    texto: str
    aplicadas: list[dict] = field(default_factory=list)
    rejeitadas: list[dict] = field(default_factory=list)
    diff: list[dict] = field(default_factory=list)
    preservado_pct: float = 100.0

    def as_dict(self) -> dict:
        return {"texto": self.texto, "aplicadas": self.aplicadas, "rejeitadas": self.rejeitadas,
                "diff": self.diff, "preservado_pct": self.preservado_pct}


def aplicar_operacoes(modelo: str, operacoes: list[dict], protegidos: list[str] | None = None) -> ResultadoMolde:
    """`protegidos`: trechos que não podem ser alterados (ex.: escolhas editoriais aprovadas)."""
    texto = modelo
    res = ResultadoMolde(texto=modelo)
    for op in operacoes:
        tipo = op.get("op")
        alvo = op.get("localizar") if tipo in ("substituir", "remover") else op.get("ancora")
        if not alvo:
            res.rejeitadas.append({**op, "erro": "operação sem trecho-alvo"})
            continue
        n = texto.count(alvo)
        if n != 1:
            res.rejeitadas.append({**op, "erro": f"trecho-alvo ocorre {n} vez(es); exige ocorrência única"})
            continue
        if tipo in ("substituir", "remover") and protegidos and any(p in alvo or alvo in p for p in protegidos):
            res.rejeitadas.append({**op, "erro": "trecho protegido pela versão aprovada"})
            continue
        if tipo == "substituir":
            texto = texto.replace(alvo, op.get("por", ""), 1)
        elif tipo == "remover":
            texto = texto.replace(alvo, "", 1)
        elif tipo == "inserir_apos":
            texto = texto.replace(alvo, alvo + op.get("texto", ""), 1)
        else:
            res.rejeitadas.append({**op, "erro": f"operação desconhecida: {tipo}"})
            continue
        res.aplicadas.append(op)
    res.texto = texto
    res.diff = diff_linhas(modelo, texto)
    res.preservado_pct = percentual_preservado(modelo, texto)
    return res


def diff_linhas(a: str, b: str) -> list[dict]:
    saida = []
    for linha in difflib.ndiff(a.splitlines(), b.splitlines()):
        marca, conteudo = linha[:2], linha[2:]
        if marca == "- ":
            saida.append({"tipo": "removido", "texto": conteudo})
        elif marca == "+ ":
            saida.append({"tipo": "adicionado", "texto": conteudo})
        elif marca == "  ":
            saida.append({"tipo": "igual", "texto": conteudo})
    return saida


def percentual_preservado(a: str, b: str) -> float:
    if not a:
        return 0.0
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    iguais = sum(bl.size for bl in sm.get_matching_blocks())
    return round(100 * iguais / len(a), 1)
