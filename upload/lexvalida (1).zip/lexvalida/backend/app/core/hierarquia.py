"""Hierarquia de precedentes (CPC, art. 927) e efeito do status do entendimento."""
from __future__ import annotations

# Peso maior = maior força vinculante. Ordem do art. 927, incisos I a V, seguida dos demais.
TIPOS: dict[str, dict] = {
    "controle_concentrado": {"peso": 1.00, "inciso": "art. 927, I", "rotulo": "Decisão do STF em controle concentrado"},
    "sumula_vinculante": {"peso": 0.98, "inciso": "art. 927, II", "rotulo": "Súmula vinculante"},
    "repercussao_geral": {"peso": 0.95, "inciso": "art. 927, III", "rotulo": "Tema de repercussão geral"},
    "repetitivo": {"peso": 0.95, "inciso": "art. 927, III", "rotulo": "Recurso repetitivo"},
    "irdr_iac": {"peso": 0.92, "inciso": "art. 927, III", "rotulo": "IRDR ou IAC"},
    "sumula": {"peso": 0.85, "inciso": "art. 927, IV", "rotulo": "Súmula (STF ou STJ)"},
    "orgao_especial": {"peso": 0.75, "inciso": "art. 927, V", "rotulo": "Orientação do plenário ou órgão especial"},
    "sumula_tribunal": {"peso": 0.60, "inciso": "persuasivo", "rotulo": "Súmula de tribunal local"},
    "acordao": {"peso": 0.40, "inciso": "persuasivo", "rotulo": "Acórdão"},
    "monocratica": {"peso": 0.20, "inciso": "persuasivo", "rotulo": "Decisão monocrática"},
}

STATUS: dict[str, dict] = {
    "vigente": {"fator": 1.0, "bloqueia": False, "alerta": None},
    "modulado": {"fator": 0.9, "bloqueia": False,
                 "alerta": "Entendimento com modulação de efeitos (CPC, art. 927, § 3º): verificar o marco temporal aplicável ao caso."},
    "afetado": {"fator": 0.8, "bloqueia": False,
                "alerta": "Matéria afetada a julgamento qualificado pendente; verificar ordem de suspensão (CPC, art. 1.037, II)."},
    "revisao": {"fator": 0.7, "bloqueia": False,
                "alerta": "Proposta de revisão de tese em andamento (CPC, art. 927, § 2º)."},
    "superado": {"fator": 0.0, "bloqueia": True,
                 "alerta": "Entendimento SUPERADO (overruling). Só cite para demonstrar a superação."},
    "cancelado": {"fator": 0.0, "bloqueia": True, "alerta": "Súmula ou tese CANCELADA."},
}


def peso_tipo(tipo: str) -> float:
    return TIPOS.get(tipo, {"peso": 0.3})["peso"]


def avaliar_status(status: str) -> dict:
    return STATUS.get(status, {"fator": 0.5, "bloqueia": False, "alerta": f"Status desconhecido: {status}"})
