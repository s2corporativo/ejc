"""Teste de compatibilidade antes de herdar o molde no lote em etapas.

A minuta-modelo foi pesquisada e revisada para UM processo. Herdar o molde (e sua pesquisa) só é
seguro quando o novo processo tem a mesma matéria, competência e fundamento. Divergência suspende a
herança automática: o item fica "incompativel" e só é gerado pelo molde se o advogado forçar,
decisão registrada na auditoria. Caso contrário, deve seguir o fluxo individual com nova pesquisa.
"""
from __future__ import annotations

import math
import re
from collections import Counter

from .texto import normalizar

PARADAS = set("""a o e de da do das dos em no na nos nas um uma uns umas que para por com sem ao aos as os se
seu sua seus suas ou como mais pelo pela pelos pelas este esta isso esse essa nao sim foi ser sao ter tem
autor autora reu re requerente requerido requerida processo autos fls pagina pag num doc documento""".split())


def _tf(texto: str) -> Counter:
    return Counter(t for t in re.findall(r"[a-z0-9]{4,}", normalizar(texto or "")) if t not in PARADAS)


def similaridade(a: str, b: str) -> float:
    ta, tb = _tf(a), _tf(b)
    if not ta or not tb:
        return 0.0
    comum = set(ta) & set(tb)
    num = sum(ta[t] * tb[t] for t in comum)
    den = math.sqrt(sum(v * v for v in ta.values())) * math.sqrt(sum(v * v for v in tb.values()))
    return round(num / den, 3) if den else 0.0


def _codigos(assuntos) -> set:
    out = set()
    for a in assuntos or []:
        if isinstance(a, dict) and a.get("codigo") is not None:
            out.add(int(a["codigo"]))
        elif isinstance(a, (int, str)) and str(a).isdigit():
            out.add(int(a))
    return out


def avaliar(modelo: dict, alvo: dict, similaridade_min: float = 0.15) -> dict:
    """modelo/alvo: {area, tribunal, orgao_julgador, classe_tpu, assuntos_tpu, polo, autos}."""
    motivos, alertas = [], []

    def dif(campo, rotulo, bloqueia=True, norm=lambda v: normalizar(str(v)) if v else None):
        a, b = norm(modelo.get(campo)), norm(alvo.get(campo))
        if a and b and a != b:
            (motivos if bloqueia else alertas).append(f"{rotulo} diferente do processo-modelo ({modelo.get(campo)} x {alvo.get(campo)}).")

    dif("area", "Matéria (área)")
    dif("polo", "Polo representado")
    dif("tribunal", "Tribunal (competência e regras locais)")
    dif("classe_tpu", "Classe processual (rito)", norm=lambda v: (v or {}).get("codigo") if isinstance(v, dict) else v)
    dif("orgao_julgador", "Órgão julgador", bloqueia=False)
    am, aa = _codigos(modelo.get("assuntos_tpu")), _codigos(alvo.get("assuntos_tpu"))
    if am and aa and not (am & aa):
        motivos.append(f"Assuntos TPU sem interseção ({sorted(am)} x {sorted(aa)}): fundamento provavelmente diverso.")
    sim = None
    if not (alvo.get("autos") or "").strip():
        motivos.append("Processo sem autos legíveis: não há como adaptar o molde aos fatos.")
    elif (modelo.get("autos") or "").strip():
        sim = similaridade(modelo["autos"], alvo["autos"])
        if sim < similaridade_min:
            motivos.append(f"Fatos dos autos pouco semelhantes ao processo-modelo (similaridade {sim} < {similaridade_min}).")
        elif sim < similaridade_min * 2:
            alertas.append(f"Similaridade moderada dos autos ({sim}): revise fatos e fundamentos herdados.")
    return {"compativel": not motivos, "motivos": motivos, "alertas": alertas, "similaridade": sim}
