"""Extração determinística de entidades jurídicas de texto livre (mensagens e documentos).

Número CNJ, OAB, datas (numéricas, por extenso e relativas), quantidade de dias de prazo, valores em
reais, dispositivos legais (art. N da lei X → id de norma da base), súmulas, tribunais, tipo de peça e
área do direito (tabela de áreas portada do classificador de intenção do EJC).
"""
from __future__ import annotations

import re
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation

from .texto import normalizar

RX_CNJ = re.compile(r"\b(\d{7})-?(\d{2})\.?(\d{4})\.?(\d)\.?(\d{2})\.?(\d{4})\b")
RX_OAB = re.compile(r"\b(?:oab\s*/?\s*)?(\d{3,6})\s*/\s*([A-Z]{2})\b", re.IGNORECASE)
MESES = ["janeiro", "fevereiro", "marco", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]
RX_DATA_NUM = re.compile(r"\b(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})\b")
RX_DATA_EXT = re.compile(r"\b(\d{1,2})(?:o|º)?\s+de\s+(" + "|".join(MESES) + r")(?:\s+de\s+(\d{4}))?\b")
RX_ISO = re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b")
NUM_EXTENSO = {"um": 1, "dois": 2, "tres": 3, "cinco": 5, "dez": 10, "quinze": 15, "vinte": 20, "trinta": 30,
               "quarenta e oito": 48, "sessenta": 60, "noventa": 90}
RX_DIAS = re.compile(r"\b(\d{1,3}|" + "|".join(sorted(NUM_EXTENSO, key=len, reverse=True)) +
                     r")\s*(?:\((?:[a-z\s]+)\)\s*)?dias?(\s+(?:uteis|corridos))?")
RX_VALOR = re.compile(r"r\$\s*([\d.]+(?:,\d{2})?)")
SIGLAS_LEI = {"cpc": "cpc", "cc": "cc", "codigo civil": "cc", "cdc": "cdc", "clt": "clt", "cf": "cf", "constituicao": "cf",
              "cp": "cp", "codigo penal": "cp", "cpp": "cpp", "ctn": "ctn", "eca": "eca", "lindb": "lindb", "lgpd": "lgpd",
              "eoab": "eoab", "estatuto da advocacia": "eoab", "ctb": "ctb", "lef": "l6830", "lei 6.830": "l6830",
              "lei 9.099": "l9099", "lei 11.419": "l11419", "lei 14.133": "l14133", "lei 8.245": "l8245",
              "lei 12.016": "l12016", "lei 8.429": "l8429", "lei 9.784": "l9784", "lei 11.101": "l11101",
              "lei 8.213": "l8213", "lei 11.340": "l11340", "lei 11.343": "l11343", "lei 6.938": "pnma",
              "lei 9.605": "lca", "decreto 6.514": "d6514"}
_RX_SIGLA = "|".join(re.escape(k) for k in sorted(SIGLAS_LEI, key=len, reverse=True))
RX_DISPOSITIVO = re.compile(
    r"\bart(?:igo)?s?\.?\s*(\d{1,4}(?:\.\d{3})?)\s*(?:o|º)?(?:\s*-\s*([a-z]))?"
    r"(?:[^.;\n]{0,40}?)\b(?:d[oa]s?\s+|,\s*)?(" + _RX_SIGLA + r")\b")
RX_SUMULA = re.compile(r"\bsumula\s*(vinculante\s*)?(?:n[ºo.]*\s*)?(\d{1,4})\s*(?:d[oa]\s+)?(stf|stj|tst)?")
RX_TRIBUNAL = re.compile(r"\b(tj[a-z]{2}|trt\s?\d{1,2}|trf\s?\d|stj|stf|tst|tse)\b")
UF = "ac al am ap ba ce df es go ma mg ms mt pa pb pe pi pr rj rn ro rr rs sc se sp to".split()

TIPOS_PECA = [
    (r"peti[cç][aã]o inicial|\binicial\b|ajuizar|propor (?:uma )?a[cç][aã]o|ingressar com a[cç][aã]o", "Petição inicial"),
    (r"contesta[cç][aã]o|contestar|defesa do r[eé]u", "Contestação"),
    (r"r[eé]plica|impugna[cç][aã]o [aà] contesta[cç][aã]o", "Réplica"),
    (r"contrarraz[oõ]es", "Contrarrazões"),
    (r"apela[cç][aã]o|apelar", "Apelação"),
    (r"agravo de instrumento", "Agravo de instrumento"),
    (r"agravo interno", "Agravo interno"),
    (r"embargos de declara[cç][aã]o|embargos declarat[oó]rios", "Embargos de declaração"),
    (r"recurso inominado", "Recurso inominado"),
    (r"recurso especial", "Recurso especial"),
    (r"recurso extraordin[aá]rio", "Recurso extraordinário"),
    (r"recurso ordin[aá]rio", "Recurso ordinário"),
    (r"mandado de seguran[cç]a", "Mandado de segurança"),
    (r"tutela (?:de urg[eê]ncia|antecipada|cautelar)|liminar", "Pedido de tutela de urgência"),
    (r"impugna[cç][aã]o (?:ao |do )?edital|impugnar (?:o )?edital", "Impugnação ao edital"),
    (r"recurso administrativo", "Recurso administrativo"),
    (r"defesa (?:do |ao )?auto de infra[cç][aã]o|defesa administrativa", "Defesa administrativa"),
    (r"notifica[cç][aã]o extrajudicial", "Notificação extrajudicial"),
    (r"cumprimento de senten[cç]a", "Cumprimento de sentença"),
    (r"execu[cç][aã]o de t[ií]tulo", "Execução de título extrajudicial"),
    (r"manifesta[cç][aã]o|peti[cç][aã]o simples|peti[cç][aã]o intermedi[aá]ria", "Manifestação"),
    (r"parecer", "Parecer"),
]

# Áreas: tabela portada do classificador determinístico do EJC (ordem: mais específico primeiro).
AREAS = [
    (("execucao fiscal", "divida ativa", "icms", "tributar", "imposto", "iptu", "iss "), "tributario"),
    (("recuperacao judicial", "falencia", "societar", "dissolucao de sociedade", "credito rural", "cedula de produto rural", "agronegocio"), "empresarial"),
    (("reclamatoria", "reclamacao trabalhista", "verbas rescisorias", "horas extras", "vinculo empregaticio", "aviso previo", "fgts", "trabalhist", "clt"), "trabalhista"),
    (("clausula penal",), "civil"),
    (("criminal", "penal", "inquerito", "dosimetria", "flagrante", "habeas corpus", "prisao preventiva", "anpp", "denuncia criminal"), "penal"),
    (("licitac", "edital", "pregao", "14.133", "contrato administrativo"), "licitacoes"),
    (("auto de infracao ambiental", "ibama", "tcfa", "ambiental", "licenciamento", "app ", "reserva legal"), "ambiental"),
    (("improbidade", "processo administrativo", "auto de infracao", "servidor publico", "administrativo"), "administrativo"),
    (("juizado especial", "juizados especiais", "recurso inominado", "lei 9.099", "jec"), "juizados"),
    (("cdc", "consumidor", "relacao de consumo", "vicio do produto", "negativacao", "cadastro de inadimplentes",
      "plano de saude", "negativa de cobertura", "banco", "tarifa"), "consumidor"),
    (("responsabilidade civil", "dano moral", "danos morais", "dano material", "cobranca", "contrato", "inadimplemento",
      "locacao", "despejo", "usucapiao", "posse", "alimentos", "divorcio", "inventario"), "civil"),
    (("previdenciar", "inss", "aposentadoria", "beneficio"), "previdenciario"),
]


def _ano(a: str) -> int:
    y = int(a)
    return y + 2000 if y < 100 else y


def datas(texto: str, hoje: date | None = None) -> list[str]:
    t, hoje, out = normalizar(texto), hoje or date.today(), []
    for m in RX_ISO.finditer(t):
        try:
            out.append(date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat())
        except ValueError:
            pass
    for m in RX_DATA_NUM.finditer(t):
        try:
            out.append(date(_ano(m.group(3)), int(m.group(2)), int(m.group(1))).isoformat())
        except ValueError:
            pass
    for m in RX_DATA_EXT.finditer(t):
        try:
            out.append(date(int(m.group(3)) if m.group(3) else hoje.year, MESES.index(m.group(2)) + 1, int(m.group(1))).isoformat())
        except ValueError:
            pass
    for palavra, delta in (("anteontem", -2), ("ontem", -1), ("hoje", 0), ("amanha", 1)):
        if re.search(rf"\b{palavra}\b", t):
            out.append((hoje + timedelta(days=delta)).isoformat())
    vistos = []
    for d in out:
        if d not in vistos:
            vistos.append(d)
    return vistos


def cnj(texto: str) -> list[str]:
    out = []
    for m in RX_CNJ.finditer(texto or ""):
        n = f"{m.group(1)}-{m.group(2)}.{m.group(3)}.{m.group(4)}.{m.group(5)}.{m.group(6)}"
        if n not in out:
            out.append(n)
    return out


def extrair(texto: str, hoje: date | None = None) -> dict:
    t = normalizar(texto or "")
    dias = []
    for m in RX_DIAS.finditer(t):
        n = int(m.group(1)) if m.group(1).isdigit() else NUM_EXTENSO[m.group(1)]
        dias.append({"dias": n, "contagem": (m.group(2) or "").strip() or None})
    valores = []
    for m in RX_VALOR.finditer(t):
        try:
            valores.append(str(Decimal(m.group(1).replace(".", "").replace(",", "."))))
        except InvalidOperation:
            pass
    dispositivos = []
    for m in RX_DISPOSITIVO.finditer(t):
        num, suf, lei = m.group(1).replace(".", ""), m.group(2), SIGLAS_LEI[m.group(3)]
        nid = f"{lei}-art-{num}" + (f"-{suf}" if suf else "")
        if nid not in dispositivos:
            dispositivos.append(nid)
    sumulas = [{"numero": m.group(2), "tribunal": (m.group(3) or "").upper() or None, "vinculante": bool(m.group(1))}
               for m in RX_SUMULA.finditer(t)]
    tribunais = sorted({m.group(1).replace(" ", "").upper() for m in RX_TRIBUNAL.finditer(t)
                        if not m.group(1).startswith("tj") or m.group(1)[2:] in UF})
    tipo = next((nome for rx, nome in TIPOS_PECA if re.search(rx, t)), None)
    area = next((a for termos, a in AREAS if any(x in t for x in termos)), None)
    oabs = [f"{m.group(1)}/{m.group(2).upper()}" for m in RX_OAB.finditer(texto or "")
            if m.group(2).lower() in UF and re.search(r"oab", (texto or "")[max(0, m.start() - 12):m.end()], re.I)]
    return {"cnj": cnj(texto), "oabs": oabs, "datas": datas(texto, hoje), "dias": dias, "valores": valores,
            "dispositivos": dispositivos, "sumulas": sumulas, "tribunais": tribunais, "tipo_peca": tipo, "area": area}
