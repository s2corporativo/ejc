"""Análise da instrução do advogado ANTES da geração: contradições, omissões e excesso.

Determinística (sem IA): aponta o que pode levar a uma peça errada e sugere perguntas. Não bloqueia;
o advogado decide se ajusta a instrução.
"""
from __future__ import annotations

import re

from .julgador import tipo_canonico
from .texto import normalizar

LIMITE_CHARS = 6000

PARES_CONTRADITORIOS = [
    (r"\b(conciso|concisa|breve|sucint\w*|curt[oa])\b", r"\b(detalhad\w*|exaustiv\w*|aprofundad\w*|extens[oa])\b",
     "Pede peça breve e, ao mesmo tempo, detalhada ou exaustiva."),
    (r"\b(com|incluir|requerer|pedir)\s+(pedido\s+de\s+)?(tutela|liminar)", r"\b(sem|nao\s+(incluir|requerer|pedir))\s+(pedido\s+de\s+)?(tutela|liminar)",
     "Instrução inclui e exclui o pedido de tutela ou liminar."),
    (r"\b(com|incluir|pedir|requerer)\s+danos?\s+mora", r"\b(sem|nao\s+(incluir|pedir|requerer))\s+danos?\s+mora",
     "Instrução inclui e exclui danos morais."),
    (r"\brepresent\w*\s+(o|a)\s+(autor|autora|requerente|reclamante|exequente)", r"\brepresent\w*\s+(o|a)\s+(reu|re|requerid[oa]|reclamad[oa]|executad[oa])",
     "Indica representação dos dois polos."),
    (r"\bjustica\s+gratuita\b", r"\b(recolh\w*|pag\w*)\s+(as\s+)?custas\b",
     "Menciona justiça gratuita e recolhimento de custas: confirme a situação (CPC, arts. 98 e 99)."),
]

CONFLITO_REGRAS = [
    (r"\b(invente|crie|fabrique)\b.{0,40}\b(jurisprud|precedente|sumula|julgado|ementa|lei)", "Pede criação de fonte jurídica: o sistema só cita fontes da base."),
    (r"\bnao\s+(precisa|e\s+necessario)\s+(verificar|conferir|checar)", "Dispensa verificação: a verificação é obrigatória no sistema."),
    (r"\b(garant\w*|assegur\w*)\s+(o\s+)?(exito|resultado|vitoria|ganho)", "Promessa de resultado é incompatível com a ética profissional (Código de Ética e Disciplina da OAB): reformule."),
]

OMISSOES = {
    "peticao_inicial": [
        (r"\b(valor\s+da\s+causa|r\$)", "Valor da causa não indicado (CPC, art. 319, V; art. 292).", "Qual o valor da causa ou os valores de cada pedido?"),
        (r"\b(requer|pedido|pedidos|condena\w*|declar\w*|indeniz\w*|restitu\w*|obriga\w*)", "Pedidos não explicitados (CPC, art. 319, IV; art. 322).", "Quais são os pedidos, com especificação?"),
        (r"\b(audiencia|conciliacao|mediacao)", "Opção pela audiência de conciliação ou mediação não informada (CPC, art. 319, VII).", "O cliente tem interesse na audiência de conciliação?"),
    ],
    "contestacao": [
        (r"\b(cita\w*|juntada|prazo|audiencia)", "Data da citação, da audiência ou da juntada não informada: tempestividade não aferível (CPC, art. 335).", "Qual o termo inicial do prazo de contestação?"),
        (r"\b(prelimin\w*|merito)", "Não indica se há preliminares (CPC, art. 337) ou só mérito.", "Há preliminares a arguir?"),
    ],
    "recurso": [
        (r"\b(intima\w*|publica\w*|ciencia|disponibiliz\w*)", "Data da intimação da decisão não informada: termo inicial do prazo recursal (CPC, art. 1.003, caput e § 5º).", "Quando a parte foi intimada da decisão recorrida?"),
        (r"\b(preparo|gratuidade|justica\s+gratuita|custas)", "Preparo ou gratuidade não informados (CPC, art. 1.007).", "O preparo foi recolhido ou a parte é beneficiária da gratuidade?"),
        (r"\b(sentenca|decisao|acordao|interlocut\w*)", "Decisão recorrida não identificada.", "Qual a decisão recorrida e o ponto impugnado?"),
    ],
    "tutela_urgencia": [
        (r"\b(perigo|risco|urgen\w*|dano\s+irrepar\w*|periculum)", "Perigo de dano ou risco ao resultado útil não descrito (CPC, art. 300).", "Qual o risco concreto de aguardar a decisão final?"),
    ],
}


def analisar(tipo_peca: str, pedido: str, tem_caso: bool = False, data_fatos_informada: bool = False,
             docs_bloqueados: int = 0) -> dict:
    t = normalizar(pedido or "")
    canon = tipo_canonico(tipo_peca)
    contradicoes = [msg for a, b, msg in PARES_CONTRADITORIOS if re.search(a, t) and re.search(b, t)]
    conflitos = [msg for rx, msg in CONFLITO_REGRAS if re.search(rx, t)]
    omissoes, perguntas = [], []
    for rx, msg, perg in OMISSOES.get(canon, []):
        if not re.search(rx, t):
            omissoes.append(msg)
            perguntas.append(perg)
    if not tem_caso:
        omissoes.append("Sem caso vinculado: a peça não terá referências aos autos verificáveis.")
    elif not data_fatos_informada:
        omissoes.append("Data dos fatos não informada no caso: vigência da norma (LINDB, art. 6º) e prescrição não serão aferidas.")
        perguntas.append("Qual a data dos fatos?")
    if docs_bloqueados:
        omissoes.append(f"{docs_bloqueados} documento(s) aguardam decisão de segurança e não serão lidos.")
    excesso = []
    if len(pedido or "") > LIMITE_CHARS:
        excesso.append(f"Instrução com {len(pedido)} caracteres: considere mover fatos para documentos do caso e manter só a estratégia.")
    frases = [f.strip() for f in re.split(r"[.;\n]+", t) if len(f.strip()) > 25]
    repetidas = sorted({f for f in frases if frases.count(f) > 1})
    if repetidas:
        excesso.append(f"{len(repetidas)} frase(s) repetida(s) na instrução.")
    return {"tipo_canonico": canon, "contradicoes": contradicoes, "conflitos_com_regras": conflitos,
            "omissoes": omissoes, "excesso": excesso, "perguntas_sugeridas": perguntas,
            "ok": not (contradicoes or conflitos or omissoes or excesso)}
