"""Habilidades (skills) em SKILL.md: conhecimento jurídico em texto legível e auditável.

Formato:
---
slug: prescricao-civil
titulo: Prescrição civil
tipo: materia            # forma | materia
area: civil
descricao: Uma linha que o seletor lê para decidir se carrega a íntegra.
gatilhos: [prescricao, prazo prescricional, art. 206]
revisado_em: 2026-10-01
---
(corpo em Markdown: lei seca, súmulas/teses com número e data, vigência, erros a evitar)

Seleção em dois estágios (carregamento progressivo): 1) só título, descrição e gatilhos são
pontuados contra o caso; 2) apenas as selecionadas têm a íntegra injetada no contexto.
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field
from pathlib import Path

from .busca import BM25
from .texto import normalizar


@dataclass
class SkillDoc:
    slug: str
    titulo: str
    tipo: str
    area: str
    descricao: str
    gatilhos: list[str]
    conteudo: str
    revisado_em: str | None = None
    meta: dict = field(default_factory=dict)


def _valor(v: str):
    v = v.strip()
    if v.startswith("[") and v.endswith("]"):
        return [x.strip().strip("'\"") for x in v[1:-1].split(",") if x.strip()]
    return v.strip("'\"")


def parse_skill_md(texto: str) -> SkillDoc:
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n?(.*)$", texto, re.S)
    if not m:
        raise ValueError("SKILL.md sem frontmatter delimitado por ---")
    meta: dict = {}
    chave_lista = None
    for linha in m.group(1).splitlines():
        if not linha.strip() or linha.strip().startswith("#"):
            continue
        if linha.lstrip().startswith("- ") and chave_lista:
            meta[chave_lista].append(linha.strip()[2:].strip().strip("'\""))
            continue
        if ":" in linha:
            k, v = linha.split(":", 1)
            v = v.split(" #")[0]
            k = k.strip()
            if v.strip() == "":
                meta[k], chave_lista = [], k
            else:
                meta[k], chave_lista = _valor(v), None
    for obrig in ("slug", "titulo", "tipo", "descricao"):
        if not meta.get(obrig):
            raise ValueError(f"SKILL.md sem campo obrigatório: {obrig}")
    if meta["tipo"] not in ("forma", "materia"):
        raise ValueError("tipo deve ser 'forma' ou 'materia'")
    gat = meta.get("gatilhos", [])
    return SkillDoc(meta["slug"], meta["titulo"], meta["tipo"], meta.get("area", ""), meta["descricao"],
                    gat if isinstance(gat, list) else [gat], m.group(2).strip(), meta.get("revisado_em"), meta)


def serializar(s: SkillDoc) -> str:
    return (f"---\nslug: {s.slug}\ntitulo: {s.titulo}\ntipo: {s.tipo}\narea: {s.area}\n"
            f"descricao: {s.descricao}\ngatilhos: [{', '.join(s.gatilhos)}]\n"
            f"revisado_em: {s.revisado_em or ''}\n---\n{s.conteudo}\n")


def carregar_diretorio(caminho: str | Path) -> list[SkillDoc]:
    p = Path(caminho)
    if not p.exists():
        return []
    return [parse_skill_md(f.read_text(encoding="utf-8")) for f in sorted(p.rglob("*.md"))]


def selecionar(skills: list[dict], contexto: str, tipo_peca: str = "", max_materia: int = 4,
               fixadas: list[str] | None = None) -> list[dict]:
    """`skills`: dicts com slug, titulo, tipo, descricao, gatilhos. Devolve selecionadas com
    confiança e motivo. Fixadas entram sempre, marcadas como obrigatórias."""
    fixadas = fixadas or []
    ctx = normalizar(contexto + " " + tipo_peca)
    bm = BM25()
    for i, s in enumerate(skills):
        bm.adicionar(i, f"{s['titulo']} {s['descricao']} {' '.join(s.get('gatilhos', []))}")
    lex = dict(bm.buscar(contexto + " " + tipo_peca, limite=len(skills)))
    maximo = max(lex.values(), default=1) or 1
    pontuadas = []
    for i, s in enumerate(skills):
        hits = [g for g in s.get("gatilhos", []) if g and normalizar(g) in ctx]
        conf = min(1.0, 0.25 * len(hits) + 0.5 * lex.get(i, 0) / maximo)
        if s["tipo"] == "forma" and tipo_peca and normalizar(tipo_peca) in normalizar(s["titulo"] + " " + " ".join(s.get("gatilhos", []))):
            conf = max(conf, 0.9)
        pontuadas.append({**s, "confianca": round(conf, 2), "gatilhos_acionados": hits,
                          "obrigatoria": s["slug"] in fixadas})
    formas = sorted([s for s in pontuadas if s["tipo"] == "forma"], key=lambda x: -x["confianca"])
    materias = sorted([s for s in pontuadas if s["tipo"] == "materia"], key=lambda x: -x["confianca"])
    escolhidas = [s for s in pontuadas if s["obrigatoria"]]
    if formas and formas[0]["confianca"] >= 0.5 and formas[0] not in escolhidas:
        escolhidas.append(formas[0])
    for s in materias:
        if len([e for e in escolhidas if e["tipo"] == "materia"]) >= max_materia:
            break
        if s["confianca"] >= 0.35 and s not in escolhidas:
            escolhidas.append(s)
    return escolhidas


def bloco_contexto(selecionadas: list[dict], conteudos: dict[str, str]) -> str:
    obrig = [s for s in selecionadas if s["obrigatoria"]]
    auto = [s for s in selecionadas if not s["obrigatoria"]]
    partes = []
    if obrig:
        partes.append("## Habilidades obrigatórias (fixadas pelo usuário)\nAplique estritamente.\n")
        partes += [f"### {s['titulo']}\n{conteudos[s['slug']]}\n" for s in obrig]
    if auto:
        partes.append("## Habilidades selecionadas para este caso\nUse como orientação; prevalece o caso concreto.\n")
        partes += [f"### {s['titulo']}\n{conteudos[s['slug']]}\n" for s in auto]
    return "\n".join(partes)


def mesclar_tres_vias(base: str, minha: str, nova_oficial: str) -> dict:
    """Mescla linha a linha: mudanças só da oficial são aceitas; só minhas, preservadas;
    alterações conflitantes no mesmo trecho viram conflito para decisão humana."""
    b, m, o = base.splitlines(), minha.splitlines(), nova_oficial.splitlines()

    def blocos(a, x):
        return [op for op in difflib.SequenceMatcher(None, a, x, autojunk=False).get_opcodes() if op[0] != "equal"]

    mudancas_m, mudancas_o = blocos(b, m), blocos(b, o)

    def sobrepoe(i1, i2, j1, j2):
        return not (i2 <= j1 or j2 <= i1) or (i1 == i2 == j1 == j2)

    conflitos = []
    for om in mudancas_m:
        for oo in mudancas_o:
            if sobrepoe(om[1], om[2], oo[1], oo[2]) and m[om[3]:om[4]] != o[oo[3]:oo[4]]:
                conflitos.append({"base": b[om[1]:om[2]], "minha": m[om[3]:om[4]], "oficial": o[oo[3]:oo[4]]})
    edits = [(om[1], om[2], m[om[3]:om[4]], "minha") for om in mudancas_m]
    for oo in mudancas_o:
        if not any(sobrepoe(oo[1], oo[2], e[0], e[1]) for e in edits):
            edits.append((oo[1], oo[2], o[oo[3]:oo[4]], "oficial"))
    resultado, pos = [], 0
    for i1, i2, linhas, _ in sorted(edits, key=lambda e: (e[0], e[1])):
        resultado += b[pos:i1] + linhas
        pos = max(pos, i2)
    resultado += b[pos:]
    return {"texto": "\n".join(resultado), "conflitos": conflitos, "automatica": not conflitos}
