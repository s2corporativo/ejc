"""Valor da causa (CPC, art. 292). Aritmética decimal com memória por pedido.

Tipos de pedido:
  cobranca           I    principal corrigido + juros de mora vencidos + penalidades até a propositura
  ato_juridico       II   valor do ato ou de sua parte controvertida
  alimentos          III  soma de 12 prestações mensais pedidas
  bem                IV   valor de avaliação da área ou do bem
  indenizacao        V    valor pretendido, inclusive dano moral
  prestacoes         §§ 1º e 2º: vencidas + vincendas (1 ano se tempo indeterminado ou superior a 1 ano;
                     soma das prestações se inferior)
Cumulação (VI): soma. Alternativos (VII): maior valor. Subsidiários (VIII): valor do pedido principal.
"""
from __future__ import annotations

from decimal import Decimal

from .calculos import CENT, _d, _q

BASES = {"cobranca": "CPC, art. 292, I", "ato_juridico": "CPC, art. 292, II", "alimentos": "CPC, art. 292, III",
         "bem": "CPC, art. 292, IV", "indenizacao": "CPC, art. 292, V", "prestacoes": "CPC, art. 292, §§ 1º e 2º"}


def valor_pedido(p: dict) -> tuple[Decimal, str]:
    t = p.get("tipo")
    if t not in BASES:
        raise ValueError(f"Tipo de pedido inválido: {t}. Use {sorted(BASES)}")
    if t == "cobranca":
        partes = [_d(p.get(k, 0)) for k in ("principal_corrigido", "juros_vencidos", "penalidades")]
        v = sum(partes, Decimal(0))
        desc = f"principal corrigido R$ {_q(partes[0])} + juros vencidos R$ {_q(partes[1])} + penalidades R$ {_q(partes[2])}"
    elif t == "alimentos":
        mensal = _d(p["prestacao_mensal"])
        v, desc = mensal * 12, f"12 x R$ {_q(mensal)}"
    elif t == "prestacoes":
        mensal, vencidas = _d(p["prestacao_mensal"]), int(p.get("vencidas", 0))
        meses = int(p.get("meses_restantes") or 0)
        indeterminado = bool(p.get("tempo_indeterminado")) or meses > 12 or not meses
        vincendas = 12 if indeterminado else meses
        v = mensal * (vencidas + vincendas)
        desc = (f"{vencidas} vencidas + {vincendas} vincendas ({'1 ano: tempo indeterminado ou superior a 1 ano' if indeterminado else 'soma das prestações restantes'})"
                f" x R$ {_q(mensal)}")
    else:
        v, desc = _d(p["valor"]), "valor informado"
    return _q(v), f"{p.get('descricao') or t}: {desc} = R$ {_q(v)} ({BASES[t]})"


def calcular(pedidos: list[dict], relacao: str = "cumulados") -> dict:
    if not pedidos:
        raise ValueError("Informe ao menos um pedido.")
    valores, memoria = [], []
    for p in pedidos:
        v, linha = valor_pedido(p)
        valores.append(v)
        memoria.append(linha)
    if relacao == "alternativos":
        total, regra = max(valores), "Pedidos alternativos: maior valor (CPC, art. 292, VII)."
    elif relacao == "subsidiarios":
        total, regra = valores[0], "Pedidos subsidiários: valor do pedido principal (CPC, art. 292, VIII)."
    else:
        total, regra = sum(valores, Decimal(0)), "Pedidos cumulados: soma (CPC, art. 292, VI)."
    memoria.append(regra)
    memoria.append(f"Valor da causa: R$ {_q(total)}.")
    return {"valor_da_causa": str(_q(total)), "memoria": memoria,
            "alertas": ["O juiz corrige de ofício o valor em desacordo com o art. 292 (CPC, art. 292, § 3º)."]}
