"""Aderência da tese: o precedente sustenta a afirmação feita na peça?

A verificação principal é feita por um modelo verificador DISTINTO do redator. Esta heurística
lexical serve de fallback e de sinal de alerta (sobreposição baixa = revisar), nunca de prova
de aderência. Detecção de polaridade simples captura negações opostas ("não cabe" x "cabe").
"""
from __future__ import annotations

import re

from .texto import normalizar, tokenizar

NEGACOES = re.compile(r"\b(nao|inexiste|incabivel|improcede|afasta|descabe|vedad)\w*")


def extrair_afirmacoes(texto: str, rx_marcador: re.Pattern) -> list[dict]:
    """Para cada marcador de precedente, devolve a frase que o contém (a afirmação sustentada)."""
    frases = re.split(r"(?<=[.;:!?])\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ\[\{])", texto)
    saida, vistos = [], set()
    for i, f in enumerate(frases):
        for m in rx_marcador.finditer(f):
            limpa = rx_marcador.sub("", f).strip(" .;")
            if len(limpa) < 20 and i > 0:  # marcador isolado após o ponto: a afirmação é a frase anterior
                limpa = (rx_marcador.sub("", frases[i - 1]).strip(" .;") + " " + limpa).strip()
            chave = (m.group(1).lower(), limpa)
            if chave not in vistos:
                vistos.add(chave)
                saida.append({"id": m.group(1).lower(), "afirmacao": limpa})
    return saida


def heuristica(afirmacao: str, tese: str) -> dict:
    a, t = set(tokenizar(afirmacao)), set(tokenizar(tese))
    if not a or not t:
        return {"classificacao": "indeterminado", "sobreposicao": 0.0, "justificativa": "Texto insuficiente."}
    sob = len(a & t) / len(a | t)
    neg_a, neg_t = bool(NEGACOES.search(normalizar(afirmacao))), bool(NEGACOES.search(normalizar(tese)))
    if sob >= 0.12 and neg_a != neg_t:
        cls, just = "possivel_contradicao", "Termos comuns com polaridade oposta (negação em apenas um dos textos)."
    elif sob >= 0.18:
        cls, just = "provavel_apoio", "Sobreposição relevante de termos entre afirmação e tese."
    elif sob >= 0.08:
        cls, just = "apoio_incerto", "Sobreposição parcial; conferir se o precedente trata do mesmo ponto."
    else:
        cls, just = "possivel_irrelevancia", "Pouca relação textual entre afirmação e tese."
    return {"classificacao": cls, "sobreposicao": round(sob, 3), "justificativa": just + " (heurística, indicativa)"}
