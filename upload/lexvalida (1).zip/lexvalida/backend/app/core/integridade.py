"""Integridade e rastreabilidade de evidências.

- SHA-256 do arquivo original (documento dos autos) e do texto de fontes (ementa, redação de norma).
- Distinção entre a PÁGINA FÍSICA do PDF e a NUMERAÇÃO DOS AUTOS (folha, ID processual), que em
  PDFs compostos (download integral do PJe, eproc, e-SAJ) não coincidem.

Carimbos reconhecidos (aparecem no rodapé ou na margem gerados pelos sistemas):
  PJe:    "Num. 123456789 - Pág. 2"
  eproc:  "Evento 12, ANEXO3, Página 2"
  e-SAJ e autos físicos digitalizados: "fls. 123" / "fl. 123"
Sem carimbo, a folha pode ser derivada de uma folha inicial informada pelo usuário.
"""
from __future__ import annotations

import hashlib
import re

RX_PJE = re.compile(r"Num\.\s*(\d{5,})\s*-\s*P[áa]g\.\s*(\d{1,4})", re.IGNORECASE)
RX_EPROC = re.compile(r"Evento\s+(\d{1,4}),\s*([A-Z][A-Z0-9_]*),\s*P[áa]gina\s+(\d{1,4})", re.IGNORECASE)
RX_FOLHA = re.compile(r"\bfls?\.\s*(\d{1,6})\b", re.IGNORECASE)


def sha256_bytes(dados: bytes) -> str:
    return hashlib.sha256(dados).hexdigest()


def sha256_texto(texto: str | None) -> str:
    """Hash do texto com espaços normalizados (quebras de linha não alteram o conteúdo jurídico)."""
    return hashlib.sha256(" ".join((texto or "").split()).encode("utf-8")).hexdigest()


def rotulo_pagina(texto: str, pagina: int, folha_inicial: int | None = None) -> dict:
    """Identifica a numeração processual de uma página física. Procura primeiro nas margens
    (primeiros e últimos 400 caracteres), onde os sistemas carimbam."""
    margem = (texto[:400] + "\n" + texto[-400:]) if len(texto) > 800 else texto
    r: dict = {"pagina": pagina}
    m = RX_PJE.search(margem)
    if m:
        r.update(sistema="pje", id_processual=m.group(1), pagina_id=int(m.group(2)))
    else:
        m = RX_EPROC.search(margem)
        if m:
            r.update(sistema="eproc", evento=int(m.group(1)), peca=m.group(2).upper(), pagina_id=int(m.group(3)))
        else:
            folhas = RX_FOLHA.findall(margem)
            if folhas:
                r.update(sistema="folha_carimbada", folha=folhas[-1])
            elif folha_inicial:
                r.update(sistema="folha_derivada", folha=str(folha_inicial + pagina - 1))
    return r


def descrever(rotulo: dict | None) -> str:
    """Texto curto para a peça: 'ID 123, pág. 2' | 'evento 12, ANEXO3, pág. 2' | 'fl. 13'."""
    if not rotulo:
        return ""
    s = rotulo.get("sistema")
    if s == "pje":
        return f"ID {rotulo['id_processual']}, pág. {rotulo['pagina_id']}"
    if s == "eproc":
        return f"evento {rotulo['evento']}, {rotulo['peca']}, pág. {rotulo['pagina_id']}"
    if s in ("folha_carimbada", "folha_derivada"):
        return f"fl. {rotulo['folha']}" + (" (derivada)" if s == "folha_derivada" else "")
    return ""


def rotulos_documento(textos_por_pagina: list[str], folha_inicial: int | None = None) -> list[dict]:
    return [rotulo_pagina(t or "", i, folha_inicial) for i, t in enumerate(textos_por_pagina, start=1)]
