"""Simulação do julgador: checagem estrutural de admissibilidade antes do protocolo.

Verificações determinísticas por presença de elementos. Não substituem a leitura técnica:
apontam ausências prováveis para revisão humana.
"""
from __future__ import annotations

import re

from .texto import normalizar


def _tem(texto: str, *padroes: str) -> bool:
    t = normalizar(texto)
    return any(re.search(p, t) for p in padroes)


CHECKLISTS: dict[str, list[dict]] = {
    "peticao_inicial": [
        {"item": "Juízo a que é dirigida", "base": "CPC, art. 319, I", "padroes": [r"excelentissim", r"juizo", r"vara", r"juiz"]},
        {"item": "Qualificação das partes", "base": "CPC, art. 319, II", "padroes": [r"cpf", r"cnpj", r"\[cpf_", r"\[cnpj_", r"inscrit", r"residente|domiciliad|sede"]},
        {"item": "Fatos e fundamentos jurídicos", "base": "CPC, art. 319, III", "padroes": [r"dos fatos", r"do direito|fundamento"]},
        {"item": "Pedido com especificações", "base": "CPC, art. 319, IV; art. 322", "padroes": [r"dos pedidos|requer|pede"]},
        {"item": "Valor da causa", "base": "CPC, art. 319, V; art. 292", "padroes": [r"valor da causa", r"da-se a causa|da se a causa"]},
        {"item": "Provas com que pretende demonstrar os fatos", "base": "CPC, art. 319, VI", "padroes": [r"prova", r"documentos? anexo|em anexo"]},
        {"item": "Opção pela audiência de conciliação ou mediação", "base": "CPC, art. 319, VII; art. 334, § 5º", "padroes": [r"audiencia de (conciliacao|mediacao)", r"conciliacao"]},
    ],
    "contestacao": [
        {"item": "Preliminares (art. 337) analisadas", "base": "CPC, art. 337", "padroes": [r"preliminar"]},
        {"item": "Impugnação específica dos fatos", "base": "CPC, art. 341", "padroes": [r"impugna", r"nao procede|inveridic|contrari"]},
        {"item": "Concentração da defesa e especificação de provas", "base": "CPC, art. 336", "padroes": [r"prova"]},
        {"item": "Pedido de improcedência ou extinção", "base": "CPC, arts. 485 e 487", "padroes": [r"improceden|extincao|extinto"]},
    ],
    "sentenca": [
        {"item": "Relatório", "base": "CPC, art. 489, I", "padroes": [r"relatorio|e o relatorio|relatados"]},
        {"item": "Fundamentação", "base": "CPC, art. 489, II", "padroes": [r"fundament|decido|passo a decidir"]},
        {"item": "Dispositivo", "base": "CPC, art. 489, III", "padroes": [r"julgo|ante o exposto|isto posto|dispositivo"]},
        {"item": "Honorários e custas", "base": "CPC, arts. 82, § 2º, e 85", "padroes": [r"honorario", r"custas"]},
    ],
    "recurso": [
        {"item": "Tempestividade demonstrada", "base": "CPC, art. 1.003, § 5º", "padroes": [r"tempestiv"]},
        {"item": "Preparo ou justiça gratuita", "base": "CPC, art. 1.007", "padroes": [r"preparo|custas recursais|justica gratuita|gratuidade"]},
        {"item": "Razões e pedido de reforma ou anulação", "base": "CPC, art. 1.010, III e IV", "padroes": [r"reform|anula"]},
        {"item": "Impugnação específica dos fundamentos da decisão (dialeticidade)", "base": "CPC, art. 932, III", "padroes": [r"fundamento d[ao] (sentenca|decisao)|a decisao recorrida|a sentenca recorrida"]},
    ],
}

CHECKLISTS["tutela_urgencia"] = [
    {"item": "Probabilidade do direito demonstrada", "base": "CPC, art. 300, caput", "padroes": [r"probabilidade do direito|fumus boni iuris|verossimilhanca"]},
    {"item": "Perigo de dano ou risco ao resultado útil do processo", "base": "CPC, art. 300, caput", "padroes": [r"perigo de dano|risco ao resultado util|periculum in mora"]},
    {"item": "Reversibilidade dos efeitos (ou justificativa da exceção)", "base": "CPC, art. 300, § 3º", "padroes": [r"reversib|irreversib"]},
    {"item": "Caução ou dispensa fundamentada", "base": "CPC, art. 300, § 1º", "padroes": [r"caucao|hipossuficien|dispensa de caucao"]},
    {"item": "Pedido específico da medida e prazo para cumprimento", "base": "CPC, arts. 297 e 536", "padroes": [r"requer.{0,80}(tutela|liminar)|(tutela|liminar).{0,80}(determin|ordenar)"]},
]

# Matérias que o juiz pode conhecer de ofício, mas sobre as quais deve ouvir as partes antes (CPC, arts. 9º e 10).
MATERIAS_OFICIO = {
    "prescricao": ("prescri", "CPC, art. 487, parágrafo único"),
    "decadencia": ("decaden", "CPC, art. 487, parágrafo único"),
    "ilegitimidade": ("ilegitimidade|legitimidade ad causam", "CPC, art. 485, VI e § 3º"),
    "interesse_processual": ("falta de interesse|ausencia de interesse", "CPC, art. 485, VI e § 3º"),
    "incompetencia_absoluta": ("incompetencia absoluta", "CPC, art. 64, § 1º"),
    "coisa_julgada": ("coisa julgada", "CPC, art. 485, V e § 3º"),
    "litispendencia": ("litispendencia", "CPC, art. 485, V e § 3º"),
    "perempcao": ("perempcao", "CPC, art. 485, V"),
    "inepcia": ("inepcia|inepta", "CPC, art. 330, I"),
    "nulidade_absoluta": ("nulidade absoluta", "CPC, art. 10"),
}


def vedacao_surpresa(texto_decisao: str, texto_autos: str) -> dict:
    """Aponta fundamentos de ofício presentes na decisão que não aparecem nos autos (indício de que
    as partes não foram ouvidas previamente). Exceção legal: improcedência liminar (CPC, art. 332, § 1º)."""
    dec, aut = normalizar(texto_decisao), normalizar(texto_autos)
    achados = []
    for nome, (padrao, base) in MATERIAS_OFICIO.items():
        if re.search(padrao, dec) and not re.search(padrao, aut):
            achados.append({"materia": nome, "base": base,
                            "mensagem": f"Fundamento '{nome}' não consta dos autos: verificar oportunidade prévia de manifestação (CPC, arts. 9º e 10)."})
    return {"achados": achados, "nota": "Indício a conferir; ressalvada a improcedência liminar (CPC, art. 332, § 1º)."}


# Ordem importa: termos mais específicos primeiro; casamento por palavra inteira.
ALIASES: list[tuple[str, str]] = [
    ("tutela", "tutela_urgencia"), ("liminar", "tutela_urgencia"),
    ("contestacao", "contestacao"), ("defesa", "contestacao"),
    ("apelacao", "recurso"), ("recurso", "recurso"), ("agravo", "recurso"), ("embargos", "recurso"),
    ("sentenca", "sentenca"), ("decisao", "sentenca"),
    ("peticao inicial", "peticao_inicial"), ("inicial", "peticao_inicial"), ("acao", "peticao_inicial"),
]


def tipo_canonico(tipo_peca: str) -> str | None:
    t = normalizar(tipo_peca)
    for chave, canon in ALIASES:
        if re.search(rf"\b{chave}\b", t):
            return canon
    return None


def simular(texto: str, tipo_peca: str) -> dict:
    canon = tipo_canonico(tipo_peca)
    if not canon:
        return {"tipo": tipo_peca, "checklist": [], "pendencias": [],
                "nota": "Sem checklist estrutural cadastrado para este tipo de peça."}
    itens, pend = [], []
    for c in CHECKLISTS[canon]:
        ok = _tem(texto, *c["padroes"])
        itens.append({"item": c["item"], "base": c["base"], "atendido": ok})
        if not ok:
            pend.append(f"{c['item']} ({c['base']}) não identificado.")
    return {"tipo": canon, "checklist": itens, "pendencias": pend,
            "nota": "Checagem estrutural por presença de elementos; exige revisão humana."}
