"""Cálculos judiciais determinísticos. Nenhum índice é presumido: as séries mensais devem
ser fornecidas pelo usuário a partir da fonte oficial (IBGE, BCB, tabela do tribunal).

Toda função devolve memória de cálculo linha a linha para conferência e anexação à peça.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import ROUND_HALF_UP, Decimal, getcontext

getcontext().prec = 28
CENT = Decimal("0.01")


def _d(v) -> Decimal:
    return v if isinstance(v, Decimal) else Decimal(str(v))


def _q(v: Decimal) -> Decimal:
    return v.quantize(CENT, rounding=ROUND_HALF_UP)


def _competencias(inicio: date, fim: date) -> list[str]:
    """Competências AAAA-MM de inicio (inclusive) até fim (exclusive)."""
    comp, a, m = [], inicio.year, inicio.month
    while (a, m) < (fim.year, fim.month):
        comp.append(f"{a:04d}-{m:02d}")
        m += 1
        if m == 13:
            a, m = a + 1, 1
    return comp


@dataclass
class Resultado:
    valor_final: Decimal
    memoria: list[str]
    alertas: list[str]

    def as_dict(self) -> dict:
        return {"valor_final": str(self.valor_final), "memoria": self.memoria, "alertas": self.alertas}


def correcao_monetaria(
    valor: float | str | Decimal,
    data_inicio: date,
    data_fim: date,
    serie_mensal_pct: dict[str, float | str],
    nome_indice: str = "índice informado",
) -> Resultado:
    """Aplica a variação mensal acumulada (produto de 1 + v/100) das competências entre o mês
    de início (inclusive) e o mês final (exclusive). Convenção explícita na memória."""
    v0 = _d(valor)
    comps = _competencias(data_inicio, data_fim)
    faltantes = [c for c in comps if c not in serie_mensal_pct]
    if faltantes:
        raise ValueError(f"Série '{nome_indice}' sem as competências: {', '.join(faltantes)}")
    fator = Decimal(1)
    memoria = [
        f"Valor original: R$ {_q(v0)} em {data_inicio:%d/%m/%Y}.",
        f"Índice: {nome_indice}; competências {comps[0] if comps else '-'} a {comps[-1] if comps else '-'} "
        f"(mês inicial inclusive, mês final exclusive).",
    ]
    for c in comps:
        var = _d(serie_mensal_pct[c])
        fator *= 1 + var / 100
        memoria.append(f"{c}: {var}% -> fator acumulado {fator.quantize(Decimal('0.0000001'))}")
    final = _q(v0 * fator)
    memoria.append(f"Valor corrigido: R$ {_q(v0)} x {fator.quantize(Decimal('0.0000001'))} = R$ {final}.")
    return Resultado(final, memoria, [])


def juros_simples(
    valor: float | str | Decimal,
    data_inicio: date,
    data_fim: date,
    taxa_mensal_pct: float | str | Decimal,
    base_legal: str,
) -> Resultado:
    """Juros simples pro rata die (mês comercial de 30 dias). A base legal da taxa deve ser
    informada (ex.: taxa contratual, CTN art. 161, § 1º, CC art. 406)."""
    v0, taxa = _d(valor), _d(taxa_mensal_pct)
    dias = (data_fim - data_inicio).days
    if dias < 0:
        raise ValueError("Data final anterior à inicial.")
    meses = Decimal(dias) / 30
    juros = _q(v0 * taxa / 100 * meses)
    memoria = [
        f"Base de cálculo: R$ {_q(v0)}.",
        f"Período: {data_inicio:%d/%m/%Y} a {data_fim:%d/%m/%Y} = {dias} dias = {meses.quantize(Decimal('0.0001'))} meses (pro rata, mês de 30 dias).",
        f"Taxa: {taxa}% a.m. ({base_legal}).",
        f"Juros: R$ {_q(v0)} x {taxa}% x {meses.quantize(Decimal('0.0001'))} = R$ {juros}.",
    ]
    return Resultado(juros, memoria, [])


def juros_legais_taxa_mensal(
    valor: float | str | Decimal,
    data_inicio: date,
    data_fim: date,
    serie_taxa_pct: dict[str, float | str],
    nome_serie: str = "taxa legal mensal (CC, art. 406)",
) -> Resultado:
    """Juros simples pela soma das taxas mensais fornecidas. Para o art. 406 do CC (redação da
    Lei 14.905/2024: Selic deduzido o IPCA, com piso zero), forneça a série OFICIAL divulgada
    pelo Banco Central ou a diferença mensal já calculada; taxas negativas são zeradas
    (art. 406, § 3º)."""
    v0 = _d(valor)
    comps = _competencias(data_inicio, data_fim)
    faltantes = [c for c in comps if c not in serie_taxa_pct]
    if faltantes:
        raise ValueError(f"Série '{nome_serie}' sem as competências: {', '.join(faltantes)}")
    soma, memoria, alertas = Decimal(0), [f"Base: R$ {_q(v0)}; série: {nome_serie}."], []
    for c in comps:
        t = _d(serie_taxa_pct[c])
        if t < 0:
            alertas.append(f"{c}: taxa negativa ({t}%) considerada zero (CC, art. 406, § 3º).")
            t = Decimal(0)
        soma += t
        memoria.append(f"{c}: {t}% (acumulado {soma}%)")
    juros = _q(v0 * soma / 100)
    memoria.append(f"Juros: R$ {_q(v0)} x {soma}% = R$ {juros}.")
    alertas.append("Conferir a metodologia oficial vigente da taxa legal antes de utilizar o resultado.")
    return Resultado(juros, memoria, alertas)


def multa_percentual(valor, percentual, base_legal: str) -> Resultado:
    v0, p = _d(valor), _d(percentual)
    m = _q(v0 * p / 100)
    return Resultado(m, [f"Multa: R$ {_q(v0)} x {p}% = R$ {m} ({base_legal})."], [])
