"""Triagem de documentos: identifica o tipo de ato e sugere a providência cabível com o prazo legal.

Determinística. Os prazos abaixo foram conferidos no texto compilado oficial (planalto.gov.br):
CPC, arts. 335, 350, 351, 1.003, § 5º, 1.009, 1.015, 1.023 e 1.029; Lei 9.099/1995, arts. 12-A, 42 e 49;
Decreto 6.514/2008, art. 113; Lei 9.784/1999, art. 66; Lei 14.133/2021, arts. 164 e 165.
A sugestão é ponto de partida: termo inicial, prazo em dobro (CPC, arts. 180, 183, 186 e 229) e
hipóteses de cabimento devem ser conferidos pelo advogado no caso concreto.
"""
from __future__ import annotations

import re

from .texto import normalizar

# (tipo, rótulo, padrões fortes, padrões de apoio)
TIPOS = [
    ("auto_infracao", "Auto de infração", [r"auto de infra[cç][aã]o"], [r"ibama|autuad|multa|infra[cç][aã]o ambiental|fiscaliza"]),
    ("edital", "Edital de licitação", [r"\bedital\b.{0,80}(preg[aã]o|licita|concorr[eê]ncia)", r"preg[aã]o eletr[oô]nico"],
     [r"habilita[cç][aã]o|proposta|sess[aã]o p[uú]blica|abertura"]),
    ("acordao", "Acórdão", [r"\bac[oó]rd[aã]o\b", r"acordam os"], [r"relator|turma|c[aâ]mara|desembargador|voto"]),
    ("sentenca", "Sentença", [r"\bsenten[cç]a\b", r"julgo (?:procedente|improcedente|parcialmente)", r"resolvo o m[eé]rito", r"julgo extint"],
     [r"dispositivo|relat[oó]rio|fundamenta[cç][aã]o|p\.?\s*r\.?\s*i\.?|publique-se"]),
    ("decisao_interlocutoria", "Decisão interlocutória", [r"\bdecis[aã]o\b(?! de mérito)", r"\bdefiro\b|\bindefiro\b", r"tutela (?:de urg[eê]ncia|provis[oó]ria)"],
     [r"intime-se|cumpra-se"]),
    ("citacao", "Citação", [r"\bcita[cç][aã]o\b", r"fica (?:o|a) r[eé]u? citad", r"mandado de cita"], [r"contestar|apresentar defesa|audi[eê]ncia de concilia"]),
    ("intimacao_replica", "Intimação para réplica", [r"r[eé]plica", r"manifestar(?:-se)? sobre a contesta[cç][aã]o", r"impugna[cç][aã]o [aà] contesta"], [r"intimad|intima[cç][aã]o"]),
    ("intimacao", "Intimação", [r"\bintima[cç][aã]o\b", r"fica(?:m)? (?:a parte |as partes )?intimad"], [r"prazo|dias"]),
    ("peticao_inicial", "Petição inicial", [r"excelent[ií]ssim", r"dos pedidos", r"d[aá]-se [aà] causa o valor"], [r"requer|dos fatos|do direito"]),
    ("contestacao", "Contestação", [r"\bcontesta[cç][aã]o\b", r"preliminarmente", r"impugna[cç][aã]o especificada"], [r"r[eé]u|requerid"]),
    ("contrato", "Contrato", [r"\bcl[aá]usula\b", r"contratante|contratada"], [r"objeto|vig[eê]ncia|rescis[aã]o|foro"]),
    ("notificacao", "Notificação extrajudicial", [r"notifica[cç][aã]o extrajudicial", r"\bnotificante\b|\bnotificad[oa]\b"], [r"prazo"]),
]


def _rito_jec(t: str) -> bool:
    return bool(re.search(r"juizado especial|juizados especiais|lei 9\.?099|\bjec\b|\bjesp\b|turma recursal", t))


def classificar(texto: str) -> dict:
    t = normalizar(texto or "")[:60000]
    pontos = []
    for tipo, rotulo, fortes, apoio in TIPOS:
        f = sum(1 for rx in fortes if re.search(rx, t))
        a = sum(1 for rx in apoio if re.search(rx, t))
        if f:
            pontos.append((f * 3 + a, tipo, rotulo))
    if not pontos:
        return {"tipo": "outro", "rotulo": "Documento", "confianca": 0.0, "jec": _rito_jec(t)}
    pontos.sort(reverse=True)
    top = pontos[0]
    segundo = pontos[1][0] if len(pontos) > 1 else 0
    conf = round(min(1.0, top[0] / 7) * (0.6 if segundo == top[0] else 1.0), 2)
    return {"tipo": top[1], "rotulo": top[2], "confianca": conf, "jec": _rito_jec(t),
            "alternativas": [p[2] for p in pontos[1:3]]}


def providencias(tipo: str, jec: bool = False) -> list[dict]:
    """[{peca, dias, contagem, base, nota}] para o tipo de ato recebido."""
    if tipo == "sentenca":
        if jec:
            return [{"peca": "Recurso inominado", "dias": 10, "contagem": "uteis", "base": "Lei 9.099/1995, arts. 42 e 12-A",
                     "nota": "Contado da ciência da sentença; preparo em 48 horas da interposição (art. 42, § 1º)."},
                    {"peca": "Embargos de declaração", "dias": 5, "contagem": "uteis", "base": "Lei 9.099/1995, arts. 49 e 12-A", "nota": ""}]
        return [{"peca": "Apelação", "dias": 15, "contagem": "uteis", "base": "CPC, arts. 1.003, § 5º, e 1.009", "nota": ""},
                {"peca": "Embargos de declaração", "dias": 5, "contagem": "uteis", "base": "CPC, art. 1.023", "nota": ""}]
    if tipo == "decisao_interlocutoria":
        return [{"peca": "Agravo de instrumento", "dias": 15, "contagem": "uteis", "base": "CPC, arts. 1.003, § 5º, e 1.015",
                 "nota": "Somente nas hipóteses do art. 1.015 (rol taxativo, com interpretação do STJ a conferir)."},
                {"peca": "Embargos de declaração", "dias": 5, "contagem": "uteis", "base": "CPC, art. 1.023", "nota": ""}]
    if tipo == "acordao":
        return [{"peca": "Recurso especial ou extraordinário", "dias": 15, "contagem": "uteis", "base": "CPC, arts. 1.003, § 5º, e 1.029",
                 "nota": "Exige prequestionamento e demais requisitos constitucionais."},
                {"peca": "Embargos de declaração", "dias": 5, "contagem": "uteis", "base": "CPC, art. 1.023", "nota": ""}]
    if tipo == "citacao":
        if jec:
            return [{"peca": "Contestação", "dias": None, "contagem": None, "base": "Lei 9.099/1995",
                     "nota": "No juizado, a defesa é apresentada até a audiência de instrução, conforme o rito local: confira o mandado."}]
        return [{"peca": "Contestação", "dias": 15, "contagem": "uteis", "base": "CPC, art. 335",
                 "nota": "O termo inicial depende da hipótese do art. 335 (audiência de conciliação, pedido de cancelamento ou art. 231)."}]
    if tipo == "intimacao_replica":
        return [{"peca": "Réplica", "dias": 15, "contagem": "uteis", "base": "CPC, arts. 350 e 351", "nota": ""}]
    if tipo == "auto_infracao":
        return [{"peca": "Defesa administrativa", "dias": 20, "contagem": "corridos",
                 "base": "Decreto 6.514/2008, art. 113; contagem contínua: Lei 9.784/1999, art. 66, § 2º",
                 "nota": "Infração ambiental federal, contada da ciência da autuação; prorroga-se ao primeiro dia útil (Lei 9.784/1999, art. 66, § 1º). "
                         "Órgãos estaduais e municipais seguem norma própria."}]
    if tipo == "edital":
        return [{"peca": "Impugnação ao edital", "dias": 3, "contagem": "uteis_antes", "base": "Lei 14.133/2021, art. 164",
                 "nota": "Até 3 dias úteis antes da abertura do certame."}]
    if tipo == "contestacao":
        return [{"peca": "Réplica", "dias": 15, "contagem": "uteis", "base": "CPC, arts. 350 e 351",
                 "nota": "Se a contestação trouxer fato impeditivo, modificativo ou extintivo, ou matéria do art. 337."}]
    return []
