"""Primitivas de recuperação: BM25, cosseno e Reciprocal Rank Fusion (Cormack et al., 2009).

Usadas pelo backend em memória (SQLite/desenvolvimento) e pela seleção de Habilidades.
Em PostgreSQL a recuperação roda no banco (pgvector + pg_trgm + full-text), ver
servicos/recuperacao.py.
"""
from __future__ import annotations

import math
from collections import Counter, defaultdict

from .texto import tokenizar


class BM25:
    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b
        self.docs: dict[int, Counter] = {}
        self.tamanhos: dict[int, int] = {}
        self.df: Counter = Counter()

    def adicionar(self, doc_id: int, texto: str) -> None:
        if doc_id in self.docs:
            self.remover(doc_id)
        tf = Counter(tokenizar(texto))
        self.docs[doc_id], self.tamanhos[doc_id] = tf, sum(tf.values())
        self.df.update(tf.keys())

    def remover(self, doc_id: int) -> None:
        tf = self.docs.pop(doc_id, None)
        self.tamanhos.pop(doc_id, None)
        if tf:
            self.df.subtract(tf.keys())

    def buscar(self, consulta: str, candidatos: set[int] | None = None, limite: int = 50) -> list[tuple[int, float]]:
        termos = tokenizar(consulta)
        if not termos or not self.docs:
            return []
        n = len(self.docs)
        media = (sum(self.tamanhos.values()) / n) or 1
        pontos: dict[int, float] = defaultdict(float)
        for t in set(termos):
            df = self.df.get(t, 0)
            if df <= 0:
                continue
            idf = math.log(1 + (n - df + 0.5) / (df + 0.5))
            for doc_id, tf in self.docs.items():
                if candidatos is not None and doc_id not in candidatos:
                    continue
                f = tf.get(t, 0)
                if f:
                    pontos[doc_id] += idf * f * (self.k1 + 1) / (
                        f + self.k1 * (1 - self.b + self.b * self.tamanhos[doc_id] / media))
        return sorted(pontos.items(), key=lambda x: -x[1])[:limite]


def cosseno(a: list[float], b: list[float]) -> float:
    num = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1.0
    nb = math.sqrt(sum(y * y for y in b)) or 1.0
    return num / (na * nb)


def rrf(listas: list[list[int]], k: int = 60) -> dict[int, float]:
    pontos: dict[int, float] = defaultdict(float)
    for lista in listas:
        for pos, doc_id in enumerate(lista):
            pontos[doc_id] += 1.0 / (k + pos + 1)
    return pontos
