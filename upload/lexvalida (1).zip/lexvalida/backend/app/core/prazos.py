"""Cálculo determinístico de prazos processuais com memória de cálculo auditável.

Base normativa implementada:
- CPC, art. 219: prazos processuais em dias úteis.
- CPC, art. 220: suspensão do curso dos prazos entre 20 de dezembro e 20 de janeiro.
- CPC, art. 224, caput: exclui o dia do começo e inclui o do vencimento.
- CPC, art. 224, §§ 2º e 3º: publicação no DJe considera-se feita no 1º dia útil seguinte
  ao da disponibilização; o prazo começa no 1º dia útil seguinte ao da publicação.
- Lei 11.419/2006, art. 5º, § 3º: intimação eletrônica por portal considera-se feita na
  data da consulta ou, não havendo consulta, ao término de 10 dias corridos do envio.
- CPC, arts. 180, 183, 186 e 229: prazo em dobro (MP, Fazenda, Defensoria, litisconsortes
  com procuradores distintos de escritórios diferentes em autos não eletrônicos; o § 2º
  do art. 229 afasta a dobra em autos eletrônicos).
- CPP, art. 798, caput e § 3º: prazos penais contínuos; vencimento em dia sem expediente
  prorroga para o 1º dia útil seguinte.

Feriados locais e dias sem expediente variam por tribunal: o calendário DEVE ser
complementado com as datas oficiais do órgão (art. 216 do CPC).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from enum import Enum


def pascoa(ano: int) -> date:
    """Data da Páscoa (algoritmo anônimo gregoriano, Meeus/Jones/Butcher)."""
    a = ano % 19
    b, c = divmod(ano, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mes = (h + l - 7 * m + 114) // 31
    dia = ((h + l - 7 * m + 114) % 31) + 1
    return date(ano, mes, dia)


def feriados_nacionais(ano: int) -> dict[date, str]:
    """Feriados nacionais fixados em lei (Lei 662/1949 e alterações; Lei 6.802/1980;
    Lei 14.759/2023 para 20 de novembro)."""
    f = {
        date(ano, 1, 1): "Confraternização Universal",
        date(ano, 4, 21): "Tiradentes",
        date(ano, 5, 1): "Dia do Trabalho",
        date(ano, 9, 7): "Independência",
        date(ano, 10, 12): "Nossa Senhora Aparecida (Lei 6.802/1980)",
        date(ano, 11, 2): "Finados",
        date(ano, 11, 15): "Proclamação da República",
        date(ano, 12, 25): "Natal",
    }
    if ano >= 2024:
        f[date(ano, 11, 20)] = "Dia Nacional de Zumbi e da Consciência Negra (Lei 14.759/2023)"
    return f


def dias_sem_expediente_forense_usuais(ano: int) -> dict[date, str]:
    """Datas usualmente sem expediente forense. NÃO são universais: conferir a resolução
    do tribunal competente antes de utilizar. Ativadas apenas por opção explícita."""
    p = pascoa(ano)
    return {
        p - timedelta(days=48): "Segunda-feira de Carnaval (conferir calendário do tribunal)",
        p - timedelta(days=47): "Terça-feira de Carnaval (conferir calendário do tribunal)",
        p - timedelta(days=3): "Quinta-feira Santa (conferir calendário do tribunal)",
        p - timedelta(days=2): "Sexta-feira da Paixão (conferir calendário do tribunal)",
        p + timedelta(days=60): "Corpus Christi (conferir calendário do tribunal)",
        date(ano, 11, 1): "Todos os Santos (conferir calendário do tribunal)",
        date(ano, 12, 8): "Nossa Senhora da Conceição (conferir calendário do tribunal)",
    }


class Contagem(str, Enum):
    UTEIS = "uteis"          # CPC art. 219; CLT art. 775; JEC (Lei 9.099, art. 12-A)
    CORRIDOS = "corridos"    # CPP art. 798; prazos materiais


class Termo(str, Enum):
    DJE = "dje"                        # data de disponibilização no diário eletrônico
    PORTAL = "portal"                  # data de envio da intimação ao portal (Lei 11.419)
    CIENCIA = "ciencia"                # data da ciência/juntada já conhecida (início no dia útil seguinte)


@dataclass
class Calendario:
    feriados_extras: dict[date, str] = field(default_factory=dict)
    usar_dias_forenses_usuais: bool = False
    aplicar_suspensao_art_220: bool = True

    def motivo_nao_util(self, d: date) -> str | None:
        if d.weekday() == 5:
            return "sábado"
        if d.weekday() == 6:
            return "domingo"
        if d in self.feriados_extras:
            return self.feriados_extras[d]
        nac = feriados_nacionais(d.year)
        if d in nac:
            return nac[d]
        if self.usar_dias_forenses_usuais:
            forense = dias_sem_expediente_forense_usuais(d.year)
            if d in forense:
                return forense[d]
        return None

    def suspenso(self, d: date) -> bool:
        """CPC, art. 220: suspensão de 20/12 a 20/01, inclusive."""
        if not self.aplicar_suspensao_art_220:
            return False
        return (d.month == 12 and d.day >= 20) or (d.month == 1 and d.day <= 20)

    def eh_util(self, d: date) -> bool:
        return self.motivo_nao_util(d) is None

    def proximo_util(self, d: date, considerar_suspensao: bool = False) -> date:
        d = d + timedelta(days=1)
        while not self.eh_util(d) or (considerar_suspensao and self.suspenso(d)):
            d += timedelta(days=1)
        return d


@dataclass
class ResultadoPrazo:
    termo_inicial_evento: date
    data_intimacao: date
    inicio_contagem: date
    vencimento: date
    dias: int
    dias_computados: int
    contagem: Contagem
    em_dobro: bool
    memoria: list[str]
    alertas: list[str]

    def as_dict(self) -> dict:
        return {
            "termo_inicial_evento": self.termo_inicial_evento.isoformat(),
            "data_intimacao": self.data_intimacao.isoformat(),
            "inicio_contagem": self.inicio_contagem.isoformat(),
            "vencimento": self.vencimento.isoformat(),
            "dias": self.dias,
            "dias_computados": self.dias_computados,
            "contagem": self.contagem.value,
            "em_dobro": self.em_dobro,
            "memoria": self.memoria,
            "alertas": self.alertas,
        }


def calcular_prazo(
    data_evento: date,
    dias: int,
    termo: Termo = Termo.DJE,
    contagem: Contagem = Contagem.UTEIS,
    calendario: Calendario | None = None,
    em_dobro: bool = False,
    motivo_dobro: str | None = None,
    data_consulta_portal: date | None = None,
    autos_eletronicos: bool = True,
) -> ResultadoPrazo:
    if dias <= 0:
        raise ValueError("O prazo deve ser um número positivo de dias.")
    cal = calendario or Calendario()
    memoria: list[str] = []
    alertas: list[str] = [
        "Feriados locais e portarias de suspensão do tribunal devem ser incluídos no calendário."
    ]

    # 1. Data em que se considera feita a intimação
    if termo == Termo.DJE:
        publicacao = cal.proximo_util(data_evento)
        memoria.append(
            f"Disponibilização no DJe em {data_evento:%d/%m/%Y}; publicação considerada em "
            f"{publicacao:%d/%m/%Y}, 1º dia útil seguinte (CPC, art. 224, § 2º)."
        )
        intimacao = publicacao
    elif termo == Termo.PORTAL:
        limite = data_evento + timedelta(days=10)
        if data_consulta_portal and data_consulta_portal <= limite:
            intimacao = data_consulta_portal
            memoria.append(
                f"Intimação por portal enviada em {data_evento:%d/%m/%Y} e consultada em "
                f"{intimacao:%d/%m/%Y} (Lei 11.419/2006, art. 5º, § 1º)."
            )
        else:
            intimacao = limite
            memoria.append(
                f"Intimação por portal enviada em {data_evento:%d/%m/%Y} sem consulta tempestiva; "
                f"considerada feita em {intimacao:%d/%m/%Y}, após 10 dias corridos "
                f"(Lei 11.419/2006, art. 5º, § 3º)."
            )
        if not cal.eh_util(intimacao):
            # Lei 11.419, art. 5º, § 2º: consulta em dia não útil considera-se no 1º útil seguinte
            nova = cal.proximo_util(intimacao - timedelta(days=1))
            memoria.append(
                f"{intimacao:%d/%m/%Y} não é dia útil ({cal.motivo_nao_util(intimacao)}); "
                f"intimação considerada em {nova:%d/%m/%Y} (Lei 11.419/2006, art. 5º, § 2º)."
            )
            intimacao = nova
    else:
        intimacao = data_evento
        memoria.append(f"Ciência considerada em {intimacao:%d/%m/%Y}, conforme informado.")

    # 2. Dobra legal
    dias_efetivos = dias
    if em_dobro:
        if motivo_dobro == "litisconsortes" and autos_eletronicos:
            alertas.append(
                "Dobra de litisconsortes NÃO aplicada: autos eletrônicos (CPC, art. 229, § 2º)."
            )
        else:
            dias_efetivos = dias * 2
            base = {
                "mp": "CPC, art. 180",
                "fazenda": "CPC, art. 183",
                "defensoria": "CPC, art. 186",
                "litisconsortes": "CPC, art. 229",
            }.get(motivo_dobro or "", "dobra legal informada")
            memoria.append(f"Prazo em dobro: {dias} x 2 = {dias_efetivos} dias ({base}).")

    # 3. Início e contagem
    considerar_suspensao = contagem == Contagem.UTEIS
    inicio = cal.proximo_util(intimacao, considerar_suspensao=considerar_suspensao)
    memoria.append(
        f"Exclui-se o dia do começo; a contagem inicia em {inicio:%d/%m/%Y} "
        f"(CPC, art. 224, caput e § 3º)."
    )

    if contagem == Contagem.UTEIS:
        d, contados, pulados = inicio, 1, []
        while contados < dias_efetivos:
            d += timedelta(days=1)
            motivo = cal.motivo_nao_util(d)
            if motivo:
                if d.weekday() < 5:
                    pulados.append(f"{d:%d/%m/%Y} ({motivo})")
                continue
            if cal.suspenso(d):
                pulados.append(f"{d:%d/%m/%Y} (suspensão do art. 220 do CPC)")
                continue
            contados += 1
        vencimento = d
        memoria.append(f"Contagem em dias úteis (CPC, art. 219): {dias_efetivos} dias úteis.")
        if pulados:
            memoria.append("Dias úteis da semana excluídos da contagem: " + "; ".join(pulados) + ".")
    else:
        vencimento = inicio + timedelta(days=dias_efetivos - 1)
        memoria.append(f"Contagem em dias corridos: {dias_efetivos} dias (CPP, art. 798).")
        if not cal.eh_util(vencimento):
            prorrogado = cal.proximo_util(vencimento)
            memoria.append(
                f"Vencimento em {vencimento:%d/%m/%Y} ({cal.motivo_nao_util(vencimento)}); "
                f"prorrogado para {prorrogado:%d/%m/%Y} (CPP, art. 798, § 3º)."
            )
            vencimento = prorrogado

    memoria.append(f"Vencimento: {vencimento:%d/%m/%Y}.")
    return ResultadoPrazo(
        termo_inicial_evento=data_evento,
        data_intimacao=intimacao,
        inicio_contagem=inicio,
        vencimento=vencimento,
        dias=dias,
        dias_computados=dias_efetivos,
        contagem=contagem,
        em_dobro=dias_efetivos != dias,
        memoria=memoria,
        alertas=alertas,
    )
