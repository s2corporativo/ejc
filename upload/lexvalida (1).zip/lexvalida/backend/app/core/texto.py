"""Normalização e tokenização de texto jurídico em português."""
from __future__ import annotations

import re
import unicodedata

STOPWORDS = frozenset(
    """a o as os um uma uns umas de do da dos das em no na nos nas por pelo pela pelos pelas
    para com sem sob sobre entre ate até e ou que se nao não mais menos como quando onde
    ao aos à às é ser foi sao são era seu sua seus suas este esta estes estas esse essa isso
    isto aquele aquela lhe lhes ja já tambem também mas pois porque art arts artigo inciso""".split()
)

_RE_TOKEN = re.compile(r"[a-z0-9]+")


def sem_acento(texto: str) -> str:
    nfkd = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in nfkd if not unicodedata.combining(c))


def normalizar(texto: str) -> str:
    return sem_acento(texto or "").lower()


def tokenizar(texto: str, remover_stopwords: bool = True) -> list[str]:
    tokens = _RE_TOKEN.findall(normalizar(texto))
    if remover_stopwords:
        tokens = [t for t in tokens if t not in STOPWORDS and len(t) > 1]
    return [_radical(t) for t in tokens]


def _radical(token: str) -> str:
    """Stemming leve (sufixos comuns do português). Não substitui um stemmer completo,
    mas aproxima flexões frequentes (indenização/indenizações, devido/devida)."""
    if token.isdigit() or len(token) <= 4:
        return token
    for suf in ("acoes", "icoes", "mente", "acao", "icao", "idade", "ismo", "ista", "veis",
                "vel", "oes", "aes", "ais", "eis", "es", "as", "os", "a", "o", "s"):
        if token.endswith(suf) and len(token) - len(suf) >= 4:
            return token[: -len(suf)]
    return token


def dividir_trechos(texto: str, tamanho: int = 900, sobreposicao: int = 150) -> list[str]:
    """Divide texto em trechos com sobreposição, respeitando quebras de parágrafo."""
    texto = (texto or "").strip()
    if len(texto) <= tamanho:
        return [texto] if texto else []
    trechos, inicio = [], 0
    while inicio < len(texto):
        fim = min(len(texto), inicio + tamanho)
        if fim < len(texto):
            quebra = texto.rfind("\n", inicio + tamanho // 2, fim)
            if quebra == -1:
                quebra = texto.rfind(". ", inicio + tamanho // 2, fim)
            if quebra != -1:
                fim = quebra + 1
        trechos.append(texto[inicio:fim].strip())
        if fim >= len(texto):
            break
        inicio = max(fim - sobreposicao, inicio + 1)
    return [t for t in trechos if t]
