"""Ingestão de PDFs com coordenadas por bloco e Camada 1 de defesa contra prompt injection.

A Camada 1 inspeciona a estrutura gráfica do PDF (ISO 32000) à procura de texto presente na
camada de dados, mas invisível ao leitor humano:
  1. render mode 3 (texto não pintado);
  2. opacidade próxima de zero;
  3. cor quase branca;
  4. glifos fora da área visível da página;
  5. fonte microscópica (< 1 pt).
Os candidatos passam por um classificador que trata o conteúdo como DADO, nunca como instrução.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field

try:
    import pymupdf as fitz  # PyMuPDF >= 1.24
except ImportError:  # pragma: no cover
    import fitz  # type: ignore

LIMIAR_BRANCO = 0.94
LIMIAR_OPACIDADE = 0.05
LIMIAR_FONTE_PT = 1.0

PADROES_INJECAO: list[tuple[str, str]] = [
    (r"ignor\w*\s+(as\s+|todas\s+as\s+)?(instru|orienta|regras|comandos)", "sobrescrever_instrucoes"),
    (r"esque[cç]\w*\s+(o\s+que|tudo|as\s+instru)", "sobrescrever_instrucoes"),
    (r"(desconsider|desobede)\w*\s+.{0,20}(instru|sistema|prompt)", "sobrescrever_instrucoes"),
    (r"(considere|tenha)\s+como\s+(verdade|verdadeiro|fato)", "manipular_fatos"),
    (r"(invente|fabrique|crie)\s+(uma\s+)?(data|valor|fato|prova|notifica)", "manipular_fatos"),
    (r"(d[eê]\s+provimento|julgue\s+(procedente|improcedente)|condene\s+o|favore[cç]a)", "forcar_resultado"),
    (r"(n[aã]o\s+mencione|omita|n[aã]o\s+revele|oculte)", "ocultar"),
    (r"(repita|revele|imprima|liste)\s+.{0,25}(prompt|instru[cç][oõ]es\s+do\s+sistema|credenciais|tokens?)", "exfiltrar"),
    (r"(voc[eê]\s+[eé]\s+(o|a|um|uma)\s+(assistente|sistema|modelo|ia)|aja\s+como|passe\s+a\s+se\s+comportar)", "personificar"),
    (r"(system\s*prompt|<\s*/?\s*system\s*>|\[\s*inst\s*\]|###\s*instruction)", "marcador_de_prompt"),
]
_REGEX = [(re.compile(p, re.IGNORECASE), cat) for p, cat in PADROES_INJECAO]


def classificar_trecho(texto: str) -> dict:
    """Classificador determinístico: o texto é tratado como dado; nenhuma instrução é executada."""
    categorias = sorted({cat for rx, cat in _REGEX if rx.search(texto or "")})
    if categorias:
        return {"risco": "alto", "categorias": categorias,
                "justificativa": "Trecho contém comando dirigido a um modelo de IA."}
    return {"risco": "baixo", "categorias": [], "justificativa": "Sem padrão de instrução a modelo."}


@dataclass
class Bloco:
    pagina: int
    texto: str
    bbox: tuple[float, float, float, float]


@dataclass
class Candidato:
    pagina: int
    texto: str
    sinais: list[str]
    bbox: tuple[float, float, float, float]
    risco: str = "baixo"
    categorias: list[str] = field(default_factory=list)
    justificativa: str = ""


@dataclass
class DocumentoProcessado:
    nome: str
    paginas: int
    blocos: list[Bloco]
    texto_por_pagina: list[str]
    candidatos_ocultos: list[Candidato]
    injecoes_texto_visivel: list[dict]
    paginas_sem_texto: list[int]

    @property
    def risco_alto(self) -> bool:
        return any(c.risco == "alto" for c in self.candidatos_ocultos) or bool(self.injecoes_texto_visivel)

    def relatorio_seguranca(self) -> dict:
        return {
            "documento": self.nome,
            "risco_alto": self.risco_alto,
            "candidatos_ocultos": [asdict(c) for c in self.candidatos_ocultos],
            "injecoes_texto_visivel": self.injecoes_texto_visivel,
            "paginas_sem_texto_ocr_necessario": self.paginas_sem_texto,
        }


def _quase_branco(cor) -> bool:
    if not cor:
        return False
    if len(cor) == 1:  # escala de cinza
        return cor[0] >= LIMIAR_BRANCO
    if len(cor) == 3:  # RGB
        return min(cor) >= LIMIAR_BRANCO
    if len(cor) == 4:  # CMYK: branco = sem tinta
        return max(cor) <= 1 - LIMIAR_BRANCO
    return False


def _fora_da_pagina(bbox, rect) -> bool:
    x0, y0, x1, y1 = bbox
    return x1 <= rect.x0 or x0 >= rect.x1 or y1 <= rect.y0 or y0 >= rect.y1


def _texto_dos_chars(span: dict) -> str:
    return "".join(chr(c[0]) for c in span.get("chars", []))


def inspecionar_pagina(page, numero: int) -> list[Candidato]:
    rect = page.cropbox
    candidatos: dict[tuple, Candidato] = {}
    for span in page.get_texttrace():
        sinais = []
        if span.get("type") == 3:
            sinais.append("render_mode_invisivel")
        if span.get("opacity", 1) is not None and span.get("opacity", 1) <= LIMIAR_OPACIDADE:
            sinais.append("opacidade_quase_zero")
        if _quase_branco(span.get("color")):
            sinais.append("cor_quase_branca")
        if span.get("size", 12) < LIMIAR_FONTE_PT:
            sinais.append("fonte_microscopica")
        bbox = tuple(round(v, 1) for v in span.get("bbox", (0, 0, 0, 0)))
        if _fora_da_pagina(bbox, rect):
            sinais.append("fora_da_pagina")
        if not sinais:
            continue
        texto = _texto_dos_chars(span).strip()
        if not texto:
            continue
        chave = (tuple(sorted(sinais)), round(bbox[1] / 4))  # agrupa por linha
        if chave in candidatos:
            candidatos[chave].texto += " " + texto
        else:
            candidatos[chave] = Candidato(numero, texto, sorted(sinais), bbox)
    resultado = []
    for c in candidatos.values():
        cls = classificar_trecho(c.texto)
        c.risco, c.categorias, c.justificativa = cls["risco"], cls["categorias"], cls["justificativa"]
        # Camada de OCR invisível sobre imagem é legítima: só eleva risco se houver comando.
        resultado.append(c)
    return resultado


def processar_pdf(dados: bytes, nome: str = "documento.pdf") -> DocumentoProcessado:
    doc = fitz.open(stream=dados, filetype="pdf")
    blocos, textos, candidatos, sem_texto, visiveis = [], [], [], [], []
    for i, page in enumerate(doc, start=1):
        ocultos = inspecionar_pagina(page, i)
        candidatos.extend(ocultos)
        texto_oculto = {c.texto for c in ocultos}
        partes = []
        for b in page.get_text("blocks"):
            x0, y0, x1, y1, txt = b[0], b[1], b[2], b[3], b[4]
            txt = (txt or "").strip()
            if not txt:
                continue
            blocos.append(Bloco(i, txt, (round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1))))
            partes.append(txt)
        texto_pagina = "\n".join(partes)
        textos.append(texto_pagina)
        if not texto_pagina.strip():
            sem_texto.append(i)
        cls = classificar_trecho(texto_pagina)
        if cls["risco"] == "alto" and not any(t in texto_pagina for t in texto_oculto if t):
            visiveis.append({"pagina": i, **cls})
    total = doc.page_count
    doc.close()
    return DocumentoProcessado(nome, total, blocos, textos, candidatos, visiveis, sem_texto)


def processar_texto(texto: str, nome: str = "texto.txt") -> DocumentoProcessado:
    """Ingestão de texto puro (sem coordenadas). Páginas separadas por form feed (\\f)."""
    paginas = texto.split("\f") if "\f" in texto else [texto]
    blocos, visiveis = [], []
    for i, p in enumerate(paginas, start=1):
        for par in [x.strip() for x in p.split("\n\n") if x.strip()]:
            blocos.append(Bloco(i, par, (0, 0, 0, 0)))
        cls = classificar_trecho(p)
        if cls["risco"] == "alto":
            visiveis.append({"pagina": i, **cls})
    return DocumentoProcessado(nome, len(paginas), blocos, paginas, [], visiveis, [])


def remover_trechos(doc: DocumentoProcessado, aprovados_para_remocao: list[str]) -> DocumentoProcessado:
    """Remove do texto que segue para a IA os trechos que o usuário decidiu excluir."""
    if not aprovados_para_remocao:
        return doc
    novos = []
    for t in doc.texto_por_pagina:
        for r in aprovados_para_remocao:
            t = t.replace(r, "[TRECHO REMOVIDO POR SEGURANÇA]")
        novos.append(t)
    doc.texto_por_pagina = novos
    for b in doc.blocos:
        for r in aprovados_para_remocao:
            b.texto = b.texto.replace(r, "[TRECHO REMOVIDO POR SEGURANÇA]")
    return doc
