from __future__ import annotations

from pathlib import Path

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from .config import get_config


class Base(DeclarativeBase):
    pass


_engine = None
_Session = None


def init_engine(url: str | None = None):
    global _engine, _Session
    url = url or get_config().database_url
    if url.startswith("postgres://") or url.startswith("postgresql://"):
        url = "postgresql+psycopg://" + url.split("://", 1)[1]
    if url.startswith("sqlite:///") and ":memory:" not in url:
        Path(url.replace("sqlite:///", "")).parent.mkdir(parents=True, exist_ok=True)
    kwargs = {"connect_args": {"check_same_thread": False}} if url.startswith("sqlite") else {"pool_pre_ping": True}
    if url == "sqlite://" or ":memory:" in url:
        from sqlalchemy.pool import StaticPool
        kwargs["poolclass"] = StaticPool
    _engine = create_engine(url, **kwargs)
    if url.startswith("sqlite"):
        @event.listens_for(_engine, "connect")
        def _fk(dbapi_conn, _):  # noqa: ANN001
            dbapi_conn.execute("PRAGMA foreign_keys=ON")
    _Session = sessionmaker(bind=_engine, expire_on_commit=False)
    from . import models  # noqa: F401
    if _engine.dialect.name == "postgresql":
        _preparar_postgres_antes()
    Base.metadata.create_all(_engine)
    if _engine.dialect.name == "postgresql":
        _preparar_postgres_depois()
    return _engine


def _preparar_postgres_antes() -> None:
    from sqlalchemy import text
    with _engine.begin() as c:
        c.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        c.execute(text("CREATE EXTENSION IF NOT EXISTS pg_trgm"))


def _preparar_postgres_depois() -> None:
    """Índices equivalentes aos do EJC: HNSW cosseno (migration 096), GIN trigram
    (migration 009) e GIN full-text em português (migration 001)."""
    from sqlalchemy import text
    with _engine.begin() as c:
        c.execute(text("CREATE INDEX IF NOT EXISTS ix_trechos_vetor_hnsw ON trechos USING hnsw (vetor vector_cosine_ops)"))
        c.execute(text("CREATE INDEX IF NOT EXISTS ix_trechos_texto_trgm ON trechos USING gin (texto gin_trgm_ops)"))
        c.execute(text("CREATE INDEX IF NOT EXISTS ix_trechos_texto_fts ON trechos USING gin (to_tsvector('portuguese', texto))"))


def get_session():
    if _Session is None:
        init_engine()
    s = _Session()
    try:
        yield s
    finally:
        s.close()


def nova_sessao():
    if _Session is None:
        init_engine()
    return _Session()
