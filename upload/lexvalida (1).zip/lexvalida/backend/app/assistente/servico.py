"""Execução do assistente: entende o pedido, coleta o que falta, chama a ferramenta certa e responde.

Princípios:
- determinístico primeiro (entidades + intenção); IA só para desempate, se houver provedor real;
- nunca inventa: cada resultado cita a base legal ou a fonte; o que não está na base é dito;
- pergunta só o essencial, uma coisa por vez, com opções clicáveis;
- ações que gravam (registrar intimação, iniciar minuta, coletar lei) respeitam papel e acesso ao caso.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_config
from ..core import entidades as ent_mod
from ..core import salvaguardas, triagem
from ..core.prazos import Calendario, Contagem, Termo, calcular_prazo
from ..core.texto import normalizar
from ..models import (Alerta, Caso, Conversa, Documento, Intimacao, Lote, LoteItem, MensagemAssistente, Minuta, Norma,
                      PerfilEstilo, Precedente)
from ..servicos import acesso, auditoria
from . import intencoes


@dataclass
class Falta:
    slot: str
    pergunta: str
    opcoes: list[str] = field(default_factory=list)


def R(texto: str, cartoes: list | None = None, acoes: list | None = None, opcoes: list | None = None) -> dict:
    return {"texto": texto, "cartoes": cartoes or [], "acoes": acoes or [], "opcoes": opcoes or []}


def _br(d: str | date | None) -> str:
    if not d:
        return "-"
    d = date.fromisoformat(d) if isinstance(d, str) else d
    return d.strftime("%d/%m/%Y")


def _pode_gravar() -> bool:
    return acesso.atual().papel != "leitor"


def _casos_recentes(db: Session) -> list[str]:
    vis = acesso.casos_visiveis(db)
    q = select(Caso).order_by(Caso.id.desc()).limit(4)
    if vis is not None:
        q = q.where(Caso.id.in_(vis or {-1}))
    return [f"#{c.id} {c.titulo[:40]}" for c in db.scalars(q)]


def _caso_de_texto(db: Session, texto: str) -> int | None:
    m = re.search(r"#(\d+)\b|\bcaso\s+(\d+)\b", texto or "", re.I)
    if m:
        cid = int(m.group(1) or m.group(2))
        if acesso.permissao_caso(db, acesso.atual(), cid):
            return cid
    for n in ent_mod.cnj(texto):
        dig = re.sub(r"\D", "", n)
        for c in db.scalars(select(Caso).where(Caso.numero_processo.is_not(None))):
            if re.sub(r"\D", "", c.numero_processo or "") == dig and acesso.permissao_caso(db, acesso.atual(), c.id):
                return c.id
    return None


# ================================================================== executores
def ex_briefing(db: Session, s: dict) -> dict:
    vis = acesso.casos_visiveis(db)
    ok = lambda cid: vis is None or cid is None or cid in vis  # noqa: E731
    hoje = date.today()
    intim = [i for i in db.scalars(select(Intimacao).where(Intimacao.status == "pendente", Intimacao.vencimento.is_not(None))
                                   .order_by(Intimacao.vencimento)) if ok(i.caso_id) and i.vencimento <= hoje + timedelta(days=10)]
    alertas = [a for a in db.scalars(select(Alerta).where(Alerta.resolvido.is_(False)).order_by(Alerta.id.desc()).limit(200))
               if ok(a.caso_id) and a.nivel in ("critico", "alerta") and a.tipo != "prazo"]
    minutas = [m for m in db.scalars(select(Minuta).where(Minuta.status == "RASCUNHO").order_by(Minuta.id.desc()).limit(200)) if ok(m.caso_id)]
    revisao = [m for m in minutas if m.fase == "revisao"]
    bloqueadas = [m for m in revisao if (m.verificacao or {}).get("bloqueado")]
    com_erro = [m for m in minutas if (m.estado or {}).get("erro")]
    docs = [d for d in db.scalars(select(Documento).where(Documento.liberado_para_ia.is_(False))) if ok(d.caso_id)]
    incomp = db.scalars(select(LoteItem).where(LoteItem.status == "incompativel")).all()
    cartoes, acoes = [], []
    if intim:
        cartoes.append({"tipo": "lista", "titulo": "Prazos nos próximos 10 dias", "itens": [
            {"titulo": f"{_br(i.vencimento)} · {i.numero_processo or 'sem número'}", "texto": (i.texto or "")[:160],
             "meta": f"{(i.vencimento - hoje).days} dia(s) · prazo de {i.prazo_dias} dias",
             "nivel": "critico" if (i.vencimento - hoje).days <= 3 else "alerta"} for i in intim[:10]]})
    if alertas:
        cartoes.append({"tipo": "lista", "titulo": "Alertas", "itens": [
            {"titulo": a.tipo.replace("_", " "), "texto": a.mensagem, "nivel": a.nivel} for a in alertas[:8]]})
    pend = []
    if revisao:
        pend.append(f"{len(revisao)} minuta(s) aguardando sua revisão" + (f", {len(bloqueadas)} com bloqueio" if bloqueadas else ""))
    for m in com_erro[:3]:
        pend.append(f"Minuta #{m.id} parou na etapa {m.estado['erro'].get('fase')}")
        acoes.append({"rotulo": f"Retomar minuta #{m.id}", "acao": "retomar_minuta", "params": {"minuta_id": m.id}})
    if docs:
        pend.append(f"{len(docs)} documento(s) com suspeita de instrução oculta aguardando sua decisão")
    if incomp:
        pend.append(f"{len(incomp)} processo(s) de lote incompatíveis com o modelo")
    if pend:
        cartoes.append({"tipo": "resultado", "titulo": "Pendências", "linhas": pend})
    if not cartoes:
        prox = next((i for i in db.scalars(select(Intimacao).where(Intimacao.status == "pendente", Intimacao.vencimento > hoje)
                                            .order_by(Intimacao.vencimento)) if ok(i.caso_id)), None)
        extra = f" O próximo prazo cadastrado vence em {_br(prox.vencimento)} ({prox.numero_processo or 'sem número'})." if prox else ""
        return R("Nada urgente: nenhum prazo nos próximos 10 dias, nenhum alerta aberto e nenhuma minuta aguardando revisão." + extra,
                 opcoes=["Calcular um prazo", "Redigir uma peça", "Consultar um processo"])
    prox = f" O mais próximo vence em {_br(intim[0].vencimento)}." if intim else ""
    return R(f"{len(intim)} prazo(s) nos próximos 10 dias, {len(alertas)} alerta(s) aberto(s) e {len(revisao)} minuta(s) em revisão.{prox}",
             cartoes, acoes)


def _resultado_prazo(r, peca: str | None, base: str | None) -> dict:
    d = r.as_dict()
    return {"tipo": "resultado", "titulo": f"Prazo{(' para ' + peca) if peca else ''}", "destaque": f"Vence em {_br(d['vencimento'])}",
            "linhas": [f"{d['dias']} dias {'úteis' if d['contagem'] == 'uteis' else 'corridos'}" + (f" · {base}" if base else "")],
            "memoria": d["memoria"], "alertas": d["alertas"]}


def ex_prazo(db: Session, s: dict) -> dict | Falta:
    e, t = s["ent"], normalizar(s["texto"])
    if s.get("contagem") == "uteis_antes" or "Impugnação ao edital" in (s.get("peca"), e.get("tipo_peca")) or re.search(r"edital|licita|preg[aã]o", t):
        return ex_licitacao(db, {**s, "modo": "impugnacao"})
    dias = s.get("dias") or (e["dias"][0]["dias"] if e["dias"] else None)
    if not dias:
        return Falta("dias", "Qual o prazo, em dias?", ["5 dias úteis", "15 dias úteis", "10 dias úteis", "30 dias corridos"])
    data_ev = s.get("data") or (e["datas"][0] if e["datas"] else None)
    if not data_ev:
        return Falta("data", "Qual a data da disponibilização no diário ou da ciência?", ["Hoje", "Ontem"])
    contagem = s.get("contagem") or (e["dias"][0]["contagem"] if e["dias"] and e["dias"][0]["contagem"] else None)
    if not contagem:
        contagem = "corridos" if re.search(r"penal|criminal|cpp|corridos", t) else "uteis"
    termo = s.get("termo") or ("portal" if re.search(r"portal|sistema do tribunal|pje|eproc", t)
                               else "ciencia" if re.search(r"ci[eê]ncia|juntada|citad|autua", t) else "dje")
    r = calcular_prazo(date.fromisoformat(data_ev), int(dias), Termo(termo), Contagem(contagem), Calendario())
    acoes = []
    if s.get("caso_id") and s.get("peca"):
        acoes.append({"rotulo": f"Redigir {s['peca']}", "acao": "redigir", "params": {"tipo_peca": s["peca"], "caso_id": s["caso_id"]},
                      "estilo": "principal"})
    return R(f"Vence em {_br(r.vencimento)} ({dias} dias {'úteis' if contagem == 'uteis' else 'corridos'}, a partir de {_br(data_ev)}). "
             "Confira feriados locais e suspensões do tribunal.", [_resultado_prazo(r, s.get("peca"), s.get("base"))], acoes)


def ex_intimacao(db: Session, s: dict) -> dict | Falta:
    if not _pode_gravar():
        return R("Seu perfil é somente leitura: não registro intimações.")
    e = s["ent"]
    data_ev = s.get("data") or (e["datas"][0] if e["datas"] else None)
    if not data_ev:
        return Falta("data", "Qual a data de disponibilização desta intimação?", ["Hoje", "Ontem"])
    caso_id = s.get("caso_id") or _caso_de_texto(db, s["texto"])
    if caso_id:
        acesso.exigir_caso(db, caso_id, edicao=True)
    from ..servicos import intimacoes
    r = intimacoes.registrar(db, [{"numero_processo": (e["cnj"] or [None])[0], "data_disponibilizacao": data_ev,
                                   "texto": s["texto"], "caso_id": caso_id}], origem="assistente")
    if not r["novas"]:
        return R("Esta intimação já estava registrada.")
    it = db.get(Intimacao, r["novas"][0])
    tri = triagem.classificar(s["texto"])
    acoes = []
    if it.caso_id:
        peca = next((p["peca"] for p in triagem.providencias(tri["tipo"], tri["jec"])), None) or (e.get("tipo_peca"))
        if peca:
            acoes.append({"rotulo": f"Redigir {peca}", "acao": "redigir", "estilo": "principal",
                          "params": {"tipo_peca": peca, "caso_id": it.caso_id, "pedido": f"Responder à intimação de {_br(data_ev)}: {s['texto'][:600]}"}})
    if not it.prazo_dias:
        return R(f"Intimação #{it.id} registrada{' no caso #' + str(it.caso_id) if it.caso_id else ''}, mas o texto não traz o prazo em dias.",
                 opcoes=["5 dias", "15 dias", "10 dias"], acoes=acoes) | {"pendente": {"intencao": "_prazo_intimacao", "slots": {"intimacao_id": it.id}, "falta": "dias"}}
    card = {"tipo": "resultado", "titulo": f"Intimação #{it.id}", "destaque": f"Vence em {_br(it.vencimento)}",
            "linhas": [f"Prazo de {it.prazo_dias} dias extraído do texto", f"Caso: #{it.caso_id}" if it.caso_id else "Sem caso vinculado (número não encontrado nos casos)"],
            "memoria": it.memoria_prazo}
    return R(f"Registrei a intimação e calculei o prazo: vence em {_br(it.vencimento)}. Já aparece nos alertas e no resumo do dia.", [card], acoes)


def ex_prazo_intimacao(db: Session, s: dict) -> dict | Falta:
    e = s["ent"]
    dias = s.get("dias") or (e["dias"][0]["dias"] if e["dias"] else None)
    if not dias:
        return Falta("dias", "Quantos dias de prazo?", ["5 dias", "15 dias"])
    from ..servicos import intimacoes
    it = intimacoes.calcular(db, db.get(Intimacao, s["intimacao_id"]), int(dias))
    return R(f"Prazo calculado: vence em {_br(it.vencimento)}.", [{"tipo": "resultado", "titulo": f"Intimação #{it.id}",
             "destaque": f"Vence em {_br(it.vencimento)}", "memoria": it.memoria_prazo}])


def ex_redigir(db: Session, s: dict) -> dict | Falta:
    if not _pode_gravar():
        return R("Seu perfil é somente leitura: não inicio minutas.")
    tipo = s.get("tipo_peca") or s["ent"].get("tipo_peca")
    if not tipo:
        return Falta("tipo_peca", "Qual peça?", ["Petição inicial", "Contestação", "Réplica", "Apelação", "Manifestação"])
    caso_id = s.get("caso_id") or _caso_de_texto(db, s["texto"])
    if not caso_id and "sem_caso" not in s:
        casos = _casos_recentes(db)
        if casos:
            return Falta("caso", "Para qual caso? Os autos do caso dão as referências verificáveis.", casos + ["Sem caso"])
    if caso_id:
        acesso.exigir_caso(db, caso_id, edicao=True)
    from ..agente import pipeline
    from ..core.analise_instrucao import analisar
    pedido = s.get("pedido") or s["texto"]
    caso = db.get(Caso, caso_id) if caso_id else None
    an = analisar(tipo, pedido, tem_caso=bool(caso), data_fatos_informada=bool(caso and caso.data_fatos))
    perfil = db.scalars(select(PerfilEstilo).order_by(PerfilEstilo.id)).first()
    m = pipeline.iniciar(db, caso_id, tipo, pedido, perfil_estilo_id=perfil.id if perfil else None)
    return _resposta_minuta(m, an)


def _resposta_minuta(m: Minuta, analise: dict | None = None) -> dict:
    e = m.estado or {}
    cartoes = []
    if analise and not analise.get("ok"):
        cartoes.append({"tipo": "resultado", "titulo": "Pontos de atenção na instrução",
                        "alertas": (analise.get("contradicoes") or []) + (analise.get("conflitos_com_regras") or []) + (analise.get("omissoes") or [])[:4]})
    if m.fase == "perguntas":
        p = (e.get("perguntas") or [{}])[0]
        acoes = [{"rotulo": o, "acao": "responder_minuta", "params": {"minuta_id": m.id, "respostas": {p.get("id", "q1"): o}}}
                 for o in (p.get("opcoes") or ["Sim", "Não"])]
        return R(f"Minuta #{m.id} ({m.tipo_peca}) planejada. Antes do roteiro: {p.get('pergunta')}", cartoes, acoes) | {"minuta_id": m.id}
    if m.fase == "aprovar_roteiro":
        cartoes.append({"tipo": "resultado", "titulo": f"Roteiro da minuta #{m.id}",
                        "linhas": [f"{i + 1}. {x.get('titulo')}" for i, x in enumerate(e.get("roteiro") or [])]})
        return R("Confira o roteiro. Ao aprovar, pesquiso, redijo por seção e verifico cada citação.", cartoes,
                 [{"rotulo": "Aprovar roteiro e redigir", "acao": "aprovar_roteiro", "params": {"minuta_id": m.id}, "estilo": "principal"},
                  {"rotulo": "Ajustar no editor", "acao": "abrir_minuta", "params": {"minuta_id": m.id}}]) | {"minuta_id": m.id}
    if m.fase == "revisao":
        v = m.verificacao or {}
        probs = v.get("problemas") or []
        cartoes.append({"tipo": "resultado", "titulo": f"Minuta #{m.id} verificada",
                        "destaque": "Bloqueada: corrija antes de aprovar" if v.get("bloqueado") else "Sem bloqueio",
                        "linhas": [f"{len(v.get('citados', {}).get('juris', []))} precedente(s), {len(v.get('citados', {}).get('lei', []))} dispositivo(s) e "
                                   f"{len(v.get('citados', {}).get('autos', []))} referência(s) aos autos conferidos"],
                        "alertas": [p["mensagem"] for p in probs[:6]]})
        return R("Minuta pronta para sua revisão. Toda saída de IA é rascunho: aprove somente após ler.", cartoes,
                 [{"rotulo": "Revisar e aprovar", "acao": "abrir_minuta", "params": {"minuta_id": m.id}, "estilo": "principal"},
                  {"rotulo": "Baixar DOCX", "acao": "baixar_minuta", "params": {"minuta_id": m.id, "formato": "docx"}}]) | {"minuta_id": m.id}
    if e.get("erro"):
        return R(f"A minuta #{m.id} parou na etapa {e['erro'].get('fase')}: {e['erro'].get('mensagem')}", cartoes,
                 [{"rotulo": "Retomar", "acao": "retomar_minuta", "params": {"minuta_id": m.id}, "estilo": "principal"}]) | {"minuta_id": m.id}
    return R(f"Minuta #{m.id} na fase {m.fase}.", cartoes, [{"rotulo": "Abrir", "acao": "abrir_minuta", "params": {"minuta_id": m.id}}])


def ex_processo(db: Session, s: dict) -> dict | Falta:
    num = s.get("numero") or (s["ent"]["cnj"] or [None])[0]
    if not num:
        return Falta("numero", "Qual o número do processo (padrão CNJ)?")
    from ..integracoes import datajud
    try:
        achados = datajud.consultar_processo(num)
    except datajud.ErroDataJud as e:
        return R(f"DataJud indisponível agora: {e}")
    if not achados:
        return R(f"O processo {num} não foi encontrado no DataJud (pode estar sob sigilo ou ainda não indexado).")
    a = sorted(achados, key=lambda x: x.get("atualizado_em") or "")[-1]
    movs = [f"{_br((x.get('data') or '')[:10]) if x.get('data') else '-'} · {x.get('nome')}" for x in (a.get("ultimos_movimentos") or [])[-6:]][::-1]
    card = {"tipo": "resultado", "titulo": f"Processo {num}", "destaque": f"{a['tribunal']} · {(a.get('classe') or {}).get('nome', '')}",
            "linhas": [f"Órgão: {(a.get('orgao_julgador') or {}).get('nome', '-')}",
                       "Assuntos: " + ", ".join(x.get("nome", "") for x in a.get("assuntos") or []),
                       f"Ajuizamento: {_br(a.get('data_ajuizamento'))} · Sistema: {a.get('sistema') or '-'}"],
            "memoria": movs, "fonte": "DataJud (API pública do CNJ)"}
    caso_id = _caso_de_texto(db, num)
    acoes = []
    if caso_id:
        acoes.append({"rotulo": f"Atualizar caso #{caso_id} com estes dados", "acao": "enriquecer_caso", "params": {"caso_id": caso_id}})
    elif _pode_gravar():
        acoes.append({"rotulo": "Criar caso a partir deste processo", "acao": "criar_caso_processo", "params": {"numero": num}, "estilo": "principal"})
    return R(f"Encontrei o processo no {a['tribunal']}. Última atualização no DataJud: {_br((a.get('atualizado_em') or '')[:10])}.", [card], acoes)


def ex_lei(db: Session, s: dict) -> dict | Falta:
    ids = s["ent"]["dispositivos"]
    if not ids:
        return Falta("dispositivo", "Qual dispositivo? Ex.: art. 219 do CPC.")
    from ..integracoes import planalto
    from ..servicos import conhecimento
    cartoes, faltando = [], []
    for nid in ids[:4]:
        n = db.get(Norma, nid)
        if not n:
            faltando.append(nid)
            continue
        v = conhecimento.versao_vigente(n, date.today())
        al = ["Início de vigência desta redação não curado: confira a redação aplicável à data dos fatos (LINDB, art. 6º)."] \
            if v and v.vigencia_inicio is None else []
        cartoes.append({"tipo": "texto_legal", "titulo": n.rotulo, "texto": v.texto if v else "(sem redação vigente)",
                        "fonte": n.fonte_url, "alertas": al, "marcador": "{{lei:" + n.id + "}}"})
    acoes = []
    slugs = sorted({f.split("-")[0] for f in faltando if f.split("-")[0] in planalto.POR_SLUG})
    if slugs and acesso.atual().papel in ("admin", "advogado"):
        acoes.append({"rotulo": "Coletar do Planalto: " + ", ".join(planalto.POR_SLUG[x]["sigla"] for x in slugs),
                      "acao": "coletar_planalto", "params": {"slugs": slugs}, "estilo": "principal"})
    def rot(nid: str) -> str:
        slug, _, resto = nid.partition("-art-")
        d = planalto.POR_SLUG.get(slug)
        return f"{d['sigla'] if d else slug.upper()}, art. {resto.upper()}"
    texto = ("Texto oficial coletado do Planalto." if cartoes else "") + \
            (f" Ainda não tenho na base: {', '.join(rot(x) for x in faltando)}." if faltando else "")
    return R(texto.strip(), cartoes, acoes)


def ex_sumula(db: Session, s: dict) -> dict | Falta:
    sums = s["ent"]["sumulas"]
    if not sums:
        return ex_pesquisa(db, s)
    cartoes, faltam = [], []
    for x in sums[:3]:
        q = select(Precedente).where(Precedente.tipo.in_(["sumula", "sumula_vinculante", "sumula_tribunal"]), Precedente.numero == x["numero"])
        if x["tribunal"]:
            q = q.where(Precedente.tribunal == x["tribunal"])
        p = db.scalars(q).first()
        if not p:
            faltam.append(f"Súmula {x['numero']}{' do ' + x['tribunal'] if x['tribunal'] else ''}")
            continue
        cartoes.append({"tipo": "texto_legal", "titulo": p.rotulo, "texto": p.ementa, "fonte": p.fonte_url,
                        "alertas": [f"Status: {p.status}"] + ([] if p.verificado else ["Registro não conferido com a fonte oficial."]),
                        "marcador": "{{juris:" + p.id + "}}"})
    txt = "" if cartoes else "Não encontrei na base. "
    if faltam:
        txt += "Fora da base: " + ", ".join(faltam) + ". Importe a base pública do EJC ou cadastre com a fonte oficial."
    return R(txt.strip() or "Súmula encontrada na base.", cartoes)


def ex_pesquisa(db: Session, s: dict) -> dict:
    from ..servicos import conhecimento
    q = s["texto"]
    caso = db.get(Caso, s["caso_id"]) if s.get("caso_id") else None
    j = conhecimento.pesquisar_jurisprudencia(db, q, limite=5)["resultados"]
    l = conhecimento.pesquisar_legislacao(db, q, caso.data_fatos if caso else None, limite=4)["resultados"]
    d = conhecimento.pesquisar_fonte(db, "doutrina", q, limite=3)
    cartoes = []
    if j:
        cartoes.append({"tipo": "lista", "titulo": "Precedentes (ordem de autoridade, CPC, art. 927)", "itens": [
            {"titulo": x["rotulo"], "texto": (x.get("tese") or x["ementa"])[:400], "meta": f"{x.get('hierarquia') or x['tipo']} · {x['status']}",
             "marcador": x["marcador"], "link": x.get("fonte_url"), "nivel": "alerta" if x.get("alerta_status") else ""} for x in j]})
    if l:
        cartoes.append({"tipo": "lista", "titulo": "Legislação", "itens": [
            {"titulo": x["rotulo"], "texto": (x["texto_na_data_dos_fatos"] or "")[:400], "marcador": x["marcador"],
             "link": None, "meta": "; ".join(x["alertas"])} for x in l]})
    if d:
        cartoes.append({"tipo": "lista", "titulo": "Material de apoio", "itens": [
            {"titulo": x.get("titulo") or x["fonte_id"], "texto": x["trecho"][:300]} for x in d]})
    if not cartoes:
        return R("Não encontrei nada pertinente na base. A base só contém o que foi importado de fontes oficiais ou do EJC: "
                 "posso coletar legislação do Planalto ou você pode importar a base do EJC.",
                 acoes=[{"rotulo": "Ver fontes de conhecimento", "acao": "abrir_fontes", "params": {}}])
    return R("Resultados da base, com o marcador para citar na peça. A IA não redige ementas: o texto vem da base.", cartoes)


def ex_verificar(db: Session, s: dict) -> dict:
    from ..servicos import documentos
    caso = db.get(Caso, s["caso_id"]) if s.get("caso_id") else None
    res = documentos.resolver_citacoes(db, s["texto"], caso.data_fatos if caso else None)
    sv = salvaguardas.verificar(res.texto)
    alertas = [p.mensagem for p in res.problemas] + [f"Possível promessa de resultado: \"{x}\"" for x in sv["promessas"]] + \
              [f"\"{a['trecho']}\": prescrição e decadência resolvem o mérito (CPC, art. 487, II)" for a in sv["merito_prescricao"]] + sv["cdc"]
    card = {"tipo": "resultado", "titulo": "Verificação", "destaque": "Bloqueado" if res.bloqueado else "Sem bloqueio",
            "alertas": alertas[:12], "linhas": [f"{len(res.citados['juris'])} precedente(s), {len(res.citados['lei'])} dispositivo(s), "
                                                f"{len(res.citados['autos'])} referência(s) aos autos"]}
    return R("Verifiquei citações, vigência, trechos dos autos e riscos de redação.", [card])


CATALOGO_PRESCR = [(r"consum|fato do produto|fato do servi|acidente de consumo", "cdc_fato_do_produto"),
                   (r"trabalh|empregad|clt", "trabalhista"),
                   (r"fazenda|municipio|estado|uniao|autarquia", "fazenda_publica"),
                   (r"enriquecimento", "enriquecimento_sem_causa"),
                   (r"divida|cobran|nota promiss|cheque|contrato|instrumento", "divida_liquida_instrumento"),
                   (r"repara|indeniz|dano", "reparacao_civil")]


def ex_prescricao(db: Session, s: dict) -> dict | Falta:
    from ..core.prescricao import CATALOGO, calcular_prescricao
    t = normalizar(s["texto"] + " " + s.get("tipo_txt", ""))
    tipo = s.get("tipo") or next((k for rx, k in CATALOGO_PRESCR if re.search(rx, t)), None)
    if not tipo:
        return Falta("tipo_txt", "Qual pretensão?", [v["descricao"][:60] for v in CATALOGO.values()][:6])
    data_ini = s.get("data") or (s["ent"]["datas"][0] if s["ent"]["datas"] else None)
    if not data_ini:
        return Falta("data", f"Qual o termo inicial ({CATALOGO[tipo]['descricao'].lower()})? Informe a data.")
    r = calcular_prescricao(date.fromisoformat(data_ini), date.today(), tipo=tipo)
    d = r.as_dict()
    return R(("Prescrição CONSUMADA" if d["prescrito"] else "Prescrição não consumada") + f": termo final em {_br(d['termo_final'])}.",
             [{"tipo": "resultado", "titulo": CATALOGO[tipo]["descricao"], "destaque": f"Termo final {_br(d['termo_final'])}",
               "linhas": [CATALOGO[tipo]["base"]], "memoria": d["memoria"], "alertas": d["alertas"]}])


def ex_intercorrente(db: Session, s: dict) -> dict | Falta:
    from ..core.prescricao import calcular_intercorrente
    t = normalizar(s["texto"])
    rito = s.get("rito") or ("lef" if re.search(r"fiscal|lef|divida ativa|6\.?830", t) else None)
    if not rito:
        return Falta("rito_txt", "É execução fiscal (LEF) ou execução civil (CPC)?", ["Execução fiscal", "Execução civil"])
    data = s.get("data") or (s["ent"]["datas"][0] if s["ent"]["datas"] else None)
    if not data:
        return Falta("data", "Qual a data da ciência da primeira tentativa infrutífera de localizar o devedor ou bens?")
    anos, base = (5, "Lei 6.830/1980, art. 40, § 4º; STJ, Súmula 314") if rito == "lef" else (s.get("anos"), s.get("base"))
    if not anos:
        return Falta("anos", "Qual o prazo prescricional da pretensão executada, em anos?", ["3 anos", "5 anos", "10 anos"])
    r = calcular_intercorrente(rito, date.fromisoformat(data), date.today(), int(anos), base or "prazo da pretensão informado")
    d = r.as_dict()
    return R(("Intercorrente CONSUMADA" if d["prescrito"] else "Intercorrente não consumada") + f": termo final em {_br(d['termo_final'])}.",
             [{"tipo": "resultado", "titulo": "Prescrição intercorrente", "destaque": f"Termo final {_br(d['termo_final'])}",
               "memoria": d["memoria"], "alertas": d["alertas"]}])


def ex_valor_causa(db: Session, s: dict) -> dict | Falta:
    from ..core import valor_causa
    t = normalizar(s["texto"])
    pedidos = []
    for m in re.finditer(r"([a-z ]{0,40}?)r\$\s*([\d.]+(?:,\d{2})?)", t):
        ctx = m.group(1)
        v = m.group(2).replace(".", "").replace(",", ".")
        if re.search(r"alimento|pensao", ctx):
            pedidos.append({"tipo": "alimentos", "prestacao_mensal": v, "descricao": "Alimentos"})
        elif re.search(r"cobran|divida|debito|principal", ctx):
            pedidos.append({"tipo": "cobranca", "principal_corrigido": v, "descricao": "Cobrança"})
        else:
            pedidos.append({"tipo": "indenizacao", "valor": v, "descricao": "Danos morais" if "moral" in ctx else "Indenização"})
    if not pedidos:
        return Falta("valores", "Quais pedidos e valores? Ex.: danos morais de R$ 10.000,00 e cobrança de R$ 5.000,00.")
    rel = "alternativos" if "alternativ" in t else "subsidiarios" if "subsidiar" in t else "cumulados"
    r = valor_causa.calcular(pedidos, rel)
    return R(f"Valor da causa: R$ {r['valor_da_causa']}.", [{"tipo": "resultado", "titulo": "Valor da causa (CPC, art. 292)",
             "destaque": f"R$ {r['valor_da_causa']}", "memoria": r["memoria"], "alertas": r.get("alertas", [])}])


def ex_licitacao(db: Session, s: dict) -> dict | Falta:
    from ..core import licitacoes
    t = normalizar(s["texto"])
    modo = s.get("modo") or ("impugnacao" if re.search(r"impugn", t) else "recurso" if re.search(r"recurs", t)
                             else "habilitacao" if (re.search(r"habilita", t) and len(t) > 200) else None)
    if not modo:
        return Falta("modo_txt", "O que precisa na licitação?", ["Prazo de impugnação", "Prazo de recurso", "Matriz de habilitação"])
    data = s.get("data") or (s["ent"]["datas"][0] if s["ent"]["datas"] else None)
    if modo == "habilitacao":
        if not data:
            return Falta("data", "Qual a data da sessão?")
        r = licitacoes.matriz_habilitacao(s["texto"], [], date.fromisoformat(data))
        return R("Matriz de habilitação a partir do edital (Lei 14.133/2021, arts. 62 a 70).",
                 [{"tipo": "resultado", "titulo": "Habilitação", "linhas": [f"{x['requisito']}: {x['situacao']}" for x in r["linhas"]],
                   "alertas": [x["exigencia"] + ": " + x["orientacao"] for x in r.get("exigencias_sem_previsao_legal", [])]}])
    if not data:
        return Falta("data", "Qual a data de abertura do certame?" if modo == "impugnacao" else "Qual a data da intimação ou da lavratura da ata?")
    r = licitacoes.prazo_impugnacao(date.fromisoformat(data)) if modo == "impugnacao" else licitacoes.prazo_recurso(date.fromisoformat(data))
    chave = "limite_protocolo" if modo == "impugnacao" else next((k for k in r if k.startswith("vencimento") or k == "limite"), None)
    destaque = f"Limite: {_br(r.get(chave))}" if chave and r.get(chave) else ""
    return R(f"{'Impugnação' if modo == 'impugnacao' else 'Recurso'}: {destaque or 'veja a memória'}.",
             [{"tipo": "resultado", "titulo": "Licitação (Lei 14.133/2021)", "destaque": destaque, "memoria": r.get("memoria", []),
               "alertas": r.get("alertas", [])}])


def ex_contradicoes(db: Session, s: dict) -> dict | Falta:
    cid = s.get("caso_id") or _caso_de_texto(db, s["texto"])
    if not cid:
        return Falta("caso", "De qual caso?", _casos_recentes(db))
    acesso.exigir_caso(db, cid)
    from ..core.contradicoes import detectar
    from ..servicos import documentos
    r = detectar(documentos.paginas_do_caso(db, cid))
    if not r["contradicoes"]:
        return R("Não encontrei datas ou valores divergentes entre os documentos do caso.")
    return R(f"{len(r['contradicoes'])} possível(is) contradição(ões) entre documentos. São indícios para conferência.",
             [{"tipo": "lista", "titulo": "Contradições", "itens": [
                 {"titulo": c["rotulo"].replace("_", " "), "texto": " x ".join(c["valores"]), "nivel": "alerta",
                  "meta": "; ".join(f"{o['documento_nome']} p. {o['pagina']}{' (' + o['numeracao_autos'] + ')' if o['numeracao_autos'] else ''}" for o in c["ocorrencias"][:4])}
                 for c in r["contradicoes"]]}])


def ex_legislativo(db: Session, s: dict) -> dict | Falta:
    tema = s.get("tema") or re.sub(r"(?i)\b(h[aá]|existe[m]?|tem|algum|alguma|projetos?|de|lei|sobre|em|tramita\w*|no|na|congresso|"
                                   r"c[aâ]mara|senado|proposi\w*|pls?|quais|os|as|o|a)\b", " ", s["texto"]).strip(" ?.!")
    tema = " ".join(tema.split())
    if len(tema) < 4:
        return Falta("tema", "Sobre qual tema?")
    from ..integracoes import legislativo
    from ..servicos import legislacao
    try:
        r = legislacao.monitorar(db, tema)
    except legislativo.ErroLegislativo as e:
        return R(str(e))
    if not r["proposicoes"]:
        return R(f"Não encontrei proposições de {r['ano']} sobre \"{tema}\" na Câmara e no Senado." + (" Falhas: " + "; ".join(r["erros"]) if r["erros"] else ""))
    return R(f"{len(r['proposicoes'])} proposição(ões) de {r['ano']} sobre \"{tema}\"" + (" (correspondência parcial)" if r.get("correspondencia") == "parcial" else "") +
             ". Projetos não são lei vigente.",
             [{"tipo": "lista", "titulo": "Proposições", "itens": [
                 {"titulo": f"{x['sigla']} ({x['casa']})", "texto": x["ementa"][:300], "meta": _br(x["data_apresentacao"]), "link": x["link"]}
                 for x in r["proposicoes"][:10]]}])


def ex_jurimetria(db: Session, s: dict) -> dict | Falta:
    trib = s.get("tribunal") or (s["ent"]["tribunais"] or [None])[0]
    if not trib:
        return Falta("tribunal", "Em qual tribunal?", ["TJMG", "TRT3", "TRF6", "STJ"])
    tema = s.get("tema") or re.sub(r"(?i)\b(jurimetria|estat[ií]stic\w*|quantos processos|taxa de \w+|no|na|do|da|de|sobre|em)\b", " ", s["texto"])
    tema = " ".join(re.sub(r"(?i)\b" + re.escape(trib) + r"\b", " ", tema).split())
    from ..integracoes import datajud, tpu
    assunto = None
    if len(tema) >= 4:
        try:
            achados = tpu.pesquisar("assunto", tema, "nome")
            assunto = achados[0]["codigo"] if achados else None
        except tpu.ErroTPU:
            assunto = None
    try:
        r = datajud.jurimetria(trib.lower(), assunto=assunto)
    except datajud.ErroDataJud as e:
        return R(f"DataJud indisponível: {e}")
    linhas = [f"{x.get('orgao') or x.get('nome')}: {x.get('total') or x.get('processos')}" for x in (r.get("por_orgao") or [])[:8]]
    return R(f"{r.get('total')} processo(s) no {trib}" + (f" com assunto TPU {assunto}" if assunto else "") +
             ". Estatística descritiva: movimento de julgamento não equivale ao desfecho final.",
             [{"tipo": "resultado", "titulo": "Jurimetria descritiva (DataJud)", "linhas": linhas,
               "memoria": [f"{k}: {v}" for k, v in (r.get("desfechos") or r.get("movimentos") or {}).items()]}])


def ex_ajuda(db: Session, s: dict) -> dict:
    return R("Escreva o que precisa, do jeito que falaria com um colega. Exemplos:",
             [{"tipo": "lista", "titulo": "O que eu faço", "itens": [
                 {"titulo": v["descricao"]} for k, v in intencoes.INTENCOES.items() if k != "ajuda"]}],
             opcoes=["O que tenho para hoje?", "Prazo de 15 dias úteis a partir de hoje", "O que diz o art. 219 do CPC?",
                     "Redigir contestação", "Há projetos de lei sobre licitações?"])


EXECUTORES = {"briefing": ex_briefing, "prazo": ex_prazo, "intimacao": ex_intimacao, "_prazo_intimacao": ex_prazo_intimacao,
              "redigir": ex_redigir, "processo": ex_processo, "lei": ex_lei, "sumula": ex_sumula, "pesquisa": ex_pesquisa,
              "verificar": ex_verificar, "prescricao": ex_prescricao, "intercorrente": ex_intercorrente,
              "valor_causa": ex_valor_causa, "licitacao": ex_licitacao, "contradicoes": ex_contradicoes,
              "legislativo": ex_legislativo, "jurimetria": ex_jurimetria, "ajuda": ex_ajuda}


# ================================================================== preenchimento de dados faltantes
def _preencher(slot: str, texto: str, ent: dict, slots: dict, db: Session) -> bool:
    t = normalizar(texto)
    if slot == "data":
        if ent["datas"]:
            slots["data"] = ent["datas"][0]
            return True
    elif slot == "dias":
        if ent["dias"]:
            slots["dias"], slots["contagem"] = ent["dias"][0]["dias"], ent["dias"][0]["contagem"] or slots.get("contagem")
            return True
        m = re.match(r"^\s*(\d{1,3})\s*$", t)
        if m:
            slots["dias"] = int(m.group(1))
            return True
    elif slot == "caso":
        if "sem caso" in t:
            slots["sem_caso"] = True
            return True
        cid = _caso_de_texto(db, texto)
        if cid:
            slots["caso_id"] = cid
            return True
    elif slot == "tipo_peca":
        if ent.get("tipo_peca"):
            slots["tipo_peca"] = ent["tipo_peca"]
            return True
        slots["tipo_peca"] = texto.strip()[:80]
        return True
    elif slot == "numero":
        if ent["cnj"]:
            slots["numero"] = ent["cnj"][0]
            return True
    elif slot == "anos":
        m = re.search(r"(\d{1,2})", t)
        if m:
            slots["anos"] = int(m.group(1))
            return True
    elif slot == "rito_txt":
        slots["rito"] = "lef" if "fiscal" in t else "cpc"
        return True
    elif slot == "modo_txt":
        slots["modo"] = "impugnacao" if "impugn" in t else "recurso" if "recurs" in t else "habilitacao"
        return True
    elif slot in ("tipo_txt", "tema", "valores", "dispositivo", "tribunal"):
        slots[slot] = texto.strip()
        if slot == "tribunal":
            slots["tribunal"] = (ent["tribunais"] or [texto.strip().upper()])[0]
        return True
    return False


def _classificar_ia(texto: str) -> str | None:
    """Desempate por IA, só com provedor real. Saída restrita às intenções conhecidas."""
    cfg = get_config()
    if cfg.llm_provider == "mock":
        return None
    try:
        from ..llm.provedores import construir, extrair_json
        lista = "; ".join(f"{k}: {v['descricao']}" for k, v in intencoes.INTENCOES.items())
        tk = salvaguardas.novo_token()
        r = construir().gerar("classificar_intencao", "Classifique o pedido do advogado em UMA das intenções. Responda só JSON "
                              '{"intencao": str}. Intenções: ' + lista + salvaguardas.INSTRUCAO_SISTEMA,
                              salvaguardas.bloco("PEDIDO", texto, tk, 2000), {}, max_tokens=60)
        nome = extrair_json(r.texto).get("intencao")
        return nome if nome in intencoes.INTENCOES else None
    except Exception:  # noqa: BLE001
        return None


# ================================================================== orquestração
def conversa(db: Session, conversa_id: int | None, caso_id: int | None = None) -> Conversa:
    ctx = acesso.atual()
    if conversa_id:
        c = db.get(Conversa, conversa_id)
        if not c or (c.usuario_id != ctx.id and not ctx.admin) or (c.usuario_id is None and ctx.id is not None and not ctx.admin):
            raise acesso.SemPermissao("Conversa inexistente ou sem acesso.")
        if caso_id is not None:
            c.caso_id = caso_id or None
        return c
    c = Conversa(usuario=ctx.nome, usuario_id=ctx.id, caso_id=caso_id or None, estado={})
    db.add(c)
    db.commit()
    return c


def _registrar(db: Session, c: Conversa, papel: str, texto: str, dados: dict | None = None) -> None:
    db.add(MensagemAssistente(conversa_id=c.id, papel=papel, texto=texto, dados=dados or {}))
    db.commit()


def _executar(db: Session, c: Conversa, nome: str, slots: dict, texto: str, ent: dict) -> dict:
    s = {**slots, "texto": slots.get("texto_original") or texto, "ent": ent, "caso_id": slots.get("caso_id") or c.caso_id}
    try:
        r = EXECUTORES[nome](db, s)
    except acesso.SemPermissao as e:
        r = R(str(e))
    except ValueError as e:
        r = R(f"Não consegui concluir: {e}")
    if isinstance(r, Falta):
        est = dict(c.estado or {})
        est["pendente"] = {"intencao": nome, "slots": {**slots, "texto_original": s["texto"]}, "falta": r.slot}
        c.estado = est
        db.commit()
        return R(r.pergunta, opcoes=r.opcoes) | {"intencao": nome, "aguardando": r.slot}
    est = dict(c.estado or {})
    est.pop("pendente", None)
    if r.get("pendente"):
        est["pendente"] = r.pop("pendente")
    c.estado = est
    db.commit()
    return r | {"intencao": nome}


def processar(db: Session, conversa_id: int | None, texto: str, caso_id: int | None = None) -> dict:
    texto = (texto or "").strip()
    if caso_id:
        acesso.exigir_caso(db, caso_id)
    c = conversa(db, conversa_id, caso_id)
    _registrar(db, c, "usuario", texto)
    ent = ent_mod.extrair(texto)
    cls = intencoes.classificar(texto, ent)
    pend = (c.estado or {}).get("pendente")
    if pend:
        slots = dict(pend["slots"])
        novo_forte = cls["intencao"] and cls["intencao"] != pend["intencao"] and cls["confianca"] >= 0.75 and len(texto) > 25
        if not novo_forte and _preencher(pend["falta"], texto, ent, slots, db):
            ent_orig = ent_mod.extrair(slots.get("texto_original", ""))
            for k in ("datas", "dias"):
                if not ent_orig[k] and ent[k]:
                    ent_orig[k] = ent[k]
            r = _executar(db, c, pend["intencao"], slots, texto, ent_orig)
            r["conversa_id"] = c.id
            _registrar(db, c, "assistente", r["texto"], r)
            return r
    nome = cls["intencao"]
    if not nome or cls["confianca"] < 0.5:
        nome = _classificar_ia(texto) or nome
    if not nome:
        if len(texto) > 400:
            r = analisar_texto(db, c, texto)
        else:
            r = R("Não entendi o que precisa. Escolha um caminho ou reescreva com mais detalhe.",
                  opcoes=["Calcular um prazo", "Redigir uma peça", "Pesquisar jurisprudência", "O que tenho para hoje?"])
    else:
        r = _executar(db, c, nome, {"caso_id": c.caso_id}, texto, ent)
        r["confianca"] = cls["confianca"]
    r["conversa_id"] = c.id
    _registrar(db, c, "assistente", r["texto"], r)
    auditoria.registrar(db, "assistente:mensagem", f"conversa:{c.id}", {"intencao": r.get("intencao"), "confianca": cls["confianca"]})
    return r


def analisar_texto(db: Session, c: Conversa, texto: str, caso_id: int | None = None, nome: str = "texto colado") -> dict:
    """Triagem de um documento ou texto longo: tipo de ato, dados extraídos e providência com prazo."""
    ent = ent_mod.extrair(texto)
    tri = triagem.classificar(texto)
    provs = triagem.providencias(tri["tipo"], tri["jec"])
    linhas = [f"Tipo identificado: {tri['rotulo']} (confiança {tri['confianca']})" + (" · rito do juizado especial" if tri["jec"] else "")]
    if ent["cnj"]:
        linhas.append("Processo: " + ", ".join(ent["cnj"]))
    if ent["datas"]:
        linhas.append("Datas no documento: " + ", ".join(_br(d) for d in ent["datas"][:5]))
    if ent["valores"]:
        linhas.append("Valores: " + ", ".join(f"R$ {v}" for v in ent["valores"][:5]))
    cid = caso_id or c.caso_id or _caso_de_texto(db, texto)
    acoes = []
    for p in provs:
        params = {"peca": p["peca"], "dias": p["dias"], "contagem": p["contagem"], "base": p["base"], "caso_id": cid}
        if p["dias"]:
            acoes.append({"rotulo": f"Prazo de {p['peca'].lower()} ({p['dias']} dias)", "acao": "prazo_sugerido", "params": params,
                          "estilo": "principal" if p is provs[0] else ""})
        if cid:
            acoes.append({"rotulo": f"Redigir {p['peca'].lower()}", "acao": "redigir",
                          "params": {"tipo_peca": p["peca"], "caso_id": cid, "pedido": f"{p['peca']} em face de {tri['rotulo'].lower()}: {texto[:800]}"}})
    if tri["tipo"].startswith("intimacao") and _pode_gravar():
        acoes.append({"rotulo": "Registrar como intimação", "acao": "registrar_intimacao", "params": {"texto": texto[:20000], "caso_id": cid}})
    if ent["cnj"]:
        acoes.append({"rotulo": "Consultar processo no DataJud", "acao": "mensagem", "params": {"texto": f"Consultar processo {ent['cnj'][0]}"}})
    card = {"tipo": "resultado", "titulo": f"Triagem: {nome}", "destaque": tri["rotulo"], "linhas": linhas,
            "alertas": [f"{p['peca']}: {p['dias'] or 'prazo conforme rito'} dias {('úteis' if p['contagem'] == 'uteis' else 'corridos') if p['dias'] else ''} · {p['base']}. {p['nota']}".strip()
                        for p in provs] + ["Sugestão inicial: confira termo inicial, prazo em dobro (CPC, arts. 180, 183, 186 e 229) e cabimento."]}
    return R(f"Identifiquei {tri['rotulo'].lower()}." + (f" Providência provável: {provs[0]['peca'].lower()}." if provs else ""), [card], acoes) | {"intencao": "triagem"}


def acao(db: Session, conversa_id: int | None, nome: str, params: dict) -> dict:
    """Ações estruturadas disparadas por botões (sem interpretação de texto)."""
    c = conversa(db, conversa_id)
    from ..agente import pipeline
    try:
        if nome == "mensagem":
            return processar(db, c.id, params.get("texto", ""))
        if nome in ("responder_minuta", "aprovar_roteiro", "retomar_minuta"):
            m = db.get(Minuta, int(params["minuta_id"]))
            if not m:
                raise ValueError("Minuta inexistente.")
            acesso.exigir_caso(db, m.caso_id, edicao=True)
            m = (pipeline.responder(db, m.id, params.get("respostas") or {}) if nome == "responder_minuta"
                 else pipeline.aprovar_roteiro(db, m.id) if nome == "aprovar_roteiro" else pipeline.retomar(db, m.id))
            r = _resposta_minuta(m)
        elif nome == "redigir":
            slots = {"tipo_peca": params.get("tipo_peca"), "caso_id": params.get("caso_id"), "pedido": params.get("pedido")}
            if not params.get("caso_id"):
                slots["sem_caso"] = True
            r = _executar(db, c, "redigir", slots, params.get("pedido") or params.get("tipo_peca", ""), ent_mod.extrair(""))
        elif nome == "criar_caso_documento":
            if not _pode_gravar():
                raise acesso.SemPermissao("Perfil de leitura não cria casos.")
            from pathlib import Path
            from ..servicos import documentos
            tmp = Path(get_config().arquivos_dir) / "tmp" / f"{params['sha']}.bin"
            if not tmp.exists():
                raise ValueError("Arquivo temporário expirado: envie o documento de novo.")
            caso = Caso(titulo=params.get("titulo") or f"Caso de {params.get('nome')}", numero_processo=params.get("numero"),
                        dono_id=acesso.atual().id)
            db.add(caso)
            db.commit()
            doc, _ = documentos.ingerir_documento(db, caso.id, params.get("nome") or "documento", tmp.read_bytes(), usuario=acesso.atual().nome)
            tmp.unlink(missing_ok=True)
            c.caso_id = caso.id
            db.commit()
            auditoria.registrar(db, "caso:criar", f"caso:{caso.id}", {"origem": "assistente", "documento": doc.id})
            r = R(f"Caso #{caso.id} criado com o documento anexado e selecionado nesta conversa.") | {"caso_id": caso.id}
        elif nome == "prazo_sugerido":
            slots = {k: params.get(k) for k in ("dias", "contagem", "base", "peca", "caso_id")}
            if params.get("contagem") == "uteis_antes":
                slots["modo"] = "impugnacao"
                r = _executar(db, c, "licitacao", slots, "impugnação ao edital", ent_mod.extrair(""))
            else:
                slots["termo"] = "ciencia"
                r = _executar(db, c, "prazo", slots, f"prazo de {params.get('dias')} dias", ent_mod.extrair(""))
        elif nome == "registrar_intimacao":
            r = _executar(db, c, "intimacao", {"caso_id": params.get("caso_id")}, params.get("texto", ""), ent_mod.extrair(params.get("texto", "")))
        elif nome == "criar_caso_processo":
            if not _pode_gravar():
                raise acesso.SemPermissao("Perfil de leitura não cria casos.")
            from ..integracoes import datajud
            a = sorted(datajud.consultar_processo(params["numero"]), key=lambda x: x.get("atualizado_em") or "")[-1]
            caso = Caso(titulo=f"Processo {params['numero']} ({(a.get('classe') or {}).get('nome', '')})", numero_processo=params["numero"],
                        tribunal=a["tribunal"], classe_tpu=a.get("classe"), assuntos_tpu=a.get("assuntos") or [],
                        orgao_julgador=(a.get("orgao_julgador") or {}).get("nome"), metadados_datajud=a, dono_id=acesso.atual().id)
            db.add(caso)
            db.commit()
            c.caso_id = caso.id
            db.commit()
            auditoria.registrar(db, "caso:criar", f"caso:{caso.id}", {"origem": "datajud"})
            r = R(f"Caso #{caso.id} criado com os dados do DataJud e selecionado nesta conversa. Envie os autos para eu analisar.") | {"caso_id": caso.id}
        elif nome == "enriquecer_caso":
            acesso.exigir_caso(db, int(params["caso_id"]), edicao=True)
            from ..integracoes import datajud
            caso = db.get(Caso, int(params["caso_id"]))
            a = sorted(datajud.consultar_processo(caso.numero_processo), key=lambda x: x.get("atualizado_em") or "")[-1]
            caso.tribunal, caso.classe_tpu, caso.assuntos_tpu = a["tribunal"], a.get("classe"), a.get("assuntos") or []
            caso.orgao_julgador, caso.metadados_datajud = (a.get("orgao_julgador") or {}).get("nome"), a
            db.commit()
            r = R(f"Caso #{caso.id} atualizado com classe, assuntos e órgão julgador do DataJud.")
        elif nome == "coletar_planalto":
            if acesso.atual().papel not in ("admin", "advogado"):
                raise acesso.SemPermissao("Somente advogado ou administrador altera a base.")
            from ..servicos import legislacao
            res = legislacao.importar_planalto(db, params.get("slugs") or [])
            ok = [f"{x['slug']}: {x.get('artigos')} artigos" for x in res["diplomas"] if x["status"] in ("ok", "inalterado")]
            r = R("Coleta concluída: " + "; ".join(ok) + (". Erros: " + "; ".join(x["erro"] for x in res["erros"]) if res["erros"] else "."),
                  opcoes=["Repita a última pergunta"])
        elif nome in ("abrir_minuta", "baixar_minuta", "abrir_fontes"):
            r = R("Esta ação abre uma tela da interface.")
        else:
            raise ValueError(f"Ação desconhecida: {nome}")
    except acesso.SemPermissao as e:
        r = R(str(e))
    except (ValueError, pipeline.ErroFluxo) as e:
        r = R(f"Não consegui concluir: {e}")
    except Exception as e:  # noqa: BLE001
        r = R(f"Falha ao executar: {str(e)[:300]}")
    r["conversa_id"] = c.id
    _registrar(db, c, "assistente", r["texto"], r)
    return r
