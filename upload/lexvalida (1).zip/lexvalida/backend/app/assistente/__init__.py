"""Assistente único: o advogado escreve o que precisa e o sistema escolhe a ferramenta, pede só o que
falta e devolve o resultado verificado, com a base legal e o caminho para a próxima providência."""
