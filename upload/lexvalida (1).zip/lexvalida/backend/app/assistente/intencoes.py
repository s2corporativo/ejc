"""Classificação determinística de intenção (auditável, sem custo), no mesmo espírito do classificador do
núcleo EJC: padrões por intenção + reforço pelas entidades encontradas. Empate ou baixa confiança podem ser
resolvidos por IA quando houver provedor real configurado; sem isso, o assistente pergunta."""
from __future__ import annotations

import re

from ..core.texto import normalizar

# nome: (descrição para o usuário, padrões, reforços por entidade)
INTENCOES: dict[str, dict] = {
    "briefing": {"descricao": "Resumo do dia: prazos, alertas e pendências",
                 "padroes": [r"\bo que (?:eu )?tenho\b", r"resumo do dia", r"\bagenda\b", r"\bpend[eê]ncias?\b",
                             r"prazos? (?:da|desta|dessa|na) semana", r"\bvencendo\b|\bvencem\b|\bvence (?:hoje|amanh)",
                             r"^bom dia|^boa tarde|^boa noite", r"o que (?:esta|est[aá]) pendente"]},
    "intimacao": {"descricao": "Registrar intimação colada e calcular o prazo",
                  "padroes": [r"fica(?:m)?\b.{0,40}intimad", r"\bintima[cç][aã]o\b.{40,}"],
                  "entidades": {"cnj": 1, "dias": 1}},
    "prazo": {"descricao": "Calcular prazo processual",
              "padroes": [r"\bprazo\b", r"quando vence", r"\bvencimento\b", r"contar (?:o )?prazo", r"dias [uú]teis"],
              "entidades": {"dias": 2, "datas": 1}},
    "redigir": {"descricao": "Redigir peça com supervisão",
                "padroes": [r"\b(?:redij|redigir|elabor|minut|escrev|prepar|fa[cç]a|fazer|montar|gerar?)\w*\b.{0,40}"
                            r"(?:pe[cç]a|peti[cç]|contesta|recurso|apela|agravo|r[eé]plica|embargos|inicial|manifesta|impugna|defesa|notifica|parecer|tutela|mandado)"],
                "entidades": {"tipo_peca": 2}},
    "processo": {"descricao": "Consultar processo no DataJud (CNJ)",
                 "padroes": [r"\b(?:consult|andamento|movimenta|situa[cç][aã]o do processo|como est[aá] o processo)"],
                 "entidades": {"cnj": 3}},
    "lei": {"descricao": "Texto de dispositivo legal",
            "padroes": [r"o que diz|texto d[oa]|reda[cç][aã]o d[oa]|transcrev|me mostre o art"],
            "entidades": {"dispositivos": 3}},
    "sumula": {"descricao": "Súmula na base", "padroes": [r"\bs[uú]mula\b"], "entidades": {"sumulas": 3}},
    "pesquisa": {"descricao": "Pesquisa de jurisprudência e legislação",
                 "padroes": [r"jurisprud|precedente|entendimento|\bteses?\b|pesquis|julgados?|o que os tribunais"]},
    "verificar": {"descricao": "Verificar citações e riscos de um texto",
                  "padroes": [r"\{\{(?:juris|lei):", r"\[\[autos:", r"verifi\w+ (?:este|esse|o) texto|confir\w+ (?:as )?cita|revis\w+ (?:este|esse) texto"]},
    "prescricao": {"descricao": "Prescrição", "padroes": [r"prescri[cç][aã]o|prescreve|prescrit"]},
    "intercorrente": {"descricao": "Prescrição intercorrente", "padroes": [r"intercorrente"]},
    "valor_causa": {"descricao": "Valor da causa", "padroes": [r"valor da causa"], "entidades": {"valores": 1}},
    "licitacao": {"descricao": "Licitações: impugnação, recurso e habilitação",
                  "padroes": [r"\bedital\b|licita|preg[aã]o|habilita[cç][aã]o|impugna[cç][aã]o ao edital|impugnar o edital",
                              r"impugna\w*\s+(?:ao |o |do )?edital|recurso (?:na|da) licita|matriz de habilita"]},
    "contradicoes": {"descricao": "Contradições entre documentos do caso", "padroes": [r"contradi|inconsist|diverg[eê]ncia entre"]},
    "legislativo": {"descricao": "Projetos de lei em tramitação",
                    "padroes": [r"projetos? de lei|\bpls?\b \d|proposi[cç]|tramita|congresso|c[aâ]mara dos deputados|senado",
                                r"projetos? de lei|proposi[cç][oõ]es"]},
    "jurimetria": {"descricao": "Jurimetria descritiva (DataJud)",
                   "padroes": [r"jurimetria|estat[ií]stic|quantos processos|taxa de (?:proced|acolh|sucesso)"]},
    "ajuda": {"descricao": "O que o assistente faz", "padroes": [r"^ajuda|o que voc[eê] (?:faz|sabe)|como funciona|como (?:te |voce )?uso"]},
}
# empate: a ordem desempata (mais específico primeiro)
PRIORIDADE = ["intimacao", "intercorrente", "verificar", "redigir", "lei", "sumula", "processo", "valor_causa", "legislativo",
              "licitacao", "contradicoes", "prescricao", "prazo", "jurimetria", "pesquisa", "briefing", "ajuda"]


def pontuar(texto: str, ent: dict) -> list[tuple[float, str]]:
    t = normalizar(texto or "")
    out = []
    for nome, cfg in INTENCOES.items():
        p = sum(2 for rx in cfg["padroes"] if re.search(rx, t))
        if p == 0 and not any(ent.get(e) for e in cfg.get("entidades", {})):
            continue
        p += sum(peso for e, peso in cfg.get("entidades", {}).items() if ent.get(e))
        if p:
            out.append((p, nome))
    # texto longo colado com "intimad" é intimação, não pedido de prazo genérico
    if (len(t) > 120 and re.search(r"intimad|intima[cç][aã]o", t)) or re.search(r"fica(?:m)?\b.{0,40}intimad", t):
        out = [x for x in out if x[1] != "intimacao"] + [(9, "intimacao")]
    # verbo de redação com tipo de peça prevalece sobre "prazo" mencionado de passagem
    out.sort(key=lambda x: (-x[0], PRIORIDADE.index(x[1])))
    return out


def classificar(texto: str, ent: dict) -> dict:
    ps = pontuar(texto, ent)
    if not ps:
        return {"intencao": None, "confianca": 0.0, "candidatas": []}
    melhor, nome = ps[0]
    segundo = ps[1][0] if len(ps) > 1 else 0
    conf = round(min(1.0, melhor / 4) * (0.6 if segundo == melhor else 1.0), 2)
    return {"intencao": nome, "confianca": conf, "candidatas": [n for _, n in ps[:3]]}
