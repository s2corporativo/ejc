"""Provedores de LLM com interface única.

- anthropic: Messages API (https://api.anthropic.com/v1/messages).
- openai_compat: qualquer endpoint /chat/completions (Ollama, vLLM, LM Studio, Groq, OpenAI).
- mock: determinístico e offline, para testes e demonstração. Não tem conhecimento jurídico:
  só reorganiza o material recebido (pesquisas, autos, modelos) e emite marcadores.

Roteamento de sigilo: caso marcado como sigiloso só pode usar o provedor LOCAL.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field

import httpx

from ..config import Config, get_config


@dataclass
class Resposta:
    texto: str
    raciocinio: str = ""
    provedor: str = ""
    modelo: str = ""
    uso: dict = field(default_factory=dict)


class ErroProvedor(RuntimeError):
    pass


class Provedor:
    nome = "base"

    def gerar(self, tarefa: str, sistema: str, usuario: str, dados: dict | None = None,
              max_tokens: int = 4000, temperatura: float = 0.2) -> Resposta:  # pragma: no cover
        raise NotImplementedError


class Anthropic(Provedor):
    nome = "anthropic"

    def __init__(self, modelo: str, chave: str, base_url: str = "", timeout: float = 180):
        if not modelo or not chave:
            raise ErroProvedor("Defina LLM_MODEL e LLM_API_KEY para o provedor anthropic.")
        self.modelo, self.chave = modelo, chave
        self.url = (base_url or "https://api.anthropic.com").rstrip("/") + "/v1/messages"
        self.timeout = timeout

    def gerar(self, tarefa, sistema, usuario, dados=None, max_tokens=4000, temperatura=0.2):
        r = httpx.post(self.url, timeout=self.timeout, headers={
            "x-api-key": self.chave, "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": self.modelo, "max_tokens": max_tokens, "temperature": temperatura,
                  "system": sistema, "messages": [{"role": "user", "content": usuario}]})
        if r.status_code >= 400:
            raise ErroProvedor(f"Anthropic {r.status_code}: {r.text[:300]}")
        d = r.json()
        texto = "".join(b.get("text", "") for b in d.get("content", []) if b.get("type") == "text")
        raciocinio = "".join(b.get("thinking", "") for b in d.get("content", []) if b.get("type") == "thinking")
        return Resposta(texto, raciocinio, self.nome, self.modelo, d.get("usage", {}))


class OpenAICompat(Provedor):
    nome = "openai_compat"

    def __init__(self, modelo: str, base_url: str, chave: str = "", timeout: float = 180):
        if not modelo or not base_url:
            raise ErroProvedor("Defina modelo e base_url do provedor compatível (ex.: http://localhost:11434/v1).")
        self.modelo, self.url, self.chave, self.timeout = modelo, base_url.rstrip("/") + "/chat/completions", chave, timeout

    def gerar(self, tarefa, sistema, usuario, dados=None, max_tokens=4000, temperatura=0.2):
        headers = {"content-type": "application/json"}
        if self.chave:
            headers["authorization"] = f"Bearer {self.chave}"
        r = httpx.post(self.url, timeout=self.timeout, headers=headers, json={
            "model": self.modelo, "max_tokens": max_tokens, "temperature": temperatura,
            "messages": [{"role": "system", "content": sistema}, {"role": "user", "content": usuario}]})
        if r.status_code >= 400:
            raise ErroProvedor(f"{self.url} {r.status_code}: {r.text[:300]}")
        d = r.json()
        msg = d["choices"][0]["message"]
        texto = msg.get("content") or ""
        raciocinio = msg.get("reasoning_content") or msg.get("reasoning") or ""
        m = re.search(r"<think>(.*?)</think>", texto, re.S)  # modelos que expõem raciocínio inline
        if m:
            raciocinio, texto = m.group(1), texto.replace(m.group(0), "").strip()
        return Resposta(texto, raciocinio, self.nome, self.modelo, d.get("usage", {}))


def construir(cfg: Config | None = None, papel: str = "redator", sigiloso: bool = False) -> Provedor:
    cfg = cfg or get_config()
    if sigiloso:
        if cfg.local_provider_base_url and cfg.local_provider_model:
            return OpenAICompat(cfg.local_provider_model, cfg.local_provider_base_url, "", cfg.timeout_llm)
        if cfg.llm_provider == "mock":
            from .mock import Mock
            return Mock()
        raise ErroProvedor("Caso sigiloso: configure LOCAL_LLM_BASE_URL/LOCAL_LLM_MODEL (ex.: Ollama) "
                           "ou anonimize os documentos antes. Envio a nuvem bloqueado.")
    if papel == "verificador" and cfg.verificador_provider:
        prov, modelo, base, chave = cfg.verificador_provider, cfg.verificador_model, cfg.verificador_base_url, cfg.verificador_api_key
    else:
        prov, modelo, base, chave = cfg.llm_provider, cfg.llm_model, cfg.llm_base_url, cfg.llm_api_key
    if prov == "anthropic":
        return Anthropic(modelo, chave, base, cfg.timeout_llm)
    if prov == "openai_compat":
        return OpenAICompat(modelo, base, chave, cfg.timeout_llm)
    if prov == "mock":
        from .mock import Mock
        return Mock()
    raise ErroProvedor(f"Provedor desconhecido: {prov}")


def extrair_json(texto: str):
    """Extrai o primeiro objeto ou lista JSON do texto (tolera cercas ```json)."""
    texto = re.sub(r"```(?:json)?", "", texto)
    for abre, fecha in (("{", "}"), ("[", "]")):
        ini = texto.find(abre)
        while ini != -1:
            prof = 0
            for i in range(ini, len(texto)):
                if texto[i] == abre:
                    prof += 1
                elif texto[i] == fecha:
                    prof -= 1
                    if prof == 0:
                        try:
                            return json.loads(texto[ini:i + 1])
                        except json.JSONDecodeError:
                            break
            ini = texto.find(abre, ini + 1)
    raise ValueError("Resposta do modelo sem JSON válido.")
