"""Usuários, papéis e isolamento por caso.

Autenticação por token (cabeçalho X-API-Token):
  - API_TOKEN do ambiente: administrador técnico (acesso total);
  - token individual de usuário: guardado apenas como SHA-256 (o token em claro é exibido uma única vez);
  - sem API_TOKEN e sem usuários cadastrados: modo local de desenvolvimento (acesso total, sem login).

Papéis: admin (tudo), advogado (casos próprios e compartilhados; edita e aprova), estagiario (casos
compartilhados; edita, não aprova), leitor (só leitura nos casos compartilhados).
Isolamento: casos, documentos, autos, minutas, provas, intimações e alertas de um caso só aparecem para
quem é dono do caso, recebeu acesso ou é admin. A busca nos autos é sempre filtrada pelo caso.
"""
from __future__ import annotations

import hmac
import secrets
from contextvars import ContextVar
from dataclasses import dataclass

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..config import get_config
from ..core.integridade import sha256_texto
from ..models import AcessoCaso, Caso, Usuario

PAPEIS = {"admin", "advogado", "estagiario", "leitor"}


@dataclass(frozen=True)
class Contexto:
    id: int | None
    nome: str
    papel: str

    @property
    def admin(self) -> bool:
        return self.papel == "admin"

    @property
    def pode_aprovar(self) -> bool:
        return self.papel in ("admin", "advogado")


LOCAL = Contexto(None, "local", "admin")
_atual: ContextVar[Contexto] = ContextVar("usuario_atual", default=LOCAL)


class SemPermissao(PermissionError):
    pass


class NaoAutenticado(PermissionError):
    pass


def atual() -> Contexto:
    return _atual.get()


def definir(ctx: Contexto):
    return _atual.set(ctx)


def _hash(token: str) -> str:
    return sha256_texto(token)


def autenticar(db: Session, token: str | None) -> Contexto:
    mestre = get_config().api_token
    if token and mestre and hmac.compare_digest(token, mestre):
        return Contexto(None, "administrador", "admin")
    if token:
        u = db.scalar(select(Usuario).where(Usuario.token_hash == _hash(token), Usuario.ativo.is_(True)))
        if u:
            return Contexto(u.id, u.nome, u.papel)
        raise NaoAutenticado("Token de API ausente ou inválido.")
    if not mestre and not db.scalar(select(func.count()).select_from(Usuario)):
        return LOCAL
    raise NaoAutenticado("Token de API ausente ou inválido.")


def criar_usuario(db: Session, nome: str, email: str, papel: str) -> tuple[Usuario, str]:
    if papel not in PAPEIS:
        raise ValueError(f"Papel inválido. Use: {sorted(PAPEIS)}")
    if db.scalar(select(Usuario).where(Usuario.email == email)):
        raise ValueError("E-mail já cadastrado.")
    if not get_config().api_token and not db.scalar(select(func.count()).select_from(Usuario)) and papel != "admin":
        raise ValueError("Sem API_TOKEN configurado, o primeiro usuário precisa ser admin (o modo local aberto termina ao criá-lo).")
    token = secrets.token_urlsafe(32)
    u = Usuario(nome=nome, email=email, papel=papel, token_hash=_hash(token))
    db.add(u)
    db.commit()
    return u, token


def renovar_token(db: Session, usuario_id: int) -> str:
    u = db.get(Usuario, usuario_id)
    if not u:
        raise ValueError("Usuário inexistente.")
    token = secrets.token_urlsafe(32)
    u.token_hash = _hash(token)
    db.commit()
    return token


def permissao_caso(db: Session, ctx: Contexto, caso_id: int) -> str | None:
    """None (sem acesso) | 'leitura' | 'edicao'."""
    if ctx.admin:
        return "edicao"
    caso = db.get(Caso, caso_id)
    if not caso:
        return None
    if ctx.id is not None and caso.dono_id == ctx.id:
        return "leitura" if ctx.papel == "leitor" else "edicao"
    a = db.scalar(select(AcessoCaso).where(AcessoCaso.caso_id == caso_id, AcessoCaso.usuario_id == ctx.id))
    if not a:
        return None
    return "leitura" if ctx.papel == "leitor" else a.permissao


def exigir_caso(db: Session, caso_id: int | None, edicao: bool = False, ctx: Contexto | None = None) -> None:
    """Sem caso vinculado: livre para usuários autenticados (material sem dados de cliente)."""
    if caso_id is None:
        ctx = ctx or atual()
        if edicao and ctx.papel == "leitor":
            raise SemPermissao("Perfil de leitura não altera dados.")
        return
    ctx = ctx or atual()
    p = permissao_caso(db, ctx, caso_id)
    if p is None:
        # Mesma resposta de "inexistente" para não revelar a existência de casos de terceiros.
        raise SemPermissao(f"Caso {caso_id} inexistente ou sem acesso.")
    if edicao and p != "edicao":
        raise SemPermissao("Seu acesso a este caso é somente leitura.")


def casos_visiveis(db: Session, ctx: Contexto | None = None) -> set[int] | None:
    """None = todos (admin)."""
    ctx = ctx or atual()
    if ctx.admin:
        return None
    proprios = set(db.scalars(select(Caso.id).where(Caso.dono_id == ctx.id))) if ctx.id is not None else set()
    compart = set(db.scalars(select(AcessoCaso.caso_id).where(AcessoCaso.usuario_id == ctx.id)))
    return proprios | compart


def conceder(db: Session, caso_id: int, usuario_id: int, permissao: str) -> AcessoCaso:
    if permissao not in ("leitura", "edicao"):
        raise ValueError("Permissão inválida: leitura ou edicao.")
    if not db.get(Usuario, usuario_id):
        raise ValueError("Usuário inexistente.")
    a = db.scalar(select(AcessoCaso).where(AcessoCaso.caso_id == caso_id, AcessoCaso.usuario_id == usuario_id))
    if a:
        a.permissao = permissao
    else:
        a = AcessoCaso(caso_id=caso_id, usuario_id=usuario_id, permissao=permissao)
        db.add(a)
    db.commit()
    return a
