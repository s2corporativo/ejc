"""Avaliação contínua (conjunto de testes de referência) com métricas publicadas.

Formato (JSON, lista de casos):
  {"tipo": "citacao", "texto": "...", "data_fatos": "AAAA-MM-DD", "esperado": {"bloqueado": true, "tipos": ["..."]}}
  {"tipo": "prazo", "entrada": {parâmetros de calcular_prazo}, "esperado": {"vencimento": "AAAA-MM-DD"}}
  {"tipo": "rag", "consulta": "...", "esperado": {"ids": ["..."], "k": 5}}
  {"tipo": "aderencia", "afirmacao": "...", "tese": "...", "esperado": {"classe": "apoio"|"nao_apoio"}}
Métricas: acerto por tipo, recall@k do RAG, taxa de detecção de citação inválida.
"""
from __future__ import annotations

from datetime import date

from sqlalchemy.orm import Session

from ..core.aderencia import heuristica
from ..core.prazos import Calendario, Contagem, Termo, calcular_prazo
from . import conhecimento, documentos


def _prazo(e: dict) -> str:
    cal = Calendario({date.fromisoformat(k): v for k, v in (e.get("feriados_extras") or {}).items()})
    r = calcular_prazo(date.fromisoformat(e["data_evento"]), int(e["dias"]), Termo(e.get("termo", "dje")),
                       Contagem(e.get("contagem", "uteis")), cal, e.get("em_dobro", False), e.get("motivo_dobro"))
    return r.vencimento.isoformat()


def executar(db: Session, casos: list[dict]) -> dict:
    por_tipo: dict[str, list[bool]] = {}
    detalhes, recalls = [], []
    for i, c in enumerate(casos):
        t, esp = c["tipo"], c.get("esperado", {})
        try:
            if t == "citacao":
                r = documentos.resolver_citacoes(db, c["texto"], date.fromisoformat(c["data_fatos"]) if c.get("data_fatos") else None)
                tipos = {p.tipo for p in r.problemas}
                ok = r.bloqueado == esp.get("bloqueado", r.bloqueado) and set(esp.get("tipos", [])) <= tipos
                obtido = {"bloqueado": r.bloqueado, "tipos": sorted(tipos)}
            elif t == "prazo":
                obtido = _prazo(c["entrada"])
                ok = obtido == esp["vencimento"]
            elif t == "rag":
                k = int(esp.get("k", 5))
                ids = [x["id"] for x in conhecimento.pesquisar_jurisprudencia(db, c["consulta"], limite=k, ordenar_por="relevancia")["resultados"]]
                alvo = set(esp["ids"])
                rec = len(alvo & set(ids)) / len(alvo) if alvo else 0.0
                recalls.append(rec)
                ok, obtido = rec == 1.0, ids
            elif t == "aderencia":
                h = heuristica(c["afirmacao"], c["tese"])["classificacao"]
                obtido = "apoio" if h in ("provavel_apoio", "apoio_incerto") else "nao_apoio"
                ok = obtido == esp["classe"]
            else:
                raise ValueError(f"tipo desconhecido: {t}")
        except Exception as e:  # noqa: BLE001
            ok, obtido = False, f"erro: {e}"
        por_tipo.setdefault(t, []).append(ok)
        detalhes.append({"indice": i, "tipo": t, "ok": ok, "obtido": obtido, "esperado": esp})
    metricas = {t: {"casos": len(v), "acertos": sum(v), "acuracia": round(sum(v) / len(v), 3)} for t, v in por_tipo.items()}
    if recalls:
        metricas["rag"]["recall_medio_at_k"] = round(sum(recalls) / len(recalls), 3)
    total = [x for v in por_tipo.values() for x in v]
    return {"executado_em": date.today().isoformat(), "total": len(total),
            "acuracia_geral": round(sum(total) / len(total), 3) if total else None,
            "metricas": metricas, "detalhes": detalhes}
