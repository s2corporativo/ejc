"""Importação do pacote de migração do EJC (EJC_Knowledge_Migration: data/raw/*.jsonl).

Gera-se o pacote na VPS com scripts/export_ejc_knowledge.py (somente leitura). Aqui:
1. valida o manifesto (contagem de linhas e SHA-256 por arquivo) e chunks órfãos, como validate_bundle.py;
2. aplica o mesmo gate de governança do importador direto do EJC:
   - base pública: não excluído, vigente, sem cliente/caso, categoria não restrita, sem bloqueio de
     confiança ou de curadoria, não revogado, não fictício, súmula só se conferida, e (padrão) somente
     rag_status "aprovado";
   - base do escritório (modelos e material interno sem cliente): importada como MODELO ou DOUTRINA
     apenas se revisada ou aprovada;
   - conteúdo de CASO ou vinculado a CLIENTE: nunca importado (sigilo profissional; LGPD, art. 6º, III);
   - corpus fictício (Bíblia EJC): fora por padrão; opcionalmente como modelo de estrutura, marcado;
3. teses institucionais entram como material de apoio (não como precedente);
4. vetores não vêm no pacote: são gerados aqui.
"""
from __future__ import annotations

import hashlib
import io
import json
import zipfile

from sqlalchemy.orm import Session

from . import conhecimento
from .importador_ejc import RESTRITAS, _importar_doc, classificar

RUINS = {"bloqueado", "recusado", "reprovado", "pendente"}
LIMITE_ARQUIVO = 2 * 1024 * 1024 * 1024


class ErroBundle(ValueError):
    pass


def _json(v):
    if isinstance(v, str):
        try:
            return json.loads(v)
        except ValueError:
            return {}
    return v or {}


def _sit(extra: dict) -> str:
    for k in ("legal_status", "situacao_normativa", "vigencia_status"):
        if (extra.get(k) or "").strip():
            return " ".join(extra[k].lower().split())
    return ""


def _escopo(d: dict) -> str:
    b = d.get("base_rag")
    if b in ("publica", "escritorio", "caso"):
        return b
    if d.get("case_id"):
        return "caso"
    if d.get("client_id"):
        return "escritorio"
    return "publica"


def gate(d: dict, exigir_aprovado: bool, incluir_escritorio: bool, incluir_ficticios: bool) -> tuple[str | None, str]:
    """(destino | None, motivo). Destinos: 'publica', 'escritorio', 'ficticio_modelo'."""
    extra = _json(d.get("extra"))
    if d.get("deleted_at"):
        return None, "excluído"
    if d.get("vigente") is False:
        return None, "versão não vigente"
    esc = _escopo(d)
    if esc == "caso" or d.get("case_id"):
        return None, "conteúdo de caso (não migrado)"
    if d.get("client_id"):
        return None, "vinculado a cliente (não migrado)"
    if (extra.get("confidence_level") or "") == "bloqueado" or (extra.get("rag_status") or "") in RUINS:
        return None, f"curadoria: {extra.get('rag_status') or extra.get('confidence_level')}"
    if bool(extra.get("ficticio")):
        return ("ficticio_modelo", "fictício como modelo de estrutura") if incluir_ficticios else (None, "corpus fictício")
    aprovado = (extra.get("rag_status") or "") == "aprovado"
    if esc == "escritorio":
        if not incluir_escritorio:
            return None, "base do escritório não selecionada"
        if not (aprovado or d.get("revisado")):
            return None, "material do escritório sem revisão ou aprovação"
        return "escritorio", ""
    if (d.get("categoria") or "") in RESTRITAS:
        return None, "categoria restrita"
    if _sit(extra) in ("revogada", "revogado"):
        return None, "norma revogada"
    if ((d.get("chave_origem") or "").startswith("sumula:") or d.get("fonte") == "sumula") and not extra.get("conferido"):
        return None, "súmula sem conferência"
    if exigir_aprovado and not aprovado:
        return None, "rag_status diferente de aprovado"
    return "publica", ""


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _linhas(b: bytes) -> list[dict]:
    out = []
    for i, ln in enumerate(b.decode("utf-8").splitlines(), 1):
        if ln.strip():
            try:
                out.append(json.loads(ln))
            except ValueError as e:
                raise ErroBundle(f"JSON inválido na linha {i}: {e}") from e
    return out


def ler_zip(dados: bytes) -> tuple[dict, dict[str, bytes]]:
    try:
        z = zipfile.ZipFile(io.BytesIO(dados))
    except zipfile.BadZipFile as e:
        raise ErroBundle("Arquivo não é um ZIP válido.") from e
    if sum(i.file_size for i in z.infolist()) > LIMITE_ARQUIVO:
        raise ErroBundle("Pacote descompactado acima de 2 GB.")
    nomes = z.namelist()
    mf = next((n for n in nomes if n.endswith("manifests/live_export_manifest.json")), None)
    if not mf:
        tem_modelo = any(n.endswith("bundle_manifest.json") for n in nomes)
        raise ErroBundle("Pacote sem dados exportados (falta manifests/live_export_manifest.json). "
                         + ("Este é o pacote-modelo: rode scripts/export_ejc_knowledge.py na VPS do EJC e envie o resultado compactado."
                            if tem_modelo else ""))
    raiz = mf[: -len("manifests/live_export_manifest.json")]
    manifesto = json.loads(z.read(mf).decode("utf-8"))
    arquivos = {}
    for tabela in ("knowledge_docs", "knowledge_chunks", "fontes_ingestao", "teses", "tese_caso_links"):
        caminho = f"{raiz}data/raw/{tabela}.jsonl"
        if caminho in nomes:
            arquivos[tabela] = z.read(caminho)
    return manifesto, arquivos


def validar(manifesto: dict, arquivos: dict[str, bytes]) -> list[str]:
    erros = []
    for nome, meta in (manifesto.get("tables") or {}).items():
        if meta.get("omitted_by_scope") or meta.get("present") is False:
            continue
        if nome not in arquivos:
            erros.append(f"{nome}: arquivo ausente")
            continue
        linhas = len([l for l in arquivos[nome].decode("utf-8").splitlines() if l.strip()])
        if linhas != meta.get("rows"):
            erros.append(f"{nome}: {linhas} linhas, manifesto declara {meta.get('rows')}")
        if meta.get("sha256") and _sha(arquivos[nome]) != meta["sha256"]:
            erros.append(f"{nome}: SHA-256 divergente do manifesto")
    return erros


def importar_zip(db: Session, dados: bytes, incluir_escritorio: bool = True, incluir_ficticios_como_modelo: bool = False,
                 exigir_aprovado: bool = True, simular: bool = False) -> dict:
    manifesto, arquivos = ler_zip(dados)
    erros = validar(manifesto, arquivos)
    if erros:
        raise ErroBundle("Pacote reprovado na validação: " + "; ".join(erros[:20]))
    docs = _linhas(arquivos.get("knowledge_docs", b""))
    chunks: dict[str, list[dict]] = {}
    orfaos = 0
    ids = {str(d["id"]) for d in docs}
    for ch in _linhas(arquivos.get("knowledge_chunks", b"")):
        did = str(ch.get("doc_id"))
        if did not in ids:
            orfaos += 1
            continue
        chunks.setdefault(did, []).append(ch)
    if orfaos:
        raise ErroBundle(f"Pacote reprovado: {orfaos} trecho(s) apontam para documento inexistente.")
    rel = {"escopo_exportado": manifesto.get("scope"), "exportado_em": manifesto.get("created_at_utc"),
           "documentos_no_pacote": len(docs), "documentos": 0, "normas": 0, "precedentes": 0, "doutrina": 0, "modelos": 0,
           "teses": 0, "trechos": 0, "vetores_reaproveitados": 0, "vetores_recalculados": 0, "ignorados": [],
           "ignorados_por_motivo": {}, "simulacao": simular}
    for d in docs:
        destino, motivo = gate(d, exigir_aprovado, incluir_escritorio, incluir_ficticios_como_modelo)
        if not destino:
            rel["ignorados_por_motivo"][motivo] = rel["ignorados_por_motivo"].get(motivo, 0) + 1
            if len(rel["ignorados"]) < 300:
                rel["ignorados"].append({"id": d.get("id"), "titulo": (d.get("titulo") or "")[:120], "motivo": motivo})
            continue
        partes = sorted(chunks.get(str(d["id"]), []), key=lambda c: c.get("chunk_index") or 0)
        if not partes:
            rel["ignorados_por_motivo"]["sem trechos"] = rel["ignorados_por_motivo"].get("sem trechos", 0) + 1
            continue
        rel["documentos"] += 1
        if simular:
            continue
        extra = _json(d.get("extra"))
        if destino == "publica":
            doc = {"id": d["id"], "titulo": d.get("titulo") or "", "categoria": d.get("categoria") or "",
                   "fonte": d.get("fonte"), "tribunal": d.get("tribunal"), "extra": extra,
                   "chave_origem": d.get("chave_origem"), "versao": d.get("versao")}
            _importar_doc(db, doc, [{"conteudo": c.get("conteudo") or "", "chunk_index": c.get("chunk_index") or 0,
                                     "pagina": c.get("pagina"), "emb": None} for c in partes], False, rel)
        else:
            fonte_tipo = "modelo" if ("modelo" in (d.get("categoria") or "") or "peca" in (d.get("categoria") or "")
                                      or destino == "ficticio_modelo") else "doutrina"
            fid = f"ejc-{d['id']}"
            titulo = ("[FICTÍCIO] " if destino == "ficticio_modelo" else "") + (d.get("titulo") or fid)
            conhecimento.remover_fonte(db, fonte_tipo, fid)
            n = conhecimento.indexar(db, fonte_tipo, fid, "\n\n".join(c.get("conteudo") or "" for c in partes),
                                     origem=f"ejc-bundle:{d['id']}",
                                     extra={"titulo": titulo, "categoria": d.get("categoria"), "escopo": destino,
                                            "ficticio": destino == "ficticio_modelo"})
            rel["trechos"] += len(n)
            rel["modelos" if fonte_tipo == "modelo" else "doutrina"] += 1
    for t in _linhas(arquivos.get("teses", b"")):
        if t.get("deleted_at") or simular:
            continue
        partes = [f"TESE INSTITUCIONAL: {t.get('titulo') or ''}", t.get("descricao") or "",
                  f"Fundamentação: {t['fundamentacao']}" if t.get("fundamentacao") else "",
                  f"Jurisprudência indicada: {t['jurisprudencia']}" if t.get("jurisprudencia") else "",
                  f"Contra-argumento: {t['contra_argumento']}" if t.get("contra_argumento") else ""]
        fid = f"ejc-tese-{t['id']}"
        conhecimento.remover_fonte(db, "doutrina", fid)
        rel["trechos"] += len(conhecimento.indexar(db, "doutrina", fid, "\n".join(p for p in partes if p),
                                                   origem=f"ejc-bundle:tese:{t['id']}",
                                                   extra={"titulo": f"Tese institucional: {t.get('titulo')}", "tipo": "tese_institucional",
                                                          "area": t.get("area_juridica"), "status": t.get("status"),
                                                          "taxa_sucesso": t.get("taxa_sucesso")}))
        rel["teses"] += 1
    return rel
