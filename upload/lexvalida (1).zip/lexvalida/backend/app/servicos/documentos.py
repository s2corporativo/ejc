"""Casos, documentos dos autos e verificação de citações contra a base.

Integridade: cada arquivo recebe SHA-256 e tem o original preservado em ARQUIVOS_DIR. Reenviar um
arquivo idêntico ao mesmo caso é recusado; reenviar com o mesmo nome cria nova VERSÃO e marca a
anterior como substituída (ela continua resolvível para citações antigas, com alerta).
"""
from __future__ import annotations

from datetime import date
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_config
from ..core import citacoes
from ..core.hierarquia import avaliar_status
from ..core.ingestao import DocumentoProcessado, processar_pdf, processar_texto, remover_trechos
from ..core.integridade import descrever, rotulos_documento, sha256_bytes, sha256_texto
from ..models import Caso, Documento, Norma, Precedente, Trecho
from . import conhecimento


class DocumentoDuplicado(ValueError):
    def __init__(self, existente: Documento):
        super().__init__(f"Arquivo idêntico (SHA-256) já consta do caso como documento {existente.id} ({existente.nome}).")
        self.existente = existente


def _preservar(dados: bytes, sha: str, nome: str) -> str:
    pasta = Path(get_config().arquivos_dir)
    pasta.mkdir(parents=True, exist_ok=True)
    ext = Path(nome).suffix.lower()[:10] or ".bin"
    destino = pasta / f"{sha}{ext}"
    if not destino.exists():
        destino.write_bytes(dados)
    return str(destino)


def ingerir_documento(db: Session, caso_id: int, nome: str, dados: bytes, folha_inicial: int | None = None,
                      usuario: str = "local") -> tuple[Documento, DocumentoProcessado]:
    caso = db.get(Caso, caso_id)
    if not caso:
        raise ValueError("Caso inexistente.")
    sha = sha256_bytes(dados)
    dup = db.scalar(select(Documento).where(Documento.caso_id == caso_id, Documento.sha256 == sha,
                                            Documento.substituido.is_(False)))
    if dup:
        raise DocumentoDuplicado(dup)
    if nome.lower().endswith(".pdf"):
        proc, tipo = processar_pdf(dados, nome), "pdf"
    else:
        proc, tipo = processar_texto(dados.decode("utf-8", errors="replace"), nome), "texto"
    anterior = db.scalar(select(Documento).where(Documento.caso_id == caso_id, Documento.nome == nome,
                                                 Documento.substituido.is_(False)).order_by(Documento.versao.desc()))
    doc = Documento(caso_id=caso_id, nome=nome, paginas=proc.paginas, seguranca=proc.relatorio_seguranca(),
                    liberado_para_ia=not proc.risco_alto, tipo=tipo, sha256=sha, tamanho_bytes=len(dados),
                    arquivo=_preservar(dados, sha, nome), versao=(anterior.versao + 1) if anterior else 1,
                    substitui_id=anterior.id if anterior else None, folha_inicial=folha_inicial,
                    rotulos_pagina=rotulos_documento(proc.texto_por_pagina, folha_inicial), ingerido_por=usuario)
    db.add(doc)
    if anterior:
        anterior.substituido = True
    db.commit()
    _indexar_paginas(db, doc, proc)
    return doc, proc


def registrar_texto_derivado(db: Session, caso_id: int, nome: str, tipo: str, paginas: list[str],
                             metadados: dict, extras_por_pagina: list[dict] | None = None,
                             usuario: str = "local", origem_bytes: bytes | None = None) -> Documento:
    """Documento produzido a partir de outra mídia (ex.: transcrição de áudio)."""
    from ..core.ingestao import classificar_trecho
    risco = [i + 1 for i, p in enumerate(paginas) if classificar_trecho(p)["risco"] == "alto"]
    seg = {"documento": nome, "risco_alto": bool(risco), "candidatos_ocultos": [],
           "injecoes_texto_visivel": [{"pagina": i} for i in risco], "paginas_sem_texto_ocr_necessario": []}
    sha = sha256_bytes(origem_bytes) if origem_bytes else sha256_texto("\f".join(paginas))
    doc = Documento(caso_id=caso_id, nome=nome, paginas=len(paginas), seguranca=seg, liberado_para_ia=not risco,
                    tipo=tipo, sha256=sha, tamanho_bytes=len(origem_bytes) if origem_bytes else None,
                    arquivo=_preservar(origem_bytes, sha, nome) if origem_bytes else None,
                    rotulos_pagina=[{"pagina": i} for i in range(1, len(paginas) + 1)], metadados=metadados,
                    ingerido_por=usuario)
    db.add(doc)
    db.commit()
    for i, texto in enumerate(paginas, start=1):
        if texto.strip():
            extra = (extras_por_pagina or [{}] * len(paginas))[i - 1] or None
            conhecimento.indexar(db, "autos", str(doc.id), texto, caso_id=caso_id, pagina=i, extra=extra)
    return doc


def _indexar_paginas(db: Session, doc: Documento, proc: DocumentoProcessado) -> None:
    conhecimento.remover_fonte(db, "autos", str(doc.id))
    for i, texto in enumerate(proc.texto_por_pagina, start=1):
        if texto.strip():
            blocos = [list(b.bbox) for b in proc.blocos if b.pagina == i]
            conhecimento.indexar(db, "autos", str(doc.id), texto, caso_id=doc.caso_id, pagina=i,
                                 bbox=blocos[:50] or None)


def verificar_integridade(db: Session, documento_id: int) -> dict:
    doc = db.get(Documento, documento_id)
    if not doc:
        raise ValueError("Documento inexistente.")
    r = {"documento_id": doc.id, "nome": doc.nome, "versao": doc.versao, "sha256_registrado": doc.sha256,
         "substituido": doc.substituido, "arquivo_preservado": bool(doc.arquivo and Path(doc.arquivo).exists())}
    if r["arquivo_preservado"]:
        atual = sha256_bytes(Path(doc.arquivo).read_bytes())
        r.update(sha256_atual=atual, integro=atual == doc.sha256)
    else:
        r.update(sha256_atual=None, integro=None, nota="Original não preservado neste servidor.")
    return r


def versoes_documento(db: Session, documento_id: int) -> list[dict]:
    doc = db.get(Documento, documento_id)
    if not doc:
        raise ValueError("Documento inexistente.")
    todos = db.scalars(select(Documento).where(Documento.caso_id == doc.caso_id, Documento.nome == doc.nome)
                       .order_by(Documento.versao)).all()
    return [{"id": d.id, "versao": d.versao, "sha256": d.sha256, "substituido": d.substituido,
             "criado_em": d.criado_em.isoformat(), "ingerido_por": d.ingerido_por} for d in todos]


def decidir_trechos_suspeitos(db: Session, documento_id: int, remover: list[str], liberar: bool = True) -> Documento:
    """Decisão humana sobre trechos sinalizados: os removidos não seguem para a IA."""
    doc = db.get(Documento, documento_id)
    if not doc:
        raise ValueError("Documento inexistente.")
    trechos = db.scalars(select(Trecho).where(Trecho.fonte_tipo == "autos", Trecho.fonte_id == str(doc.id))).all()
    paginas: dict[int, list[str]] = {}
    for t in sorted(trechos, key=lambda x: (x.pagina or 0, x.ordem)):
        paginas.setdefault(t.pagina or 1, []).append(t.texto)
    proc = DocumentoProcessado(doc.nome, doc.paginas, [], ["\n".join(paginas.get(i, [])) for i in range(1, doc.paginas + 1)],
                               [], [], [])
    proc = remover_trechos(proc, remover)
    _indexar_paginas(db, doc, proc)
    seg = dict(doc.seguranca or {})
    seg["decisao_usuario"] = {"removidos": remover, "liberado": liberar}
    doc.seguranca, doc.liberado_para_ia = seg, liberar
    db.commit()
    return doc


def rotulo_de(doc: Documento, pagina: int) -> dict | None:
    for r in doc.rotulos_pagina or []:
        if r.get("pagina") == pagina:
            return r
    return None


def texto_da_pagina(db: Session, documento_id: str, pagina: int) -> dict | None:
    doc = db.get(Documento, int(documento_id)) if str(documento_id).isdigit() else None
    if not doc:
        return None
    ts = db.scalars(select(Trecho).where(Trecho.fonte_tipo == "autos", Trecho.fonte_id == str(doc.id),
                                         Trecho.pagina == pagina).order_by(Trecho.ordem)).all()
    if not ts:
        return None
    return {"documento_nome": doc.nome, "texto": "\n".join(t.texto for t in ts), "pagina": pagina,
            "numeracao_autos": descrever(rotulo_de(doc, pagina)), "substituido": doc.substituido,
            "versao": doc.versao, "sha256": doc.sha256}


def texto_dos_autos(db: Session, caso_id: int, limite_chars: int = 60000) -> str:
    """Texto dos autos liberados para IA, com cabeçalhos [doc:ID p.N] para referência rastreável.
    Versões substituídas ficam de fora."""
    docs = db.scalars(select(Documento).where(Documento.caso_id == caso_id, Documento.liberado_para_ia.is_(True),
                                              Documento.substituido.is_(False))).all()
    partes, total = [], 0
    for d in docs:
        ts = db.scalars(select(Trecho).where(Trecho.fonte_tipo == "autos", Trecho.fonte_id == str(d.id))
                        .order_by(Trecho.pagina, Trecho.ordem)).all()
        pag_atual = None
        for t in ts:
            if t.pagina != pag_atual:
                num = descrever(rotulo_de(d, t.pagina))
                partes.append(f"\n<<doc:{d.id} \"{d.nome}\" p.{t.pagina}{' | ' + num if num else ''}>>")
                pag_atual = t.pagina
            partes.append(t.texto)
            total += len(t.texto)
            if total > limite_chars:
                partes.append("\n[... autos truncados por limite de contexto; use a busca nos autos ...]")
                return "\n".join(partes)
    return "\n".join(partes)


def resolver_citacoes(db: Session, texto: str, data_fatos: date | None) -> citacoes.Resolucao:
    ref = data_fatos or date.today()

    def prec(pid: str):
        p = db.get(Precedente, pid)
        if not p:
            return None
        st = avaliar_status(p.status)
        return {"rotulo": p.rotulo, "ementa": p.ementa, "tese": p.tese, "status": p.status,
                "alerta_status": st["alerta"], "bloqueia": st["bloqueia"], "verificado": p.verificado,
                "fonte_url": p.fonte_url, "coletado_em": p.coletado_em.strftime("%d/%m/%Y") if p.coletado_em else None,
                "hash_registrado": p.hash_ementa, "integro": (p.hash_ementa is None or p.hash_ementa == sha256_texto(p.ementa)),
                "verificacao_status": p.verificacao_status, "verificacao_nota": p.verificacao_nota}

    def norma(nid: str):
        n = db.get(Norma, nid)
        if not n:
            return None
        v, atual = conhecimento.versao_vigente(n, ref), conhecimento.versao_vigente(n, date.today())
        return {"rotulo": n.rotulo, "texto": v.texto if v else "", "vigente_na_data": v is not None,
                "difere_da_atual": bool(v and atual and v.id != atual.id), "verificado": n.verificado,
                "inicio_desconhecido": bool(v and v.vigencia_inicio is None),
                "data_referencia": ref.strftime("%d/%m/%Y"), "fonte_url": n.fonte_url,
                "integro": bool(not v or v.hash_texto is None or v.hash_texto == sha256_texto(v.texto)),
                "hash_registrado": v.hash_texto if v else None,
                "coletado_em": v.coletado_em.strftime("%d/%m/%Y") if v and v.coletado_em else None}

    return citacoes.resolver(texto, prec, norma, lambda d, p: texto_da_pagina(db, d, p))


def paginas_do_caso(db: Session, caso_id: int) -> list[dict]:
    """Páginas de todos os documentos vigentes (não substituídos) do caso, com numeração dos autos."""
    saida = []
    for d in db.scalars(select(Documento).where(Documento.caso_id == caso_id, Documento.substituido.is_(False))
                        .order_by(Documento.id)):
        ts = db.scalars(select(Trecho).where(Trecho.fonte_tipo == "autos", Trecho.fonte_id == str(d.id))
                        .order_by(Trecho.pagina, Trecho.ordem)).all()
        por_pag: dict[int, list[str]] = {}
        for t in ts:
            por_pag.setdefault(t.pagina or 1, []).append(t.texto)
        for pag, partes in sorted(por_pag.items()):
            saida.append({"documento_id": str(d.id), "documento_nome": d.nome, "pagina": pag,
                          "numeracao_autos": descrever(rotulo_de(d, pag)), "texto": "\n".join(partes)})
    return saida
