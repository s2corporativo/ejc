from __future__ import annotations

from sqlalchemy.orm import Session

from ..models import Auditoria


def registrar(db: Session, acao: str, alvo: str = "", detalhe: dict | None = None,
              provedor: str | None = None, usuario: str | None = None, tokens: float | None = None,
              duracao_ms: int | None = None, custo: float | None = None, erro: bool = False) -> None:
    if usuario is None:
        from .acesso import atual
        usuario = atual().nome
    db.add(Auditoria(acao=acao, alvo=alvo, detalhe=detalhe or {}, provedor=provedor, usuario=usuario,
                     custo_tokens=tokens, duracao_ms=duracao_ms, custo_estimado=custo, erro=erro))
    db.commit()
