"""Importação da base de conhecimento do EJC (somente leitura).

O que é importado: apenas a BASE PÚBLICA do EJC (legislação, súmulas, jurisprudência,
doutrina), na versão vigente, aplicando o mesmo gate de governança fail-closed do EJC
(ai_service.filtros_gate_rag):
  - documento não excluído, vigente, base_rag = 'publica', sem client_id/case_id;
  - categorias restritas (peças e precedentes internos, comunicações processuais) excluídas;
  - excluídos: confidence_level 'bloqueado'; rag_status bloqueado/recusado/reprovado/pendente;
    norma revogada; corpus fictício; súmula sem conferência (extra.conferido) ;
  - com exigir_aprovado=True (padrão do EJC): somente rag_status = 'aprovado'.
Conteúdo de clientes e casos NUNCA é importado (sigilo profissional e LGPD, art. 6º, III).

Embeddings: os vetores do EJC são reaproveitados quando a dimensão coincide com
EMBEDDINGS_DIM e o modelo declarado é o mesmo (ambos multilingual-e5-large por padrão);
caso contrário, os trechos são revetorizados localmente.
"""
from __future__ import annotations

import json
import re
from datetime import date

from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session

from ..config import get_config
from ..models import Trecho
from . import conhecimento, recuperacao

RESTRITAS = ["peca_interna", "peca_escritorio", "precedente_interno", "comunicacao_processual"]

SITUACAO = ("regexp_replace(lower(btrim(COALESCE(NULLIF(btrim(kd.extra->>'legal_status'),''),"
            "NULLIF(btrim(kd.extra->>'situacao_normativa'),''),NULLIF(btrim(kd.extra->>'vigencia_status'),''),''))),'\\s+',' ','g')")

SQL_DOCS = f"""
SELECT kd.id, kd.titulo, kd.categoria, kd.fonte, kd.tribunal, kd.extra, kd.chave_origem, kd.versao
FROM knowledge_docs kd
WHERE kd.deleted_at IS NULL
  AND kd.vigente = TRUE
  AND COALESCE(kd.base_rag::text, '') = 'publica'
  AND kd.client_id IS NULL AND kd.case_id IS NULL
  AND kd.categoria <> ALL(:restritas)
  AND NOT (COALESCE(kd.extra->>'confidence_level','') = 'bloqueado'
           OR COALESCE(kd.extra->>'rag_status','') IN ('bloqueado','recusado','reprovado','pendente'))
  AND {SITUACAO} NOT IN ('revogada','revogado')
  AND COALESCE((kd.extra->>'ficticio')::boolean, false) = false
  AND NOT ((COALESCE(kd.chave_origem,'') LIKE 'sumula:%' OR COALESCE(kd.fonte,'') = 'sumula')
           AND COALESCE((kd.extra->>'conferido')::boolean, false) = false)
  {{filtro_aprovado}}
  {{filtro_categoria}}
ORDER BY kd.categoria, kd.id
LIMIT :limite
"""

SQL_CHUNKS = """
SELECT doc_id, chunk_index, pagina, conteudo, embedding::text AS emb
FROM knowledge_chunks WHERE doc_id = ANY(:ids) ORDER BY doc_id, chunk_index
"""


def _numero(titulo: str) -> str:
    m = re.search(r"\d[\d.]*", titulo or "")
    return m.group(0) if m else (titulo or "")[:40]


def _data(v) -> date | None:
    if not v:
        return None
    try:
        return date.fromisoformat(str(v)[:10])
    except ValueError:
        return None


def _status_precedente(extra: dict) -> str:
    s = (extra.get("legal_status") or "").lower()
    if "cancel" in s:
        return "cancelado"
    if "super" in s:
        return "superado"
    return "vigente"


def _tipo_sumula(categoria: str, titulo: str, tribunal: str) -> str:
    if "vinculante" in (titulo or "").lower():
        return "sumula_vinculante"
    return "sumula" if tribunal in ("STF", "STJ") else "sumula_tribunal"


def classificar(doc: dict) -> str:
    cat = (doc["categoria"] or "").lower()
    if cat.startswith("legislacao") or "legisl" in cat:
        return "norma"
    if cat.startswith("sumula") or cat.startswith("jurisprud"):
        return "precedente"
    return "doutrina"


def importar(db: Session, ejc_url: str | None = None, exigir_aprovado: bool = True,
             categorias: list[str] | None = None, limite: int = 100000, reaproveitar_vetores: bool = True,
             modelo_ejc: str | None = None, dry_run: bool = False) -> dict:
    cfg = get_config()
    url = ejc_url or cfg.ejc_database_url
    if not url:
        raise ValueError("Informe EJC_DATABASE_URL (conexão somente leitura ao PostgreSQL do EJC).")
    url = url.replace("postgresql+asyncpg://", "postgresql+psycopg://")
    if url.startswith("postgresql://") or url.startswith("postgres://"):
        url = "postgresql+psycopg://" + url.split("://", 1)[1]
    eng = create_engine(url, connect_args={"options": "-c default_transaction_read_only=on"})
    filtro_aprov = "AND COALESCE(kd.extra->>'rag_status','') = 'aprovado'" if exigir_aprovado else ""
    filtro_cat = "AND kd.categoria = ANY(:cats)" if categorias else ""
    params = {"restritas": RESTRITAS, "limite": limite}
    if categorias:
        params["cats"] = categorias
    rel = {"documentos": 0, "normas": 0, "precedentes": 0, "doutrina": 0, "trechos": 0,
           "vetores_reaproveitados": 0, "vetores_recalculados": 0, "ignorados": []}
    mesmo_modelo = reaproveitar_vetores and (modelo_ejc or cfg.embeddings_model) == cfg.embeddings_model

    with eng.connect() as c:
        docs = [dict(r._mapping) for r in c.execute(
            text(SQL_DOCS.format(filtro_aprovado=filtro_aprov, filtro_categoria=filtro_cat)), params)]
        rel["documentos"] = len(docs)
        for i in range(0, len(docs), 200):
            lote = docs[i:i + 200]
            chunks: dict[str, list[dict]] = {}
            for r in c.execute(text(SQL_CHUNKS), {"ids": [d["id"] for d in lote]}):
                chunks.setdefault(r.doc_id, []).append(dict(r._mapping))
            if dry_run:
                for d in lote:
                    rel[{"norma": "normas", "precedente": "precedentes", "doutrina": "doutrina"}[classificar(d)]] += 1
                continue
            for d in lote:
                _importar_doc(db, d, chunks.get(d["id"], []), mesmo_modelo, rel)
    eng.dispose()
    return rel


def _importar_doc(db: Session, d: dict, chunks: list[dict], mesmo_modelo: bool, rel: dict) -> None:
    extra = d.get("extra") or {}
    if isinstance(extra, str):
        extra = json.loads(extra)
    if not chunks:
        rel["ignorados"].append({"id": d["id"], "motivo": "documento sem trechos"})
        return
    texto = "\n\n".join(ch["conteudo"] for ch in chunks)
    destino = classificar(d)
    novo_id = f"ejc-{d['id']}"
    origem = f"ejc:{d['id']}"
    fonte_url = d["fonte"] if (d.get("fonte") or "").startswith("http") else None

    if destino == "norma":
        verificado = ((extra.get("legal_status") or "").lower() == "vigente" and bool(extra.get("legal_status_origem"))
                      and bool(extra.get("legal_status_verificado_em")) and not extra.get("legal_status_inferido_em"))
        conhecimento.importar_norma(db, {
            "id": novo_id, "diploma": d["titulo"], "dispositivo": extra.get("dispositivo") or d["titulo"],
            "rotulo": d["titulo"], "fonte_url": fonte_url, "verificado": verificado,
            "verificado_em": (extra.get("legal_status_verificado_em") or "")[:10] or None,
            "versoes": [{"texto": texto, "vigencia_inicio": extra.get("vigencia_inicio"),
                         "ato_alterador": extra.get("ato_alterador")}]}, reindexar=False)
        rel["normas"] += 1
    elif destino == "precedente":
        cat = (d["categoria"] or "").lower()
        trib = (d.get("tribunal") or extra.get("tribunal") or (cat.split("_")[-1] if "_" in cat else "") or "N/I").upper()
        tipo = _tipo_sumula(cat, d["titulo"], trib) if cat.startswith("sumula") else "acordao"
        conhecimento.importar_precedente(db, {
            "id": novo_id, "tribunal": trib, "tipo": tipo, "numero": _numero(d["titulo"]) if tipo.startswith("sumula") else (d.get("chave_origem") or d["id"]),
            "rotulo": d["titulo"], "ementa": texto, "status": _status_precedente(extra),
            "status_nota": "Importado do EJC; status derivado de extra.legal_status." ,
            "fonte_url": fonte_url, "verificado": bool(extra.get("conferido")) or extra.get("rag_status") == "aprovado",
            "data_julgamento": _data(extra.get("data_julgamento")), "materias": [m for m in [extra.get("area_juridica") or extra.get("area")] if m],
        }, reindexar=False)
        rel["precedentes"] += 1
    else:
        rel["doutrina"] += 1

    fonte_tipo = {"norma": "norma", "precedente": "precedente", "doutrina": "doutrina"}[destino]
    recuperacao.remover(db, fonte_tipo, novo_id)
    itens = []
    for ch in chunks:
        vetor = None
        if mesmo_modelo and ch.get("emb"):
            v = json.loads(ch["emb"])
            if len(v) == get_config().embeddings_dim:
                vetor = v
        if vetor is not None:
            rel["vetores_reaproveitados"] += 1
        else:
            rel["vetores_recalculados"] += 1
        itens.append({"fonte_tipo": fonte_tipo, "fonte_id": novo_id, "texto": ch["conteudo"], "ordem": ch["chunk_index"],
                      "pagina": ch.get("pagina"), "vetor": vetor, "origem": origem,
                      "extra": {"titulo": d["titulo"], "categoria": d["categoria"], "fonte": d.get("fonte"),
                                "versao_ejc": d.get("versao")}})
    recuperacao.indexar(db, itens)
    rel["trechos"] += len(itens)


def origem_de(db: Session, trecho_id: int) -> str | None:
    t = db.get(Trecho, trecho_id)
    return t.origem if t else None
