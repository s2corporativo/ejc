"""Transcrição de áudio e vídeo (audiências, depoimentos, reuniões) com marcação temporal.

Provedores (TRANSCRICAO_PROVIDER):
  - openai_compat: endpoint /audio/transcriptions compatível (servidor próprio de Whisper, ou serviço
    contratado pelo escritório). Chave do próprio escritório.
  - local: faster-whisper instalado no servidor (requirements-opcional.txt); nada sai do servidor.
  - none: desligado.
O resultado vira documento do caso (tipo "transcricao"), pesquisável e citável por [[autos:DOC:PAGINA]];
cada "página" agrupa até 5 minutos. A relevância por trecho é indicativa (termos do caso e termos
probatórios). Rótulos de falante, quando o provedor os fornece, não comprovam a identidade de quem fala.
"""
from __future__ import annotations

import re
import tempfile
from pathlib import Path

import httpx
from sqlalchemy.orm import Session

from ..config import get_config
from ..core.texto import normalizar
from ..models import Caso
from . import documentos

EXTENSOES = {".mp3", ".wav", ".m4a", ".ogg", ".opus", ".webm", ".mp4", ".mpeg", ".mpga", ".flac", ".aac"}
JANELA_PAGINA_S = 300
TERMOS_PROBATORIOS = r"confess\w*|admit\w*|reconhec\w*|nego|negou|nao\s+sabe|nao\s+lembr\w*|testemunh\w*|presenci\w*|" \
                     r"contrat\w*|pagament\w*|pagou|recebeu|assin\w*|acident\w*|horas?\s+extras?|assedi\w*|ameac\w*|" \
                     r"valor|data|dia\s+\d|documento|prova"


class ErroTranscricao(RuntimeError):
    pass


def _hms(s: float) -> str:
    s = int(s)
    return f"{s // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}"


def _openai_compat(dados: bytes, nome: str) -> list[dict]:
    cfg = get_config()
    if not cfg.transcricao_base_url:
        raise ErroTranscricao("Defina TRANSCRICAO_BASE_URL (endpoint compatível com /audio/transcriptions).")
    headers = {"authorization": f"Bearer {cfg.transcricao_api_key}"} if cfg.transcricao_api_key else {}
    try:
        r = httpx.post(cfg.transcricao_base_url.rstrip("/") + "/audio/transcriptions", headers=headers,
                       timeout=max(cfg.http_timeout, 600),
                       files={"file": (nome, dados)},
                       data={"model": cfg.transcricao_model, "response_format": "verbose_json", "language": "pt",
                             "timestamp_granularities[]": "segment"})
    except httpx.HTTPError as e:
        raise ErroTranscricao(f"Serviço de transcrição indisponível: {e}") from e
    if r.status_code >= 400:
        raise ErroTranscricao(f"Transcrição {r.status_code}: {r.text[:300]}")
    d = r.json()
    segs = d.get("segments") or []
    if not segs and d.get("text"):
        segs = [{"start": 0, "end": 0, "text": d["text"]}]
    return [{"inicio": float(s.get("start", 0)), "fim": float(s.get("end", 0)), "texto": (s.get("text") or "").strip(),
             "falante": s.get("speaker")} for s in segs]


def _local(dados: bytes, nome: str) -> list[dict]:
    try:
        from faster_whisper import WhisperModel  # type: ignore
    except ImportError as e:
        raise ErroTranscricao("faster-whisper não instalado: pip install -r requirements-opcional.txt") from e
    with tempfile.NamedTemporaryFile(suffix=Path(nome).suffix) as f:
        f.write(dados)
        f.flush()
        modelo = WhisperModel(get_config().transcricao_model if get_config().transcricao_model != "whisper-1" else "small")
        segs, _ = modelo.transcribe(f.name, language="pt")
        return [{"inicio": s.start, "fim": s.end, "texto": s.text.strip(), "falante": None} for s in segs]


PROVEDORES = {"openai_compat": _openai_compat, "local": _local}


def relevancia(texto: str, termos_caso: set[str]) -> str:
    t = normalizar(texto)
    pontos = len(re.findall(TERMOS_PROBATORIOS, t)) + sum(1 for w in termos_caso if w in t)
    return "alta" if pontos >= 3 else ("media" if pontos >= 1 else "baixa")


def transcrever(db: Session, caso_id: int, nome: str, dados: bytes, usuario: str = "local") -> dict:
    if Path(nome).suffix.lower() not in EXTENSOES:
        raise ErroTranscricao(f"Formato não suportado. Use: {', '.join(sorted(EXTENSOES))}")
    prov = get_config().transcricao_provider
    fn = PROVEDORES.get(prov)
    if not fn:
        raise ErroTranscricao("Transcrição desligada: configure TRANSCRICAO_PROVIDER (openai_compat ou local).")
    caso = db.get(Caso, caso_id)
    if not caso:
        raise ErroTranscricao("Caso inexistente.")
    segmentos = [s for s in fn(dados, nome) if s["texto"]]
    if not segmentos:
        raise ErroTranscricao("Nenhuma fala reconhecida no arquivo.")
    termos = {w for w in re.findall(r"[a-z]{5,}", normalizar(f"{caso.titulo} {caso.area or ''} {caso.parte_contraria or ''}"))}
    paginas, extras, atual, extra_atual, limite = [], [], [], None, JANELA_PAGINA_S
    for s in segmentos:
        s["relevancia"] = relevancia(s["texto"], termos)
        while s["inicio"] >= limite:
            if atual:
                paginas.append("\n".join(atual))
                extras.append(extra_atual)
                atual, extra_atual = [], None
            limite += JANELA_PAGINA_S
        quem = f" ({s['falante']})" if s.get("falante") else ""
        atual.append(f"[{_hms(s['inicio'])} - {_hms(s['fim'])}]{quem} {s['texto']}")
        extra_atual = extra_atual or {"inicio": _hms(s["inicio"]), "segmentos": []}
        extra_atual["fim"] = _hms(s["fim"])
        extra_atual["segmentos"].append({"inicio": _hms(s["inicio"]), "fim": _hms(s["fim"]), "relevancia": s["relevancia"]})
    if atual:
        paginas.append("\n".join(atual))
        extras.append(extra_atual)
    doc = documentos.registrar_texto_derivado(
        db, caso_id, f"Transcrição - {nome}", "transcricao", paginas,
        {"origem": nome, "provedor": prov, "segmentos": len(segmentos), "duracao": _hms(segmentos[-1]["fim"]),
         "aviso": "Transcrição automática: confira com a mídia original antes de citar. Rótulos de falante não comprovam identidade."},
        extras, usuario=usuario, origem_bytes=dados)
    return {"documento_id": doc.id, "paginas": doc.paginas, "segmentos": [
        {**s, "inicio": _hms(s["inicio"]), "fim": _hms(s["fim"])} for s in segmentos],
        "liberado_para_ia": doc.liberado_para_ia, "metadados": doc.metadados}
