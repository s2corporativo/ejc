"""Biblioteca de Habilidades: oficiais (arquivos SKILL.md versionados) e do usuário (forks)."""
from __future__ import annotations

from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_config
from ..core import skills as core
from ..models import Skill


def sincronizar_oficiais(db: Session, diretorio: str | None = None) -> dict:
    """Carrega/atualiza as habilidades oficiais do diretório. Forks do usuário são preservados e
    recebem sinal de 'atualização disponível' quando a oficial muda de versão."""
    docs = core.carregar_diretorio(diretorio or get_config().skills_dir)
    novos, atualizados = 0, 0
    for d in docs:
        s = db.scalar(select(Skill).where(Skill.slug == d.slug, Skill.oficial.is_(True)))
        if s is None:
            db.add(Skill(slug=d.slug, titulo=d.titulo, tipo=d.tipo, area=d.area, descricao=d.descricao,
                         gatilhos=d.gatilhos, conteudo=d.conteudo, oficial=True, versao=1,
                         revisado_em=date.fromisoformat(d.revisado_em) if d.revisado_em else None,
                         historico=[{"versao": 1, "conteudo": d.conteudo, "nota": "carga inicial"}]))
            novos += 1
        elif s.conteudo != d.conteudo or s.descricao != d.descricao or s.gatilhos != d.gatilhos:
            hist = list(s.historico or [])
            s.versao += 1
            hist.append({"versao": s.versao, "conteudo": d.conteudo, "nota": "atualização do catálogo"})
            s.titulo, s.tipo, s.area, s.descricao, s.gatilhos, s.conteudo, s.historico = (
                d.titulo, d.tipo, d.area, d.descricao, d.gatilhos, d.conteudo, hist)
            atualizados += 1
    db.commit()
    return {"novas": novos, "atualizadas": atualizados, "total_arquivos": len(docs)}


def _efetivas(db: Session, dono: str | None = None) -> list[Skill]:
    """Uma por slug: o fork ativo do usuário prevalece sobre a oficial."""
    todas = db.scalars(select(Skill).where(Skill.ativa.is_(True))).all()
    por_slug: dict[str, Skill] = {}
    for s in todas:
        if s.oficial:
            por_slug.setdefault(s.slug, s)
    for s in todas:
        if not s.oficial and (dono is None or s.dono == dono):
            por_slug[s.slug] = s
    return list(por_slug.values())


def selecionar_para(db: Session, contexto: str, tipo_peca: str, fixadas: list[str] | None = None,
                    dono: str | None = None) -> tuple[list[dict], str]:
    efetivas = _efetivas(db, dono)
    if not efetivas:
        return [], ""
    dicts = [{"id": s.id, "slug": s.slug, "titulo": s.titulo, "tipo": s.tipo, "descricao": s.descricao,
              "gatilhos": s.gatilhos or [], "versao": s.versao, "oficial": s.oficial} for s in efetivas]
    sel = core.selecionar(dicts, contexto, tipo_peca, fixadas=fixadas)
    conteudos = {s.slug: s.conteudo for s in efetivas}
    return sel, core.bloco_contexto(sel, conteudos)


def criar_fork(db: Session, slug: str, conteudo: str, dono: str = "local", nota: str = "") -> Skill:
    oficial = db.scalar(select(Skill).where(Skill.slug == slug, Skill.oficial.is_(True)))
    existente = db.scalar(select(Skill).where(Skill.slug == slug, Skill.oficial.is_(False), Skill.dono == dono))
    if existente:
        existente.versao += 1
        existente.conteudo = conteudo
        existente.historico = list(existente.historico or []) + [{"versao": existente.versao, "conteudo": conteudo, "nota": nota}]
        db.commit()
        return existente
    base = oficial
    s = Skill(slug=slug, titulo=base.titulo if base else slug, tipo=base.tipo if base else "materia",
              area=base.area if base else "", descricao=base.descricao if base else nota or slug,
              gatilhos=list(base.gatilhos or []) if base else [], conteudo=conteudo, oficial=False,
              origem_id=base.id if base else None, origem_versao=base.versao if base else None, versao=1, dono=dono,
              historico=[{"versao": 1, "conteudo": conteudo, "nota": nota or "fork"}])
    db.add(s)
    db.commit()
    return s


def criar_propria(db: Session, doc_md: str, dono: str = "local") -> Skill:
    d = core.parse_skill_md(doc_md)
    s = Skill(slug=d.slug, titulo=d.titulo, tipo=d.tipo, area=d.area, descricao=d.descricao, gatilhos=d.gatilhos,
              conteudo=d.conteudo, oficial=False, dono=dono, historico=[{"versao": 1, "conteudo": d.conteudo, "nota": "criação"}])
    db.add(s)
    db.commit()
    return s


def atualizacoes_pendentes(db: Session, dono: str = "local") -> list[dict]:
    pend = []
    for f in db.scalars(select(Skill).where(Skill.oficial.is_(False), Skill.dono == dono, Skill.origem_id.is_not(None))):
        of = db.get(Skill, f.origem_id)
        if of and of.versao > (f.origem_versao or 0):
            pend.append({"slug": f.slug, "fork_id": f.id, "oficial_versao": of.versao, "base_versao": f.origem_versao})
    return pend


def propor_mescla(db: Session, fork_id: int) -> dict:
    f = db.get(Skill, fork_id)
    of = db.get(Skill, f.origem_id) if f and f.origem_id else None
    if not f or not of:
        raise ValueError("Fork sem habilidade oficial de origem.")
    base = next((h["conteudo"] for h in of.historico or [] if h["versao"] == f.origem_versao), of.conteudo)
    r = core.mesclar_tres_vias(base, f.conteudo, of.conteudo)
    return {**r, "fork_id": f.id, "de_versao": f.origem_versao, "para_versao": of.versao}


def aplicar_mescla(db: Session, fork_id: int, texto: str) -> Skill:
    f = db.get(Skill, fork_id)
    of = db.get(Skill, f.origem_id)
    f.versao += 1
    f.conteudo, f.origem_versao = texto, of.versao
    f.historico = list(f.historico or []) + [{"versao": f.versao, "conteudo": texto, "nota": f"mescla com oficial v{of.versao}"}]
    db.commit()
    return f
