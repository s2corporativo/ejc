"""Coleta de legislação oficial (Planalto) e monitor legislativo (Câmara e Senado)."""
from __future__ import annotations

from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core.integridade import sha256_texto
from ..integracoes import legislativo, planalto
from ..models import FonteColeta, Norma, Proposicao, agora
from . import auditoria, conhecimento


def _fonte(db: Session, fid: str, descricao: str, url: str | None) -> FonteColeta:
    f = db.get(FonteColeta, fid)
    if not f:
        f = FonteColeta(id=fid, descricao=descricao, url=url)
        db.add(f)
    return f


def importar_diploma(db: Session, slug: str, html: str | None = None, forcar: bool = False) -> dict:
    d = planalto.POR_SLUG.get(slug)
    if not d:
        raise ValueError(f"Diploma desconhecido: {slug}. Catálogo: {sorted(planalto.POR_SLUG)}")
    f = _fonte(db, f"planalto:{slug}", d["titulo"], d["url"])
    f.ultima_execucao = agora()
    try:
        html = html if html is not None else planalto.baixar(d)
        h = sha256_texto(html)
        if f.hash_fonte == h and not forcar and f.status in ("ok", "inalterado"):
            f.status = "inalterado"
            db.commit()
            return {"slug": slug, "status": "inalterado", "artigos": f.itens}
        prep = planalto.preparar(d, html)
    except planalto.ErroPlanalto as e:
        f.status, f.erro = "erro", str(e)[:1000]
        db.commit()
        return {"slug": slug, "status": "erro", "erro": str(e)}
    hoje = date.today().isoformat()
    for a in prep["artigos"]:
        conhecimento.importar_norma(db, {
            "id": a["id"], "diploma": d["titulo"], "dispositivo": a["dispositivo"], "rotulo": a["rotulo"],
            "fonte_url": d["url"], "verificado": True, "verificado_por": "coleta automática: planalto.gov.br (texto compilado)",
            "verificado_em": hoje, "coletado_em": agora().isoformat(),
            "versoes": [{"texto": a["texto"], "vigencia_inicio": None}]})
    # artigos que deixaram de existir na página (renumeração ou revogação integral) ficam sem versão vigente
    ids = {a["id"] for a in prep["artigos"]}
    antigos = db.scalars(select(Norma).where(Norma.id.like(f"{slug}-%"))).all()
    encerrados = 0
    for n in antigos:
        if n.id not in ids:
            for v in n.versoes:
                if v.vigencia_fim is None:
                    v.vigencia_fim = date.today()
                    encerrados += 1
    f.status, f.erro, f.itens, f.hash_fonte = "ok", None, len(prep["artigos"]), h
    f.detalhe = {"revogados_ignorados": prep["revogados_ignorados"], "encerrados": encerrados, "caracteres": prep["caracteres"]}
    db.commit()
    auditoria.registrar(db, "conhecimento:planalto", f"planalto:{slug}", {"artigos": len(prep["artigos"])})
    return {"slug": slug, "status": "ok", "artigos": len(prep["artigos"]), **f.detalhe}


def importar_planalto(db: Session, slugs: list[str] | None = None, forcar: bool = False) -> dict:
    res = [importar_diploma(db, s, forcar=forcar) for s in (slugs or planalto.PADRAO)]
    return {"diplomas": res, "artigos": sum(r.get("artigos") or 0 for r in res if r["status"] == "ok"),
            "erros": [r for r in res if r["status"] == "erro"]}


def catalogo(db: Session) -> list[dict]:
    out = []
    for d in planalto.CATALOGO:
        f = db.get(FonteColeta, f"planalto:{d['slug']}")
        out.append({"slug": d["slug"], "sigla": d["sigla"], "titulo": d["titulo"], "area": d["area"], "url": d["url"],
                    "padrao": d["slug"] in planalto.PADRAO, "status": f.status if f else "nunca",
                    "artigos": f.itens if f else 0,
                    "ultima_execucao": f.ultima_execucao.isoformat() if f and f.ultima_execucao else None,
                    "erro": f.erro if f else None})
    return out


def monitorar(db: Session, tema: str, ano: int | None = None) -> dict:
    r = legislativo.buscar(tema, ano)
    novos = 0
    for p in r["proposicoes"]:
        x = db.get(Proposicao, p["id"])
        if not x:
            x = Proposicao(id=p["id"], casa=p["casa"], sigla=p["sigla"], ementa=p["ementa"], link=p["link"],
                           data_apresentacao=date.fromisoformat(p["data_apresentacao"]) if p["data_apresentacao"] else None,
                           temas=[tema])
            db.add(x)
            novos += 1
        elif tema not in (x.temas or []):
            x.temas = list(x.temas or []) + [tema]
    f = _fonte(db, "legislativo", "Monitor legislativo Câmara e Senado", None)
    f.ultima_execucao, f.status = agora(), "erro" if r["erros"] and not r["proposicoes"] else "ok"
    f.itens, f.erro = (f.itens or 0) + novos, "; ".join(r["erros"]) or None
    db.commit()
    return {**r, "novas": novos}
