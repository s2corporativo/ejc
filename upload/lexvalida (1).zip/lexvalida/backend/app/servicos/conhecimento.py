"""Serviço de conhecimento: importação, indexação, busca e resolução temporal de normas.

Chunking: chunker jurídico portado do EJC (por artigo na legislação; por seção nas demais
fontes jurídicas; teto = janela do modelo de embedding, EMBEDDINGS_MAX_CHARS).
"""
from __future__ import annotations

from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core.chunker_juridico import chunk_documento_juridico
from ..core.hierarquia import TIPOS, avaliar_status, peso_tipo
from ..core.integridade import sha256_texto
from ..models import Documento, Norma, NormaVersao, Precedente, Relacao, Trecho, agora
from . import recuperacao

CATEGORIA_CHUNK = {"norma": "legislacao", "precedente": "jurisprudencia", "doutrina": "doutrina",
                   "modelo": "modelo", "autos": None}


def indexar(db: Session, fonte_tipo: str, fonte_id: str, texto: str, caso_id: int | None = None,
            pagina: int | None = None, bbox: list | None = None, origem: str | None = None,
            extra: dict | None = None) -> list[int]:
    partes = chunk_documento_juridico(texto, categoria=CATEGORIA_CHUNK.get(fonte_tipo)) or ([texto] if texto.strip() else [])
    return recuperacao.indexar(db, [
        {"fonte_tipo": fonte_tipo, "fonte_id": fonte_id, "texto": p, "caso_id": caso_id, "pagina": pagina,
         "bbox": bbox, "ordem": i, "origem": origem, "extra": extra}
        for i, p in enumerate(partes)])


def remover_fonte(db: Session, fonte_tipo: str, fonte_id: str) -> None:
    recuperacao.remover(db, fonte_tipo, fonte_id)


# ------------------------------------------------------------------ importação
def _data(v):
    return date.fromisoformat(v) if isinstance(v, str) and v else v


def _momento(v):
    from datetime import datetime
    if isinstance(v, str) and v:
        return datetime.fromisoformat(v.replace("Z", "+00:00")).replace(tzinfo=None)
    return v or agora()


def importar_precedente(db: Session, d: dict, reindexar: bool = True) -> Precedente:
    faltam = [c for c in ["id", "tribunal", "tipo", "numero", "rotulo", "ementa"] if not d.get(c)]
    if faltam:
        raise ValueError(f"Precedente sem campos obrigatórios: {faltam}")
    if d["tipo"] not in TIPOS:
        raise ValueError(f"Tipo inválido: {d['tipo']}. Use um de {sorted(TIPOS)}")
    p = db.get(Precedente, d["id"])
    if p is None:
        p = Precedente(id=d["id"])
        db.add(p)
    for campo in ["tribunal", "tipo", "numero", "rotulo", "ementa", "tese", "orgao_julgador", "relator",
                  "status", "status_nota", "fonte_url", "verificado", "verificado_por"]:
        if campo in d:
            setattr(p, campo, d[campo])
    for campo in ["data_julgamento", "data_publicacao", "status_atualizado_em", "verificado_em"]:
        if d.get(campo):
            setattr(p, campo, _data(d[campo]))
    p.materias = d.get("materias", p.materias or [])
    p.status = p.status or "vigente"
    # Registro de citação: data de coleta e hash da ementa íntegra coletada
    p.coletado_em = _momento(d.get("coletado_em"))
    p.hash_ementa = sha256_texto(p.ementa)
    p.verificacao_status = d.get("verificacao_status") or ("conferido" if p.verificado else "nao_verificado")
    db.commit()
    if reindexar:
        remover_fonte(db, "precedente", p.id)
        corpo = "\n".join(x for x in [p.rotulo, p.tese or "", p.ementa, " ".join(p.materias or [])] if x)
        indexar(db, "precedente", p.id, corpo, origem=d.get("origem"))
    for rel in d.get("relacoes", []):
        registrar_relacao(db, f"precedente:{p.id}", rel["destino"], rel["tipo"], rel.get("nota"))
    return p


def importar_norma(db: Session, d: dict, reindexar: bool = True) -> Norma:
    for c in ["id", "diploma", "dispositivo", "rotulo", "versoes"]:
        if not d.get(c):
            raise ValueError(f"Norma sem campo obrigatório: {c}")
    n = db.get(Norma, d["id"])
    if n is None:
        n = Norma(id=d["id"])
        db.add(n)
    n.diploma, n.dispositivo, n.rotulo = d["diploma"], d["dispositivo"], d["rotulo"]
    n.fonte_url, n.verificado = d.get("fonte_url"), bool(d.get("verificado", False))
    n.verificado_por, n.verificado_em = d.get("verificado_por"), _data(d.get("verificado_em"))
    n.versoes.clear()
    db.flush()
    for v in d["versoes"]:
        n.versoes.append(NormaVersao(texto=v["texto"], vigencia_inicio=_data(v.get("vigencia_inicio")),
                                     vigencia_fim=_data(v.get("vigencia_fim")), ato_alterador=v.get("ato_alterador"),
                                     hash_texto=sha256_texto(v["texto"]), coletado_em=_momento(v.get("coletado_em") or d.get("coletado_em"))))
    _validar_versoes(n)
    db.commit()
    if reindexar:
        remover_fonte(db, "norma", n.id)
        atual = versao_vigente(n, date.today()) or n.versoes[-1]
        indexar(db, "norma", n.id, f"{n.rotulo}\n{atual.texto}", origem=d.get("origem"))
    return n


def _validar_versoes(n: Norma) -> None:
    vs = sorted(n.versoes, key=lambda v: v.vigencia_inicio or date.min)
    for a, b in zip(vs, vs[1:]):
        if a.vigencia_fim is None or (b.vigencia_inicio and a.vigencia_fim >= b.vigencia_inicio):
            raise ValueError(f"{n.id}: versões com vigência sobreposta ou aberta antes de nova versão.")


def registrar_relacao(db: Session, origem: str, destino: str, tipo: str, nota: str | None = None) -> None:
    existe = db.scalar(select(Relacao).where(Relacao.origem == origem, Relacao.destino == destino, Relacao.tipo == tipo))
    if not existe:
        db.add(Relacao(origem=origem, destino=destino, tipo=tipo, nota=nota))
        db.commit()


# ---------------------------------------------------------------- consultas
def versao_vigente(n: Norma, em: date) -> NormaVersao | None:
    for v in n.versoes:
        if (v.vigencia_inicio is None or v.vigencia_inicio <= em) and (v.vigencia_fim is None or em <= v.vigencia_fim):
            return v
    return None


def relacoes_de(db: Session, no: str) -> list[dict]:
    rs = db.scalars(select(Relacao).where((Relacao.origem == no) | (Relacao.destino == no)))
    return [{"origem": r.origem, "destino": r.destino, "tipo": r.tipo, "nota": r.nota} for r in rs]


def _ranks(h: dict) -> dict:
    return {k: v for k, v in h.items() if k.startswith("rank_") or k in ("rrf", "similaridade")}


def pesquisar_jurisprudencia(db: Session, consulta: str, tribunal: str | None = None, limite: int = 10,
                             ordenar_por: str = "autoridade", incluir_superados: bool = False) -> dict:
    hits = recuperacao.buscar(db, consulta, "precedente", limite=limite * 4)
    vistos, resultados, excluidos = set(), [], []
    for h in hits:
        t = db.get(Trecho, h["trecho_id"])
        if not t or t.fonte_id in vistos:
            continue
        vistos.add(t.fonte_id)
        p = db.get(Precedente, t.fonte_id)
        if not p or (tribunal and p.tribunal.upper() != tribunal.upper()):
            continue
        st = avaliar_status(p.status)
        if st["bloqueia"] and not incluir_superados:
            excluidos.append({"id": p.id, "rotulo": p.rotulo, "status": p.status, "motivo": st["alerta"]})
            continue
        resultados.append({
            "id": p.id, "rotulo": p.rotulo, "tribunal": p.tribunal, "tipo": p.tipo,
            "hierarquia": TIPOS.get(p.tipo, {}).get("inciso"), "status": p.status,
            "alerta_status": st["alerta"], "status_nota": p.status_nota, "tese": p.tese, "ementa": p.ementa,
            "fonte_url": p.fonte_url, "verificado": p.verificado, **_ranks(h),
            "pontuacao": round(h["rrf"] * (0.5 + peso_tipo(p.tipo)) * st["fator"], 6),
            "relacoes": relacoes_de(db, f"precedente:{p.id}"), "marcador": "{{juris:" + p.id + "}}",
        })
    chave = (lambda r: (-peso_tipo(r["tipo"]), -r["pontuacao"])) if ordenar_por == "autoridade" else (lambda r: -r["pontuacao"])
    resultados.sort(key=chave)
    return {"consulta": consulta, "resultados": resultados[:limite], "excluidos_por_status": excluidos,
            "nota": "Ementas exibidas na íntegra conforme base importada. Confira a fonte oficial antes do protocolo."}


def pesquisar_legislacao(db: Session, consulta: str, data_fatos: date | None = None, limite: int = 8) -> dict:
    hits = recuperacao.buscar(db, consulta, "norma", limite=limite * 3)
    ref = data_fatos or date.today()
    vistos, res = set(), []
    for h in hits:
        t = db.get(Trecho, h["trecho_id"])
        if not t or t.fonte_id in vistos:
            continue
        vistos.add(t.fonte_id)
        n = db.get(Norma, t.fonte_id)
        if not n:
            continue
        v_fato, v_hoje = versao_vigente(n, ref), versao_vigente(n, date.today())
        alertas = []
        if v_fato is None:
            alertas.append(f"Nenhuma versão vigente em {ref:%d/%m/%Y}.")
        else:
            if v_fato.vigencia_inicio is None:
                alertas.append("Início de vigência não curado: confirmar a redação aplicável à data dos fatos.")
            if v_hoje and v_fato.id != v_hoje.id:
                alertas.append("A redação vigente na data dos fatos difere da redação atual.")
        res.append({
            "id": n.id, "rotulo": n.rotulo, "diploma": n.diploma, "verificado": n.verificado,
            "texto_na_data_dos_fatos": v_fato.texto if v_fato else None,
            "texto_atual": v_hoje.texto if v_hoje else None,
            "ato_alterador": v_fato.ato_alterador if v_fato else None,
            "data_referencia": ref.isoformat(), "alertas": alertas, **_ranks(h),
            "marcador": "{{lei:" + n.id + "}}",
        })
        if len(res) >= limite:
            break
    return {"consulta": consulta, "resultados": res}


def pesquisar_autos(db: Session, caso_id: int, consulta: str, limite: int = 8) -> list[dict]:
    from ..core.integridade import descrever
    substituidos = {str(i) for i in db.scalars(select(Documento.id).where(Documento.caso_id == caso_id,
                                                                          Documento.substituido.is_(True)))}
    saida = []
    for h in recuperacao.buscar(db, consulta, "autos", caso_id=caso_id, limite=limite + len(substituidos) * 2):
        t = db.get(Trecho, h["trecho_id"])
        if t.fonte_id in substituidos:
            continue
        if len(saida) >= limite:
            break
        doc = db.get(Documento, int(t.fonte_id)) if t.fonte_id.isdigit() else None
        rot = next((r for r in (doc.rotulos_pagina or []) if r.get("pagina") == t.pagina), None) if doc else None
        saida.append({"trecho_id": t.id, "documento_id": t.fonte_id, "pagina": t.pagina, "bbox": t.bbox,
                      "numeracao_autos": descrever(rot), "extra": t.extra,
                      "texto": t.texto, "relevancia": h["rrf"], **_ranks(h),
                      "marcador": f"[[autos:{t.fonte_id}:{t.pagina}]]"})
    return saida


def pesquisar_fonte(db: Session, fonte_tipo: str, consulta: str, limite: int = 5) -> list[dict]:
    """Doutrina e modelos (inclui material importado do EJC)."""
    vistos, saida = set(), []
    for h in recuperacao.buscar(db, consulta, fonte_tipo, limite=limite * 3):
        t = db.get(Trecho, h["trecho_id"])
        if t.fonte_id in vistos:
            continue
        vistos.add(t.fonte_id)
        saida.append({"fonte_id": t.fonte_id, "origem": t.origem, "titulo": (t.extra or {}).get("titulo"),
                      "trecho": t.texto[:1200], "relevancia": h["rrf"], **_ranks(h)})
    return saida[:limite]


def pesquisar_modelos(db: Session, consulta: str, limite: int = 3) -> list[dict]:
    return [{"modelo_id": x["fonte_id"], "trecho": x["trecho"][:600], "relevancia": x["relevancia"]}
            for x in pesquisar_fonte(db, "modelo", consulta, limite)]
