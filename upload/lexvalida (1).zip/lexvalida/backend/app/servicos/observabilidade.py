"""Observabilidade: custo, tempo, erros, fontes consultadas e decisões de aprovação, a partir da
trilha de auditoria (cada chamada de IA registra tokens, duração e custo estimado)."""
from __future__ import annotations

from collections import defaultdict
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Auditoria, agora


def _p95(vals: list[int]) -> int | None:
    if not vals:
        return None
    v = sorted(vals)
    return v[min(len(v) - 1, int(round(0.95 * (len(v) - 1))))]


def resumo(db: Session, dias: int = 30) -> dict:
    desde = agora() - timedelta(days=dias)
    llm = defaultdict(lambda: {"chamadas": 0, "erros": 0, "tokens": 0.0, "custo_estimado": 0.0, "duracoes": []})
    por_minuta = defaultdict(lambda: {"chamadas": 0, "tokens": 0.0, "custo_estimado": 0.0, "duracao_ms": 0})
    integracoes, aprovacoes, verif = defaultdict(int), defaultdict(int), {"total": 0, "bloqueadas": 0}
    erros_total, eventos = 0, 0
    for a in db.scalars(select(Auditoria).where(Auditoria.momento >= desde)):
        eventos += 1
        erros_total += bool(a.erro)
        if a.acao.startswith("llm:"):
            t = llm[a.acao[4:]]
            t["chamadas"] += 1
            t["erros"] += bool(a.erro)
            t["tokens"] += a.custo_tokens or 0
            t["custo_estimado"] += a.custo_estimado or 0
            if a.duracao_ms is not None:
                t["duracoes"].append(a.duracao_ms)
            if a.alvo.startswith("minuta:"):
                pm = por_minuta[a.alvo]
                pm["chamadas"] += 1
                pm["tokens"] += a.custo_tokens or 0
                pm["custo_estimado"] += a.custo_estimado or 0
                pm["duracao_ms"] += a.duracao_ms or 0
        elif a.acao.startswith("integracao:") or a.acao.startswith("conhecimento:"):
            integracoes[a.acao] += 1
        elif a.acao == "aprovacao":
            aprovacoes[a.usuario] += 1
        elif a.acao == "verificacao":
            verif["total"] += 1
            verif["bloqueadas"] += bool((a.detalhe or {}).get("bloqueado"))
    tarefas = {k: {"chamadas": v["chamadas"], "erros": v["erros"], "tokens": int(v["tokens"]),
                   "custo_estimado": round(v["custo_estimado"], 4),
                   "duracao_media_ms": int(sum(v["duracoes"]) / len(v["duracoes"])) if v["duracoes"] else None,
                   "duracao_p95_ms": _p95(v["duracoes"])} for k, v in sorted(llm.items())}
    top = sorted(({"minuta": k, **{kk: (round(vv, 4) if isinstance(vv, float) else vv) for kk, vv in v.items()}}
                  for k, v in por_minuta.items()), key=lambda x: -x["tokens"])[:10]
    return {"periodo_dias": dias, "eventos": eventos, "erros": erros_total,
            "ia": {"tarefas": tarefas, "total_tokens": sum(t["tokens"] for t in tarefas.values()),
                   "custo_estimado_total": round(sum(t["custo_estimado"] for t in tarefas.values()), 4),
                   "minutas_mais_custosas": top},
            "verificacoes": verif, "aprovacoes_por_responsavel": dict(aprovacoes),
            "fontes_e_integracoes": dict(integracoes),
            "nota": "Custo estimado só aparece com LLM_PRECO_ENTRADA_MTOK e LLM_PRECO_SAIDA_MTOK configurados."}
