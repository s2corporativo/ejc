"""Recuperação híbrida com dois backends e a mesma semântica:

PostgreSQL (produção), arquitetura do RAG do EJC:
  perna vetorial: pgvector, distância de cosseno (<=>), limiar RAG_MIN_SIM, índice HNSW
                  com hnsw.ef_search elevado na transação;
  perna trigram:  pg_trgm similarity (índice GIN);
  perna full-text: tsvector 'portuguese' com consulta em OR dos lexemas e ts_rank_cd
                  (o EJC usa plainto_tsquery, que exige todos os termos; o OR melhora o recall);
  fusão: Reciprocal Rank Fusion, k = RAG_RRF_K (60).

SQLite (desenvolvimento/testes): BM25 + cosseno em memória, mesma fusão RRF.
"""
from __future__ import annotations

import re
import threading

from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from ..config import get_config
from ..core import embeddings
from ..core.busca import BM25, cosseno, rrf
from ..models import Trecho

_lock = threading.Lock()
_mem: dict | None = None   # {"bm25": BM25, "vet": {id: vec}, "meta": {id: (fonte_tipo, caso_id)}}


def _pg(db: Session) -> bool:
    return db.get_bind().dialect.name == "postgresql"


# ------------------------------------------------------------------ escrita
def indexar(db: Session, itens: list[dict]) -> list[int]:
    """itens: {fonte_tipo, fonte_id, texto, caso_id?, pagina?, bbox?, ordem?, vetor?, origem?, extra?}.
    Itens sem `vetor` são vetorizados em lote; falha de embedding grava o trecho sem vetor
    (recuperável pelas pernas textuais, como no EJC)."""
    if not itens:
        return []
    faltam = [i for i, it in enumerate(itens) if it.get("vetor") is None]
    if faltam:
        vets = embeddings.gerar([itens[i]["texto"] for i in faltam], modo="passage")
        if vets:
            for i, v in zip(faltam, vets):
                itens[i]["vetor"] = v
    idx = None if _pg(db) else _indice_memoria(db)   # sincroniza antes de inserir (evita duplicar no índice)
    trechos = []
    for it in itens:
        t = Trecho(fonte_tipo=it["fonte_tipo"], fonte_id=str(it["fonte_id"]), caso_id=it.get("caso_id"),
                   ordem=it.get("ordem", 0), pagina=it.get("pagina"), bbox=it.get("bbox"), texto=it["texto"],
                   vetor=it.get("vetor"), origem=it.get("origem"), extra=it.get("extra"))
        db.add(t)
        trechos.append(t)
    db.flush()
    if idx is not None:
        with _lock:
            for t in trechos:
                _mem_add(idx, t)
    db.commit()
    _marcar_sincronizado(db)
    return [t.id for t in trechos]


def remover(db: Session, fonte_tipo: str, fonte_id: str) -> None:
    ts = db.scalars(select(Trecho).where(Trecho.fonte_tipo == fonte_tipo, Trecho.fonte_id == str(fonte_id))).all()
    if not _pg(db) and _mem is not None:
        with _lock:
            for t in ts:
                _mem["bm25"].remover(t.id)
                _mem["vet"].pop(t.id, None)
                _mem["meta"].pop(t.id, None)
    for t in ts:
        db.delete(t)
    db.commit()
    _marcar_sincronizado(db)


def resetar_memoria() -> None:
    global _mem
    with _lock:
        _mem = None


def _mem_add(idx: dict, t: Trecho) -> None:
    idx["bm25"].adicionar(t.id, t.texto)
    if t.vetor is not None:
        idx["vet"][t.id] = list(t.vetor)
    idx["meta"][t.id] = (t.fonte_tipo, t.caso_id)


def _impressao(db: Session) -> tuple:
    """Impressão digital barata da tabela de trechos: detecta gravações feitas por outro processo
    (ex.: script de importação rodando com o servidor no ar) e força a reconstrução do índice."""
    return tuple(db.execute(select(func.count(Trecho.id), func.max(Trecho.id))).one())


def _marcar_sincronizado(db: Session) -> None:
    if not _pg(db) and _mem is not None:
        with _lock:
            _mem["fp"] = _impressao(db)


def _indice_memoria(db: Session) -> dict:
    global _mem
    fp = _impressao(db)
    with _lock:
        if _mem is None or _mem.get("fp") != fp:
            _mem = {"bm25": BM25(), "vet": {}, "meta": {}, "fp": fp}
            for t in db.scalars(select(Trecho)):
                _mem_add(_mem, t)
        return _mem


# ------------------------------------------------------------------- leitura
def buscar(db: Session, consulta: str, fonte_tipo: str, caso_id: int | None = None, limite: int = 10) -> list[dict]:
    if not (consulta or "").strip():
        return []
    pool = max(limite * 3, 12)
    if _pg(db):
        return _buscar_pg(db, consulta, fonte_tipo, caso_id, limite, pool)
    return _buscar_memoria(db, consulta, fonte_tipo, caso_id, limite, pool)


def _fundir(pernas: dict[str, list[int]], limite: int, extras: dict[int, dict]) -> list[dict]:
    k = get_config().rag_rrf_k
    fund = rrf(list(pernas.values()), k=k)
    saida = []
    for tid, s in sorted(fund.items(), key=lambda x: -x[1])[:limite]:
        ranks = {f"rank_{n}": (lst.index(tid) + 1 if tid in lst else None) for n, lst in pernas.items()}
        saida.append({"trecho_id": tid, "rrf": round(s, 6), **ranks, **extras.get(tid, {})})
    return saida


def _buscar_memoria(db, consulta, fonte_tipo, caso_id, limite, pool) -> list[dict]:
    idx = _indice_memoria(db)
    cands = {i for i, (ft, cid) in idx["meta"].items()
             if ft == fonte_tipo and (caso_id is None or cid == caso_id)}
    if not cands:
        return []
    lex = [i for i, _ in idx["bm25"].buscar(consulta, cands, pool)]
    pernas = {"lexical": lex}
    extras: dict[int, dict] = {}
    qv = embeddings.gerar([consulta], modo="query")
    if qv:
        min_sim = get_config().rag_min_sim if embeddings.provider() != "hash" else -1.0
        sims = [(i, cosseno(qv[0], idx["vet"][i])) for i in cands if i in idx["vet"]]
        sims = sorted([x for x in sims if x[1] >= min_sim], key=lambda x: -x[1])[:pool]
        pernas["vetorial"] = [i for i, _ in sims]
        extras = {i: {"similaridade": round(s, 4)} for i, s in sims}
    return _fundir(pernas, limite, extras)


_RX_LEX = re.compile(r"[^\W_]{3,}", re.UNICODE)


def _tsquery_or(consulta: str) -> str:
    """Lexemas em OR para to_tsquery. Mantém acentos (o dicionário 'portuguese' faz o
    stemming sobre a forma acentuada, igual ao to_tsvector do documento). Só caracteres de
    palavra entram: nenhum operador do usuário chega ao to_tsquery."""
    termos = list(dict.fromkeys(_RX_LEX.findall((consulta or "").lower())))[:12]
    return " | ".join(termos)


def _buscar_pg(db, consulta, fonte_tipo, caso_id, limite, pool) -> list[dict]:
    cfg = get_config()
    filtro = "fonte_tipo = :ft" + (" AND caso_id = :caso" if caso_id is not None else "")
    base = {"ft": fonte_tipo, "lim": pool}
    if caso_id is not None:
        base["caso"] = caso_id
    pernas: dict[str, list[int]] = {}
    extras: dict[int, dict] = {}

    qv = embeddings.gerar([consulta], modo="query")
    if qv:
        max_dist = 2.0 if embeddings.provider() == "hash" else max(0.0, min(2.0, 1.0 - cfg.rag_min_sim))
        try:
            db.execute(text(f"SET LOCAL hnsw.ef_search = {int(cfg.rag_ef_search)}"))
        except Exception:  # noqa: BLE001
            db.rollback()
        try:
            rows = db.execute(text(f"""
                SELECT id, (vetor <=> CAST(:vec AS vector)) AS dist FROM trechos
                WHERE {filtro} AND vetor IS NOT NULL AND (vetor <=> CAST(:vec AS vector)) <= :max_dist
                ORDER BY vetor <=> CAST(:vec AS vector) LIMIT :lim"""),
                {**base, "vec": str(qv[0]), "max_dist": max_dist}).all()
            pernas["vetorial"] = [r.id for r in rows]
            for r in rows:
                extras.setdefault(r.id, {})["similaridade"] = round(1 - float(r.dist), 4)
        except Exception:  # noqa: BLE001 — degrada para as pernas textuais
            db.rollback()

    if cfg.rag_trgm_enabled:
        try:
            rows = db.execute(text(f"""
                SELECT id FROM trechos WHERE {filtro} AND similarity(texto, :q) > 0.05
                ORDER BY similarity(texto, :q) DESC LIMIT :lim"""), {**base, "q": consulta[:300]}).all()
            pernas["trigram"] = [r.id for r in rows]
        except Exception:  # noqa: BLE001
            db.rollback()

    tsq = _tsquery_or(consulta)
    if cfg.rag_fts_enabled and tsq:
        try:
            rows = db.execute(text(f"""
                SELECT id FROM trechos
                WHERE {filtro} AND to_tsvector('portuguese', texto) @@ to_tsquery('portuguese', :tsq)
                ORDER BY ts_rank_cd(to_tsvector('portuguese', texto), to_tsquery('portuguese', :tsq)) DESC
                LIMIT :lim"""), {**base, "tsq": tsq}).all()
            pernas["fts"] = [r.id for r in rows]
        except Exception:  # noqa: BLE001
            db.rollback()
    return _fundir(pernas, limite, extras)
