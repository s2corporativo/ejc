"""Editor com blocos estáveis e sugestões ancoradas.

Cada linha da minuta é um bloco com ID estável. Quando o texto muda (edição livre, molde, sugestão),
os IDs são realinhados por correspondência de sequência: blocos inalterados mantêm o ID, blocos
alterados no mesmo lugar mantêm o ID, inseridos recebem ID novo. Sugestões (da IA ou de pessoas)
apontam para um bloco e guardam o texto original: se o bloco mudou depois, a sugestão fica obsoleta
em vez de sobrescrever trabalho posterior. Aceitar gera nova versão e nova verificação.
Modos: "minuta" (sugestões pendentes para decisão) e "auto" (aplica e registra cada uma).
"""
from __future__ import annotations

import difflib
import json

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core.citacoes import RX_AUTOS, RX_JURIS, RX_LEI
from ..llm import prompts
from ..llm.provedores import construir, extrair_json
from ..models import Caso, Minuta, Sugestao, VersaoMinuta, agora
from . import auditoria


class ErroEditor(ValueError):
    pass


def _novo_id(est: dict) -> str:
    est["bloco_seq"] = int(est.get("bloco_seq", 0)) + 1
    return f"b{est['bloco_seq']:05d}"


def sincronizar(m: Minuta) -> list[dict]:
    """Realinha os blocos ao texto atual da minuta e devolve a lista [{id, texto}]."""
    est = dict(m.estado or {})
    antigos = est.get("blocos") or []
    linhas = (m.texto or "").split("\n")
    if [b["texto"] for b in antigos] == linhas:
        return antigos
    novos: list[dict] = []
    sm = difflib.SequenceMatcher(a=[b["texto"] for b in antigos], b=linhas, autojunk=False)
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            novos += [{"id": antigos[i1 + k]["id"], "texto": linhas[j1 + k]} for k in range(j2 - j1)]
        elif op == "replace":
            for k in range(j2 - j1):
                bid = antigos[i1 + k]["id"] if i1 + k < i2 else _novo_id(est)
                novos.append({"id": bid, "texto": linhas[j1 + k]})
        elif op == "insert":
            novos += [{"id": _novo_id(est), "texto": linhas[j1 + k]} for k in range(j2 - j1)]
    est["blocos"] = novos
    m.estado = est
    return novos


def _texto(blocos: list[dict]) -> str:
    return "\n".join(b["texto"] for b in blocos)


def _marcadores(t: str) -> set[str]:
    return {x.group(0) for rx in (RX_JURIS, RX_LEI, RX_AUTOS) for x in rx.finditer(t or "")}


def _sug(s: Sugestao) -> dict:
    return {"id": s.id, "bloco_id": s.bloco_id, "original": s.original, "proposto": s.proposto, "motivo": s.motivo,
            "autor": s.autor, "status": s.status, "decidido_por": s.decidido_por,
            "decidido_em": s.decidido_em.isoformat() if s.decidido_em else None, "criado_em": s.criado_em.isoformat()}


def blocos(db: Session, minuta_id: int) -> dict:
    m = db.get(Minuta, minuta_id)
    if not m:
        raise ErroEditor("Minuta inexistente.")
    bl = sincronizar(m)
    db.commit()
    pend = db.scalars(select(Sugestao).where(Sugestao.minuta_id == m.id).order_by(Sugestao.id)).all()
    return {"minuta_id": m.id, "status": m.status, "blocos": bl, "sugestoes": [_sug(s) for s in pend]}


def sugerir(db: Session, minuta_id: int, bloco_id: str, proposto: str, motivo: str = "", autor: str = "local") -> Sugestao:
    m = db.get(Minuta, minuta_id)
    if not m:
        raise ErroEditor("Minuta inexistente.")
    if m.status == "APROVADA":
        raise ErroEditor("Minuta aprovada é imutável.")
    bl = {b["id"]: b for b in sincronizar(m)}
    if bloco_id not in bl:
        raise ErroEditor(f"Bloco {bloco_id} inexistente.")
    original = bl[bloco_id]["texto"]
    perdidos = _marcadores(original) - _marcadores(proposto)
    if perdidos:
        motivo = (motivo + " " if motivo else "") + f"[ATENÇÃO: remove citação verificável {', '.join(sorted(perdidos))}]"
    s = Sugestao(minuta_id=m.id, bloco_id=bloco_id, original=original, proposto=proposto, motivo=motivo, autor=autor)
    db.add(s)
    db.commit()
    return s


def decidir(db: Session, sugestao_id: int, aceitar: bool, responsavel: str = "local", verificar: bool = True) -> dict:
    s = db.get(Sugestao, sugestao_id)
    if not s or s.status != "pendente":
        raise ErroEditor("Sugestão inexistente ou já decidida.")
    m = db.get(Minuta, s.minuta_id)
    if m.status == "APROVADA":
        raise ErroEditor("Minuta aprovada é imutável.")
    bl = sincronizar(m)
    alvo = next((b for b in bl if b["id"] == s.bloco_id), None)
    s.decidido_por, s.decidido_em = responsavel, agora()
    if not aceitar:
        s.status = "rejeitada"
        db.commit()
        auditoria.registrar(db, "editor:sugestao_rejeitada", f"minuta:{m.id}", {"sugestao": s.id}, usuario=responsavel)
        return {"sugestao": _sug(s)}
    if alvo is None or alvo["texto"] != s.original:
        s.status = "obsoleta"
        db.commit()
        raise ErroEditor("O bloco mudou depois da sugestão: ela ficou obsoleta. Gere nova sugestão.")
    alvo["texto"] = s.proposto
    novas = s.proposto.split("\n")
    if len(novas) > 1:  # sugestão que divide o parágrafo: primeiras linhas no bloco, demais em blocos novos
        est = dict(m.estado)
        idx = bl.index(alvo)
        alvo["texto"] = novas[0]
        for k, linha in enumerate(novas[1:], start=1):
            bl.insert(idx + k, {"id": _novo_id(est), "texto": linha})
        m.estado = est
    est = dict(m.estado)
    est["blocos"] = bl
    m.estado = est
    m.texto = _texto(bl)
    s.status = "aceita"
    db.add(VersaoMinuta(minuta_id=m.id, texto=m.texto, nota=f"Sugestão #{s.id} aceita (bloco {s.bloco_id})", autor=responsavel))
    db.commit()
    auditoria.registrar(db, "editor:sugestao_aceita", f"minuta:{m.id}", {"sugestao": s.id, "bloco": s.bloco_id},
                        usuario=responsavel)
    for outra in db.scalars(select(Sugestao).where(Sugestao.minuta_id == m.id, Sugestao.bloco_id == s.bloco_id,
                                                   Sugestao.status == "pendente")):
        outra.status = "obsoleta"
    db.commit()
    if verificar and m.fase in ("revisao", "verificacao"):
        from ..agente import pipeline
        pipeline.verificar(db, m.id)
    return {"sugestao": _sug(s), "texto": m.texto}


def sugerir_ia(db: Session, minuta_id: int, instrucao: str, bloco_ids: list[str] | None = None,
               modo: str = "minuta", responsavel: str = "local") -> dict:
    m = db.get(Minuta, minuta_id)
    if not m:
        raise ErroEditor("Minuta inexistente.")
    if m.status == "APROVADA":
        raise ErroEditor("Minuta aprovada é imutável.")
    bl = [b for b in sincronizar(m) if b["texto"].strip()]
    if bloco_ids:
        bl = [b for b in bl if b["id"] in set(bloco_ids)]
    if not bl:
        raise ErroEditor("Nenhum bloco selecionado.")
    caso = db.get(Caso, m.caso_id) if m.caso_id else None
    prov = construir(papel="redator", sigiloso=bool(caso and caso.sigiloso and not (m.estado or {}).get("anonimizado")))
    usuario = f"INSTRUÇÃO: {instrucao}\n<blocos>\n{json.dumps(bl[:200], ensure_ascii=False)}\n</blocos>"
    r = prov.gerar("sugerir", prompts.SISTEMA_BASE + "\n\n" + prompts.SUGERIR, usuario, {"instrucao": instrucao, "blocos": bl})
    auditoria.registrar(db, "llm:sugerir", f"minuta:{m.id}", {"uso": r.uso}, f"{r.provedor}:{r.modelo}")
    ids_validos = {b["id"] for b in bl}
    criadas, ignoradas = [], []
    for it in extrair_json(r.texto).get("sugestoes", []):
        if it.get("bloco_id") not in ids_validos or not isinstance(it.get("proposto"), str):
            ignoradas.append(it.get("bloco_id"))
            continue
        criadas.append(sugerir(db, m.id, it["bloco_id"], it["proposto"], it.get("motivo", ""), autor=f"ia:{r.provedor}"))
    aplicadas = []
    if modo == "auto":
        for s in criadas:
            if "[ATENÇÃO" in s.motivo:
                continue   # nunca aplica automaticamente sugestão que remove citação verificável
            decidir(db, s.id, True, responsavel=f"auto ({responsavel})", verificar=False)
            aplicadas.append(s.id)
        if aplicadas and m.fase in ("revisao", "verificacao"):
            from ..agente import pipeline
            pipeline.verificar(db, m.id)
    return {"criadas": [_sug(db.get(Sugestao, s.id)) for s in criadas], "aplicadas": aplicadas,
            "ignoradas_bloco_invalido": ignoradas}


def restaurar_versao(db: Session, minuta_id: int, versao_id: int, responsavel: str = "local") -> Minuta:
    v = db.get(VersaoMinuta, versao_id)
    if not v or v.minuta_id != minuta_id:
        raise ErroEditor("Versão inexistente para esta minuta.")
    from ..agente import pipeline
    return pipeline.editar(db, minuta_id, v.texto, nota=f"Restaurada a versão #{versao_id}")
