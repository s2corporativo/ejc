"""Conformidade LGPD do próprio sistema.

- Registro das operações de tratamento (LGPD, art. 37), derivado da trilha de auditoria.
- Relatório de Impacto à Proteção de Dados Pessoais (RIPD, art. 38), gerado a partir da
  configuração efetiva (provedores de IA, local ou nuvem, pseudonimização, retenção).
O RIPD gerado é um rascunho técnico: o controlador (escritório) deve revisá-lo e assiná-lo.
"""
from __future__ import annotations

from collections import Counter
from datetime import date

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..config import get_config
from ..models import Auditoria, Caso, Documento, Intimacao, Minuta

FINALIDADES = {
    "documento": ("Ingestão de documentos dos autos", "Exercício regular de direitos em processo (LGPD, art. 7º, VI; art. 11, II, d)"),
    "llm": ("Geração e verificação de minutas por IA", "Exercício regular de direitos e execução de contrato com o cliente (art. 7º, V e VI)"),
    "intimacoes": ("Captura de intimações publicadas", "Cumprimento de obrigação legal ou regulatória e exercício de direitos (art. 7º, II e VI)"),
    "conhecimento": ("Base de conhecimento jurídico (fontes públicas)", "Dados públicos (art. 7º, § 3º e § 4º)"),
    "caso": ("Cadastro de casos", "Execução de contrato e exercício regular de direitos (art. 7º, V e VI)"),
    "verificacao": ("Verificação de citações e prazos", "Exercício regular de direitos (art. 7º, VI)"),
    "aprovacao": ("Aprovação humana de minutas", "Exercício regular de direitos (art. 7º, VI)"),
    "monitor": ("Monitoramento de precedentes e temas", "Legítimo interesse do escritório na defesa do cliente (art. 7º, IX)"),
    "distinguishing": ("Análise de precedentes", "Exercício regular de direitos (art. 7º, VI)"),
    "lote": ("Geração em lote", "Exercício regular de direitos (art. 7º, VI)"),
    "editor": ("Edição assistida de minutas", "Exercício regular de direitos (art. 7º, VI)"),
    "estilo": ("Perfis de estilo a partir de modelos do escritório", "Legítimo interesse (art. 7º, IX)"),
    "prova": ("Recorte de imagens de prova dos autos", "Exercício regular de direitos (art. 7º, VI; art. 11, II, d)"),
    "usuario": ("Gestão de usuários e acessos", "Execução de contrato e legítimo interesse (art. 7º, V e IX)"),
    "precedente": ("Conferência de precedentes", "Dados públicos (art. 7º, §§ 3º e 4º)"),
}


def registro_operacoes(db: Session) -> dict:
    cont, provs = Counter(), Counter()
    for a in db.scalars(select(Auditoria)):
        prefixo = a.acao.split(":")[0]
        cont[prefixo] += 1
        if a.provedor:
            provs[a.provedor.split(":")[0]] += 1
    linhas = [{"operacao": k, "finalidade": FINALIDADES.get(k, (k, "a classificar"))[0],
               "base_legal_sugerida": FINALIDADES.get(k, (k, "a classificar pelo encarregado"))[1], "ocorrencias": v}
              for k, v in sorted(cont.items())]
    return {"gerado_em": date.today().isoformat(), "operacoes": linhas, "provedores_de_ia_utilizados": dict(provs),
            "nota": "Bases legais sugeridas para validação do encarregado (LGPD, art. 41)."}


def ripd(db: Session) -> str:
    cfg = get_config()
    n = lambda m: db.scalar(select(func.count()).select_from(m))  # noqa: E731
    sigilosos = db.scalar(select(func.count()).select_from(Caso).where(Caso.sigiloso.is_(True)))
    nuvem = cfg.llm_provider in ("anthropic", "openai_compat") and not cfg.llm_base_url.startswith("http://ollama")
    ops = registro_operacoes(db)["operacoes"]
    linhas_ops = "\n".join(f"| {o['finalidade']} | {o['base_legal_sugerida']} | {o['ocorrencias']} |" for o in ops) or "| (sem operações registradas) | | |"
    return f"""# Relatório de Impacto à Proteção de Dados Pessoais (RASCUNHO)
Sistema: LexValida | Gerado em {date.today():%d/%m/%Y} | Base: LGPD, art. 38

## 1. Descrição do tratamento
Apoio à atividade advocatícia: ingestão de autos, pesquisa jurídica, geração e verificação de minutas,
cálculo de prazos e monitoramento de precedentes. Volume atual: {n(Caso)} casos ({sigilosos} sigilosos),
{n(Documento)} documentos, {n(Minuta)} minutas, {n(Intimacao)} intimações.

## 2. Dados tratados
Dados pessoais de clientes e partes contrárias constantes dos autos (identificação, contato, dados
processuais) e, conforme o caso, dados sensíveis (saúde, menores, matéria penal) em processos sigilosos.

## 3. Operações e bases legais
| Finalidade | Base legal sugerida | Ocorrências |
|---|---|---|
{linhas_ops}

## 4. Compartilhamento e transferência internacional
- IA redatora: {cfg.llm_provider}{' (provedor em nuvem: avaliar art. 33 e contrato de operador)' if nuvem else ''}.
- IA verificadora: {cfg.verificador_provider or cfg.llm_provider}.
- IA local para casos sigilosos: {'configurada' if cfg.local_provider_base_url else 'NÃO configurada (casos sigilosos bloqueados para nuvem)'}.
- Embeddings: {cfg.embeddings_provider} ({cfg.embeddings_model}); provider local não envia dados a terceiros.
- Transcrição de áudio e vídeo: {cfg.transcricao_provider}{' (serviço externo: avaliar art. 33 e contrato de operador)' if cfg.transcricao_provider == 'openai_compat' else ''}. A voz é dado pessoal; o sistema não faz identificação biométrica de falantes.
- Integrações oficiais (DataJud, DJEN, SGT, STJ): somente consultas a dados públicos.

## 5. Medidas de segurança
Pseudonimização reversível com cofre, bloqueio de nuvem para casos sigilosos, detecção de prompt injection
em duas camadas, revisão humana obrigatória antes da aprovação, trilha de auditoria com autoria, usuários com papéis e isolamento por caso, token de API
({'ativo' if cfg.api_token else 'NÃO configurado'}), arquivos originais com SHA-256, banco com acesso restrito ao host.

## 6. Riscos e mitigação
| Risco | Mitigação |
|---|---|
| Vazamento a provedor de IA | Pseudonimização; IA local para sigilo; contrato de operador |
| Citação inexistente ou superada | Protocolo de marcadores e bloqueio na verificação |
| Reidentificação por dados indiretos | Alerta de identificadores indiretos |
| Acesso indevido | Token de API, rede restrita, auditoria |

## 7. Pendências do controlador
Validar bases legais, definir prazos de retenção, registrar o encarregado (art. 41), aprovar e assinar.
"""
