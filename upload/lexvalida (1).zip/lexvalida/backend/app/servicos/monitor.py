"""Monitor jurídico contínuo.

1. Precedente alterado (superado, cancelado, modulado, afetado, em revisão): toda minuta que o
   cita é reverificada. Minuta APROVADA é imutável, então gera alerta crítico para o advogado
   avaliar petição de esclarecimento, aditamento ou recurso conforme a fase do processo.
2. Tema afetado (repetitivo, repercussão geral, IRDR/IAC): cruza com a carteira por assunto TPU
   (vínculo forte) e por similaridade com os autos (vínculo a conferir). Base: CPC, art. 1.037, II
   (suspensão de processos) e art. 1.036.
Todas as operações são idempotentes (chave única por alerta).
"""
from __future__ import annotations

import re

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core.aderencia import heuristica
from ..core.hierarquia import avaliar_status
from ..models import Alerta, Caso, Minuta, Precedente
from . import auditoria, conhecimento, documentos

TIPOS_TEMA = {"repetitivo", "repercussao_geral", "irdr_iac", "controle_concentrado"}


def alertar(db: Session, chave: str, tipo: str, nivel: str, mensagem: str, **campos) -> Alerta | None:
    if db.scalar(select(Alerta).where(Alerta.chave == chave)):
        return None
    a = Alerta(chave=chave[:200], tipo=tipo, nivel=nivel, mensagem=mensagem,
               caso_id=campos.get("caso_id"), minuta_id=campos.get("minuta_id"),
               precedente_id=campos.get("precedente_id"), intimacao_id=campos.get("intimacao_id"),
               detalhe=campos.get("detalhe") or {})
    db.add(a)
    db.commit()
    return a


def minutas_que_citam(db: Session, pid: str) -> list[Minuta]:
    alvo = "{{juris:" + pid + "}}"
    return [m for m in db.scalars(select(Minuta).where(Minuta.status != "DESCARTADA")) if alvo in (m.texto or "")]


def reverificar_citacoes(db: Session, m: Minuta) -> dict:
    """Reverificação determinística (sem nova chamada de IA): reaplica o resolvedor de citações."""
    caso = db.get(Caso, m.caso_id) if m.caso_id else None
    res = documentos.resolver_citacoes(db, m.texto, caso.data_fatos if caso else None)
    v = dict(m.verificacao or {})
    outros = [p for p in v.get("problemas", []) if p.get("tipo") in ("aderencia", "cofre")]
    v["problemas"] = [p.as_dict() for p in res.problemas] + outros
    v["bloqueado"] = any(p["nivel"] == "bloqueante" for p in v["problemas"]) or \
        (v.get("seguranca") or {}).get("indicador") == "possivel_injecao"
    m.verificacao = v
    if m.status != "APROVADA":
        m.texto_resolvido = res.texto + ("\n\n" + res.anexo if res.anexo else "")
    db.commit()
    return v


def precedente_alterado(db: Session, pid: str, status_anterior: str | None) -> list[int]:
    p = db.get(Precedente, pid)
    if not p or p.status == status_anterior:
        return []
    st = avaliar_status(p.status)
    gerados = []
    for m in minutas_que_citam(db, pid):
        reverificar_citacoes(db, m)
        nivel = "critico" if (st["bloqueia"] and m.status == "APROVADA") else ("alerta" if st["alerta"] else "info")
        situacao = "aprovada (imutável)" if m.status == "APROVADA" else "em rascunho (reverificada)"
        a = alertar(db, f"prec:{pid}:{p.status}:min:{m.id}", "precedente_alterado", nivel,
                    f"{p.rotulo} passou de '{status_anterior}' para '{p.status}'. A minuta #{m.id} ({situacao}) o cita. "
                    f"{st['alerta'] or ''}".strip(), minuta_id=m.id, caso_id=m.caso_id, precedente_id=pid,
                    detalhe={"de": status_anterior, "para": p.status, "nota": p.status_nota})
        if a:
            gerados.append(a.id)
    auditoria.registrar(db, "monitor:precedente_alterado", f"precedente:{pid}", {"alertas": len(gerados)})
    return gerados


def _codigos(lista) -> set[int]:
    saida = set()
    for x in lista or []:
        v = x.get("codigo") if isinstance(x, dict) else x
        try:
            saida.add(int(v))
        except (TypeError, ValueError):
            continue
    return saida


def varrer_temas(db: Session, limiar_textual: float = 0.12) -> list[int]:
    temas = db.scalars(select(Precedente).where(Precedente.tipo.in_(TIPOS_TEMA), Precedente.status == "afetado")).all()
    casos = db.scalars(select(Caso)).all()
    gerados = []
    for t in temas:
        cods_tema = _codigos(t.assuntos_tpu)
        texto_tema = t.tese or t.ementa
        for c in casos:
            comum = cods_tema & _codigos(c.assuntos_tpu)
            if comum:
                nivel, motivo = ("critico" if t.suspensao_nacional else "alerta"), f"assunto TPU em comum {sorted(comum)}"
            else:
                trechos = conhecimento.pesquisar_autos(db, c.id, texto_tema, limite=3)
                melhor = max((heuristica(texto_tema, x["texto"])["sobreposicao"] for x in trechos), default=0.0)
                if melhor < limiar_textual:
                    continue
                nivel, motivo = "alerta", f"similaridade textual com os autos ({melhor:.2f}); conferir"
            sus = " Há ordem de suspensão nacional: verificar sobrestamento (CPC, art. 1.037, II)." if t.suspensao_nacional else ""
            a = alertar(db, f"tema:{t.id}:caso:{c.id}", "tema_afetado", nivel,
                        f"Caso #{c.id} ({c.titulo}) pode ser alcançado por {t.rotulo}, afetado para julgamento ({motivo}).{sus}",
                        caso_id=c.id, precedente_id=t.id, detalhe={"motivo": motivo, "suspensao_nacional": t.suspensao_nacional})
            if a:
                gerados.append(a.id)
    return gerados


def varrer_aprovadas(db: Session) -> list[int]:
    """Varredura completa: minutas aprovadas que citam precedente hoje não vigente."""
    gerados = []
    rx = re.compile(r"\{\{juris:([a-z0-9][a-z0-9._-]*)\}\}", re.I)
    for m in db.scalars(select(Minuta).where(Minuta.status == "APROVADA")):
        for pid in set(x.lower() for x in rx.findall(m.texto or "")):
            p = db.get(Precedente, pid)
            if p and p.status != "vigente":
                st = avaliar_status(p.status)
                a = alertar(db, f"prec:{pid}:{p.status}:min:{m.id}", "precedente_alterado",
                            "critico" if st["bloqueia"] else "alerta",
                            f"Minuta aprovada #{m.id} cita {p.rotulo}, hoje com status '{p.status}'. {st['alerta'] or ''}".strip(),
                            minuta_id=m.id, caso_id=m.caso_id, precedente_id=pid)
                if a:
                    gerados.append(a.id)
    return gerados


def executar(db: Session) -> dict:
    r = {"temas": varrer_temas(db), "aprovadas": varrer_aprovadas(db)}
    auditoria.registrar(db, "monitor:execucao", "", {k: len(v) for k, v in r.items()})
    return {k: len(v) for k, v in r.items()}


def listar(db: Session, apenas_abertos: bool = True, caso_id: int | None = None) -> list[dict]:
    q = select(Alerta).order_by(Alerta.id.desc())
    if apenas_abertos:
        q = q.where(Alerta.resolvido.is_(False))
    if caso_id:
        q = q.where(Alerta.caso_id == caso_id)
    ordem = {"critico": 0, "alerta": 1, "info": 2}
    itens = [{"id": a.id, "tipo": a.tipo, "nivel": a.nivel, "mensagem": a.mensagem, "caso_id": a.caso_id,
              "minuta_id": a.minuta_id, "precedente_id": a.precedente_id, "intimacao_id": a.intimacao_id,
              "resolvido": a.resolvido, "detalhe": a.detalhe, "criado_em": a.criado_em.isoformat()}
             for a in db.scalars(q.limit(500))]
    return sorted(itens, key=lambda x: (ordem.get(x["nivel"], 3), -x["id"]))
