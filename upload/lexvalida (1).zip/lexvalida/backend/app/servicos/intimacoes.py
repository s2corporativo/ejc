"""Intimações: captura (DJEN ou registro manual), vínculo ao caso, prazo calculado e minuta.

O prazo só é calculado automaticamente quando o próprio texto da intimação o declara
("prazo de 15 (quinze) dias", "em 8 dias"). Caso contrário, fica pendente de informação pelo
advogado: o sistema não presume o prazo do ato.
"""
from __future__ import annotations

import hashlib
import re
from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core.prazos import Calendario, Contagem, Termo, calcular_prazo
from ..core.texto import normalizar
from ..integracoes import djen
from ..models import Caso, Intimacao
from . import auditoria, monitor

RX_PRAZO = [
    re.compile(r"prazo\s+(?:legal\s+)?(?:comum\s+)?de\s+(\d{1,3})\s*(?:\([^)]{1,30}\))?\s*dias?\s*(uteis|corridos)?"),
    re.compile(r"\b(?:em|no\s+prazo\s+de)\s+(\d{1,3})\s*(?:\([^)]{1,30}\))?\s*dias?\s*(uteis|corridos)?"),
    re.compile(r"\b(\d{1,3})\s*(?:\([^)]{1,30}\))?\s*dias?\s*(uteis|corridos)?\s*para\s"),
]


def extrair_prazo(texto: str) -> tuple[int | None, str | None]:
    t = normalizar(texto)
    for rx in RX_PRAZO:
        m = rx.search(t)
        if m:
            dias = int(m.group(1))
            if 0 < dias <= 365:
                return dias, m.group(2)
    return None, None


def _digitos(n: str | None) -> str:
    return re.sub(r"\D", "", n or "")


def _vincular_caso(db: Session, numero: str | None) -> int | None:
    d = _digitos(numero)
    if len(d) != 20:
        return None
    for c in db.scalars(select(Caso).where(Caso.numero_processo.is_not(None))):
        if _digitos(c.numero_processo) == d:
            return c.id
    return None


def calcular(db: Session, it: Intimacao, dias: int | None = None, contagem: str | None = None,
             calendario: Calendario | None = None) -> Intimacao:
    if dias:
        it.prazo_dias, it.prazo_origem = dias, "informado"
    if it.prazo_dias and it.data_disponibilizacao:
        cont = Contagem.CORRIDOS if contagem == "corridos" else Contagem.UTEIS
        r = calcular_prazo(it.data_disponibilizacao, it.prazo_dias, Termo.DJE, cont, calendario)
        it.vencimento = r.vencimento
        it.memoria_prazo = r.memoria + r.alertas + (
            ["Prazo extraído do texto da intimação: confirmar a natureza do ato e a contagem."]
            if it.prazo_origem == "extraido_do_texto" else [])
        dias_rest = (r.vencimento - date.today()).days
        nivel = "critico" if dias_rest <= 3 else "alerta" if dias_rest <= 7 else "info"
        monitor.alertar(db, f"intim:{it.id}:venc:{r.vencimento.isoformat()}", "prazo", nivel,
                        f"Intimação #{it.id} ({it.numero_processo or 'sem número'}): vencimento em {r.vencimento:%d/%m/%Y}.",
                        caso_id=it.caso_id, intimacao_id=it.id, detalhe={"vencimento": r.vencimento.isoformat()})
    db.commit()
    return it


def registrar(db: Session, itens: list[dict], origem: str = "djen") -> dict:
    novas, existentes = [], 0
    for x in itens:
        idx = x.get("id_externo") or hashlib.sha1(
            f"{x.get('numero_processo')}|{x.get('data_disponibilizacao')}|{x.get('texto', '')}".encode()).hexdigest()
        if db.scalar(select(Intimacao).where(Intimacao.origem == origem, Intimacao.id_externo == str(idx))):
            existentes += 1
            continue
        dias, tipo_cont = extrair_prazo(x.get("texto", ""))
        dd = x.get("data_disponibilizacao")
        it = Intimacao(origem=origem, id_externo=str(idx), numero_processo=x.get("numero_processo"),
                       tribunal=x.get("tribunal"), orgao=x.get("orgao"), tipo=x.get("tipo"),
                       data_disponibilizacao=date.fromisoformat(dd) if isinstance(dd, str) and dd else dd,
                       texto=x.get("texto", ""), link=x.get("link"),
                       caso_id=x.get("caso_id") or _vincular_caso(db, x.get("numero_processo")),
                       prazo_dias=dias, prazo_origem="extraido_do_texto" if dias else None)
        db.add(it)
        db.commit()
        calcular(db, it, contagem=tipo_cont)
        novas.append(it.id)
    auditoria.registrar(db, "intimacoes:registrar", origem, {"novas": len(novas), "existentes": existentes})
    return {"novas": novas, "existentes": existentes}


def sincronizar_djen(db: Session, oabs: list[tuple[str, str]], inicio: date | None = None, fim: date | None = None,
                     cliente=None) -> dict:
    total = {"novas": [], "existentes": 0, "erros": []}
    for numero, uf in oabs:
        try:
            r = registrar(db, djen.consultar_por_oab(numero, uf, inicio, fim, cliente=cliente), "djen")
            total["novas"] += r["novas"]
            total["existentes"] += r["existentes"]
        except djen.ErroDJEN as e:
            total["erros"].append({"oab": f"{numero}/{uf}", "erro": str(e)})
    return total


def parse_oabs(texto: str) -> list[tuple[str, str]]:
    saida = []
    for parte in (texto or "").split(","):
        m = re.match(r"\s*([\d.]+)\s*/\s*([A-Za-z]{2})\s*$", parte)
        if m:
            saida.append((m.group(1).replace(".", ""), m.group(2).upper()))
    return saida


def as_dict(it: Intimacao) -> dict:
    return {"id": it.id, "origem": it.origem, "numero_processo": it.numero_processo, "tribunal": it.tribunal,
            "orgao": it.orgao, "tipo": it.tipo, "data_disponibilizacao": it.data_disponibilizacao,
            "texto": it.texto[:3000], "link": it.link, "caso_id": it.caso_id, "prazo_dias": it.prazo_dias,
            "prazo_origem": it.prazo_origem, "vencimento": it.vencimento, "memoria_prazo": it.memoria_prazo,
            "minuta_id": it.minuta_id, "status": it.status}
