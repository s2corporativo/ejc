"""Imagens de prova: recorte de área de página do PDF original dos autos.

O recorte é feito a partir do ARQUIVO ORIGINAL preservado (conferido pelo SHA-256 antes do recorte),
com legenda e origem (documento, página física, numeração dos autos). Inserido na peça pelo marcador
[[print:ID]]. O recorte comprova de onde a imagem saiu; não atesta a autenticidade do documento.
"""
from __future__ import annotations

from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core.integridade import descrever, sha256_bytes
from ..models import Documento, ProvaImagem
from .documentos import rotulo_de

try:
    import pymupdf as fitz
except ImportError:  # pragma: no cover
    import fitz

DPI = 150
LIMITE_AREA_PX = 4000 * 4000


class ErroProva(ValueError):
    pass


def recortar(db: Session, documento_id: int, pagina: int, bbox: list[float], legenda: str,
             usuario: str = "local") -> ProvaImagem:
    doc = db.get(Documento, documento_id)
    if not doc:
        raise ErroProva("Documento inexistente.")
    if doc.tipo != "pdf" or not doc.arquivo or not Path(doc.arquivo).exists():
        raise ErroProva("Recorte exige o PDF original preservado no servidor.")
    dados = Path(doc.arquivo).read_bytes()
    if doc.sha256 and sha256_bytes(dados) != doc.sha256:
        raise ErroProva("O arquivo preservado não confere com o SHA-256 registrado: recorte recusado.")
    if len(bbox) != 4 or bbox[2] <= bbox[0] or bbox[3] <= bbox[1]:
        raise ErroProva("Área inválida: informe [x0, y0, x1, y1] em pontos do PDF, com x1 > x0 e y1 > y0.")
    pdf = fitz.open(stream=dados, filetype="pdf")
    try:
        if not 1 <= pagina <= pdf.page_count:
            raise ErroProva(f"Página {pagina} inexistente (o documento tem {pdf.page_count}).")
        pg = pdf[pagina - 1]
        clip = fitz.Rect(*bbox) & pg.rect
        if clip.is_empty:
            raise ErroProva("A área informada está fora da página.")
        zoom = DPI / 72
        if clip.width * zoom * clip.height * zoom > LIMITE_AREA_PX:
            raise ErroProva("Área grande demais para recorte.")
        png = pg.get_pixmap(clip=clip, matrix=fitz.Matrix(zoom, zoom)).tobytes("png")
    finally:
        pdf.close()
    p = ProvaImagem(caso_id=doc.caso_id, documento_id=doc.id, pagina=pagina, bbox=[round(v, 1) for v in clip],
                    legenda=legenda.strip(), png=png, sha256_png=sha256_bytes(png), sha256_documento=doc.sha256,
                    criado_por=usuario)
    db.add(p)
    db.commit()
    return p


def origem(db: Session, p: ProvaImagem) -> str:
    doc = db.get(Documento, p.documento_id)
    num = descrever(rotulo_de(doc, p.pagina)) if doc else ""
    return (f"Fonte: {doc.nome if doc else 'documento ' + str(p.documento_id)}, p. {p.pagina} do PDF"
            f"{', ' + num if num else ''}. SHA-256 do recorte: {p.sha256_png[:16]}.")


def como_dict(db: Session, p: ProvaImagem) -> dict:
    return {"id": p.id, "caso_id": p.caso_id, "documento_id": p.documento_id, "pagina": p.pagina, "bbox": p.bbox,
            "legenda": p.legenda, "sha256_png": p.sha256_png, "sha256_documento": p.sha256_documento,
            "origem": origem(db, p), "marcador": f"[[print:{p.id}]]", "criado_por": p.criado_por,
            "criado_em": p.criado_em.isoformat()}


def listar(db: Session, caso_id: int) -> list[dict]:
    return [como_dict(db, p) for p in db.scalars(select(ProvaImagem).where(ProvaImagem.caso_id == caso_id)
                                                 .order_by(ProvaImagem.id))]
