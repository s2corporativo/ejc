"""Agente de redação com supervisão humana obrigatória (máquina de estados).

Fases:
  planejamento -> perguntas (aguarda advogado) -> aprovar_roteiro (aguarda advogado)
  -> pesquisa -> redacao -> verificacao -> revisao (RASCUNHO, aguarda aprovação humana)

Nenhuma minuta sai como APROVADA sem ato explícito do usuário, e a aprovação é bloqueada
enquanto houver problema bloqueante na verificação (citação inexistente, precedente
superado, norma não vigente na data dos fatos, trecho dos autos não encontrado).
"""
from __future__ import annotations

import hashlib
import json
import time
from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core import citacoes
from ..core import estilo as estilo_core
from ..core import salvaguardas
from ..core.analise_instrucao import analisar as analisar_instrucao
from ..core.aderencia import extrair_afirmacoes, heuristica
from ..core.anonimizador import Cofre, anonimizar, desanonimizar
from ..core.julgador import simular
from ..llm import prompts
from ..llm.provedores import Provedor, construir, extrair_json
from ..config import get_config
from ..models import Caso, Minuta, PerfilEstilo, Precedente, Skill, VersaoMinuta
from ..servicos import auditoria, conhecimento, documentos
from ..servicos import skills as skills_srv

MAX_REFORMULACOES = 2


class ErroFluxo(RuntimeError):
    pass


def _evento(m: Minuta, tipo: str, **dados) -> None:
    est = dict(m.estado or {})
    est.setdefault("eventos", []).append({"tipo": tipo, **dados})
    m.estado = est


def _set(m: Minuta, **kv) -> None:
    est = dict(m.estado or {})
    est.update(kv)
    m.estado = est


def _provedores(db: Session, m: Minuta) -> tuple[Provedor, Provedor]:
    caso = db.get(Caso, m.caso_id) if m.caso_id else None
    sig = bool(caso and caso.sigiloso and not (m.estado or {}).get("anonimizado"))
    return construir(papel="redator", sigiloso=sig), construir(papel="verificador", sigiloso=sig)


def tokens_de(uso: dict) -> tuple[int, int]:
    """Anthropic: input_tokens/output_tokens; compatíveis com OpenAI: prompt_tokens/completion_tokens."""
    uso = uso or {}
    ent = int(uso.get("input_tokens") or uso.get("prompt_tokens") or 0)
    sai = int(uso.get("output_tokens") or uso.get("completion_tokens") or 0)
    return ent, sai


def custo_de(ent: int, sai: int) -> float | None:
    cfg = get_config()
    if not (cfg.llm_preco_entrada_mtok or cfg.llm_preco_saida_mtok):
        return None
    return round(ent * cfg.llm_preco_entrada_mtok / 1e6 + sai * cfg.llm_preco_saida_mtok / 1e6, 6)


def _chamar(db: Session, prov: Provedor, m: Minuta, tarefa: str, sistema: str, usuario: str,
            dados: dict, json_esperado: bool = True, max_tokens: int = 4000):
    cfg, gasto = get_config(), (m.estado or {}).get("custos") or {}
    if gasto.get("chamadas", 0) >= cfg.agente_max_chamadas:
        raise ErroFluxo(f"Orçamento da minuta atingido: {gasto['chamadas']} chamadas de IA (AGENTE_MAX_CHAMADAS). "
                        "Aumente o limite e use Retomar.")
    if cfg.agente_max_custo and gasto.get("custo_estimado", 0) >= cfg.agente_max_custo:
        raise ErroFluxo(f"Orçamento da minuta atingido: custo estimado {gasto['custo_estimado']} (AGENTE_MAX_CUSTO).")
    sistema = sistema + salvaguardas.INSTRUCAO_SISTEMA
    t0 = time.monotonic()
    try:
        r = prov.gerar(tarefa, sistema, usuario, dados, max_tokens=max_tokens)
    except Exception as e:
        auditoria.registrar(db, f"llm:{tarefa}", f"minuta:{m.id}", {"erro": str(e)[:500]}, getattr(prov, "nome", "?"),
                            duracao_ms=int((time.monotonic() - t0) * 1000), erro=True)
        raise
    dur = int((time.monotonic() - t0) * 1000)
    ent, sai = tokens_de(r.uso)
    custo = custo_de(ent, sai)
    est = dict(m.estado or {})
    est.setdefault("raciocinios", []).append({"tarefa": tarefa, "raciocinio": r.raciocinio[:4000]})
    c = dict(est.get("custos") or {"chamadas": 0, "tokens_entrada": 0, "tokens_saida": 0, "duracao_ms": 0, "custo_estimado": 0.0})
    c["chamadas"] += 1
    c["tokens_entrada"] += ent
    c["tokens_saida"] += sai
    c["duracao_ms"] += dur
    c["custo_estimado"] = round(c["custo_estimado"] + (custo or 0), 6)
    est["custos"] = c
    m.estado = est
    auditoria.registrar(db, f"llm:{tarefa}", f"minuta:{m.id}", {"uso": r.uso}, f"{r.provedor}:{r.modelo}",
                        tokens=ent + sai, duracao_ms=dur, custo=custo)
    return extrair_json(r.texto) if json_esperado else r.texto


def _autos(db: Session, m: Minuta) -> str:
    if not m.caso_id:
        return ""
    texto = documentos.texto_dos_autos(db, m.caso_id)
    est = m.estado or {}
    if est.get("anonimizado") and texto:
        cofre = Cofre.from_dict(est.get("cofre", {}))
        r = anonimizar(texto, cofre)
        _set(m, cofre=r["cofre"], identificadores_indiretos=r["identificadores_indiretos"][:20])
        return r["texto"]
    return texto


# ------------------------------------------------------------------ fases
def iniciar(db: Session, caso_id: int | None, tipo_peca: str, pedido: str,
            skills_fixadas: list[str] | None = None, anonimizar_autos: bool = False,
            gerar_peca_contraria: bool = True, perfil_estilo_id: int | None = None) -> Minuta:
    caso = db.get(Caso, caso_id) if caso_id else None
    if caso_id and not caso:
        raise ErroFluxo("Caso inexistente.")
    if caso:
        bloqueados = [d.nome for d in caso.documentos if not d.liberado_para_ia]
        if bloqueados:
            raise ErroFluxo("Documentos com suspeita de prompt injection aguardam sua decisão: " + ", ".join(bloqueados))
    if perfil_estilo_id and not db.get(PerfilEstilo, perfil_estilo_id):
        raise ErroFluxo("Perfil de estilo inexistente.")
    analise = analisar_instrucao(tipo_peca, pedido, tem_caso=bool(caso), data_fatos_informada=bool(caso and caso.data_fatos))
    m = Minuta(caso_id=caso_id, tipo_peca=tipo_peca, pedido=pedido, fase="planejamento",
               estado={"skills_fixadas": skills_fixadas or [], "anonimizado": anonimizar_autos,
                       "gerar_peca_contraria": gerar_peca_contraria, "perfil_estilo_id": perfil_estilo_id,
                       "analise_instrucao": analise, "criado_por": auditoria_usuario()})
    db.add(m)
    db.commit()
    redator, _ = _provedores(db, m)
    autos = _autos(db, m)
    tk = salvaguardas.novo_token()
    usuario = (f"Tipo de peça: {tipo_peca}\nPedido do advogado: {pedido}\n"
               f"Data dos fatos: {caso.data_fatos if caso and caso.data_fatos else 'não informada'}\n"
               + salvaguardas.bloco("AUTOS", autos, tk, 40000))
    plano = _chamar(db, redator, m, "planejar", prompts.SISTEMA_BASE + "\n\n" + prompts.PLANEJAR, usuario,
                    {"tipo_peca": tipo_peca, "pedido": pedido, "autos_texto": autos})
    _set(m, plano=plano, perguntas=plano.get("perguntas", []))
    _evento(m, "plano", perguntas=len(plano.get("perguntas", [])))
    if plano.get("perguntas"):
        m.fase = "perguntas"
        db.commit()
        return m
    db.commit()
    return _gerar_roteiro(db, m, {})


def auditoria_usuario() -> str:
    from ..servicos.acesso import atual
    return atual().nome


def responder(db: Session, minuta_id: int, respostas: dict) -> Minuta:
    m = _obter(db, minuta_id, "perguntas")
    _set(m, respostas=respostas)
    _evento(m, "respostas", total=len(respostas))
    return _gerar_roteiro(db, m, respostas)


def _gerar_roteiro(db: Session, m: Minuta, respostas: dict) -> Minuta:
    redator, _ = _provedores(db, m)
    est = m.estado or {}
    usuario = (f"Tipo de peça: {m.tipo_peca}\nPedido: {m.pedido}\nPlano: {json.dumps(est.get('plano', {}), ensure_ascii=False)}\n"
               f"Respostas do advogado: {json.dumps(respostas, ensure_ascii=False)}")
    rot = _chamar(db, redator, m, "roteiro", prompts.SISTEMA_BASE + "\n\n" + prompts.ROTEIRO, usuario,
                  {"tipo_peca": m.tipo_peca})
    _set(m, roteiro=rot.get("secoes", []))
    m.fase = "aprovar_roteiro"
    db.commit()
    return m


def aprovar_roteiro(db: Session, minuta_id: int, secoes: list[dict] | None = None) -> Minuta:
    m = _obter(db, minuta_id, "aprovar_roteiro")
    if secoes:
        _set(m, roteiro=secoes)
    _set(m, roteiro_aprovado=True)
    _evento(m, "roteiro_aprovado", secoes=len((m.estado or {}).get("roteiro", [])))
    m.fase = "pesquisa"
    db.commit()
    return _executar_etapas(db, m)


def _executar_etapas(db: Session, m: Minuta) -> Minuta:
    """Pesquisa, redação e verificação. Cada etapa concluída fica gravada; em caso de falha, a fase
    é preservada e `retomar` continua do ponto de parada sem repetir chamadas já concluídas."""
    try:
        if m.fase == "pesquisa":
            if not (m.estado or {}).get("pesquisa"):
                _pesquisar(db, m)
            m.fase = "redacao"
            db.commit()
        if m.fase == "redacao":
            _redigir(db, m)
        if m.fase == "verificacao":
            verificar(db, m.id)
    except Exception as e:
        db.rollback()
        m = db.get(Minuta, m.id)
        _set(m, erro={"fase": m.fase, "mensagem": str(e)[:1000]})
        _evento(m, "falha", fase=m.fase)
        db.commit()
        raise
    m = db.get(Minuta, m.id)
    if (m.estado or {}).get("erro"):
        est = dict(m.estado)
        est.pop("erro", None)
        m.estado = est
        db.commit()
    return m


def retomar(db: Session, minuta_id: int) -> Minuta:
    m = db.get(Minuta, minuta_id)
    if not m:
        raise ErroFluxo("Minuta inexistente.")
    if m.fase == "falha":  # compatibilidade com registros antigos
        m.fase = (m.estado or {}).get("erro", {}).get("fase") or "pesquisa"
        db.commit()
    if m.fase not in ("pesquisa", "redacao", "verificacao"):
        raise ErroFluxo(f"Nada a retomar na fase '{m.fase}'.")
    _evento(m, "retomada", fase=m.fase)
    db.commit()
    return _executar_etapas(db, m)


def _pesquisar(db: Session, m: Minuta) -> None:
    redator, _ = _provedores(db, m)
    est = m.estado or {}
    caso = db.get(Caso, m.caso_id) if m.caso_id else None
    consultas = (est.get("plano") or {}).get("consultas", {})
    juris, leis, autos, buscas = {}, {}, {}, []

    for q in [c for c in consultas.get("jurisprudencia", []) if c][:6]:
        tentativas, atual = 0, q
        while True:
            r = conhecimento.pesquisar_jurisprudencia(db, atual, limite=5)
            buscas.append({"fonte": "jurisprudencia", "consulta": atual, "resultados": len(r["resultados"]),
                           "excluidos_por_status": [e["id"] for e in r["excluidos_por_status"]]})
            for it in r["resultados"]:
                juris.setdefault(it["id"], it)
            if r["resultados"] or tentativas >= MAX_REFORMULACOES:
                break
            nova = _chamar(db, redator, m, "reformular", prompts.SISTEMA_BASE + "\n\n" + prompts.REFORMULAR,
                           f"Consulta: {atual}", {"consulta": atual}).get("consultas", [])
            tentativas += 1
            if not nova:
                break
            atual = nova[0]

    for q in [c for c in consultas.get("legislacao", []) if c][:6]:
        r = conhecimento.pesquisar_legislacao(db, q, caso.data_fatos if caso else None, limite=5)
        buscas.append({"fonte": "legislacao", "consulta": q, "resultados": len(r["resultados"])})
        for it in r["resultados"]:
            if it["texto_na_data_dos_fatos"]:
                leis.setdefault(it["id"], it)

    if m.caso_id:
        pontos = [c for c in consultas.get("autos", []) if c]
        for s in est.get("roteiro", []):
            pontos += [s.get("titulo", "")] + list(s.get("pontos", []))
        for q in [p for p in pontos if p][:10]:
            res = conhecimento.pesquisar_autos(db, m.caso_id, q, limite=4)
            buscas.append({"fonte": "autos", "consulta": q, "resultados": len(res)})
            for it in res:
                autos.setdefault(it["trecho_id"], it)

    modelos = conhecimento.pesquisar_modelos(db, f"{m.tipo_peca} {m.pedido}")
    doutrina = conhecimento.pesquisar_fonte(db, "doutrina", f"{m.tipo_peca} {m.pedido}", limite=4)
    provas_caso = []
    if m.caso_id:
        from ..servicos import provas as provas_srv
        provas_caso = [{"id": p["id"], "legenda": p["legenda"], "origem": p["origem"]} for p in provas_srv.listar(db, m.caso_id)]
    _set(m, pesquisa={"jurisprudencia": list(juris.values()), "legislacao": list(leis.values()),
                      "autos": list(autos.values()), "modelos": modelos, "doutrina": doutrina, "provas": provas_caso},
         buscas=buscas)
    _evento(m, "pesquisa", jurisprudencia=len(juris), legislacao=len(leis), autos=len(autos),
            modelos=len(modelos), doutrina=len(doutrina))
    db.commit()


def _bloco_pesquisa(pq: dict) -> str:
    linhas = ["PRECEDENTES DISPONÍVEIS (cite apenas por {{juris:ID}}):"]
    for j in pq.get("jurisprudencia", []):
        alerta = f" [ALERTA: {j['alerta_status']}]" if j.get("alerta_status") else ""
        linhas.append(f"- ID {j['id']} | {j['rotulo']} | {j.get('hierarquia') or ''}{alerta}\n  Tese/ementa: {(j.get('tese') or j['ementa'])[:700]}")
    linhas.append("\nDISPOSITIVOS DISPONÍVEIS (cite apenas por {{lei:ID}}), redação vigente na data dos fatos:")
    for n in pq.get("legislacao", []):
        linhas.append(f"- ID {n['id']} | {n['rotulo']}: {(n['texto_na_data_dos_fatos'] or '')[:600]}")
    if pq.get("doutrina"):
        linhas.append("\nMATERIAL DE APOIO (doutrina/base do EJC; use para raciocínio, não cite como precedente nem como lei):")
        for x in pq["doutrina"]:
            linhas.append(f"- {x.get('titulo') or x['fonte_id']}: {x['trecho'][:500]}")
    linhas.append("\nTRECHOS DOS AUTOS RELEVANTES (cite por [[autos:DOC:PAGINA]]):")
    for a in pq.get("autos", [])[:20]:
        num = f" ({a['numeracao_autos']})" if a.get("numeracao_autos") else ""
        linhas.append(f"- doc {a['documento_id']} p.{a['pagina']}{num}: {a['texto'][:500]}")
    if pq.get("provas"):
        linhas.append("\nIMAGENS DE PROVA DISPONÍVEIS (insira em linha própria com [[print:ID]]):")
        for p in pq["provas"]:
            linhas.append(f"- [[print:{p['id']}]] {p['legenda']} ({p['origem']})")
    return "\n".join(linhas)


def _redigir(db: Session, m: Minuta) -> None:
    redator, _ = _provedores(db, m)
    est = m.estado or {}
    pq = est.get("pesquisa", {})
    contexto_skills = f"{m.tipo_peca} {m.pedido} {(est.get('plano') or {}).get('resumo_caso', '')}"
    if est.get("skills_aplicadas") is None:
        selecionadas, bloco_skills = skills_srv.selecionar_para(db, contexto_skills, m.tipo_peca, est.get("skills_fixadas", []))
        _set(m, skills_aplicadas=[_registro_skill(db, s) for s in selecionadas], bloco_skills=bloco_skills)
        db.commit()
        est = m.estado
    bloco_skills = est.get("bloco_skills", "")
    perfil_txt = ""
    if est.get("perfil_estilo_id"):
        pf = db.get(PerfilEstilo, est["perfil_estilo_id"])
        if pf:
            perfil_txt = pf.instrucoes
            if not est.get("perfil_aplicado"):
                _set(m, perfil_aplicado={"id": pf.id, "nome": pf.nome, "versao": pf.versao,
                                         "sha256": hashlib.sha256(pf.instrucoes.encode()).hexdigest()})
    sistema = (prompts.SISTEMA_BASE + "\n\n" + prompts.REDIGIR_SECAO + ("\n\n" + bloco_skills if bloco_skills else "")
               + ("\n\n" + perfil_txt if perfil_txt else ""))
    autos = _autos(db, m)
    bloco_pq = _bloco_pesquisa(pq)
    modelos = "\n---\n".join(x["trecho"] for x in pq.get("modelos", []))
    feitas = dict(est.get("secoes_redigidas") or {})
    secoes_txt = []
    for idx, s in enumerate(est.get("roteiro", [])):
        chave_s = hashlib.sha256(json.dumps(s, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]
        pronto = feitas.get(str(idx))
        if pronto and pronto.get("chave") == chave_s:
            secoes_txt.append(pronto["texto"])   # retomada: seção já redigida não é gerada de novo
            continue
        tk = salvaguardas.novo_token()
        usuario = (f"Peça: {m.tipo_peca}\nPedido: {m.pedido}\nRespostas do advogado: {json.dumps(est.get('respostas', {}), ensure_ascii=False)}\n"
                   f"Roteiro aprovado: {json.dumps(est.get('roteiro'), ensure_ascii=False)}\n"
                   f"SEÇÃO A REDIGIR: {json.dumps(s, ensure_ascii=False)}\n"
                   + "\n\n".join(x for x in (salvaguardas.bloco("PESQUISA", bloco_pq, tk), salvaguardas.bloco("MODELO", modelos, tk, 6000),
                                              salvaguardas.bloco("AUTOS", autos, tk, 30000)) if x))
        txt = _chamar(db, redator, m, "redigir_secao", sistema, usuario,
                      {"secao": s, "pesquisa": pq}, json_esperado=False, max_tokens=3000)
        secoes_txt.append(txt.strip())
        feitas[str(idx)] = {"chave": chave_s, "titulo": s.get("titulo"), "texto": txt.strip()}
        _set(m, secoes_redigidas=feitas)
        _evento(m, "secao_redigida", secao=s.get("titulo"))
        db.commit()
    m.texto = "\n\n".join(secoes_txt)
    db.add(VersaoMinuta(minuta_id=m.id, texto=m.texto, nota="Redação inicial do agente", autor="ia"))
    m.fase = "verificacao"
    db.commit()


def _registro_skill(db: Session, s: dict) -> dict:
    """Registra exatamente a versão aplicada: slug, versão, oficial ou do usuário e SHA-256 do conteúdo."""
    sk = db.get(Skill, s["id"]) if s.get("id") else None
    return {"slug": s["slug"], "titulo": s["titulo"], "confianca": s["confianca"], "obrigatoria": s["obrigatoria"],
            "versao": s.get("versao"), "oficial": s.get("oficial"), "skill_id": sk.id if sk else None,
            "sha256": hashlib.sha256(sk.conteudo.encode()).hexdigest() if sk else None}


def _propor_correcoes(db: Session, m: Minuta, achados: list[dict]) -> None:
    """Salvaguarda não reescreve sozinha: cria sugestão ancorada no bloco para decisão humana."""
    from sqlalchemy import select as _sel
    from ..models import Sugestao
    from ..servicos import editor
    for b in editor.sincronizar(m):
        novo = b["texto"]
        for a in achados:
            if a["trecho"] in novo:
                novo = novo.replace(a["trecho"], a["correcao"], 1)
        if novo != b["texto"] and not db.scalar(_sel(Sugestao).where(
                Sugestao.minuta_id == m.id, Sugestao.bloco_id == b["id"], Sugestao.proposto == novo)):
            db.add(Sugestao(minuta_id=m.id, bloco_id=b["id"], original=b["texto"], proposto=novo, autor="salvaguarda",
                            motivo="Prescrição e decadência resolvem o mérito (CPC, art. 487, II)."))
    db.commit()


def _contradicoes(db: Session, caso_id: int | None) -> list[dict]:
    if not caso_id:
        return []
    from ..core.contradicoes import detectar
    return [{"rotulo": c["rotulo"], "valores": c["valores"], "mensagem": c["mensagem"]}
            for c in detectar(documentos.paginas_do_caso(db, caso_id))["contradicoes"]]


def verificar(db: Session, minuta_id: int) -> Minuta:
    """Verificação completa. Pode ser chamada novamente após edição humana."""
    m = db.get(Minuta, minuta_id)
    if not m:
        raise ErroFluxo("Minuta inexistente.")
    _, verificador = _provedores(db, m)
    caso = db.get(Caso, m.caso_id) if m.caso_id else None
    est = m.estado or {}

    texto = m.texto
    if est.get("anonimizado") and est.get("cofre"):
        d = desanonimizar(texto, est["cofre"])
        texto = d["texto"]
        alertas_cofre = d["alertas"]
    else:
        alertas_cofre = []

    res = documentos.resolver_citacoes(db, texto, caso.data_fatos if caso else None)

    # Aderência da tese: verificador distinto do redator
    aderencias = []
    for af in extrair_afirmacoes(m.texto, citacoes.RX_JURIS)[:15]:
        p = db.get(Precedente, af["id"])
        if not p:
            continue
        tese = p.tese or p.ementa
        try:
            r = _chamar(db, verificador, m, "aderencia", prompts.ADERENCIA,
                        f"AFIRMAÇÃO DA PEÇA: {af['afirmacao']}\nPRECEDENTE {p.rotulo}\nTESE/EMENTA: {tese}",
                        {"afirmacao": af["afirmacao"], "tese": tese})
            origem = "verificador"
        except Exception as e:  # noqa: BLE001
            r, origem = heuristica(af["afirmacao"], tese), f"heuristica ({e.__class__.__name__})"
        aderencias.append({"precedente": p.id, "rotulo": p.rotulo, "afirmacao": af["afirmacao"][:300],
                           "classificacao": r.get("classificacao"), "justificativa": r.get("justificativa"),
                           "origem": origem, "heuristica": heuristica(af["afirmacao"], tese)})

    # Camada 2: auditoria do raciocínio
    rac = "\n".join(x["raciocinio"] for x in est.get("raciocinios", []) if x.get("raciocinio"))
    if rac:
        try:
            aud = _chamar(db, verificador, m, "auditoria", prompts.AUDITORIA,
                          f"INSTRUÇÕES DO SISTEMA:\n{prompts.REGRAS_INVARIANTES}\n\nPEDIDO DO USUÁRIO:\n{m.pedido}\n\nRACIOCÍNIO DO REDATOR:\n{rac[:12000]}",
                          {"raciocinio": rac})
        except Exception as e:  # noqa: BLE001
            aud = {"injecao": None, "fabricacao": None, "justificativa": f"Auditoria indisponível: {e}"}
    else:
        aud = {"injecao": None, "fabricacao": None,
               "justificativa": "Provedor não expôs raciocínio; auditoria da Camada 2 não aplicável a esta geração."}
    indicador = "seguro"
    if aud.get("injecao"):
        indicador = "possivel_injecao"
    elif aud.get("fabricacao"):
        indicador = "possivel_fabricacao"
    elif aud.get("injecao") is None:
        indicador = "nao_auditado"

    julg = simular(res.texto, m.tipo_peca)
    if julg.get("tipo") == "sentenca" and m.caso_id:
        from ..core.julgador import vedacao_surpresa
        julg["vedacao_surpresa"] = vedacao_surpresa(res.texto, documentos.texto_dos_autos(db, m.caso_id, limite_chars=400000))
        for a in julg["vedacao_surpresa"]["achados"]:
            julg["pendencias"].append(a["mensagem"])
    contraria = est.get("peca_contraria")
    if est.get("gerar_peca_contraria", True) and contraria is None:
        try:
            contraria = _chamar(db, verificador, m, "contraria", prompts.SISTEMA_BASE + "\n\n" + prompts.CONTRARIA,
                                salvaguardas.bloco("PECA", m.texto, salvaguardas.novo_token(), 30000), {"texto": m.texto})
        except Exception as e:  # noqa: BLE001
            contraria = {"erro": str(e)}
        _set(m, peca_contraria=contraria)

    pendencias = [l for l in m.texto.splitlines() if "[PESQUISA PENDENTE" in l or "[DADO PENDENTE" in l]
    estilo_rel = None
    if est.get("perfil_estilo_id"):
        pf = db.get(PerfilEstilo, est["perfil_estilo_id"])
        if pf:
            estilo_rel = estilo_core.aderencia(res.texto, pf.metricas or {})
    problemas = [p.as_dict() for p in res.problemas] + [{"nivel": "alerta", "tipo": "cofre", "mensagem": a, "marcador": ""} for a in alertas_cofre]
    import re as _re
    from ..models import ProvaImagem
    for pid in sorted(set(_re.findall(r"\[\[print:(\d+)\]\]", m.texto))):
        pv = db.get(ProvaImagem, int(pid))
        if not pv or pv.caso_id != m.caso_id:
            problemas.append({"nivel": "bloqueante", "tipo": "prova_invalida",
                              "mensagem": f"Imagem de prova {pid} inexistente ou de outro caso.", "marcador": f"[[print:{pid}]]"})
    for a in aderencias:
        if a["classificacao"] in ("contrario", "distinguivel", "irrelevante"):
            problemas.append({"nivel": "bloqueante" if a["classificacao"] == "contrario" else "alerta",
                              "tipo": "aderencia", "mensagem": f"{a['rotulo']}: {a['classificacao']}. {a['justificativa']}",
                              "marcador": a["precedente"]})
    sv = salvaguardas.verificar(res.texto)
    for pr in sv["promessas"]:
        problemas.append({"nivel": "alerta", "tipo": "promessa_resultado", "marcador": pr,
                          "mensagem": f"Possível promessa de resultado: \"{pr}\". Reformule (ética profissional da advocacia)."})
    for a in sv["merito_prescricao"]:
        problemas.append({"nivel": "alerta", "tipo": "prescricao_merito", "marcador": a["trecho"],
                          "mensagem": f"Prescrição ou decadência qualificada como \"{a['trecho']}\": é resolução de mérito "
                                      "(CPC, art. 487, II). Correção proposta no editor."})
    for a in sv["cdc"]:
        problemas.append({"nivel": "alerta", "tipo": "cdc_vicio_fato", "mensagem": a, "marcador": ""})
    if sv["merito_prescricao"] and m.status != "APROVADA":
        _propor_correcoes(db, m, sv["merito_prescricao"])
    bloqueado = any(p["nivel"] == "bloqueante" for p in problemas) or indicador == "possivel_injecao"
    m.texto_resolvido = res.texto + ("\n\n" + res.anexo if res.anexo else "")
    m.verificacao = {
        "bloqueado": bloqueado, "problemas": problemas, "citados": res.citados, "aderencia": aderencias,
        "seguranca": {"indicador": indicador, **aud}, "julgador": julg, "pendencias": pendencias,
        "skills_aplicadas": est.get("skills_aplicadas", []), "verificado_em": date.today().isoformat(),
        "perfil_estilo": {"aplicado": est.get("perfil_aplicado"), **(estilo_rel or {})} if estilo_rel else None,
        "analise_instrucao": est.get("analise_instrucao"), "custos": est.get("custos"),
        "contradicoes_autos": _contradicoes(db, m.caso_id),
    }
    m.fase = "revisao"
    m.status = "RASCUNHO"
    db.commit()
    auditoria.registrar(db, "verificacao", f"minuta:{m.id}", {"bloqueado": bloqueado, "problemas": len(problemas)})
    return m


def editar(db: Session, minuta_id: int, texto: str, nota: str = "Edição do advogado") -> Minuta:
    m = db.get(Minuta, minuta_id)
    if not m:
        raise ErroFluxo("Minuta inexistente.")
    if m.status == "APROVADA":
        raise ErroFluxo("Minuta aprovada é imutável; crie nova versão.")
    m.texto = texto
    db.add(VersaoMinuta(minuta_id=m.id, texto=texto, nota=nota, autor=auditoria_usuario()))
    db.commit()
    return verificar(db, m.id)


def aprovar(db: Session, minuta_id: int, responsavel: str, ciente_alertas: bool = False) -> Minuta:
    m = db.get(Minuta, minuta_id)
    if not m or m.fase != "revisao":
        raise ErroFluxo("A minuta precisa estar em revisão para ser aprovada.")
    v = m.verificacao or {}
    if v.get("bloqueado"):
        raise ErroFluxo("Há problemas bloqueantes na verificação. Corrija e verifique novamente.")
    if any(p["nivel"] == "alerta" for p in v.get("problemas", [])) and not ciente_alertas:
        raise ErroFluxo("Existem alertas. Confirme ciência (ciente_alertas=true) para aprovar.")
    if not responsavel.strip():
        raise ErroFluxo("Informe o advogado responsável pela aprovação.")
    m.status, m.aprovada_por = "APROVADA", responsavel
    db.commit()
    auditoria.registrar(db, "aprovacao", f"minuta:{m.id}", {"responsavel": responsavel}, usuario=responsavel)
    return m


def _obter(db: Session, minuta_id: int, fase: str) -> Minuta:
    m = db.get(Minuta, minuta_id)
    if not m:
        raise ErroFluxo("Minuta inexistente.")
    if m.fase != fase:
        raise ErroFluxo(f"Fase atual é '{m.fase}', esperado '{fase}'.")
    return m


def versoes(db: Session, minuta_id: int) -> list[dict]:
    return [{"id": v.id, "nota": v.nota, "autor": v.autor, "criado_em": v.criado_em.isoformat(), "texto": v.texto}
            for v in db.scalars(select(VersaoMinuta).where(VersaoMinuta.minuta_id == minuta_id).order_by(VersaoMinuta.id))]
