"""Distinguishing estruturado: precedente x fatos do caso (CPC, art. 489, § 1º, VI; art. 927, § 1º).

Etapa 1 (com cache no precedente): extração da ratio decidendi e dos fatos materiais.
Etapa 2: para cada fato material, busca nos autos e comparação pelo verificador.
Resultado: aplica | distinguir | inconclusivo, sempre sujeito a revisão do advogado.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from ..core.aderencia import heuristica
from ..llm import prompts
from ..llm.provedores import construir, extrair_json
from ..models import Caso, Precedente
from ..servicos import auditoria, conhecimento


class ErroDistinguishing(RuntimeError):
    pass


def ratio(db: Session, p: Precedente, sigiloso: bool = False, renovar: bool = False) -> dict:
    if p.ratio_estruturada and not renovar:
        return p.ratio_estruturada
    prov = construir(papel="verificador", sigiloso=sigiloso)
    tese = p.tese or p.ementa
    r = prov.gerar("ratio", prompts.SISTEMA_BASE + "\n\n" + prompts.RATIO,
                   f"<precedente>\n{p.rotulo}\nTESE: {p.tese or ''}\nEMENTA: {p.ementa}\n</precedente>", {"tese": tese})
    dados = extrair_json(r.texto)
    p.ratio_estruturada = dados
    db.commit()
    return dados


def analisar(db: Session, precedente_id: str, caso_id: int) -> dict:
    p, caso = db.get(Precedente, precedente_id), db.get(Caso, caso_id)
    if not p or not caso:
        raise ErroDistinguishing("Precedente ou caso inexistente.")
    rt = ratio(db, p, caso.sigiloso)
    fatos = [f for f in rt.get("fatos_materiais", []) if f][:8]
    trechos = {}
    bloco = []
    for f in fatos:
        achados = conhecimento.pesquisar_autos(db, caso_id, f, limite=3)
        trechos[f] = [{"texto": a["texto"][:600], "marcador": a["marcador"],
                       "sobreposicao": heuristica(f, a["texto"])["sobreposicao"]} for a in achados]
        bloco.append(f"FATO MATERIAL: {f}\n" + "\n".join(f"  {a['marcador']}: {a['texto'][:600]}" for a in achados))
    prov = construir(papel="verificador", sigiloso=caso.sigiloso)
    r = prov.gerar("distinguir", prompts.SISTEMA_BASE + "\n\n" + prompts.DISTINGUIR,
                   f"PRECEDENTE: {p.rotulo}\nRATIO: {rt.get('ratio')}\n<autos>\n" + "\n\n".join(bloco) + "\n</autos>",
                   {"fatos_materiais": fatos, "trechos": trechos})
    res = extrair_json(r.texto)
    auditoria.registrar(db, "distinguishing", f"precedente:{p.id}", {"caso": caso_id, "conclusao": res.get("conclusao")},
                        f"{r.provedor}:{r.modelo}")
    return {"precedente": {"id": p.id, "rotulo": p.rotulo}, "caso_id": caso_id, "ratio": rt, **res,
            "nota": "Análise de apoio. A decisão de aplicar ou distinguir o precedente é do advogado."}
