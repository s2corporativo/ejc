"""Configuração por variáveis de ambiente (ver .env.example).

Os parâmetros de RAG seguem os mesmos nomes e defaults do EJC (Ecossistema Jurídico Clovis),
para que os dois sistemas compartilhem modelo de embedding, dimensão e calibragem.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]


def _bool(nome: str, padrao: bool) -> bool:
    v = os.getenv(nome)
    return padrao if v is None else v.strip().lower() in {"1", "true", "sim", "yes", "on"}


@dataclass(frozen=True)
class Config:
    database_url: str = field(default_factory=lambda: os.getenv(
        "DATABASE_URL", f"sqlite:///{RAIZ / 'data' / 'lexvalida.db'}"))
    # Provedores: mock | anthropic | openai_compat (Ollama, vLLM, Groq, OpenAI, LM Studio)
    llm_provider: str = field(default_factory=lambda: os.getenv("LLM_PROVIDER", "mock"))
    llm_model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", ""))
    llm_base_url: str = field(default_factory=lambda: os.getenv("LLM_BASE_URL", ""))
    llm_api_key: str = field(default_factory=lambda: os.getenv("LLM_API_KEY", ""))
    verificador_provider: str = field(default_factory=lambda: os.getenv("VERIFICADOR_PROVIDER", ""))
    verificador_model: str = field(default_factory=lambda: os.getenv("VERIFICADOR_MODEL", ""))
    verificador_base_url: str = field(default_factory=lambda: os.getenv("VERIFICADOR_BASE_URL", ""))
    verificador_api_key: str = field(default_factory=lambda: os.getenv("VERIFICADOR_API_KEY", ""))
    local_provider_base_url: str = field(default_factory=lambda: os.getenv("LOCAL_LLM_BASE_URL", ""))
    local_provider_model: str = field(default_factory=lambda: os.getenv("LOCAL_LLM_MODEL", ""))
    timeout_llm: float = field(default_factory=lambda: float(os.getenv("LLM_TIMEOUT", "180")))

    # ── Embeddings (mesmo contrato do EJC) ─────────────────────────────────
    # local = fastembed (ONNX, sem torch) | http = serviço interno | hash = dev/testes, sem modelo
    embeddings_provider: str = field(default_factory=lambda: os.getenv("EMBEDDINGS_PROVIDER", "local"))
    embeddings_model: str = field(default_factory=lambda: os.getenv("EMBEDDINGS_MODEL", "intfloat/multilingual-e5-large"))
    embeddings_dim: int = field(default_factory=lambda: int(os.getenv("EMBEDDINGS_DIM", "1024")))
    embeddings_api_url: str = field(default_factory=lambda: os.getenv("EMBEDDINGS_API_URL", "http://embeddings:8010/embed"))
    embeddings_timeout: int = field(default_factory=lambda: int(os.getenv("EMBEDDINGS_TIMEOUT", "120")))
    embeddings_batch: int = field(default_factory=lambda: int(os.getenv("EMBEDDINGS_BATCH", "16")))
    embeddings_max_chars: int = field(default_factory=lambda: int(os.getenv("EMBEDDINGS_MAX_CHARS", "1800")))

    # ── Recuperação híbrida (mesma calibragem do EJC) ───────────────────────
    rag_min_sim: float = field(default_factory=lambda: float(os.getenv("RAG_MIN_SIM", "0.55")))
    rag_fts_enabled: bool = field(default_factory=lambda: _bool("RAG_FTS_ENABLED", True))
    rag_trgm_enabled: bool = field(default_factory=lambda: _bool("RAG_TRGM_ENABLED", True))
    rag_ef_search: int = field(default_factory=lambda: int(os.getenv("RAG_EF_SEARCH", "100")))
    rag_rrf_k: int = field(default_factory=lambda: int(os.getenv("RAG_RRF_K", "60")))

    # Importação do EJC (somente leitura)
    ejc_database_url: str = field(default_factory=lambda: os.getenv("EJC_DATABASE_URL", ""))
    ejc_api_url: str = field(default_factory=lambda: os.getenv("EJC_API_URL", ""))
    ejc_api_token: str = field(default_factory=lambda: os.getenv("EJC_API_TOKEN", ""))

    # ── Integrações oficiais ────────────────────────────────────────────────
    # DataJud (CNJ): chave PÚBLICA rotativa. Vazio = descobre na wiki oficial do CNJ.
    datajud_api_key: str = field(default_factory=lambda: os.getenv("DATAJUD_API_KEY", ""))
    datajud_base_url: str = field(default_factory=lambda: os.getenv("DATAJUD_BASE_URL", "https://api-publica.datajud.cnj.jus.br"))
    datajud_wiki_url: str = field(default_factory=lambda: os.getenv("DATAJUD_WIKI_URL", "https://datajud-wiki.cnj.jus.br/api-publica/acesso/"))
    sgt_url: str = field(default_factory=lambda: os.getenv("SGT_URL", "https://www.cnj.jus.br/sgt/sgt_ws.php"))
    djen_base_url: str = field(default_factory=lambda: os.getenv("DJEN_BASE_URL", "https://comunicaapi.pje.jus.br/api/v1"))
    djen_oabs: str = field(default_factory=lambda: os.getenv("DJEN_OABS", ""))   # ex.: "123456/MG,654321/MG"
    stj_ckan_url: str = field(default_factory=lambda: os.getenv("STJ_CKAN_URL", "https://dadosabertos.web.stj.jus.br/api/3/action"))
    http_timeout: float = field(default_factory=lambda: float(os.getenv("HTTP_TIMEOUT", "60")))
    # Rotinas automáticas (0 = desligadas): monitor de precedentes/temas e captura do DJEN
    monitor_intervalo_horas: float = field(default_factory=lambda: float(os.getenv("MONITOR_INTERVALO_HORAS", "0")))
    # Pré-checagem de peticionamento: limite por arquivo em MB, conforme o tribunal (0 = só informa)
    peticionamento_limite_mb: float = field(default_factory=lambda: float(os.getenv("PETICIONAMENTO_LIMITE_MB", "0")))

    # Arquivos originais preservados (integridade por SHA-256, recorte de provas)
    arquivos_dir: str = field(default_factory=lambda: os.getenv("ARQUIVOS_DIR") or str(RAIZ / "data" / "arquivos"))
    # Custo estimado por execução: preço por milhão de tokens na moeda do contrato (0 = só tokens)
    llm_preco_entrada_mtok: float = field(default_factory=lambda: float(os.getenv("LLM_PRECO_ENTRADA_MTOK", "0")))
    llm_preco_saida_mtok: float = field(default_factory=lambda: float(os.getenv("LLM_PRECO_SAIDA_MTOK", "0")))
    # Transcrição de áudio e vídeo: none | openai_compat (endpoint /audio/transcriptions) | local (faster-whisper)
    transcricao_provider: str = field(default_factory=lambda: os.getenv("TRANSCRICAO_PROVIDER", "none"))
    transcricao_base_url: str = field(default_factory=lambda: os.getenv("TRANSCRICAO_BASE_URL", ""))
    transcricao_api_key: str = field(default_factory=lambda: os.getenv("TRANSCRICAO_API_KEY", ""))
    transcricao_model: str = field(default_factory=lambda: os.getenv("TRANSCRICAO_MODEL", "whisper-1"))
    # Lote: similaridade mínima dos autos com o processo-modelo para herdar o molde
    lote_similaridade_min: float = field(default_factory=lambda: float(os.getenv("LOTE_SIMILARIDADE_MIN", "0.15")))

    # Orçamento por minuta (agente): teto de chamadas de IA e de custo estimado (0 = sem teto de custo)
    agente_max_chamadas: int = field(default_factory=lambda: int(os.getenv("AGENTE_MAX_CHAMADAS", "80")))
    agente_max_custo: float = field(default_factory=lambda: float(os.getenv("AGENTE_MAX_CUSTO", "0")))

    api_token: str = field(default_factory=lambda: os.getenv("API_TOKEN", ""))
    skills_dir: str = field(default_factory=lambda: os.getenv("SKILLS_DIR", str(RAIZ / "skills")))

    @property
    def postgres(self) -> bool:
        return self.database_url.startswith("postgresql")


def get_config() -> Config:
    return Config()
