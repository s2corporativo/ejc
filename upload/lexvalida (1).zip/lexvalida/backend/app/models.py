"""Modelo de dados.

Grafo jurídico: Norma (com versões no tempo) e Precedente (com status de vigência do
entendimento), ligados por Relacao. Trecho é a unidade de recuperação (RAG) de qualquer
fonte: precedente, norma, doutrina, modelo do usuário ou autos do caso.
"""
from __future__ import annotations

from datetime import UTC, date, datetime

from sqlalchemy import JSON, Boolean, Date, DateTime, Float, ForeignKey, Integer, LargeBinary, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import TypeDecorator

from .config import get_config
from .db import Base


class VetorTipo(TypeDecorator):
    """pgvector vector(EMBEDDINGS_DIM) no PostgreSQL (mesmo contrato do EJC);
    JSON nos demais bancos (desenvolvimento/testes)."""
    impl = JSON
    cache_ok = True

    def load_dialect_impl(self, dialect):
        if dialect.name == "postgresql":
            from pgvector.sqlalchemy import Vector
            return dialect.type_descriptor(Vector(get_config().embeddings_dim))
        return dialect.type_descriptor(JSON())

    def process_result_value(self, value, dialect):
        if value is not None and not isinstance(value, list):
            return [float(x) for x in value]
        return value


def agora() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


# --------------------------------------------------------------------------- normas
class Norma(Base):
    __tablename__ = "normas"
    id: Mapped[str] = mapped_column(String(120), primary_key=True)   # ex.: "cc-art-206-p3-v"
    diploma: Mapped[str] = mapped_column(String(200))                # ex.: "Código Civil (Lei 10.406/2002)"
    dispositivo: Mapped[str] = mapped_column(String(200))            # ex.: "art. 206, § 3º, V"
    rotulo: Mapped[str] = mapped_column(String(300))                 # forma de citação
    fonte_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    verificado: Mapped[bool] = mapped_column(Boolean, default=False)
    verificado_por: Mapped[str | None] = mapped_column(String(120), nullable=True)
    verificado_em: Mapped[date | None] = mapped_column(Date, nullable=True)
    versoes: Mapped[list["NormaVersao"]] = relationship(back_populates="norma", cascade="all, delete-orphan",
                                                        order_by="NormaVersao.vigencia_inicio")


class NormaVersao(Base):
    __tablename__ = "normas_versoes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    norma_id: Mapped[str] = mapped_column(ForeignKey("normas.id", ondelete="CASCADE"))
    texto: Mapped[str] = mapped_column(Text)
    vigencia_inicio: Mapped[date | None] = mapped_column(Date, nullable=True)  # None = início não curado
    vigencia_fim: Mapped[date | None] = mapped_column(Date, nullable=True)   # None = vigente
    ato_alterador: Mapped[str | None] = mapped_column(String(300), nullable=True)
    hash_texto: Mapped[str | None] = mapped_column(String(64), nullable=True)      # SHA-256 do texto na coleta
    coletado_em: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    norma: Mapped[Norma] = relationship(back_populates="versoes")


# --------------------------------------------------------------------- precedentes
class Precedente(Base):
    __tablename__ = "precedentes"
    id: Mapped[str] = mapped_column(String(120), primary_key=True)   # ex.: "stj-sumula-385"
    tribunal: Mapped[str] = mapped_column(String(30))
    tipo: Mapped[str] = mapped_column(String(40))                    # ver core/hierarquia.py
    numero: Mapped[str] = mapped_column(String(80))
    rotulo: Mapped[str] = mapped_column(String(300))                 # forma de citação completa
    ementa: Mapped[str] = mapped_column(Text)                        # texto ÍNTEGRO oficial
    tese: Mapped[str | None] = mapped_column(Text, nullable=True)
    orgao_julgador: Mapped[str | None] = mapped_column(String(200), nullable=True)
    relator: Mapped[str | None] = mapped_column(String(200), nullable=True)
    data_julgamento: Mapped[date | None] = mapped_column(Date, nullable=True)
    data_publicacao: Mapped[date | None] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="vigente")  # vigente|superado|cancelado|modulado|afetado|revisao
    status_nota: Mapped[str | None] = mapped_column(Text, nullable=True)
    status_atualizado_em: Mapped[date | None] = mapped_column(Date, nullable=True)
    materias: Mapped[list] = mapped_column(JSON, default=list)
    assuntos_tpu: Mapped[list] = mapped_column(JSON, default=list)          # códigos TPU de assunto
    suspensao_nacional: Mapped[bool] = mapped_column(Boolean, default=False)  # CPC, art. 1.037, II
    fonte_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    verificado: Mapped[bool] = mapped_column(Boolean, default=False)
    verificado_por: Mapped[str | None] = mapped_column(String(120), nullable=True)
    verificado_em: Mapped[date | None] = mapped_column(Date, nullable=True)
    ratio_estruturada: Mapped[dict | None] = mapped_column(JSON, nullable=True)  # cache do distinguishing
    # Registro de citação: integridade e estado da conferência com a fonte oficial
    coletado_em: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    hash_ementa: Mapped[str | None] = mapped_column(String(64), nullable=True)
    verificacao_status: Mapped[str] = mapped_column(String(20), default="nao_verificado")  # nao_verificado|conferido|divergente
    verificacao_nota: Mapped[str | None] = mapped_column(Text, nullable=True)


class Relacao(Base):
    __tablename__ = "relacoes"
    __table_args__ = (UniqueConstraint("origem", "destino", "tipo"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    origem: Mapped[str] = mapped_column(String(140))    # "precedente:stj-sumula-385" | "norma:cc-art-206"
    destino: Mapped[str] = mapped_column(String(140))
    tipo: Mapped[str] = mapped_column(String(30))       # interpreta|aplica|supera|cancela|modula|altera|revoga|cita
    nota: Mapped[str | None] = mapped_column(Text, nullable=True)


class Trecho(Base):
    __tablename__ = "trechos"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    fonte_tipo: Mapped[str] = mapped_column(String(20), index=True)  # precedente|norma|doutrina|modelo|autos
    fonte_id: Mapped[str] = mapped_column(String(140), index=True)
    caso_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    ordem: Mapped[int] = mapped_column(Integer, default=0)
    pagina: Mapped[int | None] = mapped_column(Integer, nullable=True)
    bbox: Mapped[list | None] = mapped_column(JSON, nullable=True)
    texto: Mapped[str] = mapped_column(Text)
    vetor: Mapped[list | None] = mapped_column(VetorTipo, nullable=True)
    origem: Mapped[str | None] = mapped_column(String(60), nullable=True)   # ex.: "ejc:<doc_id>"
    extra: Mapped[dict | None] = mapped_column(JSON, nullable=True)


# ---------------------------------------------------------------------- operação
class Caso(Base):
    __tablename__ = "casos"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    titulo: Mapped[str] = mapped_column(String(300))
    area: Mapped[str | None] = mapped_column(String(80), nullable=True)
    data_fatos: Mapped[date | None] = mapped_column(Date, nullable=True)   # define a norma aplicável no tempo
    sigiloso: Mapped[bool] = mapped_column(Boolean, default=False)          # força provedor local
    numero_processo: Mapped[str | None] = mapped_column(String(30), nullable=True, index=True)
    tribunal: Mapped[str | None] = mapped_column(String(20), nullable=True)
    orgao_julgador: Mapped[str | None] = mapped_column(String(300), nullable=True)
    parte_contraria: Mapped[str | None] = mapped_column(String(300), nullable=True, index=True)
    polo: Mapped[str | None] = mapped_column(String(10), nullable=True)     # ativo | passivo
    classe_tpu: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    assuntos_tpu: Mapped[list] = mapped_column(JSON, default=list)
    metadados_datajud: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    dono_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)
    documentos: Mapped[list["Documento"]] = relationship(back_populates="caso", cascade="all, delete-orphan")


class Documento(Base):
    __tablename__ = "documentos"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    caso_id: Mapped[int] = mapped_column(ForeignKey("casos.id", ondelete="CASCADE"))
    nome: Mapped[str] = mapped_column(String(300))
    paginas: Mapped[int] = mapped_column(Integer, default=0)
    seguranca: Mapped[dict] = mapped_column(JSON, default=dict)
    liberado_para_ia: Mapped[bool] = mapped_column(Boolean, default=False)
    tipo: Mapped[str] = mapped_column(String(20), default="pdf")            # pdf | texto | transcricao
    sha256: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    tamanho_bytes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    arquivo: Mapped[str | None] = mapped_column(String(500), nullable=True)  # cópia preservada do original
    versao: Mapped[int] = mapped_column(Integer, default=1)
    substitui_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    substituido: Mapped[bool] = mapped_column(Boolean, default=False)
    # Página física do PDF x numeração dos autos: [{"pagina": 1, "folha": "12", "id_processual": "123", "pagina_id": 3}]
    rotulos_pagina: Mapped[list] = mapped_column(JSON, default=list)
    folha_inicial: Mapped[int | None] = mapped_column(Integer, nullable=True)
    metadados: Mapped[dict] = mapped_column(JSON, default=dict)
    ingerido_por: Mapped[str | None] = mapped_column(String(120), nullable=True)
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)
    caso: Mapped[Caso] = relationship(back_populates="documentos")


class Minuta(Base):
    __tablename__ = "minutas"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    caso_id: Mapped[int | None] = mapped_column(ForeignKey("casos.id", ondelete="SET NULL"), nullable=True)
    tipo_peca: Mapped[str] = mapped_column(String(120))
    pedido: Mapped[str] = mapped_column(Text, default="")
    fase: Mapped[str] = mapped_column(String(40), default="planejamento")
    estado: Mapped[dict] = mapped_column(JSON, default=dict)   # plano, perguntas, respostas, roteiro, pesquisas, secoes
    texto: Mapped[str] = mapped_column(Text, default="")       # com marcadores
    texto_resolvido: Mapped[str] = mapped_column(Text, default="")
    verificacao: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="RASCUNHO")  # RASCUNHO|APROVADA|DESCARTADA
    aprovada_por: Mapped[str | None] = mapped_column(String(120), nullable=True)
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)
    atualizado_em: Mapped[datetime] = mapped_column(DateTime, default=agora, onupdate=agora)


class VersaoMinuta(Base):
    __tablename__ = "minutas_versoes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    minuta_id: Mapped[int] = mapped_column(ForeignKey("minutas.id", ondelete="CASCADE"))
    texto: Mapped[str] = mapped_column(Text)
    nota: Mapped[str] = mapped_column(String(300), default="")
    autor: Mapped[str] = mapped_column(String(60), default="sistema")
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)


class Desfecho(Base):
    """Retroalimentação: o que funcionou em cada peça."""
    __tablename__ = "desfechos"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    minuta_id: Mapped[int] = mapped_column(ForeignKey("minutas.id", ondelete="CASCADE"))
    resultado: Mapped[str] = mapped_column(String(40))   # procedente|parcial|improcedente|acordo|extinto|pendente
    teses_acolhidas: Mapped[list] = mapped_column(JSON, default=list)
    teses_rejeitadas: Mapped[list] = mapped_column(JSON, default=list)
    precedentes_decisivos: Mapped[list] = mapped_column(JSON, default=list)
    observacoes: Mapped[str] = mapped_column(Text, default="")
    data: Mapped[date | None] = mapped_column(Date, nullable=True)


class Skill(Base):
    __tablename__ = "skills"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    slug: Mapped[str] = mapped_column(String(120), index=True)
    titulo: Mapped[str] = mapped_column(String(200))
    tipo: Mapped[str] = mapped_column(String(10))     # forma|materia
    area: Mapped[str] = mapped_column(String(80), default="")
    descricao: Mapped[str] = mapped_column(Text)
    gatilhos: Mapped[list] = mapped_column(JSON, default=list)
    conteudo: Mapped[str] = mapped_column(Text)
    oficial: Mapped[bool] = mapped_column(Boolean, default=True)
    origem_id: Mapped[int | None] = mapped_column(ForeignKey("skills.id"), nullable=True)   # fork
    origem_versao: Mapped[int | None] = mapped_column(Integer, nullable=True)
    versao: Mapped[int] = mapped_column(Integer, default=1)
    dono: Mapped[str | None] = mapped_column(String(120), nullable=True)
    ativa: Mapped[bool] = mapped_column(Boolean, default=True)
    revisado_em: Mapped[date | None] = mapped_column(Date, nullable=True)
    historico: Mapped[list] = mapped_column(JSON, default=list)


class Lote(Base):
    __tablename__ = "lotes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    instrucao: Mapped[str] = mapped_column(Text)
    tipo_peca: Mapped[str] = mapped_column(String(120))
    modo: Mapped[str] = mapped_column(String(20), default="etapas")   # etapas|instantaneo
    caso_modelo_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    minuta_modelo_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    molde_congelado: Mapped[str | None] = mapped_column(Text, nullable=True)
    molde_aprovado_por: Mapped[str | None] = mapped_column(String(120), nullable=True)
    molde_aprovado_em: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    molde_versao_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    fase: Mapped[str] = mapped_column(String(30), default="aguardando_modelo")
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)


class LoteItem(Base):
    __tablename__ = "lotes_itens"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    lote_id: Mapped[int] = mapped_column(ForeignKey("lotes.id", ondelete="CASCADE"))
    caso_id: Mapped[int] = mapped_column(Integer)
    minuta_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="pendente")   # pendente|gerando|pronto|falha|incompativel
    erro: Mapped[str | None] = mapped_column(Text, nullable=True)
    compatibilidade: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    diff: Mapped[list] = mapped_column(JSON, default=list)


class Auditoria(Base):
    __tablename__ = "auditoria"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    momento: Mapped[datetime] = mapped_column(DateTime, default=agora)
    usuario: Mapped[str] = mapped_column(String(120), default="local")
    acao: Mapped[str] = mapped_column(String(80))
    alvo: Mapped[str] = mapped_column(String(120), default="")
    provedor: Mapped[str | None] = mapped_column(String(60), nullable=True)
    detalhe: Mapped[dict] = mapped_column(JSON, default=dict)
    custo_tokens: Mapped[float | None] = mapped_column(Float, nullable=True)      # tokens (entrada + saída)
    duracao_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    custo_estimado: Mapped[float | None] = mapped_column(Float, nullable=True)    # moeda, se preços configurados
    erro: Mapped[bool] = mapped_column(Boolean, default=False)


class Alerta(Base):
    """Monitor: precedente alterado, tema afetado com possível sobrestamento, intimação com prazo."""
    __tablename__ = "alertas"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tipo: Mapped[str] = mapped_column(String(40), index=True)
    nivel: Mapped[str] = mapped_column(String(15), default="alerta")    # critico | alerta | info
    mensagem: Mapped[str] = mapped_column(Text)
    caso_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    minuta_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    precedente_id: Mapped[str | None] = mapped_column(String(120), nullable=True)
    intimacao_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    chave: Mapped[str] = mapped_column(String(200), unique=True)           # idempotência
    resolvido: Mapped[bool] = mapped_column(Boolean, default=False)
    detalhe: Mapped[dict] = mapped_column(JSON, default=dict)
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)


class Intimacao(Base):
    __tablename__ = "intimacoes"
    __table_args__ = (UniqueConstraint("origem", "id_externo"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    origem: Mapped[str] = mapped_column(String(20), default="djen")
    id_externo: Mapped[str] = mapped_column(String(80), default="")
    numero_processo: Mapped[str | None] = mapped_column(String(30), nullable=True, index=True)
    tribunal: Mapped[str | None] = mapped_column(String(20), nullable=True)
    orgao: Mapped[str | None] = mapped_column(String(300), nullable=True)
    tipo: Mapped[str | None] = mapped_column(String(80), nullable=True)
    data_disponibilizacao: Mapped[date | None] = mapped_column(Date, nullable=True)
    texto: Mapped[str] = mapped_column(Text, default="")
    link: Mapped[str | None] = mapped_column(String(500), nullable=True)
    caso_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    prazo_dias: Mapped[int | None] = mapped_column(Integer, nullable=True)
    prazo_origem: Mapped[str | None] = mapped_column(String(30), nullable=True)   # extraido_do_texto | informado
    vencimento: Mapped[date | None] = mapped_column(Date, nullable=True)
    memoria_prazo: Mapped[list] = mapped_column(JSON, default=list)
    minuta_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="pendente")   # pendente | em_minuta | cumprida
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)


# ------------------------------------------------------------------ usuários e acesso
class Usuario(Base):
    __tablename__ = "usuarios"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    nome: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(200), unique=True)
    papel: Mapped[str] = mapped_column(String(20), default="advogado")   # admin | advogado | estagiario | leitor
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)     # SHA-256 do token; o token não é guardado
    ativo: Mapped[bool] = mapped_column(Boolean, default=True)
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)


class AcessoCaso(Base):
    __tablename__ = "acessos_caso"
    __table_args__ = (UniqueConstraint("caso_id", "usuario_id"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    caso_id: Mapped[int] = mapped_column(ForeignKey("casos.id", ondelete="CASCADE"))
    usuario_id: Mapped[int] = mapped_column(ForeignKey("usuarios.id", ondelete="CASCADE"))
    permissao: Mapped[str] = mapped_column(String(10), default="leitura")   # leitura | edicao


# ------------------------------------------------------------------ editor
class Sugestao(Base):
    """Alteração proposta (IA ou pessoa) ancorada em um bloco estável da minuta."""
    __tablename__ = "sugestoes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    minuta_id: Mapped[int] = mapped_column(ForeignKey("minutas.id", ondelete="CASCADE"), index=True)
    bloco_id: Mapped[str] = mapped_column(String(20))
    original: Mapped[str] = mapped_column(Text)
    proposto: Mapped[str] = mapped_column(Text)
    motivo: Mapped[str] = mapped_column(Text, default="")
    autor: Mapped[str] = mapped_column(String(120), default="ia")
    status: Mapped[str] = mapped_column(String(15), default="pendente")   # pendente | aceita | rejeitada | obsoleta
    decidido_por: Mapped[str | None] = mapped_column(String(120), nullable=True)
    decidido_em: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)


class PerfilEstilo(Base):
    __tablename__ = "perfis_estilo"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    nome: Mapped[str] = mapped_column(String(120))
    dono: Mapped[str] = mapped_column(String(120), default="local")
    instrucoes: Mapped[str] = mapped_column(Text)            # editável pelo usuário
    metricas: Mapped[dict] = mapped_column(JSON, default=dict)
    extraido_ia: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    modelos_analisados: Mapped[int] = mapped_column(Integer, default=0)
    versao: Mapped[int] = mapped_column(Integer, default=1)
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)
    atualizado_em: Mapped[datetime] = mapped_column(DateTime, default=agora, onupdate=agora)


class ProvaImagem(Base):
    """Recorte de página do PDF dos autos inserido na peça, com origem e hash."""
    __tablename__ = "provas_imagem"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    caso_id: Mapped[int] = mapped_column(ForeignKey("casos.id", ondelete="CASCADE"), index=True)
    documento_id: Mapped[int] = mapped_column(ForeignKey("documentos.id", ondelete="CASCADE"))
    pagina: Mapped[int] = mapped_column(Integer)
    bbox: Mapped[list] = mapped_column(JSON)
    legenda: Mapped[str] = mapped_column(Text, default="")
    png: Mapped[bytes] = mapped_column(LargeBinary)
    sha256_png: Mapped[str] = mapped_column(String(64))
    sha256_documento: Mapped[str | None] = mapped_column(String(64), nullable=True)
    criado_por: Mapped[str] = mapped_column(String(120), default="local")
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)


class FonteColeta(Base):
    """Telemetria das coletas de fontes oficiais (Planalto, Câmara, Senado...)."""
    __tablename__ = "fontes_coleta"
    id: Mapped[str] = mapped_column(String(80), primary_key=True)        # ex.: "planalto:cpc"
    descricao: Mapped[str] = mapped_column(String(300), default="")
    url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    ultima_execucao: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="nunca")      # nunca | ok | inalterado | erro
    itens: Mapped[int] = mapped_column(Integer, default=0)
    hash_fonte: Mapped[str | None] = mapped_column(String(64), nullable=True)
    erro: Mapped[str | None] = mapped_column(Text, nullable=True)
    detalhe: Mapped[dict] = mapped_column(JSON, default=dict)


class Proposicao(Base):
    """Monitor legislativo: proposições da Câmara e do Senado (ementa, situação, link)."""
    __tablename__ = "proposicoes"
    id: Mapped[str] = mapped_column(String(60), primary_key=True)        # "camara:123" | "senado:456"
    casa: Mapped[str] = mapped_column(String(10))
    sigla: Mapped[str] = mapped_column(String(30))                       # "PL 1234/2026"
    ementa: Mapped[str] = mapped_column(Text)
    data_apresentacao: Mapped[date | None] = mapped_column(Date, nullable=True)
    link: Mapped[str | None] = mapped_column(String(500), nullable=True)
    temas: Mapped[list] = mapped_column(JSON, default=list)
    coletado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)


class Conversa(Base):
    """Conversa com o assistente: guarda o pedido em andamento (intenção e dados já coletados)."""
    __tablename__ = "conversas"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    usuario: Mapped[str] = mapped_column(String(120), default="local")
    usuario_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    caso_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    estado: Mapped[dict] = mapped_column(JSON, default=dict)
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)
    atualizado_em: Mapped[datetime] = mapped_column(DateTime, default=agora, onupdate=agora)


class MensagemAssistente(Base):
    __tablename__ = "mensagens_assistente"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    conversa_id: Mapped[int] = mapped_column(ForeignKey("conversas.id", ondelete="CASCADE"), index=True)
    papel: Mapped[str] = mapped_column(String(15))          # usuario | assistente
    texto: Mapped[str] = mapped_column(Text, default="")
    dados: Mapped[dict] = mapped_column(JSON, default=dict)  # intenção, cartões, ações
    criado_em: Mapped[datetime] = mapped_column(DateTime, default=agora)
