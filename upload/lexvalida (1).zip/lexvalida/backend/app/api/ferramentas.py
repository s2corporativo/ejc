"""Ferramentas determinísticas: prazos, prescrição, cálculos, anonimização, verificação."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ..core import calculos, julgador, molde, onus
from ..core.anonimizador import Cofre, anonimizar, desanonimizar
from ..core.prazos import Calendario, Contagem, Termo, calcular_prazo
from ..core.prescricao import CATALOGO, calcular_prescricao
from ..db import get_session
from ..servicos import conhecimento, documentos

r = APIRouter(prefix="/api", tags=["ferramentas"])


class PrazoIn(BaseModel):
    data_evento: date
    dias: int = Field(gt=0)
    termo: Termo = Termo.DJE
    contagem: Contagem = Contagem.UTEIS
    em_dobro: bool = False
    motivo_dobro: str | None = None
    data_consulta_portal: date | None = None
    autos_eletronicos: bool = True
    feriados_extras: dict[date, str] = {}
    usar_dias_forenses_usuais: bool = False
    aplicar_suspensao_art_220: bool = True


@r.post("/prazos")
def prazo(p: PrazoIn):
    cal = Calendario(p.feriados_extras, p.usar_dias_forenses_usuais, p.aplicar_suspensao_art_220)
    try:
        return calcular_prazo(p.data_evento, p.dias, p.termo, p.contagem, cal, p.em_dobro, p.motivo_dobro,
                              p.data_consulta_portal, p.autos_eletronicos).as_dict()
    except ValueError as e:
        raise HTTPException(422, str(e)) from e


class PrescricaoIn(BaseModel):
    termo_inicial: date
    data_referencia: date
    tipo: str | None = None
    prazo_anos: int | None = None
    base_legal: str | None = None
    data_interrupcao: date | None = None
    data_extincao_contrato: date | None = None


@r.get("/prescricao/catalogo")
def catalogo_prescricao():
    return CATALOGO


@r.post("/prescricao")
def prescricao(p: PrescricaoIn):
    try:
        return calcular_prescricao(**p.model_dump()).as_dict()
    except ValueError as e:
        raise HTTPException(422, str(e)) from e


class CorrecaoIn(BaseModel):
    valor: str
    data_inicio: date
    data_fim: date
    serie_mensal_pct: dict[str, str]
    nome_indice: str = "índice informado"


@r.post("/calculos/correcao")
def correcao(p: CorrecaoIn):
    try:
        return calculos.correcao_monetaria(p.valor, p.data_inicio, p.data_fim, p.serie_mensal_pct, p.nome_indice).as_dict()
    except (ValueError, ArithmeticError) as e:
        raise HTTPException(422, str(e)) from e


class JurosIn(BaseModel):
    valor: str
    data_inicio: date
    data_fim: date
    taxa_mensal_pct: str | None = None
    base_legal: str | None = None
    serie_taxa_pct: dict[str, str] | None = None


@r.post("/calculos/juros")
def juros(p: JurosIn):
    try:
        if p.serie_taxa_pct:
            return calculos.juros_legais_taxa_mensal(p.valor, p.data_inicio, p.data_fim, p.serie_taxa_pct).as_dict()
        if not p.taxa_mensal_pct or not p.base_legal:
            raise ValueError("Informe taxa_mensal_pct e base_legal, ou a série oficial da taxa legal.")
        return calculos.juros_simples(p.valor, p.data_inicio, p.data_fim, p.taxa_mensal_pct, p.base_legal).as_dict()
    except (ValueError, ArithmeticError) as e:
        raise HTTPException(422, str(e)) from e


class AnonIn(BaseModel):
    texto: str
    cofre: dict | None = None
    nomes_adicionais: list[str] = []


@r.post("/anonimizar")
def anon(p: AnonIn):
    return anonimizar(p.texto, Cofre.from_dict(p.cofre) if p.cofre else None, p.nomes_adicionais)


class DesanonIn(BaseModel):
    texto: str
    cofre: dict


@r.post("/desanonimizar")
def desanon(p: DesanonIn):
    return desanonimizar(p.texto, p.cofre)


class VerificarIn(BaseModel):
    texto: str
    data_fatos: date | None = None
    tipo_peca: str | None = None


@r.post("/verificar-texto")
def verificar_texto(p: VerificarIn, db: Session = Depends(get_session)):
    """Verifica qualquer texto que siga o protocolo de marcadores, inclusive escrito por humano."""
    res = documentos.resolver_citacoes(db, p.texto, p.data_fatos).as_dict()
    from ..core import salvaguardas
    sv = salvaguardas.verificar(res["texto"])
    for pr in sv["promessas"]:
        res["problemas"].append({"nivel": "alerta", "tipo": "promessa_resultado", "marcador": pr,
                                 "mensagem": f"Possível promessa de resultado: \"{pr}\"."})
    for a in sv["merito_prescricao"]:
        res["problemas"].append({"nivel": "alerta", "tipo": "prescricao_merito", "marcador": a["trecho"],
                                 "mensagem": f"\"{a['trecho']}\": prescrição e decadência resolvem o mérito; use \"{a['correcao']}\"."})
    for a in sv["cdc"]:
        res["problemas"].append({"nivel": "alerta", "tipo": "cdc_vicio_fato", "mensagem": a, "marcador": ""})
    if p.tipo_peca:
        res["julgador"] = julgador.simular(res["texto"], p.tipo_peca)
    return res


class JulgadorIn(BaseModel):
    texto: str
    tipo_peca: str


@r.post("/julgador")
def simular_julgador(p: JulgadorIn):
    return julgador.simular(p.texto, p.tipo_peca)


class Alegacao(BaseModel):
    alegacao: str
    parte: str = "autor"
    natureza: str | None = None
    distribuicao_dinamica: str | None = None


class MatrizIn(BaseModel):
    caso_id: int
    rito: str = "civel"
    alegacoes: list[Alegacao]
    inversao_deferida: bool = False


@r.post("/matriz-probatoria")
def matriz(p: MatrizIn, db: Session = Depends(get_session)):
    try:
        return onus.montar_matriz([a.model_dump() for a in p.alegacoes], p.rito,
                                  lambda q: conhecimento.pesquisar_autos(db, p.caso_id, q, limite=3),
                                  p.inversao_deferida, limiar_relevancia=0.0)
    except ValueError as e:
        raise HTTPException(422, str(e)) from e


class MoldeIn(BaseModel):
    modelo: str
    operacoes: list[dict]
    protegidos: list[str] = []


@r.post("/molde/aplicar")
def aplicar_molde(p: MoldeIn):
    return molde.aplicar_operacoes(p.modelo, p.operacoes, p.protegidos).as_dict()
