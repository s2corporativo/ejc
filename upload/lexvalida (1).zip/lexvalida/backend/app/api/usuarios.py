"""Usuários, papéis e compartilhamento de casos."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_session
from ..models import AcessoCaso, Caso, Usuario
from ..servicos import acesso, auditoria
from . import deps

r = APIRouter(prefix="/api", tags=["usuarios"])


def _u(u: Usuario) -> dict:
    return {"id": u.id, "nome": u.nome, "email": u.email, "papel": u.papel, "ativo": u.ativo,
            "criado_em": u.criado_em.isoformat()}


@r.get("/eu")
def eu():
    c = acesso.atual()
    return {"id": c.id, "nome": c.nome, "papel": c.papel, "admin": c.admin, "pode_aprovar": c.pode_aprovar}


class UsuarioIn(BaseModel):
    nome: str
    email: str
    papel: str = "advogado"


@r.post("/usuarios")
def criar(p: UsuarioIn, db: Session = Depends(get_session)):
    deps.admin()
    try:
        u, token = acesso.criar_usuario(db, p.nome, p.email, p.papel)
    except ValueError as e:
        raise HTTPException(422, str(e)) from e
    auditoria.registrar(db, "usuario:criar", f"usuario:{u.id}", {"papel": u.papel})
    return {**_u(u), "token": token, "aviso": "Guarde o token agora: ele não é armazenado e não será exibido novamente."}


@r.get("/usuarios")
def listar(db: Session = Depends(get_session)):
    deps.admin()
    return [_u(u) for u in db.scalars(select(Usuario).order_by(Usuario.nome))]


class UsuarioPatch(BaseModel):
    papel: str | None = None
    ativo: bool | None = None


@r.patch("/usuarios/{uid}")
def alterar(uid: int, p: UsuarioPatch, db: Session = Depends(get_session)):
    deps.admin()
    u = db.get(Usuario, uid)
    if not u:
        raise HTTPException(404, "Usuário inexistente.")
    if p.papel is not None:
        if p.papel not in acesso.PAPEIS:
            raise HTTPException(422, f"Papel inválido. Use: {sorted(acesso.PAPEIS)}")
        u.papel = p.papel
    if p.ativo is not None:
        u.ativo = p.ativo
    db.commit()
    auditoria.registrar(db, "usuario:alterar", f"usuario:{uid}", p.model_dump(exclude_none=True))
    return _u(u)


@r.post("/usuarios/{uid}/token")
def novo_token(uid: int, db: Session = Depends(get_session)):
    deps.admin()
    try:
        token = acesso.renovar_token(db, uid)
    except ValueError as e:
        raise HTTPException(404, str(e)) from e
    auditoria.registrar(db, "usuario:token_renovado", f"usuario:{uid}")
    return {"id": uid, "token": token}


class AcessoIn(BaseModel):
    usuario_id: int
    permissao: str = "leitura"


def _dono_ou_admin(db: Session, caso_id: int) -> None:
    deps.caso(db, caso_id)
    c, ctx = db.get(Caso, caso_id), acesso.atual()
    if not ctx.admin and (ctx.id is None or c.dono_id != ctx.id):
        raise HTTPException(403, "Somente o dono do caso ou um administrador gerencia o compartilhamento.")


@r.get("/casos/{caso_id}/acessos")
def acessos(caso_id: int, db: Session = Depends(get_session)):
    deps.caso(db, caso_id)
    out = []
    for a in db.scalars(select(AcessoCaso).where(AcessoCaso.caso_id == caso_id)):
        u = db.get(Usuario, a.usuario_id)
        out.append({"usuario_id": a.usuario_id, "nome": u.nome if u else None, "papel": u.papel if u else None,
                    "permissao": a.permissao})
    return out


@r.post("/casos/{caso_id}/acessos")
def conceder(caso_id: int, p: AcessoIn, db: Session = Depends(get_session)):
    _dono_ou_admin(db, caso_id)
    try:
        a = acesso.conceder(db, caso_id, p.usuario_id, p.permissao)
    except ValueError as e:
        raise HTTPException(422, str(e)) from e
    auditoria.registrar(db, "caso:acesso_concedido", f"caso:{caso_id}", p.model_dump())
    return {"caso_id": caso_id, "usuario_id": a.usuario_id, "permissao": a.permissao}


@r.delete("/casos/{caso_id}/acessos/{uid}")
def revogar(caso_id: int, uid: int, db: Session = Depends(get_session)):
    _dono_ou_admin(db, caso_id)
    a = db.scalar(select(AcessoCaso).where(AcessoCaso.caso_id == caso_id, AcessoCaso.usuario_id == uid))
    if a:
        db.delete(a)
        db.commit()
    auditoria.registrar(db, "caso:acesso_revogado", f"caso:{caso_id}", {"usuario_id": uid})
    return {"caso_id": caso_id, "usuario_id": uid, "revogado": bool(a)}
