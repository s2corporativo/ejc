"""Editor com blocos e sugestões, perfis de estilo, análise da instrução e observabilidade."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core import estilo as estilo_core
from ..core.analise_instrucao import analisar
from ..db import get_session
from ..llm import prompts
from ..llm.provedores import construir, extrair_json
from ..models import Caso, Minuta, PerfilEstilo, Sugestao
from ..servicos import acesso, auditoria, editor, observabilidade
from . import deps

r = APIRouter(prefix="/api", tags=["edicao"])


def _m(db: Session, mid: int, edicao: bool = False) -> Minuta:
    m = db.get(Minuta, mid)
    if not m:
        raise HTTPException(404, "Minuta inexistente.")
    deps.caso(db, m.caso_id, edicao)
    return m


# ------------------------------------------------------------------ editor
@r.get("/minutas/{mid}/blocos")
def blocos(mid: int, db: Session = Depends(get_session)):
    _m(db, mid)
    return editor.blocos(db, mid)


class SugestaoIn(BaseModel):
    bloco_id: str
    proposto: str
    motivo: str = ""


@r.post("/minutas/{mid}/sugestoes")
def sugerir(mid: int, p: SugestaoIn, db: Session = Depends(get_session)):
    _m(db, mid, edicao=True)
    try:
        s = editor.sugerir(db, mid, p.bloco_id, p.proposto, p.motivo, autor=acesso.atual().nome)
    except editor.ErroEditor as e:
        raise HTTPException(422, str(e)) from e
    return editor._sug(s)


class SugestaoIaIn(BaseModel):
    instrucao: str
    bloco_ids: list[str] | None = None
    modo: str = "minuta"     # minuta | auto


@r.post("/minutas/{mid}/sugestoes/ia")
def sugerir_ia(mid: int, p: SugestaoIaIn, db: Session = Depends(get_session)):
    _m(db, mid, edicao=True)
    if p.modo not in ("minuta", "auto"):
        raise HTTPException(422, "Modo: minuta ou auto.")
    try:
        return editor.sugerir_ia(db, mid, p.instrucao, p.bloco_ids, p.modo, acesso.atual().nome)
    except editor.ErroEditor as e:
        raise HTTPException(422, str(e)) from e
    except Exception as e:  # noqa: BLE001
        raise HTTPException(503, str(e)) from e


class DecisaoIn(BaseModel):
    aceitar: bool


@r.post("/sugestoes/{sid}/decisao")
def decidir(sid: int, p: DecisaoIn, db: Session = Depends(get_session)):
    s = db.get(Sugestao, sid)
    if not s:
        raise HTTPException(404, "Sugestão inexistente.")
    _m(db, s.minuta_id, edicao=True)
    try:
        return editor.decidir(db, sid, p.aceitar, acesso.atual().nome)
    except editor.ErroEditor as e:
        raise HTTPException(409 if "obsoleta" in str(e) else 422, str(e)) from e


@r.post("/minutas/{mid}/versoes/{vid}/restaurar")
def restaurar(mid: int, vid: int, db: Session = Depends(get_session)):
    _m(db, mid, edicao=True)
    try:
        m = editor.restaurar_versao(db, mid, vid, acesso.atual().nome)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(422, str(e)) from e
    return {"id": m.id, "fase": m.fase, "bloqueado": (m.verificacao or {}).get("bloqueado"), "texto": m.texto}


# ------------------------------------------------------------------ análise da instrução
class AnaliseIn(BaseModel):
    tipo_peca: str
    pedido: str
    caso_id: int | None = None


@r.post("/analise-instrucao")
def analise(p: AnaliseIn, db: Session = Depends(get_session)):
    caso = None
    if p.caso_id:
        deps.caso(db, p.caso_id)
        caso = db.get(Caso, p.caso_id)
    bloqueados = sum(1 for d in caso.documentos if not d.liberado_para_ia) if caso else 0
    return analisar(p.tipo_peca, p.pedido, tem_caso=bool(caso), data_fatos_informada=bool(caso and caso.data_fatos),
                    docs_bloqueados=bloqueados)


# ------------------------------------------------------------------ perfis de estilo
def _pf(p: PerfilEstilo) -> dict:
    return {"id": p.id, "nome": p.nome, "dono": p.dono, "instrucoes": p.instrucoes, "metricas": p.metricas,
            "extraido_ia": p.extraido_ia, "modelos_analisados": p.modelos_analisados, "versao": p.versao,
            "atualizado_em": p.atualizado_em.isoformat()}


class PerfilIn(BaseModel):
    nome: str
    modelos: list[str]
    usar_ia: bool = True


@r.post("/estilo/perfis")
def criar_perfil(p: PerfilIn, db: Session = Depends(get_session)):
    textos = [t for t in p.modelos if t and t.strip()][:12]
    if not textos:
        raise HTTPException(422, "Envie ao menos um modelo de peça do escritório.")
    met = estilo_core.metricas(textos)
    ia = None
    if p.usar_ia:
        try:
            prov = construir()
            resp = prov.gerar("estilo", prompts.SISTEMA_BASE + "\n\n" + prompts.ESTILO,
                              "\n\n=====\n\n".join(f"<modelo>\n{m[:15000]}\n</modelo>" for m in textos), {"modelos": textos})
            ia = extrair_json(resp.texto)
        except Exception as e:  # noqa: BLE001  (perfil determinístico continua válido)
            ia = {"erro": str(e)[:300]}
    pf = PerfilEstilo(nome=p.nome, dono=acesso.atual().nome, instrucoes=estilo_core.instrucoes(met, ia if ia and "erro" not in ia else None),
                      metricas=met, extraido_ia=ia, modelos_analisados=len(textos))
    db.add(pf)
    db.commit()
    auditoria.registrar(db, "estilo:perfil_criado", f"perfil:{pf.id}", {"modelos": len(textos)})
    return _pf(pf)


@r.get("/estilo/perfis")
def listar_perfis(db: Session = Depends(get_session)):
    return [_pf(p) for p in db.scalars(select(PerfilEstilo).order_by(PerfilEstilo.nome))]


class PerfilEdicaoIn(BaseModel):
    instrucoes: str
    nome: str | None = None


@r.put("/estilo/perfis/{pid}")
def editar_perfil(pid: int, p: PerfilEdicaoIn, db: Session = Depends(get_session)):
    pf = db.get(PerfilEstilo, pid)
    if not pf:
        raise HTTPException(404, "Perfil inexistente.")
    pf.instrucoes, pf.versao = p.instrucoes.strip(), pf.versao + 1
    if p.nome:
        pf.nome = p.nome
    db.commit()
    auditoria.registrar(db, "estilo:perfil_editado", f"perfil:{pid}", {"versao": pf.versao})
    return _pf(pf)


# ------------------------------------------------------------------ observabilidade
@r.get("/observabilidade")
def observar(dias: int = 30, db: Session = Depends(get_session)):
    deps.admin()
    return observabilidade.resumo(db, max(1, min(dias, 3650)))
