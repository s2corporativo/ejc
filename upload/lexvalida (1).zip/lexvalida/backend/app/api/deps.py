from __future__ import annotations

from fastapi import HTTPException

from ..db import get_session  # noqa: F401  (reexport)
from ..servicos import acesso


def exigir_token() -> None:
    """A autenticação é feita no middleware (main.py), que define o usuário do contexto.
    Mantido como dependência dos routers para compatibilidade."""
    return None


def usuario():
    return acesso.atual()


def caso(db, caso_id: int | None, edicao: bool = False) -> None:
    try:
        acesso.exigir_caso(db, caso_id, edicao)
    except acesso.SemPermissao as e:
        raise HTTPException(404 if "inexistente" in str(e) else 403, str(e)) from e


def admin() -> None:
    if not acesso.atual().admin:
        raise HTTPException(403, "Operação restrita a administradores.")
