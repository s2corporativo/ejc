"""Evidências do caso: contradições, imagens de prova, transcrição e Visual Law."""
from __future__ import annotations

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import HTMLResponse, Response
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..core import contradicoes, visual_law
from ..db import get_session
from ..models import Caso, ProvaImagem
from ..servicos import acesso, auditoria, documentos, provas, transcricao
from . import deps

r = APIRouter(prefix="/api", tags=["evidencias"])
LIMITE_MIDIA = 300 * 1024 * 1024


@r.get("/casos/{caso_id}/contradicoes")
def contradicoes_caso(caso_id: int, db: Session = Depends(get_session)):
    deps.caso(db, caso_id)
    return contradicoes.detectar(documentos.paginas_do_caso(db, caso_id))


# ---------------------------------------------------------------- imagens de prova
class RecorteIn(BaseModel):
    documento_id: int
    pagina: int
    bbox: list[float]
    legenda: str


@r.post("/casos/{caso_id}/provas")
def recortar(caso_id: int, p: RecorteIn, db: Session = Depends(get_session)):
    deps.caso(db, caso_id, edicao=True)
    d = db.get(documentos.Documento, p.documento_id)
    if not d or d.caso_id != caso_id:
        raise HTTPException(404, "Documento inexistente neste caso.")
    try:
        pr = provas.recortar(db, p.documento_id, p.pagina, p.bbox, p.legenda, acesso.atual().nome)
    except provas.ErroProva as e:
        raise HTTPException(422, str(e)) from e
    auditoria.registrar(db, "prova:recorte", f"prova:{pr.id}", {"documento": d.id, "pagina": p.pagina, "sha256": pr.sha256_png})
    return provas.como_dict(db, pr)


@r.get("/casos/{caso_id}/provas")
def listar_provas(caso_id: int, db: Session = Depends(get_session)):
    deps.caso(db, caso_id)
    return provas.listar(db, caso_id)


@r.get("/provas/{pid}/imagem")
def imagem(pid: int, db: Session = Depends(get_session)):
    p = db.get(ProvaImagem, pid)
    if not p:
        raise HTTPException(404, "Prova inexistente.")
    deps.caso(db, p.caso_id)
    return Response(p.png, media_type="image/png", headers={"X-SHA256": p.sha256_png})


# ---------------------------------------------------------------- transcrição
@r.post("/casos/{caso_id}/transcricoes")
async def transcrever(caso_id: int, arquivo: UploadFile = File(...), db: Session = Depends(get_session)):
    deps.caso(db, caso_id, edicao=True)
    dados = await arquivo.read()
    if len(dados) > LIMITE_MIDIA:
        raise HTTPException(413, "Mídia acima de 300 MB: divida o arquivo.")
    try:
        res = transcricao.transcrever(db, caso_id, arquivo.filename or "midia", dados, acesso.atual().nome)
    except transcricao.ErroTranscricao as e:
        raise HTTPException(503 if "configure" in str(e).lower() or "defina" in str(e).lower() else 422, str(e)) from e
    auditoria.registrar(db, "documento:transcricao", f"documento:{res['documento_id']}",
                        {"segmentos": len(res["segmentos"]), "provedor": res["metadados"]["provedor"]})
    return res


# ---------------------------------------------------------------- Visual Law
class EventoIn(BaseModel):
    data: str
    fato: str
    referencia: str | None = None


class VisualIn(BaseModel):
    eventos_extras: list[EventoIn] = []
    usar_autos: bool = True


def _caso_dict(c: Caso) -> dict:
    return {k: getattr(c, k) for k in ("numero_processo", "tribunal", "orgao_julgador", "classe_tpu", "assuntos_tpu",
                                       "parte_contraria", "data_fatos")}


def montar_visual(db: Session, caso_id: int, extras: list[dict] | None = None, usar_autos: bool = True) -> dict:
    c = db.get(Caso, caso_id)
    eventos = visual_law.eventos_dos_autos(documentos.paginas_do_caso(db, caso_id)) if usar_autos else []
    eventos += [{**e, "origem": "advogado"} for e in (extras or [])]
    return {"quadro_resumo": visual_law.quadro_resumo(_caso_dict(c)), "linha_do_tempo": visual_law.linha_do_tempo(eventos),
            "titulo": c.titulo}


@r.post("/casos/{caso_id}/visual-law")
def visual(caso_id: int, p: VisualIn, formato: str = "json", db: Session = Depends(get_session)):
    deps.caso(db, caso_id)
    v = montar_visual(db, caso_id, [e.model_dump() for e in p.eventos_extras], p.usar_autos)
    if formato == "html":
        return HTMLResponse(visual_law.html_visual(v["titulo"], v["quadro_resumo"], v["linha_do_tempo"]))
    return v
