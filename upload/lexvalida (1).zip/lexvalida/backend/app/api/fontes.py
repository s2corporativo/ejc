"""Fontes oficiais de conhecimento: Planalto, monitor legislativo e pacote de migração do EJC."""
from __future__ import annotations

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_session, nova_sessao
from ..integracoes import legislativo
from ..models import FonteColeta, Proposicao
from ..servicos import acesso, auditoria, legislacao

r = APIRouter(prefix="/api", tags=["fontes"])


def _pode_curar() -> None:
    if acesso.atual().papel not in ("admin", "advogado"):
        raise HTTPException(403, "Somente advogado ou administrador altera a base de conhecimento.")


@r.get("/fontes")
def fontes(db: Session = Depends(get_session)):
    return {"planalto": legislacao.catalogo(db),
            "coletas": [{"id": f.id, "descricao": f.descricao, "status": f.status, "itens": f.itens,
                         "ultima_execucao": f.ultima_execucao.isoformat() if f.ultima_execucao else None, "erro": f.erro}
                        for f in db.scalars(select(FonteColeta).order_by(FonteColeta.id))]}


class PlanaltoIn(BaseModel):
    slugs: list[str] | None = None
    forcar: bool = False


def _rodar_planalto(slugs, forcar, ctx):
    acesso.definir(ctx)
    db = nova_sessao()
    try:
        legislacao.importar_planalto(db, slugs, forcar)
    finally:
        db.close()


@r.post("/fontes/planalto")
def coletar_planalto(p: PlanaltoIn, bg: BackgroundTasks, assincrono: bool = True, db: Session = Depends(get_session)):
    """Coleta o texto compilado dos diplomas (padrão: os mais usados) e grava cada artigo como norma citável."""
    _pode_curar()
    if p.slugs:
        desconhecidos = [s for s in p.slugs if s not in legislacao.planalto.POR_SLUG]
        if desconhecidos:
            raise HTTPException(422, f"Diplomas desconhecidos: {desconhecidos}")
    if assincrono:
        bg.add_task(_rodar_planalto, p.slugs, p.forcar, acesso.atual())
        return {"iniciado": True, "diplomas": p.slugs or legislacao.planalto.PADRAO,
                "nota": "Acompanhe em GET /api/fontes (status e artigos por diploma)."}
    return legislacao.importar_planalto(db, p.slugs, p.forcar)


class TemaIn(BaseModel):
    tema: str
    ano: int | None = None


@r.post("/fontes/legislativo")
def monitorar(p: TemaIn, db: Session = Depends(get_session)):
    try:
        return legislacao.monitorar(db, p.tema, p.ano)
    except legislativo.ErroLegislativo as e:
        raise HTTPException(422, str(e)) from e


@r.get("/proposicoes")
def proposicoes(tema: str | None = None, db: Session = Depends(get_session)):
    q = select(Proposicao).order_by(Proposicao.data_apresentacao.desc()).limit(300)
    itens = db.scalars(q).all()
    if tema:
        itens = [x for x in itens if tema in (x.temas or [])]
    return [{"id": x.id, "casa": x.casa, "sigla": x.sigla, "ementa": x.ementa, "link": x.link, "temas": x.temas,
             "data_apresentacao": x.data_apresentacao.isoformat() if x.data_apresentacao else None} for x in itens]


@r.post("/fontes/bundle-ejc")
async def importar_bundle(arquivo: UploadFile = File(...), incluir_escritorio: bool = True,
                          incluir_ficticios_como_modelo: bool = False, exigir_aprovado: bool = True,
                          simular: bool = False, db: Session = Depends(get_session)):
    """Pacote de migração do EJC (ZIP com data/raw/*.jsonl e manifests/live_export_manifest.json)."""
    _pode_curar()
    from ..servicos import importador_bundle
    dados = await arquivo.read()
    try:
        rel = importador_bundle.importar_zip(db, dados, incluir_escritorio=incluir_escritorio,
                                             incluir_ficticios_como_modelo=incluir_ficticios_como_modelo,
                                             exigir_aprovado=exigir_aprovado, simular=simular)
    except importador_bundle.ErroBundle as e:
        raise HTTPException(422, str(e)) from e
    auditoria.registrar(db, "conhecimento:bundle_ejc", arquivo.filename or "", {k: v for k, v in rel.items() if k != "ignorados"})
    return rel
