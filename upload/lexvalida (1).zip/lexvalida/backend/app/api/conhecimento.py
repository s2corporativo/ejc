"""Casos, documentos dos autos e base de conhecimento (incluindo importação do EJC)."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..core.hierarquia import STATUS, TIPOS
from ..db import get_session
from . import deps
from ..models import Caso, Documento, Norma, Precedente, Trecho
from ..servicos import acesso, auditoria, conhecimento, documentos, importador_ejc, monitor

r = APIRouter(prefix="/api", tags=["conhecimento"])
LIMITE_UPLOAD = 60 * 1024 * 1024


class CasoIn(BaseModel):
    titulo: str
    area: str | None = None
    data_fatos: date | None = None
    sigiloso: bool = False
    numero_processo: str | None = None
    parte_contraria: str | None = None
    polo: str | None = None
    assuntos_tpu: list[dict] = []


def _caso(c: Caso) -> dict:
    return {"id": c.id, "titulo": c.titulo, "area": c.area, "data_fatos": c.data_fatos, "sigiloso": c.sigiloso,
            "numero_processo": c.numero_processo, "parte_contraria": c.parte_contraria, "polo": c.polo,
            "tribunal": c.tribunal, "orgao_julgador": c.orgao_julgador, "classe_tpu": c.classe_tpu,
            "assuntos_tpu": c.assuntos_tpu, "dono_id": c.dono_id,
            "documentos": [_doc(d) for d in c.documentos]}


def _doc(d: Documento) -> dict:
    return {"id": d.id, "nome": d.nome, "tipo": d.tipo, "paginas": d.paginas, "liberado_para_ia": d.liberado_para_ia,
            "seguranca": d.seguranca, "sha256": d.sha256, "versao": d.versao, "substituido": d.substituido,
            "substitui_id": d.substitui_id, "folha_inicial": d.folha_inicial, "rotulos_pagina": d.rotulos_pagina,
            "metadados": d.metadados, "ingerido_por": d.ingerido_por}


def _doc_do_caso(db: Session, documento_id: int, edicao: bool = False) -> Documento:
    d = db.get(Documento, documento_id)
    if not d:
        raise HTTPException(404, "Documento inexistente.")
    deps.caso(db, d.caso_id, edicao)
    return d


@r.post("/casos")
def criar_caso(p: CasoIn, db: Session = Depends(get_session)):
    c = Caso(**p.model_dump(), dono_id=acesso.atual().id)
    db.add(c)
    db.commit()
    auditoria.registrar(db, "caso:criar", f"caso:{c.id}")
    return _caso(c)


@r.get("/casos")
def listar_casos(db: Session = Depends(get_session)):
    vis = acesso.casos_visiveis(db)
    q = select(Caso).order_by(Caso.id.desc())
    if vis is not None:
        q = q.where(Caso.id.in_(vis or {-1}))
    return [_caso(c) for c in db.scalars(q)]


@r.get("/casos/{caso_id}")
def obter_caso(caso_id: int, db: Session = Depends(get_session)):
    deps.caso(db, caso_id)
    c = db.get(Caso, caso_id)
    if not c:
        raise HTTPException(404, "Caso inexistente.")
    return _caso(c)


@r.post("/casos/{caso_id}/documentos")
async def enviar_documento(caso_id: int, arquivo: UploadFile = File(...), folha_inicial: int | None = Form(None),
                           db: Session = Depends(get_session)):
    deps.caso(db, caso_id, edicao=True)
    dados = await arquivo.read()
    if len(dados) > LIMITE_UPLOAD:
        raise HTTPException(413, "Arquivo acima de 60 MB.")
    try:
        doc, proc = documentos.ingerir_documento(db, caso_id, arquivo.filename or "documento", dados, folha_inicial,
                                                 acesso.atual().nome)
    except documentos.DocumentoDuplicado as e:
        raise HTTPException(409, str(e)) from e
    except ValueError as e:
        raise HTTPException(422, str(e)) from e
    auditoria.registrar(db, "documento:ingerir", f"documento:{doc.id}",
                        {"risco_alto": proc.risco_alto, "sha256": doc.sha256, "versao": doc.versao})
    return _doc(doc)


@r.get("/documentos/{documento_id}/integridade")
def integridade(documento_id: int, db: Session = Depends(get_session)):
    _doc_do_caso(db, documento_id)
    return documentos.verificar_integridade(db, documento_id)


@r.get("/documentos/{documento_id}/versoes")
def versoes_doc(documento_id: int, db: Session = Depends(get_session)):
    _doc_do_caso(db, documento_id)
    return documentos.versoes_documento(db, documento_id)


@r.get("/documentos/{documento_id}/arquivo")
def baixar_original(documento_id: int, db: Session = Depends(get_session)):
    d = _doc_do_caso(db, documento_id)
    from pathlib import Path
    if not d.arquivo or not Path(d.arquivo).exists():
        raise HTTPException(404, "Original não preservado neste servidor.")
    return FileResponse(d.arquivo, filename=d.nome)


class DecisaoIn(BaseModel):
    remover_trechos: list[str] = []
    liberar: bool = True


@r.post("/documentos/{documento_id}/decisao-seguranca")
def decidir(documento_id: int, p: DecisaoIn, db: Session = Depends(get_session)):
    _doc_do_caso(db, documento_id, edicao=True)
    try:
        d = documentos.decidir_trechos_suspeitos(db, documento_id, p.remover_trechos, p.liberar)
    except ValueError as e:
        raise HTTPException(404, str(e)) from e
    auditoria.registrar(db, "documento:decisao_seguranca", f"documento:{d.id}", p.model_dump())
    return {"id": d.id, "liberado_para_ia": d.liberado_para_ia, "seguranca": d.seguranca}


@r.get("/documentos/{documento_id}/paginas/{pagina}")
def pagina(documento_id: int, pagina: int, db: Session = Depends(get_session)):
    _doc_do_caso(db, documento_id)
    p = documentos.texto_da_pagina(db, str(documento_id), pagina)
    if not p:
        raise HTTPException(404, "Página inexistente.")
    blocos = db.scalars(select(Trecho.bbox).where(Trecho.fonte_tipo == "autos", Trecho.fonte_id == str(documento_id),
                                                  Trecho.pagina == pagina)).first()
    return {**p, "blocos": blocos}


@r.get("/casos/{caso_id}/buscar")
def buscar_autos(caso_id: int, q: str, db: Session = Depends(get_session)):
    deps.caso(db, caso_id)
    return conhecimento.pesquisar_autos(db, caso_id, q)


# ------------------------------------------------------------ base de conhecimento
@r.get("/conhecimento/tipos")
def tipos():
    return {"tipos_precedente": TIPOS, "status": STATUS}


@r.post("/conhecimento/precedentes")
def importar_precedentes(itens: list[dict], db: Session = Depends(get_session)):
    ok, erros = [], []
    for it in itens:
        try:
            ok.append(conhecimento.importar_precedente(db, it).id)
        except (ValueError, KeyError) as e:
            db.rollback()
            erros.append({"id": it.get("id"), "erro": str(e)})
    auditoria.registrar(db, "conhecimento:precedentes", "", {"importados": len(ok), "erros": len(erros)})
    return {"importados": ok, "erros": erros}


@r.post("/conhecimento/normas")
def importar_normas(itens: list[dict], db: Session = Depends(get_session)):
    ok, erros = [], []
    for it in itens:
        try:
            ok.append(conhecimento.importar_norma(db, it).id)
        except (ValueError, KeyError) as e:
            db.rollback()
            erros.append({"id": it.get("id"), "erro": str(e)})
    auditoria.registrar(db, "conhecimento:normas", "", {"importados": len(ok), "erros": len(erros)})
    return {"importados": ok, "erros": erros}


class TextoFonteIn(BaseModel):
    id: str
    titulo: str
    texto: str


@r.post("/conhecimento/textos/{fonte_tipo}")
def importar_texto(fonte_tipo: str, p: TextoFonteIn, db: Session = Depends(get_session)):
    if fonte_tipo not in ("modelos", "doutrina"):
        raise HTTPException(404, "Use /conhecimento/textos/modelos ou /conhecimento/textos/doutrina.")
    ft = "modelo" if fonte_tipo == "modelos" else "doutrina"
    conhecimento.remover_fonte(db, ft, p.id)
    ids = conhecimento.indexar(db, ft, p.id, p.texto, extra={"titulo": p.titulo})
    return {"id": p.id, "trechos": len(ids)}


class StatusIn(BaseModel):
    status: str
    nota: str | None = None


@r.patch("/precedentes/{pid}/status")
def alterar_status(pid: str, p: StatusIn, db: Session = Depends(get_session)):
    if p.status not in STATUS:
        raise HTTPException(422, f"Status inválido. Use: {sorted(STATUS)}")
    pr = db.get(Precedente, pid)
    if not pr:
        raise HTTPException(404, "Precedente inexistente.")
    anterior = pr.status
    pr.status, pr.status_nota, pr.status_atualizado_em = p.status, p.nota, date.today()
    db.commit()
    auditoria.registrar(db, "precedente:status", f"precedente:{pid}", {"de": anterior, "para": p.status, "nota": p.nota})
    alertas = monitor.precedente_alterado(db, pid, anterior)
    return {"id": pid, "status": pr.status, "alertas_gerados": len(alertas)}


class ConferenciaIn(BaseModel):
    resultado: str          # conferido | divergente
    responsavel: str
    nota: str | None = None
    fonte_url: str | None = None


@r.post("/precedentes/{pid}/conferencia")
def conferir(pid: str, p: ConferenciaIn, db: Session = Depends(get_session)):
    """Registro humano da conferência do precedente com a fonte oficial."""
    if p.resultado not in ("conferido", "divergente"):
        raise HTTPException(422, "Resultado: conferido ou divergente.")
    pr = db.get(Precedente, pid)
    if not pr:
        raise HTTPException(404, "Precedente inexistente.")
    from ..core.integridade import sha256_texto
    pr.verificacao_status, pr.verificacao_nota = p.resultado, p.nota
    pr.verificado = p.resultado == "conferido"
    pr.verificado_por, pr.verificado_em = p.responsavel, date.today()
    if p.fonte_url:
        pr.fonte_url = p.fonte_url
    db.commit()
    auditoria.registrar(db, "precedente:conferencia", f"precedente:{pid}", p.model_dump())
    return {"id": pid, "verificacao_status": pr.verificacao_status, "verificado": pr.verificado,
            "hash_ementa": pr.hash_ementa, "integro": pr.hash_ementa == sha256_texto(pr.ementa)}


@r.get("/precedentes/{pid}")
def obter_precedente(pid: str, db: Session = Depends(get_session)):
    p = db.get(Precedente, pid)
    if not p:
        raise HTTPException(404, "Precedente inexistente.")
    return {**{c.name: getattr(p, c.name) for c in p.__table__.columns},
            "relacoes": conhecimento.relacoes_de(db, f"precedente:{pid}")}


@r.get("/pesquisa/jurisprudencia")
def pesquisa_juris(q: str, tribunal: str | None = None, ordenar_por: str = "autoridade",
                   incluir_superados: bool = False, limite: int = 10, db: Session = Depends(get_session)):
    return conhecimento.pesquisar_jurisprudencia(db, q, tribunal, limite, ordenar_por, incluir_superados)


@r.get("/pesquisa/legislacao")
def pesquisa_lei(q: str, data_fatos: date | None = None, db: Session = Depends(get_session)):
    return conhecimento.pesquisar_legislacao(db, q, data_fatos)


@r.get("/pesquisa/{fonte_tipo}")
def pesquisa_fonte(fonte_tipo: str, q: str, db: Session = Depends(get_session)):
    if fonte_tipo not in ("doutrina", "modelos"):
        raise HTTPException(404, "Fonte inválida.")
    return conhecimento.pesquisar_fonte(db, "modelo" if fonte_tipo == "modelos" else "doutrina", q)


@r.get("/conhecimento/estatisticas")
def estatisticas(db: Session = Depends(get_session)):
    por_fonte = dict(db.execute(select(Trecho.fonte_tipo, func.count()).group_by(Trecho.fonte_tipo)).all())
    sem_vetor = db.scalar(select(func.count()).select_from(Trecho).where(Trecho.vetor.is_(None)))
    do_ejc = db.scalar(select(func.count()).select_from(Trecho).where(Trecho.origem.like("ejc:%")))
    return {"precedentes": db.scalar(select(func.count()).select_from(Precedente)),
            "normas": db.scalar(select(func.count()).select_from(Norma)),
            "trechos_por_fonte": por_fonte, "trechos_sem_vetor": sem_vetor, "trechos_importados_do_ejc": do_ejc,
            "precedentes_nao_verificados": db.scalar(select(func.count()).select_from(Precedente).where(Precedente.verificado.is_(False))),
            "documentos": db.scalar(select(func.count()).select_from(Documento))}


class ImportarEjcIn(BaseModel):
    ejc_database_url: str | None = None
    exigir_aprovado: bool = True
    categorias: list[str] | None = None
    limite: int = 100000
    reaproveitar_vetores: bool = True
    modelo_ejc: str | None = None
    dry_run: bool = False


@r.post("/conhecimento/importar-ejc")
def importar_ejc(p: ImportarEjcIn, db: Session = Depends(get_session)):
    try:
        rel = importador_ejc.importar(db, p.ejc_database_url, p.exigir_aprovado, p.categorias, p.limite,
                                      p.reaproveitar_vetores, p.modelo_ejc, p.dry_run)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(422, f"Falha na importação do EJC: {e}") from e
    auditoria.registrar(db, "conhecimento:importar_ejc", "", {k: v for k, v in rel.items() if k != "ignorados"})
    return rel
