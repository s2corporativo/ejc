"""Integrações oficiais, monitor, intimações, regras jurídicas adicionais e governança."""
from __future__ import annotations

import json
from datetime import date

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..agente import distinguishing, pipeline
from ..config import RAIZ, get_config
from ..core import julgador, licitacoes, peticionamento, valor_causa
from ..core.prazos import Calendario
from ..core.prescricao import calcular_intercorrente
from ..db import get_session
from ..integracoes import datajud, ejc, stj, tpu
from ..models import Alerta, Caso, Intimacao, Precedente
from . import deps
from ..servicos import acesso, auditoria, avaliacao, conformidade, conhecimento, documentos, intimacoes, monitor, teses

r = APIRouter(prefix="/api", tags=["inteligencia"])


def _err(e: Exception, codigo: int = 422) -> HTTPException:
    return HTTPException(codigo, str(e))


# ----------------------------------------------------------------- DataJud / TPU
@r.get("/datajud/chave")
def chave_datajud():
    try:
        k = datajud.descobrir_chave()
        return {"origem": "DATAJUD_API_KEY" if get_config().datajud_api_key else "wiki oficial do CNJ",
                "chave_mascarada": k[:6] + "..." + k[-4:], "fonte": get_config().datajud_wiki_url}
    except datajud.ErroDataJud as e:
        raise _err(e, 502) from e


@r.get("/datajud/processo")
def processo_datajud(numero: str):
    try:
        return datajud.consultar_processo(numero)
    except datajud.ErroDataJud as e:
        raise _err(e, 502) from e


class JurimetriaIn(BaseModel):
    tribunal: str
    municipio_ibge: int | None = None
    classe: int | None = None
    assunto: int | None = None
    orgao: str | None = None


@r.post("/datajud/jurimetria")
def jurimetria(p: JurimetriaIn, db: Session = Depends(get_session)):
    try:
        res = datajud.jurimetria(p.tribunal, p.municipio_ibge, p.classe, p.assunto, p.orgao)
    except datajud.ErroDataJud as e:
        raise _err(e, 502) from e
    auditoria.registrar(db, "integracao:datajud_jurimetria", p.tribunal, p.model_dump())
    return res


@r.post("/casos/{caso_id}/enriquecer-datajud")
def enriquecer(caso_id: int, db: Session = Depends(get_session)):
    deps.caso(db, caso_id, edicao=True)
    c = db.get(Caso, caso_id)
    if not c or not c.numero_processo:
        raise HTTPException(422, "Caso inexistente ou sem número de processo.")
    try:
        achados = datajud.consultar_processo(c.numero_processo)
    except datajud.ErroDataJud as e:
        raise _err(e, 502) from e
    if not achados:
        raise HTTPException(404, "Processo não encontrado no DataJud (pode estar sob sigilo ou ainda não indexado).")
    a = sorted(achados, key=lambda x: x.get("atualizado_em") or "")[-1]
    c.tribunal, c.classe_tpu, c.assuntos_tpu = a["tribunal"], a["classe"], a["assuntos"]
    c.orgao_julgador = (a.get("orgao_julgador") or {}).get("nome")
    c.metadados_datajud = a
    db.commit()
    auditoria.registrar(db, "integracao:datajud_processo", f"caso:{c.id}", {"numero": c.numero_processo})
    return a


@r.get("/tpu")
def pesquisar_tpu(tabela: str, valor: str, por: str = "nome"):
    try:
        return tpu.pesquisar(tabela, valor, por)
    except tpu.ErroTPU as e:
        raise _err(e, 502) from e


# ------------------------------------------------------------- STJ e temas
class StjIn(BaseModel):
    termos: list[str]
    orgaos: list[str] | None = None
    limite: int = 50


@r.post("/conhecimento/stj")
def importar_stj(p: StjIn, db: Session = Depends(get_session)):
    try:
        itens = stj.buscar_acordaos(p.termos, p.orgaos, p.limite)
    except stj.ErroSTJ as e:
        raise _err(e, 502) from e
    ids = [conhecimento.importar_precedente(db, it).id for it in itens]
    auditoria.registrar(db, "conhecimento:stj", "", {"importados": len(ids), "termos": p.termos})
    return {"importados": ids}


class TemaIn(BaseModel):
    tribunal: str
    tipo: str              # repetitivo | repercussao_geral | irdr_iac
    numero: str
    tese: str | None = None
    questao: str
    situacao: str          # afetado | julgado | cancelado | revisao
    suspensao_nacional: bool = False
    assuntos_tpu: list[int] = []
    fonte_url: str | None = None
    data_afetacao: date | None = None


@r.post("/conhecimento/temas")
def importar_temas(itens: list[TemaIn], db: Session = Depends(get_session)):
    mapa_status = {"afetado": "afetado", "julgado": "vigente", "cancelado": "cancelado", "revisao": "revisao"}
    ok, alertas = [], 0
    for t in itens:
        pid = f"{t.tribunal.lower()}-tema-{t.numero}".replace(" ", "")
        anterior = (db.get(Precedente, pid).status if db.get(Precedente, pid) else None)
        rotulo = {"repetitivo": "Tema Repetitivo", "repercussao_geral": "Tema de Repercussão Geral", "irdr_iac": "IRDR/IAC"}.get(t.tipo, "Tema")
        conhecimento.importar_precedente(db, {
            "id": pid, "tribunal": t.tribunal.upper(), "tipo": t.tipo, "numero": t.numero,
            "rotulo": f"{t.tribunal.upper()}, {rotulo} {t.numero}", "tese": t.tese,
            "ementa": f"Questão submetida a julgamento: {t.questao}" + (f"\nTese firmada: {t.tese}" if t.tese else ""),
            "status": mapa_status.get(t.situacao, "vigente"), "fonte_url": t.fonte_url,
            "verificado": bool(t.fonte_url), "status_nota": f"Situação informada: {t.situacao}"})
        p = db.get(Precedente, pid)
        p.suspensao_nacional, p.assuntos_tpu = t.suspensao_nacional, t.assuntos_tpu
        db.commit()
        if anterior is not None and anterior != p.status:
            alertas += len(monitor.precedente_alterado(db, pid, anterior))
        ok.append(pid)
    alertas += len(monitor.varrer_temas(db))
    return {"importados": ok, "alertas_gerados": alertas}


# --------------------------------------------------------------------- monitor
@r.post("/monitor/executar")
def executar_monitor(db: Session = Depends(get_session)):
    return monitor.executar(db)


@r.get("/alertas")
def alertas(abertos: bool = True, caso_id: int | None = None, db: Session = Depends(get_session)):
    if caso_id:
        deps.caso(db, caso_id)
    vis = acesso.casos_visiveis(db)
    return [a for a in monitor.listar(db, abertos, caso_id) if vis is None or a["caso_id"] is None or a["caso_id"] in vis]


@r.post("/alertas/{aid}/resolver")
def resolver_alerta(aid: int, db: Session = Depends(get_session)):
    a = db.get(Alerta, aid)
    if not a:
        raise HTTPException(404, "Alerta inexistente.")
    deps.caso(db, a.caso_id, edicao=True)
    a.resolvido = True
    db.commit()
    auditoria.registrar(db, "monitor:alerta_resolvido", f"alerta:{aid}")
    return {"id": aid, "resolvido": True}


# ------------------------------------------------------------------ intimações
class SyncIn(BaseModel):
    oabs: str | None = None   # "123456/MG,654321/MG"; vazio = DJEN_OABS
    inicio: date | None = None
    fim: date | None = None


@r.post("/intimacoes/sincronizar-djen")
def sincronizar(p: SyncIn, db: Session = Depends(get_session)):
    oabs = intimacoes.parse_oabs(p.oabs or get_config().djen_oabs)
    if not oabs:
        raise HTTPException(422, "Informe as OABs (ex.: 123456/MG) ou configure DJEN_OABS.")
    return intimacoes.sincronizar_djen(db, oabs, p.inicio, p.fim)


class IntimacaoIn(BaseModel):
    numero_processo: str | None = None
    tribunal: str | None = None
    tipo: str | None = None
    data_disponibilizacao: date
    texto: str
    caso_id: int | None = None


@r.post("/intimacoes")
def registrar_intimacoes(itens: list[IntimacaoIn], db: Session = Depends(get_session)):
    for i in itens:
        deps.caso(db, i.caso_id, edicao=True)
    return intimacoes.registrar(db, [i.model_dump() for i in itens], origem="manual")


@r.get("/intimacoes")
def listar_intimacoes(status: str | None = None, db: Session = Depends(get_session)):
    q = select(Intimacao).order_by(Intimacao.vencimento.is_(None), Intimacao.vencimento, Intimacao.id.desc())
    if status:
        q = q.where(Intimacao.status == status)
    vis = acesso.casos_visiveis(db)
    if vis is not None:
        q = q.where(Intimacao.caso_id.in_(vis or {-1}) | Intimacao.caso_id.is_(None))
    return [intimacoes.as_dict(i) for i in db.scalars(q.limit(500))]


class PrazoIntimIn(BaseModel):
    dias: int
    contagem: str = "uteis"
    feriados_extras: dict[date, str] = {}


@r.post("/intimacoes/{iid}/prazo")
def prazo_intimacao(iid: int, p: PrazoIntimIn, db: Session = Depends(get_session)):
    it = db.get(Intimacao, iid)
    if not it:
        raise HTTPException(404, "Intimação inexistente.")
    deps.caso(db, it.caso_id, edicao=True)
    return intimacoes.as_dict(intimacoes.calcular(db, it, p.dias, p.contagem, Calendario(p.feriados_extras)))


class MinutaIntimIn(BaseModel):
    tipo_peca: str
    pedido: str


@r.post("/intimacoes/{iid}/minuta")
def minuta_intimacao(iid: int, p: MinutaIntimIn, db: Session = Depends(get_session)):
    it = db.get(Intimacao, iid)
    if not it or not it.caso_id:
        raise HTTPException(422, "Intimação inexistente ou não vinculada a caso.")
    deps.caso(db, it.caso_id, edicao=True)
    try:
        m = pipeline.iniciar(db, it.caso_id, p.tipo_peca,
                             f"{p.pedido}\n\nIntimação de {it.data_disponibilizacao}: {it.texto[:1500]}")
    except Exception as e:  # noqa: BLE001
        raise _err(e) from e
    it.minuta_id, it.status = m.id, "em_minuta"
    db.commit()
    return {"intimacao_id": it.id, "minuta_id": m.id, "fase": m.fase}


# ------------------------------------------------------------- regras jurídicas
class IntercorrenteIn(BaseModel):
    rito: str
    data_ciencia_tentativa_infrutifera: date
    data_referencia: date
    prazo_anos: int = 0
    base_prazo: str = ""
    data_interrupcao: date | None = None


@r.post("/prescricao/intercorrente")
def intercorrente(p: IntercorrenteIn):
    try:
        return calcular_intercorrente(**p.model_dump()).as_dict()
    except ValueError as e:
        raise _err(e) from e


class ValorCausaIn(BaseModel):
    pedidos: list[dict]
    relacao: str = "cumulados"


@r.post("/valor-causa")
def valor_da_causa(p: ValorCausaIn):
    try:
        return valor_causa.calcular(p.pedidos, p.relacao)
    except (ValueError, KeyError, ArithmeticError) as e:
        raise _err(e) from e


class SurpresaIn(BaseModel):
    texto_decisao: str
    caso_id: int | None = None
    texto_autos: str | None = None


@r.post("/vedacao-surpresa")
def surpresa(p: SurpresaIn, db: Session = Depends(get_session)):
    if p.caso_id:
        deps.caso(db, p.caso_id)
    autos = p.texto_autos or (documentos.texto_dos_autos(db, p.caso_id, limite_chars=400000) if p.caso_id else "")
    if not autos:
        raise HTTPException(422, "Informe caso_id com autos carregados ou texto_autos.")
    return julgador.vedacao_surpresa(p.texto_decisao, autos)


class DistIn(BaseModel):
    precedente_id: str
    caso_id: int


@r.post("/distinguishing")
def analisar_distinguishing(p: DistIn, db: Session = Depends(get_session)):
    deps.caso(db, p.caso_id)
    try:
        return distinguishing.analisar(db, p.precedente_id, p.caso_id)
    except Exception as e:  # noqa: BLE001
        raise _err(e) from e


@r.get("/teses-massa")
def teses_massa(parte: str | None = None, assunto: int | None = None, db: Session = Depends(get_session)):
    return teses.mapa(db, parte, assunto, acesso.casos_visiveis(db))


class LicPrazoIn(BaseModel):
    data: date
    feriados_extras: dict[date, str] = {}
    contrarrazoes: bool = False


@r.post("/licitacoes/impugnacao")
def lic_impugnacao(p: LicPrazoIn):
    return licitacoes.prazo_impugnacao(p.data, Calendario(p.feriados_extras))


@r.post("/licitacoes/recurso")
def lic_recurso(p: LicPrazoIn):
    return licitacoes.prazo_recurso(p.data, Calendario(p.feriados_extras), p.contrarrazoes)


class HabilitacaoIn(BaseModel):
    texto_edital: str
    documentos: list[dict] = []
    data_sessao: date


@r.post("/licitacoes/habilitacao")
def lic_habilitacao(p: HabilitacaoIn):
    try:
        return licitacoes.matriz_habilitacao(p.texto_edital, p.documentos, p.data_sessao)
    except ValueError as e:
        raise _err(e) from e


@r.post("/trabalhista/liquidacao")
def liquidacao(payload: dict, db: Session = Depends(get_session)):
    try:
        res = ejc.liquidacao_trabalhista(payload)
    except ejc.ErroEJC as e:
        raise _err(e, 502) from e
    auditoria.registrar(db, "integracao:ejc_liquidacao", "", {"verbas": len(payload.get("verbas", []))})
    return res


# ------------------------------------------------------------------- governança
@r.get("/conformidade/registro-operacoes")
def registro(db: Session = Depends(get_session)):
    return conformidade.registro_operacoes(db)


@r.get("/conformidade/ripd", response_class=PlainTextResponse)
def gerar_ripd(db: Session = Depends(get_session)):
    return conformidade.ripd(db)


@r.post("/avaliacao")
def avaliar(casos: list[dict] | None = None, db: Session = Depends(get_session)):
    if not casos:
        casos = json.loads((RAIZ / "data" / "avaliacao" / "casos.json").read_text(encoding="utf-8"))
    res = avaliacao.executar(db, casos)
    auditoria.registrar(db, "avaliacao", "", {"acuracia_geral": res["acuracia_geral"], "total": res["total"]})
    return res


@r.post("/peticionamento/checar")
async def checar_peticionamento(arquivos: list[UploadFile] = File(...)):
    lim = get_config().peticionamento_limite_mb
    saida = []
    for a in arquivos:
        saida.append(peticionamento.checar(await a.read(), a.filename or "arquivo.pdf", lim))
    return {"arquivos": saida, "apto": all(x["apto"] for x in saida)}
