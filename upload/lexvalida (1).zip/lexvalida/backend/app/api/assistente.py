"""Assistente único: mensagens, ações por botão, envio de documento e resumo do dia."""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..assistente import servico
from ..config import get_config
from ..core.ingestao import processar_pdf, processar_texto
from ..core.integridade import sha256_bytes
from ..db import get_session
from ..models import MensagemAssistente
from ..servicos import acesso, documentos
from . import deps

r = APIRouter(prefix="/api/assistente", tags=["assistente"])
LIMITE = 60 * 1024 * 1024


def _err(e: Exception) -> HTTPException:
    return HTTPException(404 if "inexistente" in str(e) else 403, str(e))


class MensagemIn(BaseModel):
    texto: str
    conversa_id: int | None = None
    caso_id: int | None = None


@r.post("/mensagens")
def mensagem(p: MensagemIn, db: Session = Depends(get_session)):
    if not p.texto.strip():
        raise HTTPException(422, "Escreva o que precisa.")
    try:
        return servico.processar(db, p.conversa_id, p.texto[:60000], p.caso_id)
    except acesso.SemPermissao as e:
        raise _err(e) from e


class AcaoIn(BaseModel):
    acao: str
    params: dict = {}
    conversa_id: int | None = None


@r.post("/acoes")
def acao(p: AcaoIn, db: Session = Depends(get_session)):
    try:
        return servico.acao(db, p.conversa_id, p.acao, p.params)
    except acesso.SemPermissao as e:
        raise _err(e) from e


@r.post("/documento")
async def documento(arquivo: UploadFile = File(...), conversa_id: int | None = Form(None), caso_id: int | None = Form(None),
                    db: Session = Depends(get_session)):
    dados = await arquivo.read()
    if len(dados) > LIMITE:
        raise HTTPException(413, "Arquivo acima de 60 MB.")
    nome = arquivo.filename or "documento"
    try:
        c = servico.conversa(db, conversa_id, caso_id)
    except acesso.SemPermissao as e:
        raise _err(e) from e
    cid = caso_id or c.caso_id
    aviso = ""
    if cid:
        deps.caso(db, cid, edicao=True)
        try:
            doc, proc = documentos.ingerir_documento(db, cid, nome, dados, usuario=acesso.atual().nome)
            aviso = f"Anexado ao caso #{cid} como documento {doc.id}."
        except documentos.DocumentoDuplicado as e:
            doc = e.existente
            proc = processar_pdf(dados, nome) if nome.lower().endswith(".pdf") else processar_texto(dados.decode("utf-8", "replace"), nome)
            aviso = f"Este arquivo já estava no caso #{cid} (documento {doc.id})."
    else:
        proc = processar_pdf(dados, nome) if nome.lower().endswith(".pdf") else processar_texto(dados.decode("utf-8", "replace"), nome)
    texto = "\n".join(proc.texto_por_pagina)
    res = servico.analisar_texto(db, c, texto, cid, nome)
    if proc.risco_alto:
        res["cartoes"].insert(0, {"tipo": "resultado", "titulo": "Segurança", "destaque": "Possível instrução oculta à IA",
                                  "alertas": ["O documento contém texto oculto ou instrução dirigida a IA. Ele fica bloqueado para a IA "
                                              "até sua decisão na aba Casos e autos."]})
    if proc.paginas_sem_texto:
        res["cartoes"].append({"tipo": "resultado", "titulo": "Leitura", "alertas": [f"Páginas sem texto (precisam de OCR): {proc.paginas_sem_texto[:20]}"]})
    if not cid and servico._pode_gravar():
        sha = sha256_bytes(dados)
        tmp = Path(get_config().arquivos_dir) / "tmp"
        tmp.mkdir(parents=True, exist_ok=True)
        (tmp / f"{sha}.bin").write_bytes(dados)
        from ..core.entidades import cnj
        n = (cnj(texto) or [None])[0]
        res["acoes"].insert(0, {"rotulo": "Criar caso com este documento", "acao": "criar_caso_documento", "estilo": "principal",
                                "params": {"sha": sha, "nome": nome, "numero": n, "titulo": f"Processo {n}" if n else f"Caso de {nome}"}})
    res["texto"] = (aviso + " " + res["texto"]).strip()
    res["conversa_id"] = c.id
    servico._registrar(db, c, "usuario", f"[documento] {nome}")
    servico._registrar(db, c, "assistente", res["texto"], res)
    return res


@r.get("/hoje")
def hoje(db: Session = Depends(get_session)):
    return servico.ex_briefing(db, {})


@r.get("/conversas/{cid}")
def historico(cid: int, db: Session = Depends(get_session)):
    try:
        c = servico.conversa(db, cid)
    except acesso.SemPermissao as e:
        raise _err(e) from e
    msgs = db.scalars(select(MensagemAssistente).where(MensagemAssistente.conversa_id == c.id).order_by(MensagemAssistente.id)).all()
    return {"id": c.id, "caso_id": c.caso_id, "mensagens": [{"papel": m.papel, "texto": m.texto, "dados": m.dados,
                                                             "criado_em": m.criado_em.isoformat()} for m in msgs]}
