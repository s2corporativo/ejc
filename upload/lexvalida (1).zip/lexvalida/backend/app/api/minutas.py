"""Minutas (agente com supervisão humana), lotes, habilidades, estilo e auditoria."""
from __future__ import annotations

import io
from datetime import date

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from fastapi.responses import PlainTextResponse, StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..agente import lote as lote_srv
from ..agente import pipeline
from ..db import get_session, nova_sessao
from ..llm import prompts
from ..llm.provedores import ErroProvedor, construir, extrair_json
from ..models import Auditoria, Desfecho, Minuta, Skill
from ..servicos import acesso, auditoria
from ..servicos import skills as skills_srv
from . import deps

r = APIRouter(prefix="/api", tags=["minutas"])


def _erro(e: Exception) -> HTTPException:
    if isinstance(e, ErroProvedor):
        return HTTPException(503, str(e))
    return HTTPException(422, str(e))


def _minuta(m: Minuta, completo: bool = True) -> dict:
    d = {"id": m.id, "caso_id": m.caso_id, "tipo_peca": m.tipo_peca, "pedido": m.pedido, "fase": m.fase,
         "status": m.status, "aprovada_por": m.aprovada_por, "criado_em": m.criado_em.isoformat(),
         "bloqueado": (m.verificacao or {}).get("bloqueado")}
    if completo:
        est = dict(m.estado or {})
        est.pop("cofre", None)  # o cofre de anonimização não trafega pela API
        d.update({"estado": est, "texto": m.texto, "texto_resolvido": m.texto_resolvido, "verificacao": m.verificacao})
    return d


def _m(db: Session, mid: int, edicao: bool = False) -> Minuta:
    m = db.get(Minuta, mid)
    if not m:
        raise HTTPException(404, "Minuta inexistente.")
    deps.caso(db, m.caso_id, edicao)
    return m


class IniciarIn(BaseModel):
    caso_id: int | None = None
    tipo_peca: str
    pedido: str
    skills_fixadas: list[str] = []
    anonimizar_autos: bool = False
    gerar_peca_contraria: bool = True
    perfil_estilo_id: int | None = None


@r.post("/minutas")
def iniciar(p: IniciarIn, db: Session = Depends(get_session)):
    deps.caso(db, p.caso_id, edicao=True)
    try:
        return _minuta(pipeline.iniciar(db, p.caso_id, p.tipo_peca, p.pedido, p.skills_fixadas,
                                        p.anonimizar_autos, p.gerar_peca_contraria, p.perfil_estilo_id))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.get("/minutas")
def listar(db: Session = Depends(get_session)):
    vis = acesso.casos_visiveis(db)
    q = select(Minuta).order_by(Minuta.id.desc()).limit(200)
    if vis is not None:
        q = q.where(Minuta.caso_id.in_(vis or {-1}) | Minuta.caso_id.is_(None))
    return [_minuta(m, False) for m in db.scalars(q)]


@r.get("/minutas/{mid}")
def obter(mid: int, db: Session = Depends(get_session)):
    return _minuta(_m(db, mid))


class RespostasIn(BaseModel):
    respostas: dict


@r.post("/minutas/{mid}/respostas")
def responder(mid: int, p: RespostasIn, db: Session = Depends(get_session)):
    _m(db, mid, edicao=True)
    try:
        return _minuta(pipeline.responder(db, mid, p.respostas))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


class RoteiroIn(BaseModel):
    secoes: list[dict] | None = None


def _executar_roteiro(mid: int, secoes, ctx=None):
    if ctx is not None:
        acesso.definir(ctx)   # tarefa em segundo plano mantém a autoria
    db = nova_sessao()
    try:
        pipeline.aprovar_roteiro(db, mid, secoes)
    except Exception:  # noqa: BLE001  (erro e fase de parada ficam gravados; use /retomar)
        pass
    finally:
        db.close()


@r.post("/minutas/{mid}/roteiro/aprovar")
def aprovar_roteiro(mid: int, p: RoteiroIn, bg: BackgroundTasks, assincrono: bool = False,
                    db: Session = Depends(get_session)):
    _m(db, mid, edicao=True)
    if assincrono:
        m = db.get(Minuta, mid)
        if not m or m.fase != "aprovar_roteiro":
            raise HTTPException(422, "Minuta fora da fase de aprovação do roteiro.")
        bg.add_task(_executar_roteiro, mid, p.secoes, acesso.atual())
        return {"id": mid, "fase": "pesquisa", "assincrono": True}
    try:
        return _minuta(pipeline.aprovar_roteiro(db, mid, p.secoes))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.post("/minutas/{mid}/retomar")
def retomar(mid: int, db: Session = Depends(get_session)):
    """Continua de onde a geração parou, sem refazer seções e pesquisas já concluídas."""
    _m(db, mid, edicao=True)
    try:
        return _minuta(pipeline.retomar(db, mid))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


class TextoIn(BaseModel):
    texto: str
    nota: str = "Edição do advogado"


@r.put("/minutas/{mid}/texto")
def editar(mid: int, p: TextoIn, db: Session = Depends(get_session)):
    _m(db, mid, edicao=True)
    try:
        return _minuta(pipeline.editar(db, mid, p.texto, p.nota))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.post("/minutas/{mid}/verificar")
def verificar(mid: int, db: Session = Depends(get_session)):
    _m(db, mid, edicao=True)
    try:
        return _minuta(pipeline.verificar(db, mid))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


class AprovarIn(BaseModel):
    responsavel: str
    ciente_alertas: bool = False


@r.post("/minutas/{mid}/aprovar")
def aprovar(mid: int, p: AprovarIn, db: Session = Depends(get_session)):
    _m(db, mid, edicao=True)
    if not acesso.atual().pode_aprovar:
        raise HTTPException(403, "Somente advogado ou administrador aprova minutas (EOAB, art. 1º, I, e art. 3º, § 2º).")
    try:
        return _minuta(pipeline.aprovar(db, mid, p.responsavel, p.ciente_alertas))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.get("/minutas/{mid}/versoes")
def versoes(mid: int, db: Session = Depends(get_session)):
    _m(db, mid)
    return pipeline.versoes(db, mid)


class DesfechoIn(BaseModel):
    resultado: str
    teses_acolhidas: list[str] = []
    teses_rejeitadas: list[str] = []
    precedentes_decisivos: list[str] = []
    observacoes: str = ""
    data: date | None = None


@r.post("/minutas/{mid}/desfecho")
def desfecho(mid: int, p: DesfechoIn, db: Session = Depends(get_session)):
    _m(db, mid, edicao=True)
    d = Desfecho(minuta_id=mid, **p.model_dump())
    db.add(d)
    db.commit()
    return {"id": d.id}


@r.get("/desfechos/estatisticas")
def estat_desfechos(db: Session = Depends(get_session)):
    cont: dict[str, dict] = {}
    for d in db.scalars(select(Desfecho)):
        for p in d.precedentes_decisivos or []:
            c = cont.setdefault(p, {"acolhido": 0, "total": 0})
            c["total"] += 1
            c["acolhido"] += d.resultado in ("procedente", "parcial", "acordo")
    return {"precedentes": cont, "nota": "Estatística descritiva da base própria; não é previsão de resultado."}


@r.get("/minutas/{mid}/exportar")
def exportar(mid: int, formato: str = "docx", visual_law: bool = False, db: Session = Depends(get_session)):
    """docx | txt | html. Marcadores [[print:ID]] viram a imagem recortada com legenda e origem;
    visual_law=true acrescenta quadro-resumo e linha do tempo (dados do caso e fatos datados dos autos)."""
    import base64
    import html as _html
    import re as _re

    from ..models import ProvaImagem
    from ..servicos import provas as provas_srv
    m = _m(db, mid)
    texto = m.texto_resolvido or m.texto
    rotulo = "MINUTA APROVADA" if m.status == "APROVADA" else "RASCUNHO, SUJEITO A REVISÃO DO ADVOGADO"
    rx_print = _re.compile(r"\[\[print:(\d+)\]\]")

    def prova(pid: str):
        p = db.get(ProvaImagem, int(pid))
        return p if p and p.caso_id == m.caso_id else None

    vis = None
    if visual_law and m.caso_id:
        from .evidencias import montar_visual
        vis = montar_visual(db, m.caso_id)
    if formato == "txt":
        def _t(x):
            p = prova(x.group(1))
            return f"[Imagem: {p.legenda}. {provas_srv.origem(db, p)}]" if p else "[IMAGEM INVÁLIDA]"
        return PlainTextResponse(f"{rotulo}\n\n{rx_print.sub(_t, texto)}")
    if formato == "html":
        from fastapi.responses import HTMLResponse

        from ..core.visual_law import html_visual
        def _h(x):
            p = prova(x.group(1))
            if not p:
                return "<p><strong>[IMAGEM INVÁLIDA]</strong></p>"
            return (f'<figure><img alt="{_html.escape(p.legenda)}" style="max-width:100%" src="data:image/png;base64,'
                    f'{base64.b64encode(p.png).decode()}"><figcaption>{_html.escape(p.legenda)}<br><small>'
                    f'{_html.escape(provas_srv.origem(db, p))}</small></figcaption></figure>')
        corpo = "".join(f"<p>{x}</p>" if not x.startswith("<figure") else x for x in
                        [rx_print.sub(_h, _html.escape(par)) for par in texto.split("\n") if par.strip()])
        extra = ""
        if vis:
            v = html_visual(vis["titulo"], vis["quadro_resumo"], vis["linha_do_tempo"])
            extra = v[v.index("<body>") + 6: v.index("</body>")]
        return HTMLResponse(f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Minuta {mid}</title>'
                            f'<style>body{{font:16px/1.6 "Times New Roman",serif;max-width:800px;margin:24px auto;padding:0 16px}}'
                            f'figure{{margin:16px 0}}figcaption{{font-size:13px;color:#444}}</style></head><body>'
                            f'<p><strong>{rotulo}</strong></p>{extra}{corpo}</body></html>')
    from docx import Document
    from docx.shared import Cm, Pt
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name, st.font.size = "Times New Roman", Pt(12)
    doc.add_paragraph(rotulo).runs[0].bold = True
    if vis:
        doc.add_heading("Quadro-resumo", level=2)
        if vis["quadro_resumo"]:
            t = doc.add_table(rows=0, cols=2)
            t.style = "Table Grid"
            for k, v in vis["quadro_resumo"]:
                c = t.add_row().cells
                c[0].text, c[1].text = k, v
        doc.add_heading("Linha do tempo", level=2)
        if vis["linha_do_tempo"]:
            t = doc.add_table(rows=1, cols=3)
            t.style = "Table Grid"
            t.rows[0].cells[0].text, t.rows[0].cells[1].text, t.rows[0].cells[2].text = "Data", "Fato", "Referência"
            from datetime import date as _d
            for e in vis["linha_do_tempo"]:
                c = t.add_row().cells
                c[0].text = _d.fromisoformat(e["data"]).strftime("%d/%m/%Y")
                c[1].text, c[2].text = e["fato"], e.get("referencia") or "informado pelo advogado"
        else:
            doc.add_paragraph("Nenhum fato datado identificado nos autos.")
    for par in texto.split("\n"):
        pr = rx_print.fullmatch(par.strip())
        if pr:
            p = prova(pr.group(1))
            if not p:
                doc.add_paragraph("[IMAGEM INVÁLIDA]")
                continue
            doc.add_picture(io.BytesIO(p.png), width=Cm(15))
            leg = doc.add_paragraph(p.legenda)
            leg.runs[0].italic = True
            doc.add_paragraph(provas_srv.origem(db, p)).runs[0].font.size = Pt(9)
        elif par.strip() and par.strip().isupper() and len(par.strip()) < 120:
            doc.add_heading(par.strip(), level=2)
        else:
            doc.add_paragraph(rx_print.sub(lambda x: f"[imagem {x.group(1)}]", par))
    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                             headers={"Content-Disposition": f'attachment; filename="minuta-{mid}.docx"'})


# ------------------------------------------------------------------------- lotes
class LoteIn(BaseModel):
    caso_ids: list[int]
    instrucao: str
    tipo_peca: str
    modo: str = "etapas"
    caso_modelo_id: int | None = None
    roteiro: list[dict] | None = None


@r.post("/lotes")
def criar_lote(p: LoteIn, db: Session = Depends(get_session)):
    for cid in p.caso_ids:
        deps.caso(db, cid, edicao=True)
    try:
        l = lote_srv.criar(db, p.caso_ids, p.instrucao, p.tipo_peca, p.modo, p.caso_modelo_id, p.roteiro)
        return lote_srv.status(db, l.id)
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.post("/lotes/{lid}/aprovar-modelo")
def aprovar_modelo(lid: int, db: Session = Depends(get_session)):
    if not acesso.atual().pode_aprovar:
        raise HTTPException(403, "Somente advogado ou administrador aprova o molde do lote.")
    try:
        lote_srv.aprovar_modelo(db, lid, acesso.atual().nome)
        return lote_srv.status(db, lid)
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


def _gerar_lote(lid: int, apenas_falhas: bool, ctx=None, forcar: list[int] | None = None):
    if ctx is not None:
        acesso.definir(ctx)
    db = nova_sessao()
    try:
        lote_srv.gerar_demais(db, lid, apenas_falhas, forcar)
    finally:
        db.close()


@r.post("/lotes/{lid}/gerar")
def gerar_lote(lid: int, bg: BackgroundTasks, apenas_falhas: bool = False, assincrono: bool = True,
               forcar: str = "", db: Session = Depends(get_session)):
    """forcar: IDs de casos (separados por vírgula) marcados como incompatíveis que o advogado
    decidiu, mesmo assim, gerar pelo molde. A decisão fica na auditoria."""
    ids_forcar = [int(x) for x in forcar.split(",") if x.strip().isdigit()]
    if ids_forcar:
        auditoria.registrar(db, "lote:forcar_incompativeis", f"lote:{lid}", {"casos": ids_forcar})
    if assincrono:
        bg.add_task(_gerar_lote, lid, apenas_falhas, acesso.atual(), ids_forcar)
        return {"id": lid, "fase": "gerando", "assincrono": True}
    try:
        lote_srv.gerar_demais(db, lid, apenas_falhas, ids_forcar)
        return lote_srv.status(db, lid)
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.get("/lotes/{lid}")
def status_lote(lid: int, db: Session = Depends(get_session)):
    try:
        return lote_srv.status(db, lid)
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


# --------------------------------------------------------------------- habilidades
def _skill(s: Skill, completo: bool = False) -> dict:
    d = {"id": s.id, "slug": s.slug, "titulo": s.titulo, "tipo": s.tipo, "area": s.area, "descricao": s.descricao,
         "gatilhos": s.gatilhos, "oficial": s.oficial, "versao": s.versao, "dono": s.dono, "ativa": s.ativa,
         "origem_id": s.origem_id, "origem_versao": s.origem_versao}
    if completo:
        d.update({"conteudo": s.conteudo, "historico": s.historico})
    return d


@r.post("/skills/sincronizar")
def sincronizar(db: Session = Depends(get_session)):
    return skills_srv.sincronizar_oficiais(db)


@r.get("/skills")
def listar_skills(db: Session = Depends(get_session)):
    return [_skill(s) for s in db.scalars(select(Skill).order_by(Skill.tipo, Skill.slug))]


@r.get("/skills/{sid}")
def obter_skill(sid: int, db: Session = Depends(get_session)):
    s = db.get(Skill, sid)
    if not s:
        raise HTTPException(404, "Habilidade inexistente.")
    return _skill(s, True)


class ForkIn(BaseModel):
    conteudo: str
    nota: str = ""
    dono: str = "local"


@r.post("/skills/{slug}/fork")
def fork(slug: str, p: ForkIn, db: Session = Depends(get_session)):
    return _skill(skills_srv.criar_fork(db, slug, p.conteudo, p.dono, p.nota), True)


class SkillMdIn(BaseModel):
    skill_md: str
    dono: str = "local"


@r.post("/skills")
def criar_skill(p: SkillMdIn, db: Session = Depends(get_session)):
    try:
        return _skill(skills_srv.criar_propria(db, p.skill_md, p.dono), True)
    except ValueError as e:
        raise HTTPException(422, str(e)) from e


@r.get("/skills-atualizacoes")
def atualizacoes(dono: str = "local", db: Session = Depends(get_session)):
    return skills_srv.atualizacoes_pendentes(db, dono)


@r.get("/skills/fork/{fid}/mescla")
def propor_mescla(fid: int, db: Session = Depends(get_session)):
    try:
        return skills_srv.propor_mescla(db, fid)
    except ValueError as e:
        raise HTTPException(422, str(e)) from e


class MesclaIn(BaseModel):
    texto: str


@r.put("/skills/fork/{fid}/mescla")
def aplicar_mescla(fid: int, p: MesclaIn, db: Session = Depends(get_session)):
    return _skill(skills_srv.aplicar_mescla(db, fid, p.texto), True)


class SelecaoIn(BaseModel):
    contexto: str
    tipo_peca: str = ""
    fixadas: list[str] = []


@r.post("/skills/selecionar")
def selecionar(p: SelecaoIn, db: Session = Depends(get_session)):
    sel, _ = skills_srv.selecionar_para(db, p.contexto, p.tipo_peca, p.fixadas)
    return sel


# ------------------------------------------------------------------- estilo e auditoria
class EstiloIn(BaseModel):
    modelos: list[str]


@r.post("/estilo/perfil")
def perfil_estilo(p: EstiloIn):
    try:
        prov = construir()
        resp = prov.gerar("estilo", prompts.SISTEMA_BASE + "\n\n" + prompts.ESTILO,
                          "\n\n=====\n\n".join(f"<modelo>\n{m[:15000]}\n</modelo>" for m in p.modelos[:8]),
                          {"modelos": p.modelos})
        return extrair_json(resp.texto)
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.get("/auditoria")
def listar_auditoria(limite: int = 200, db: Session = Depends(get_session)):
    return [{"id": a.id, "momento": a.momento.isoformat(), "usuario": a.usuario, "acao": a.acao, "alvo": a.alvo,
             "provedor": a.provedor, "detalhe": a.detalhe}
            for a in db.scalars(select(Auditoria).order_by(Auditoria.id.desc()).limit(min(limite, 1000)))]
