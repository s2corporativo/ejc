"""STJ: Portal de Dados Abertos (CKAN), espelhos de acórdãos por órgão julgador.

Contrato (o mesmo verificado em produção pelo EJC, app/services/ingestors/stj.py):
- GET {ckan}/package_show?id=espelhos-de-acordaos-<orgao> -> result.resources[] com JSON mensais;
- cada JSON é uma lista de acórdãos com ementa, teseJuridica, numeroRegistro, numeroProcesso,
  siglaClasse, ministroRelator, nomeOrgaoJulgador, dataDecisao, dataPublicacao.
Neste ambiente o host não é alcançável; testes com respostas gravadas.
"""
from __future__ import annotations

from datetime import datetime

import httpx

from ..config import get_config
from ..core.texto import normalizar

ORGAOS = ["corte-especial", "primeira-secao", "segunda-secao", "terceira-secao",
          "primeira-turma", "segunda-turma", "terceira-turma", "quarta-turma", "quinta-turma", "sexta-turma"]


class ErroSTJ(RuntimeError):
    pass


def _data(v) -> str | None:
    if not v:
        return None
    s = str(v)
    for fmt in ("%Y%m%d", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(s[:10] if "-" in s or "/" in s else s[:8], fmt).date().isoformat()
        except ValueError:
            continue
    return None


def para_precedente(a: dict, orgao: str) -> dict | None:
    ementa = (a.get("ementa") or "").strip()
    if not ementa:
        return None
    reg = str(a.get("numeroRegistro") or a.get("numeroProcesso") or "").strip()
    classe = (a.get("siglaClasse") or "").strip()
    num = str(a.get("numeroProcesso") or reg)
    return {
        "id": f"stj-{classe.lower()}-{reg}".replace(" ", "").replace("/", "-")[:120],
        "tribunal": "STJ", "tipo": "acordao", "numero": f"{classe} {num}".strip(),
        "rotulo": f"STJ, {classe} {num}, {a.get('nomeOrgaoJulgador') or orgao}".strip(", "),
        "ementa": ementa, "tese": (a.get("teseJuridica") or None),
        "orgao_julgador": a.get("nomeOrgaoJulgador") or orgao, "relator": a.get("ministroRelator"),
        "data_julgamento": _data(a.get("dataDecisao")), "data_publicacao": _data(a.get("dataPublicacao")),
        "status": "vigente", "fonte_url": "https://dadosabertos.web.stj.jus.br/",
        "verificado": True, "verificado_por": "Dados abertos STJ (fonte oficial)",
        "status_nota": "Importado do portal de dados abertos do STJ.",
    }


def buscar_acordaos(termos: list[str], orgaos: list[str] | None = None, limite: int = 50,
                    cliente: httpx.Client | None = None) -> list[dict]:
    """Baixa o lote mensal mais recente de cada órgão e filtra pelos termos (todos presentes)."""
    cfg = get_config()
    c = cliente or httpx.Client(timeout=cfg.http_timeout, follow_redirects=True)
    termos_n = [normalizar(t) for t in termos if t.strip()]
    saida = []
    for orgao in orgaos or ORGAOS:
        try:
            r = c.get(f"{cfg.stj_ckan_url.rstrip('/')}/package_show", params={"id": f"espelhos-de-acordaos-{orgao}"})
            r.raise_for_status()
            recursos = [x for x in (r.json().get("result") or {}).get("resources", []) if (x.get("format") or "").upper() == "JSON"]
            if not recursos:
                continue
            recurso = sorted(recursos, key=lambda x: x.get("name") or x.get("url") or "")[-1]
            lote = c.get(recurso["url"])
            lote.raise_for_status()
        except httpx.HTTPError as e:
            raise ErroSTJ(f"Portal de dados abertos do STJ indisponível: {e}") from e
        for a in lote.json():
            alvo = normalizar((a.get("ementa") or "") + " " + (a.get("teseJuridica") or ""))
            if all(t in alvo for t in termos_n):
                p = para_precedente(a, orgao)
                if p:
                    saida.append(p)
                    if len(saida) >= limite:
                        return saida
    return saida
