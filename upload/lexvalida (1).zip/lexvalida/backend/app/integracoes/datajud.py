"""DataJud (CNJ): API pública de metadados processuais.

Contrato verificado ao vivo em 04/10/2026:
- POST {base}/api_publica_<tribunal>/_search (consulta no formato Elasticsearch);
- header "Authorization: APIKey <chave pública>";
- a chave é PÚBLICA, divulgada e rotacionada pelo CNJ em
  https://datajud-wiki.cnj.jus.br/api-publica/acesso/ ("a chave poderá ser alterada pelo CNJ a
  qualquer momento"). Por isso o sistema a descobre na própria wiki oficial, guarda em cache e a
  renova automaticamente ao receber 401. DATAJUD_API_KEY sobrepõe a descoberta.

Uso de dados: apenas metadados públicos (classe, assuntos, órgão, movimentos). O DataJud não
traz nomes de partes. A jurimetria é DESCRITIVA e por ÓRGÃO JULGADOR; não há perfil de magistrado.
"""
from __future__ import annotations

import html
import re
import threading
import time

import httpx

from ..config import get_config

# Códigos TPU de movimento conferidos no SGT/CNJ (filhos de 385 "Com Resolução do Mérito")
MOV_PROCEDENCIA, MOV_IMPROCEDENCIA, MOV_PARCIAL, MOV_TRANSACAO = 219, 220, 221, 466

UF_TR = {"01": "ac", "02": "al", "03": "ap", "04": "am", "05": "ba", "06": "ce", "07": "dft", "08": "es",
         "09": "go", "10": "ma", "11": "mt", "12": "ms", "13": "mg", "14": "pa", "15": "pb", "16": "pr",
         "17": "pe", "18": "pi", "19": "rj", "20": "rn", "21": "rs", "22": "ro", "23": "rr", "24": "sc",
         "25": "se", "26": "sp", "27": "to"}

_RX_CNJ = re.compile(r"^(\d{7})-?(\d{2})\.?(\d{4})\.?(\d)\.?(\d{2})\.?(\d{4})$")
_RX_CHAVE = re.compile(r"APIKey\s+([A-Za-z0-9+/=_\-]{20,})")

_lock = threading.Lock()
_cache = {"chave": None, "obtida_em": 0.0}
TTL_CHAVE = 24 * 3600


class ErroDataJud(RuntimeError):
    pass


def descobrir_chave(forcar: bool = False, cliente: httpx.Client | None = None) -> str:
    cfg = get_config()
    if cfg.datajud_api_key:
        return cfg.datajud_api_key
    with _lock:
        if not forcar and _cache["chave"] and time.time() - _cache["obtida_em"] < TTL_CHAVE:
            return _cache["chave"]
        c = cliente or httpx.Client(timeout=cfg.http_timeout, follow_redirects=True,
                                    headers={"User-Agent": "Mozilla/5.0 (LexValida)"})
        try:
            r = c.get(cfg.datajud_wiki_url)
            r.raise_for_status()
        except httpx.HTTPError as e:
            raise ErroDataJud(f"Não foi possível obter a chave pública na wiki do CNJ: {e}") from e
        m = _RX_CHAVE.search(html.unescape(re.sub(r"<[^>]+>", " ", r.text)))
        if not m:
            raise ErroDataJud("Chave pública não localizada na wiki do CNJ; defina DATAJUD_API_KEY.")
        _cache.update(chave=m.group(1), obtida_em=time.time())
        return m.group(1)


def normalizar_numero(numero: str) -> tuple[str, str]:
    """Devolve (numero_20_digitos, alias_do_endpoint) a partir do número CNJ (Res. CNJ 65/2008)."""
    n = re.sub(r"\s", "", numero or "")
    m = _RX_CNJ.match(n)
    if not m:
        raise ErroDataJud("Número CNJ inválido. Formato: NNNNNNN-DD.AAAA.J.TR.OOOO")
    digitos = "".join(m.groups())
    j, tr = m.group(4), m.group(5)
    alias = {"8": f"tj{UF_TR.get(tr, '')}", "5": f"trt{int(tr)}", "4": f"trf{int(tr)}", "3": "stj",
             "6": f"tre-{UF_TR.get(tr, '')}", "9": f"tjm{UF_TR.get(tr, '')}"}.get(j)
    if j == "5" and tr == "00":
        alias = "tst"
    if not alias or alias.endswith("tj") or alias.endswith("-"):
        raise ErroDataJud(f"Segmento de justiça {j}.{tr} não mapeado para o DataJud.")
    return digitos, alias


def _post(alias: str, corpo: dict, cliente: httpx.Client | None = None) -> dict:
    cfg = get_config()
    c = cliente or httpx.Client(timeout=cfg.http_timeout)
    url = f"{cfg.datajud_base_url.rstrip('/')}/api_publica_{alias}/_search"
    for tentativa in (0, 1):
        chave = descobrir_chave(forcar=tentativa == 1, cliente=cliente)
        r = c.post(url, json=corpo, headers={"Authorization": f"APIKey {chave}", "Content-Type": "application/json"})
        if r.status_code == 401 and tentativa == 0 and not cfg.datajud_api_key:
            continue  # chave rotacionada: rebusca na wiki e repete uma vez
        if r.status_code >= 400:
            raise ErroDataJud(f"DataJud {r.status_code}: {r.text[:300]}")
        return r.json()
    raise ErroDataJud("DataJud recusou a chave pública mesmo após renovação.")


def _resumo(src: dict, max_mov: int = 15) -> dict:
    movs = sorted(src.get("movimentos") or [], key=lambda m: m.get("dataHora") or "")
    da = src.get("dataAjuizamento") or ""
    return {
        "numero": src.get("numeroProcesso"), "tribunal": src.get("tribunal"), "grau": src.get("grau"),
        "data_ajuizamento": f"{da[:4]}-{da[4:6]}-{da[6:8]}" if len(da) >= 8 else None,
        "classe": src.get("classe"), "assuntos": src.get("assuntos") or [],
        "orgao_julgador": src.get("orgaoJulgador"), "sistema": (src.get("sistema") or {}).get("nome"),
        "nivel_sigilo": src.get("nivelSigilo"), "atualizado_em": src.get("dataHoraUltimaAtualizacao"),
        "ultimos_movimentos": [{"codigo": m.get("codigo"), "nome": m.get("nome"), "data": m.get("dataHora")}
                               for m in movs[-max_mov:]],
        "desfecho_registrado": next((m.get("nome") for m in reversed(movs)
                                     if m.get("codigo") in (MOV_PROCEDENCIA, MOV_IMPROCEDENCIA, MOV_PARCIAL, MOV_TRANSACAO)), None),
    }


def consultar_processo(numero: str, cliente: httpx.Client | None = None) -> list[dict]:
    digitos, alias = normalizar_numero(numero)
    d = _post(alias, {"size": 10, "query": {"match": {"numeroProcesso": digitos}}}, cliente)
    return [_resumo(h["_source"]) for h in d.get("hits", {}).get("hits", [])]


def jurimetria(tribunal: str, municipio_ibge: int | None = None, classe: int | None = None,
               assunto: int | None = None, orgao: str | None = None, cliente: httpx.Client | None = None) -> dict:
    """Estatística descritiva: volume por órgão julgador e presença de movimentos de desfecho
    (TPU 219, 220, 221, 466). A presença do movimento não equivale ao resultado final do processo
    (pode haver reforma em recurso, embargos ou mais de um julgamento)."""
    filtros = []
    if municipio_ibge:
        filtros.append({"term": {"orgaoJulgador.codigoMunicipioIBGE": municipio_ibge}})
    if classe:
        filtros.append({"term": {"classe.codigo": classe}})
    if assunto:
        filtros.append({"term": {"assuntos.codigo": assunto}})
    if orgao:
        filtros.append({"term": {"orgaoJulgador.nome.keyword": orgao}})
    if not filtros:
        raise ErroDataJud("Informe ao menos um filtro (município, classe, assunto ou órgão).")
    desf = {"filters": {"filters": {
        "procedencia": {"term": {"movimentos.codigo": MOV_PROCEDENCIA}},
        "improcedencia": {"term": {"movimentos.codigo": MOV_IMPROCEDENCIA}},
        "procedencia_parcial": {"term": {"movimentos.codigo": MOV_PARCIAL}},
        "transacao_homologada": {"term": {"movimentos.codigo": MOV_TRANSACAO}}}}}
    corpo = {"size": 0, "track_total_hits": True, "query": {"bool": {"filter": filtros}},
             "aggs": {"por_orgao": {"terms": {"field": "orgaoJulgador.nome.keyword", "size": 15}, "aggs": {"desfechos": desf}},
                      "por_assunto": {"terms": {"field": "assuntos.nome.keyword", "size": 10}},
                      "por_classe": {"terms": {"field": "classe.nome.keyword", "size": 10}}}}
    d = _post(tribunal.lower(), corpo, cliente)
    ag = d.get("aggregations", {})
    orgaos = []
    for b in ag.get("por_orgao", {}).get("buckets", []):
        des = {k: v["doc_count"] for k, v in b["desfechos"]["buckets"].items()}
        julgados = sum(des.values())
        orgaos.append({"orgao": b["key"], "processos": b["doc_count"], "movimentos_de_desfecho": des,
                       "proporcoes": {k: round(v / julgados, 3) for k, v in des.items()} if julgados else {}})
    return {
        "tribunal": tribunal.upper(), "filtros": {"municipio_ibge": municipio_ibge, "classe": classe, "assunto": assunto, "orgao": orgao},
        "total": d.get("hits", {}).get("total", {}).get("value"), "por_orgao": orgaos,
        "por_assunto": [(b["key"], b["doc_count"]) for b in ag.get("por_assunto", {}).get("buckets", [])],
        "por_classe": [(b["key"], b["doc_count"]) for b in ag.get("por_classe", {}).get("buckets", [])],
        "nota": ("Fonte: DataJud/CNJ. Estatística descritiva por órgão julgador; a presença de movimento de "
                 "desfecho não equivale ao resultado final. Não é previsão de resultado."),
    }
