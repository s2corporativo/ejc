"""DJEN (Diário de Justiça Eletrônico Nacional) via API pública Comunica do CNJ.

Contrato: GET {base}/comunicacao?numeroOab=&ufOab=&dataDisponibilizacaoInicio=&dataDisponibilizacaoFim=
&pagina=&itensPorPagina=. Consulta pública, sem autenticação. O mesmo contrato é usado e validado em
produção pelo EJC (app/integrations/djen_comunica_client.py, verificado com requisição real em
18/07/2026). Neste ambiente de desenvolvimento o host não é alcançável pela rede; os testes usam
respostas gravadas e a verificação ao vivo deve ser feita no servidor. O EJC registra que a API
devolve 403 (bloqueio geográfico) para acessos de fora do Brasil: o servidor precisa sair por IP
brasileiro.

Atenção (LGPD): as comunicações trazem dados de terceiros. Armazenar só o necessário ao prazo.
"""
from __future__ import annotations

import re
from datetime import date

import httpx

from ..config import get_config

ITENS_POR_PAGINA = 100
MAX_PAGINAS = 20


class ErroDJEN(RuntimeError):
    pass


def _texto(html_txt: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html_txt or "")).strip()


_RX_CNJ = re.compile(r"\b\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}\b")


def _campo(item: dict, *nomes: str):
    for n in nomes:
        if item.get(n):
            return item[n]
    return None


def normalizar(item: dict) -> dict:
    """Aceita as variantes camelCase e snake_case observadas na API (fixtures do EJC)."""
    texto = _texto(_campo(item, "texto") or "")
    numero = _campo(item, "numeroprocessocommascara", "numeroProcesso", "numero_processo")
    if not numero:
        m = _RX_CNJ.search(texto)
        numero = m.group(0) if m else None
    data = _campo(item, "dataDisponibilizacao", "data_disponibilizacao", "datadisponibilizacao") or ""
    return {
        "id_externo": str(_campo(item, "id", "hash") or ""),
        "numero_processo": numero,
        "tribunal": _campo(item, "siglaTribunal", "sigla_tribunal"),
        "orgao": _campo(item, "nomeOrgao", "nome_orgao"),
        "tipo": _campo(item, "tipoComunicacao", "tipo_comunicacao"),
        "data_disponibilizacao": str(data)[:10] or None,
        "texto": texto[:20000],
        "link": item.get("link"),
    }


def consultar_por_oab(numero_oab: str, uf_oab: str, inicio: date | None = None, fim: date | None = None,
                      cliente: httpx.Client | None = None) -> list[dict]:
    cfg = get_config()
    c = cliente or httpx.Client(timeout=cfg.http_timeout, headers={"User-Agent": "LexValida/1.0"})
    saida, pagina = [], 1
    while pagina <= MAX_PAGINAS:
        params = {"numeroOab": numero_oab, "ufOab": uf_oab.upper(), "pagina": pagina, "itensPorPagina": ITENS_POR_PAGINA}
        if inicio:
            params["dataDisponibilizacaoInicio"] = inicio.isoformat()
        if fim:
            params["dataDisponibilizacaoFim"] = fim.isoformat()
        try:
            r = c.get(f"{cfg.djen_base_url.rstrip('/')}/comunicacao", params=params)
            r.raise_for_status()
        except httpx.HTTPError as e:
            raise ErroDJEN(f"DJEN/Comunica indisponível: {e}") from e
        d = r.json()
        itens = d.get("items") or d.get("itens") or []
        saida.extend(normalizar(i) for i in itens)
        total = d.get("count") or d.get("total") or 0
        if not itens or len(saida) >= total:
            break
        pagina += 1
    return saida
