"""Monitor legislativo: proposições da Câmara dos Deputados (API v2) e do Senado Federal (Dados Abertos).

Ambas são APIs públicas, sem chave. Retornam a EMENTA da proposição: servem para acompanhar projetos em
tramitação sobre um tema; não são lei vigente (legislação vigente vem do Planalto).
A Câmara aceita filtro por palavras-chave, mas o casamento é amplo; o Senado lista por ano e sigla.
Em ambos o resultado é refiltrado localmente pelos termos do tema.
"""
from __future__ import annotations

import re
from datetime import date

import httpx

from ..config import get_config
from ..core.texto import normalizar

CAMARA = "https://dadosabertos.camara.leg.br/api/v2/proposicoes"
SENADO = "https://legis.senado.leg.br/dadosabertos/materia/pesquisa/lista.json"
UA = "Mozilla/5.0 (compatible; LexValida/1.3; monitor legislativo publico)"
TIPOS = ("PL", "PLP", "PEC", "MPV")
PARADAS = {"para", "sobre", "pela", "pelo", "como", "entre", "contra", "com", "das", "dos", "que", "uma"}


class ErroLegislativo(RuntimeError):
    pass


def termos(tema: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]{4,}", normalizar(tema)) if w not in PARADAS]


def relevancia(ementa: str, ts: list[str]) -> float:
    e = normalizar(ementa)
    if not ts:
        return 0.0
    achados = sum(1 for t in ts if t in e or (len(t) > 6 and t[:max(5, len(t) - 3)] in e))
    return round(achados / len(ts), 2)


def _cliente(c):
    return c or httpx.Client(timeout=get_config().http_timeout, headers={"User-Agent": UA, "Accept": "application/json"})


def camara(tema: str, ano: int | None = None, cliente: httpx.Client | None = None, limite: int = 100) -> list[dict]:
    c, ano = _cliente(cliente), ano or date.today().year
    out = []
    for tipo in TIPOS[:3]:
        try:
            r = c.get(CAMARA, params={"siglaTipo": tipo, "keywords": tema, "ano": ano, "ordem": "DESC",
                                      "ordenarPor": "id", "itens": limite})
        except httpx.HTTPError as e:
            raise ErroLegislativo(f"Câmara indisponível: {e}") from e
        if r.status_code >= 400:
            raise ErroLegislativo(f"Câmara {r.status_code}: {r.text[:200]}")
        for x in r.json().get("dados", []):
            out.append({"id": f"camara:{x['id']}", "casa": "camara", "sigla": f"{x.get('siglaTipo')} {x.get('numero')}/{x.get('ano')}",
                        "ementa": x.get("ementa") or "", "data_apresentacao": (x.get("dataApresentacao") or "")[:10] or None,
                        "link": f"https://www.camara.leg.br/proposicoesWeb/fichadetramitacao?idProposicao={x['id']}"})
    return out


def senado(tema: str, ano: int | None = None, cliente: httpx.Client | None = None) -> list[dict]:
    c, ano = _cliente(cliente), ano or date.today().year
    out = []
    for tipo in ("PL", "PLP", "PEC"):
        try:
            r = c.get(SENADO, params={"ano": ano, "sigla": tipo})
        except httpx.HTTPError as e:
            raise ErroLegislativo(f"Senado indisponível: {e}") from e
        if r.status_code >= 400:
            raise ErroLegislativo(f"Senado {r.status_code}: {r.text[:200]}")
        mats = (((r.json() or {}).get("PesquisaBasicaMateria") or {}).get("Materias") or {}).get("Materia") or []
        if isinstance(mats, dict):
            mats = [mats]
        for m in mats:
            out.append({"id": f"senado:{m.get('Codigo')}", "casa": "senado", "sigla": m.get("DescricaoIdentificacao") or tipo,
                        "ementa": m.get("Ementa") or "", "data_apresentacao": (m.get("Data") or "")[:10] or None,
                        "link": f"https://www25.senado.leg.br/web/atividade/materias/-/materia/{m.get('Codigo')}"})
    return out


def buscar(tema: str, ano: int | None = None, cliente: httpx.Client | None = None, minimo: float = 1.0) -> dict:
    ts = termos(tema)
    if not ts:
        raise ErroLegislativo("Informe um tema com ao menos uma palavra de 4 letras.")
    itens, erros = [], []
    for nome, fn in (("camara", camara), ("senado", senado)):
        try:
            itens += fn(tema, ano, cliente)
        except ErroLegislativo as e:
            erros.append(f"{nome}: {e}")
    vistos, todos = set(), []
    for it in itens:
        if it["id"] not in vistos:
            vistos.add(it["id"])
            todos.append({**it, "relevancia": relevancia(it["ementa"], ts)})
    saida = [x for x in todos if x["relevancia"] >= minimo]
    parcial = not saida and len(ts) > 1
    if parcial:  # nenhum com todos os termos: mostra os que têm a maioria, sinalizados
        saida = [x for x in todos if x["relevancia"] >= 0.66]
    saida.sort(key=lambda x: x["data_apresentacao"] or "", reverse=True)
    saida.sort(key=lambda x: -x["relevancia"])
    return {"tema": tema, "termos": ts, "ano": ano or date.today().year, "proposicoes": saida[:60], "erros": erros,
            "correspondencia": "parcial" if parcial else "todos_os_termos",
            "nota": "Proposições em tramitação: não são lei vigente. Confira a situação no link oficial."}
