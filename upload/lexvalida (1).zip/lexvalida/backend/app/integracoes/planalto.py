"""Legislação federal do Planalto (texto compilado), artigo por artigo, texto VERBATIM.

Parser portado do ingestor do EJC (services/ingestors/planalto.py), adaptado ao modelo do LexValida:
cada artigo vira uma Norma própria (ex.: "cpc-art-219", rótulo "CPC, art. 219"), citável por
{{lei:cpc-art-219}} e com SHA-256 do texto e data de coleta.

Limites declarados:
- o texto compilado traz só a redação ATUAL; a data de início de vigência de cada redação não vem na
  página, então a versão entra com início "não curado" e a citação mostra esse alerta (LINDB, art. 6º);
- artigo integralmente revogado (corpo reduzido à anotação "Revogado") não é importado;
- diploma cujo cabeçalho declara revogação total não é importado.
Uma URL incorreta falha sem fabricar texto (mínimo de tamanho e de artigos reconhecidos).
"""
from __future__ import annotations

import re
import unicodedata

import httpx
from bs4 import BeautifulSoup

from ..config import get_config

MIN_TEXTO = 2000
MIN_ARTIGOS = 5
P = "https://www.planalto.gov.br/ccivil_03/"
# Identificação no formato padrão de agentes automatizados; o servidor recusa UA sem o prefixo "Mozilla/5.0".
UA = "Mozilla/5.0 (compatible; LexValida/1.3; consulta de legislacao publica)"

CATALOGO: list[dict] = [
    {"slug": "cf", "sigla": "CF", "titulo": "Constituição Federal de 1988", "area": "constitucional", "url": P + "constituicao/constituicaocompilado.htm"},
    {"slug": "cc", "sigla": "CC", "titulo": "Código Civil (Lei 10.406/2002)", "area": "civil", "url": P + "leis/2002/l10406compilada.htm"},
    {"slug": "cpc", "sigla": "CPC", "titulo": "Código de Processo Civil (Lei 13.105/2015)", "area": "processual_civil", "url": P + "_ato2015-2018/2015/lei/l13105.htm"},
    {"slug": "clt", "sigla": "CLT", "titulo": "Consolidação das Leis do Trabalho (DL 5.452/1943)", "area": "trabalhista", "url": P + "decreto-lei/del5452compilado.htm"},
    {"slug": "cdc", "sigla": "CDC", "titulo": "Código de Defesa do Consumidor (Lei 8.078/1990)", "area": "consumidor", "url": P + "leis/l8078compilado.htm"},
    {"slug": "cp", "sigla": "CP", "titulo": "Código Penal (DL 2.848/1940)", "area": "penal", "url": P + "decreto-lei/del2848compilado.htm"},
    {"slug": "cpp", "sigla": "CPP", "titulo": "Código de Processo Penal (DL 3.689/1941)", "area": "processual_penal", "url": P + "decreto-lei/del3689compilado.htm"},
    {"slug": "eca", "sigla": "ECA", "titulo": "Estatuto da Criança e do Adolescente (Lei 8.069/1990)", "area": "infancia_juventude", "url": P + "leis/l8069compilado.htm"},
    {"slug": "ctn", "sigla": "CTN", "titulo": "Código Tributário Nacional (Lei 5.172/1966)", "area": "tributario", "url": P + "leis/l5172compilado.htm"},
    {"slug": "lindb", "sigla": "LINDB", "titulo": "Lei de Introdução às Normas do Direito Brasileiro (DL 4.657/1942)", "area": "civil", "url": P + "decreto-lei/del4657compilado.htm"},
    {"slug": "l9099", "sigla": "Lei 9.099/1995", "titulo": "Lei dos Juizados Especiais (Lei 9.099/1995)", "area": "processual_civil", "url": P + "leis/l9099.htm"},
    {"slug": "l11419", "sigla": "Lei 11.419/2006", "titulo": "Informatização do Processo Judicial (Lei 11.419/2006)", "area": "processual_civil", "url": P + "_ato2004-2006/2006/lei/l11419.htm"},
    {"slug": "l12016", "sigla": "Lei 12.016/2009", "titulo": "Lei do Mandado de Segurança (Lei 12.016/2009)", "area": "processual_civil", "url": P + "_ato2007-2010/2009/lei/l12016.htm"},
    {"slug": "lgpd", "sigla": "LGPD", "titulo": "Lei Geral de Proteção de Dados Pessoais (Lei 13.709/2018)", "area": "digital", "url": P + "_ato2015-2018/2018/lei/l13709.htm"},
    {"slug": "eoab", "sigla": "EOAB", "titulo": "Estatuto da Advocacia e da OAB (Lei 8.906/1994)", "area": "advocacia", "url": P + "leis/l8906.htm"},
    {"slug": "l14133", "sigla": "Lei 14.133/2021", "titulo": "Lei de Licitações e Contratos Administrativos (Lei 14.133/2021)", "area": "administrativo", "url": P + "_ato2019-2022/2021/lei/l14133.htm"},
    {"slug": "l8429", "sigla": "Lei 8.429/1992", "titulo": "Lei de Improbidade Administrativa (Lei 8.429/1992)", "area": "administrativo", "url": P + "leis/l8429.htm"},
    {"slug": "l9784", "sigla": "Lei 9.784/1999", "titulo": "Lei do Processo Administrativo Federal (Lei 9.784/1999)", "area": "administrativo", "url": P + "leis/l9784.htm"},
    {"slug": "l6830", "sigla": "LEF", "titulo": "Lei de Execução Fiscal (Lei 6.830/1980)", "area": "tributario", "url": P + "leis/l6830.htm"},
    {"slug": "l8245", "sigla": "Lei 8.245/1991", "titulo": "Lei do Inquilinato (Lei 8.245/1991)", "area": "civil", "url": P + "leis/l8245.htm"},
    {"slug": "l11101", "sigla": "Lei 11.101/2005", "titulo": "Recuperação Judicial e Falência (Lei 11.101/2005)", "area": "empresarial", "url": P + "_ato2004-2006/2005/lei/l11101.htm"},
    {"slug": "lc123", "sigla": "LC 123/2006", "titulo": "Estatuto da ME e EPP (LC 123/2006)", "area": "empresarial", "url": P + "leis/lcp/lcp123.htm"},
    {"slug": "l8213", "sigla": "Lei 8.213/1991", "titulo": "Planos de Benefícios da Previdência Social (Lei 8.213/1991)", "area": "previdenciario", "url": P + "leis/l8213cons.htm"},
    {"slug": "ctb", "sigla": "CTB", "titulo": "Código de Trânsito Brasileiro (Lei 9.503/1997)", "area": "transito", "url": P + "leis/l9503compilado.htm"},
    {"slug": "l11340", "sigla": "Lei 11.340/2006", "titulo": "Lei Maria da Penha (Lei 11.340/2006)", "area": "penal", "url": P + "_ato2004-2006/2006/lei/l11340.htm"},
    {"slug": "l11343", "sigla": "Lei 11.343/2006", "titulo": "Lei de Drogas (Lei 11.343/2006)", "area": "penal", "url": P + "_ato2004-2006/2006/lei/l11343.htm"},
    {"slug": "l10741", "sigla": "Lei 10.741/2003", "titulo": "Estatuto da Pessoa Idosa (Lei 10.741/2003)", "area": "civil", "url": P + "leis/2003/l10.741.htm"},
    {"slug": "pnma", "sigla": "Lei 6.938/1981", "titulo": "Política Nacional do Meio Ambiente (Lei 6.938/1981)", "area": "ambiental", "url": P + "leis/l6938.htm"},
    {"slug": "lca", "sigla": "Lei 9.605/1998", "titulo": "Lei de Crimes Ambientais (Lei 9.605/1998)", "area": "ambiental", "url": P + "leis/l9605.htm"},
    {"slug": "cflo", "sigla": "Código Florestal", "titulo": "Código Florestal (Lei 12.651/2012)", "area": "ambiental", "url": P + "_ato2011-2014/2012/lei/l12651.htm"},
    {"slug": "d6514", "sigla": "Decreto 6.514/2008", "titulo": "Infrações e Sanções Administrativas Ambientais (Decreto 6.514/2008)", "area": "ambiental", "url": P + "_ato2007-2010/2008/decreto/d6514.htm"},
]
POR_SLUG = {d["slug"]: d for d in CATALOGO}
PADRAO = ["cf", "cc", "cpc", "cdc", "clt", "lindb", "l9099", "l11419", "eoab", "lgpd", "l14133", "l6830"]


class ErroPlanalto(RuntimeError):
    pass


# ------------------------------------------------------------------ parser (puro)
_RE_REVOGADO = re.compile(r"\(\s*Revogad[oa][^)]*\)", re.IGNORECASE)
_BOILERPLATE = {"presidência da república", "casa civil", "secretaria-geral", "subchefia para assuntos jurídicos",
                "subchefia de assuntos jurídicos", "texto compilado", "texto compilado(vigência)", "(vigência)",
                "vigência", "mensagem de veto", "índice", "voltar ao início"}
_RE_NAO_SUBSTITUI = re.compile(r"^este texto não substitui o publicado", re.IGNORECASE)
_RE_ART = re.compile(r"^Art\.\s*(\d{1,3}(?:\.\d{3})+|\d{1,4})\s*([ºo°])?\s*(-[A-Za-z]{1,3})?\s*[.\sº°]")
_RE_ART_BARE = re.compile(r"^Art\.\s*\d{1,4}$")
_RE_DIPLOMA_REVOGADO = re.compile(r"(?m)^\s*\(?\s*(?:revogad[oa]s?\s+(?:integralmente\s+|expressamente\s+)?(?:pel[ao]s?\b|a\s+partir\b|em\s+\d)|vig[êe]ncia\s+encerrada\b)", re.IGNORECASE)
_RE_SO_REVOGADO = re.compile(r"^\s*Art\.[^\n]{0,30}?(?:\(\s*Revogad[oa][^)]*\)|Revogad[oa]\.?)\s*$", re.IGNORECASE)


def _limpar(t: str) -> str:
    t = unicodedata.normalize("NFC", t).replace("\xa0", " ")
    # páginas antigas quebram "§ 1º" em três linhas ("§", "1", "o"): recompõe só esse padrão
    t = re.sub(r"§\s*\n\s*(\d{1,3})\s*\n\s*[oº°]\b", r"§ \1º", t)
    t = re.sub(r"[ \t]+", " ", t)
    return re.sub(r"\n{3,}", "\n\n", t).strip()


def extrair_texto(html: str) -> str:
    """HTML compilado → texto limpo. Remove script/style e o texto RISCADO (redação revogada),
    preservando só a anotação "(Revogado ...)"; remove linhas de navegação. Não reescreve o texto legal."""
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style"]):
        tag.decompose()
    for tag in soup.find_all(["strike", "s", "del"]):
        m = _RE_REVOGADO.search(tag.get_text(" ", strip=True))
        if m:
            tag.replace_with(m.group(0))
        else:
            tag.decompose()
    txt = soup.get_text("\n").replace("\xa0", " ")
    txt = re.sub(r"[ \t]+\n", "\n", txt)
    txt = re.sub(r"\n[ \t]+", "\n", txt)
    brutas, linhas, i = txt.split("\n"), [], 0
    while i < len(brutas):
        ln = brutas[i]
        if ln.strip() == "Art." and i + 1 < len(brutas) and re.match(r"^\d{1,3}(?:\.\d{3})*\s*(?:[ºo°])?(?:-[A-Za-z]{1,3})?[.\sº°]", brutas[i + 1].strip()):
            ln, i = f"Art. {brutas[i + 1].strip()}", i + 1
        if _RE_ART_BARE.fullmatch(ln.strip()) and i + 1 < len(brutas) and brutas[i + 1].strip() in {"o", "º", "°"}:
            ln, i = f"{ln.rstrip()} {brutas[i + 1].strip()}", i + 1
            if i + 1 < len(brutas) and re.match(r"-[A-Za-z]{1,3}\.", brutas[i + 1].strip()):
                ln, i = f"{ln} {brutas[i + 1].strip()}", i + 1
        chave = ln.strip().lower()
        if chave not in _BOILERPLATE and not _RE_NAO_SUBSTITUI.match(chave):
            linhas.append(ln)
        i += 1
    return _limpar("\n".join(linhas))


def dividir_artigos(texto: str) -> list[tuple[str | None, str]]:
    """[(numero_canonico | None, bloco)]. Numeração só avança (ou recomeça em 1, como no ADCT), o que
    evita confundir remissões "art. 5º" no meio do texto com início de artigo."""
    blocos, atual, rotulo, ultimo, seq = [], [], None, 0, 0

    def fechar():
        corpo = "\n".join(atual).strip()
        if corpo:
            blocos.append((rotulo, corpo))

    for ln in texto.split("\n"):
        m = _RE_ART.match(ln.strip())
        if m:
            n = int(m.group(1).replace(".", ""))
            suf = (m.group(3) or "").upper()
            if n > ultimo or (n == ultimo and suf) or (n == 1 and ultimo > 1):
                fechar()
                if n == 1 and ultimo > 1:
                    seq += 1
                atual, ultimo = [ln], n
                rotulo = f"{seq}|{m.group(1)}{suf}"
                continue
        atual.append(ln)
    fechar()
    return blocos


def diploma_revogado(texto: str) -> bool:
    cabecalho = "\n".join([ln for ln in texto.splitlines() if ln.strip()][:2])
    return bool(_RE_DIPLOMA_REVOGADO.search(cabecalho))


def _id_artigo(slug: str, seq: int, numero: str) -> str:
    n = numero.replace(".", "").lower()
    pref = "" if seq == 0 else ("adct-" if slug == "cf" else f"parte{seq + 1}-")
    return f"{slug}-{pref}art-{n}"


def preparar(diploma: dict, html: str) -> dict:
    texto = extrair_texto(html)
    if len(texto) < MIN_TEXTO:
        raise ErroPlanalto(f"{diploma['slug']}: texto com {len(texto)} caracteres; página errada ou truncada.")
    if diploma_revogado(texto):
        raise ErroPlanalto(f"{diploma['slug']}: o cabeçalho declara o diploma revogado; não importado.")
    artigos, revogados = [], 0
    for rot, corpo in dividir_artigos(texto):
        if not rot:
            continue
        seq, numero = rot.split("|")
        if _RE_SO_REVOGADO.match(corpo.strip()):
            revogados += 1
            continue
        base, _, suf = numero.partition("-")
        n_exib = (f"{base}º" if base.isdigit() and int(base) < 10 else base) + (f"-{suf}" if suf else "")
        art_label = f"art. {n_exib}" + ("" if not seq or seq == "0" else (" do ADCT" if diploma["slug"] == "cf" else f" (parte {int(seq) + 1})"))
        artigos.append({"id": _id_artigo(diploma["slug"], int(seq), numero), "dispositivo": art_label,
                        "rotulo": f"{diploma['sigla']}, {art_label}", "texto": corpo})
    if len(artigos) < MIN_ARTIGOS:
        raise ErroPlanalto(f"{diploma['slug']}: só {len(artigos)} artigos reconhecidos; parser não reconheceu a página.")
    return {"artigos": artigos, "revogados_ignorados": revogados, "caracteres": len(texto)}


def baixar(diploma: dict, cliente: httpx.Client | None = None) -> str:
    c = cliente or httpx.Client(timeout=max(get_config().http_timeout, 60), follow_redirects=True,
                                headers={"User-Agent": UA})
    try:
        r = c.get(diploma["url"])
    except httpx.HTTPError as e:
        raise ErroPlanalto(f"{diploma['slug']}: Planalto indisponível ({e}).") from e
    if r.status_code != 200:
        raise ErroPlanalto(f"{diploma['slug']}: HTTP {r.status_code} em {diploma['url']}")
    bruto = r.content
    for enc in (r.charset_encoding, "utf-8", "latin-1"):
        if not enc:
            continue
        try:
            return bruto.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return bruto.decode("latin-1", errors="replace")
