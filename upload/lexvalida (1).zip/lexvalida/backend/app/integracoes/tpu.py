"""Tabelas Processuais Unificadas (TPU, Res. CNJ 46/2007) via webservice SOAP público do SGT/CNJ.

Contrato verificado ao vivo em 04/10/2026: operação pesquisarItemPublicoWS(tipoTabela, tipoPesquisa,
valorPesquisa); tipoTabela A = assuntos, C = classes, M = movimentos; tipoPesquisa C = código,
N = nome. Retorna Item(cod_item, cod_item_pai, nome, dscGlossario).
"""
from __future__ import annotations

import html
import re
import xml.etree.ElementTree as ET
from functools import lru_cache

import httpx

from ..config import get_config

TABELAS = {"assunto": "A", "classe": "C", "movimento": "M"}

ENVELOPE = ('<?xml version="1.0" encoding="UTF-8"?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" '
            'xmlns:sgt="https://www.cnj.jus.br/sgt/sgt_ws.php"><soapenv:Body><sgt:pesquisarItemPublicoWS>'
            '<tipoTabela>{t}</tipoTabela><tipoPesquisa>{p}</tipoPesquisa><valorPesquisa>{v}</valorPesquisa>'
            '</sgt:pesquisarItemPublicoWS></soapenv:Body></soapenv:Envelope>')


class ErroTPU(RuntimeError):
    pass


def _limpar(t: str) -> str:
    t = html.unescape(html.unescape(t or ""))
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", t)).strip()


def parse_resposta(xml: str) -> list[dict]:
    try:
        raiz = ET.fromstring(xml)
    except ET.ParseError as e:
        raise ErroTPU(f"Resposta SOAP inválida: {e}") from e
    itens = []
    for item in raiz.iter():
        if item.tag.endswith("Item"):
            campos = {c.tag.split("}")[-1]: (c.text or "") for c in item}
            if "cod_item" in campos:
                itens.append({"codigo": int(campos["cod_item"]), "codigo_pai": int(campos.get("cod_item_pai") or 0),
                              "nome": campos.get("nome", "").strip(), "glossario": _limpar(campos.get("dscGlossario", ""))[:1500]})
    return itens


def pesquisar(tabela: str, valor: str, por: str = "nome", cliente: httpx.Client | None = None) -> list[dict]:
    if tabela not in TABELAS:
        raise ErroTPU(f"Tabela inválida: {tabela}. Use {sorted(TABELAS)}")
    valor_xml = html.escape(str(valor).strip())
    if not valor_xml:
        raise ErroTPU("Informe o valor da pesquisa.")
    return _pesquisar_cache(TABELAS[tabela], "C" if por == "codigo" else "N", valor_xml) if cliente is None \
        else _executar(TABELAS[tabela], "C" if por == "codigo" else "N", valor_xml, cliente)


@lru_cache(maxsize=512)
def _pesquisar_cache(t: str, p: str, v: str) -> list[dict]:
    return _executar(t, p, v, None)


def _executar(t: str, p: str, v: str, cliente: httpx.Client | None) -> list[dict]:
    cfg = get_config()
    c = cliente or httpx.Client(timeout=cfg.http_timeout)
    try:
        r = c.post(cfg.sgt_url, content=ENVELOPE.format(t=t, p=p, v=v).encode("utf-8"),
                   headers={"Content-Type": "text/xml; charset=utf-8",
                            "SOAPAction": '"https://www.cnj.jus.br/sgt/sgt_ws.php#pesquisarItemPublicoWS"'})
        r.raise_for_status()
    except httpx.HTTPError as e:
        raise ErroTPU(f"SGT/CNJ indisponível: {e}") from e
    return parse_resposta(r.text)
