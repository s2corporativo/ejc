"""Integração com o EJC por API (sem duplicar funcionalidade).

Liquidação trabalhista: delega ao endpoint do EJC POST {EJC_API_URL}/api/trabalhista/liquidacao/calcular
(ADC 58 / Selic real BCB), autenticado com o token de um usuário do EJC (perfil de equipe).
O payload segue o modelo LiquidacaoIn do EJC: verbas[], data_ajuizamento, data_calculo,
percentual_honorarios, fator_ipcae_pre_ajuizamento, usar_indice_oficial, data_inicio_correcao.
"""
from __future__ import annotations

import httpx

from ..config import get_config


class ErroEJC(RuntimeError):
    pass


def liquidacao_trabalhista(payload: dict, cliente: httpx.Client | None = None) -> dict:
    cfg = get_config()
    if not cfg.ejc_api_url or not cfg.ejc_api_token:
        raise ErroEJC("Configure EJC_API_URL e EJC_API_TOKEN para usar a liquidação trabalhista do EJC.")
    c = cliente or httpx.Client(timeout=cfg.http_timeout)
    try:
        r = c.post(f"{cfg.ejc_api_url.rstrip('/')}/api/trabalhista/liquidacao/calcular", json=payload,
                   headers={"Authorization": f"Bearer {cfg.ejc_api_token}"})
    except httpx.HTTPError as e:
        raise ErroEJC(f"EJC indisponível: {e}") from e
    if r.status_code >= 400:
        raise ErroEJC(f"EJC {r.status_code}: {r.text[:300]}")
    return r.json()
