Respostas reais gravadas em 04/10/2026: DataJud (api_publica_tjmg, metadados públicos, sem partes) e SGT/CNJ (TPU).
Fixtures djen_* e stj_* reproduzem o contrato das APIs com conteúdo FICTÍCIO.
