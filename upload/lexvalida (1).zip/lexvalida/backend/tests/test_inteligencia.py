"""Integrações (com respostas reais gravadas e fixtures de contrato), monitor, intimações,
regras jurídicas adicionais e governança. Testes AO VIVO: defina LIVE=1."""
import json
import os
import types
from datetime import date
from pathlib import Path

import httpx
import pytest

try:
    import pymupdf as fitz
except ImportError:  # pragma: no cover
    import fitz

FX = Path(__file__).parent / "fixtures"
AUTOS = (Path(__file__).resolve().parents[2] / "data" / "exemplos" / "autos_ficticios.txt").read_bytes()


def _fake_httpx(handler):
    def cliente(**kw):
        kw.pop("transport", None)
        return httpx.Client(transport=httpx.MockTransport(handler), **{k: v for k, v in kw.items() if k in ("timeout", "headers", "follow_redirects")})
    return types.SimpleNamespace(Client=cliente, HTTPError=httpx.HTTPError)


def _handler(req: httpx.Request) -> httpx.Response:
    u = str(req.url)
    if "datajud-wiki" in u:
        return httpx.Response(200, text="<p>APIKey atual: <code>Authorization: APIKey CHAVEPUBLICATESTE1234567890==</code></p>")
    if "api_publica_tjmg" in u:
        assert req.headers["Authorization"] == "APIKey CHAVEPUBLICATESTE1234567890=="
        corpo = json.loads(req.content)
        nome = "datajud_jurimetria_betim_6226.json" if corpo.get("size") == 0 else "datajud_processo.json"
        return httpx.Response(200, json=json.loads((FX / nome).read_text()))
    if "sgt_ws.php" in u:
        nome = "tpu_assunto_6226.xml" if b"<tipoPesquisa>C" in req.content else "tpu_assunto_nome.xml"
        return httpx.Response(200, text=(FX / nome).read_text())
    if "comunicacao" in u:
        return httpx.Response(200, json=json.loads((FX / "djen_oab.json").read_text()))
    if "package_show" in u:
        return httpx.Response(200, json=json.loads((FX / "stj_package.json").read_text()))
    if "20260901.json" in u:
        return httpx.Response(200, json=json.loads((FX / "stj_lote.json").read_text()))
    if "liquidacao/calcular" in u:
        assert req.headers["Authorization"] == "Bearer tok-ejc"
        return httpx.Response(200, json={"total": 1234.56, "regime": "ADC 58"})
    return httpx.Response(404)


@pytest.fixture
def mock_rede(monkeypatch):
    from app.integracoes import datajud, djen, ejc, stj, tpu
    fake = _fake_httpx(_handler)
    for mod in (datajud, djen, ejc, stj, tpu):
        monkeypatch.setattr(mod, "httpx", fake)
    datajud._cache.update(chave=None, obtida_em=0.0)
    tpu._pesquisar_cache.cache_clear()
    monkeypatch.setenv("EJC_API_URL", "http://ejc.local")
    monkeypatch.setenv("EJC_API_TOKEN", "tok-ejc")


def _caso(c, **kw):
    r = c.post("/api/casos", json={"titulo": "Caso", "data_fatos": "2025-03-10", **kw})
    assert r.status_code == 200, r.text
    return r.json()["id"]


# --------------------------------------------------------------- integrações
def test_datajud_chave_descoberta_e_processo(cliente, mock_rede):
    assert cliente.get("/api/datajud/chave").json()["origem"] == "wiki oficial do CNJ"
    r = cliente.get("/api/datajud/processo", params={"numero": "5039998-29.2024.8.13.0027"}).json()
    assert r[0]["classe"]["codigo"] == 7 and r[0]["orgao_julgador"]["codigoMunicipioIBGE"] == 3106705
    cid = _caso(cliente, numero_processo="5039998-29.2024.8.13.0027")
    e = cliente.post(f"/api/casos/{cid}/enriquecer-datajud").json()
    assert e["tribunal"] == "TJMG"
    assert cliente.get(f"/api/casos/{cid}").json()["assuntos_tpu"]


def test_datajud_jurimetria_descritiva(cliente, mock_rede):
    r = cliente.post("/api/datajud/jurimetria", json={"tribunal": "tjmg", "municipio_ibge": 3106705, "assunto": 6226}).json()
    assert r["total"] == 20139
    v5 = next(o for o in r["por_orgao"] if o["orgao"].startswith("5ª Vara Cível"))
    assert v5["movimentos_de_desfecho"]["improcedencia"] == 541
    assert "não é previsão" in r["nota"].lower() or "Não é previsão" in r["nota"]


def test_numero_cnj_invalido():
    from app.integracoes.datajud import ErroDataJud, normalizar_numero
    assert normalizar_numero("0001234-56.2025.8.13.0027") == ("00012345620258130027", "tjmg")
    assert normalizar_numero("0007777-88.2024.5.03.0142")[1] == "trt3"
    with pytest.raises(ErroDataJud):
        normalizar_numero("123")


def test_tpu(cliente, mock_rede):
    r = cliente.get("/api/tpu", params={"tabela": "assunto", "valor": "6226", "por": "codigo"}).json()
    assert r[0]["nome"] == "Inclusão Indevida em Cadastro de Inadimplentes" and r[0]["codigo_pai"] == 7779
    r = cliente.get("/api/tpu", params={"tabela": "assunto", "valor": "cadastro de inadimplentes"}).json()
    assert {x["codigo"] for x in r} >= {6026, 6226}


def test_stj_importa_acordaos_filtrados(cliente, mock_rede):
    r = cliente.post("/api/conhecimento/stj", json={"termos": ["inscricao indevida"], "orgaos": ["terceira-turma"]}).json()
    assert len(r["importados"]) == 1
    p = cliente.get(f"/api/precedentes/{r['importados'][0]}").json()
    assert p["tribunal"] == "STJ" and p["verificado"]


def test_liquidacao_trabalhista_via_ejc(cliente, mock_rede):
    r = cliente.post("/api/trabalhista/liquidacao", json={"verbas": [{"rubrica": "x", "valor": 1}],
                                                          "data_ajuizamento": "2025-01-01", "data_calculo": "2026-01-01"})
    assert r.json()["regime"] == "ADC 58"


# ---------------------------------------------------- intimações e monitor
def test_djen_intimacao_prazo_e_minuta(cliente, mock_rede):
    cid = _caso(cliente, numero_processo="0001234-56.2025.8.13.0027")
    cliente.post(f"/api/casos/{cid}/documentos", files={"arquivo": ("i.txt", AUTOS, "text/plain")})
    r = cliente.post("/api/intimacoes/sincronizar-djen", json={"oabs": "123456/MG"}).json()
    assert len(r["novas"]) == 2 and not r["erros"]
    again = cliente.post("/api/intimacoes/sincronizar-djen", json={"oabs": "123456/MG"}).json()
    assert again["existentes"] == 2  # idempotente
    lista = cliente.get("/api/intimacoes").json()
    tjmg = next(i for i in lista if i["tribunal"] == "TJMG")
    assert tjmg["caso_id"] == cid and tjmg["prazo_dias"] == 15 and tjmg["vencimento"] == "2026-10-26"
    trt = next(i for i in lista if i["tribunal"] == "TRT3")
    assert trt["numero_processo"] == "0007777-88.2024.5.03.0142" and trt["prazo_dias"] == 8
    assert any(a["tipo"] == "prazo" for a in cliente.get("/api/alertas").json())
    m = cliente.post(f"/api/intimacoes/{tjmg['id']}/minuta", json={"tipo_peca": "Contestação", "pedido": "contestar"}).json()
    assert m["minuta_id"]


def test_precedente_superado_alerta_minuta_aprovada(base):
    caso = _caso(base)
    base.post(f"/api/casos/{caso}/documentos", files={"arquivo": ("i.txt", AUTOS, "text/plain")})
    m = base.post("/api/minutas", json={"caso_id": caso, "tipo_peca": "Contestação", "pedido": "negativação sem notificação"}).json()
    if m["fase"] == "perguntas":
        base.post(f"/api/minutas/{m['id']}/respostas", json={"respostas": {}})
    m = base.post(f"/api/minutas/{m['id']}/roteiro/aprovar", json={}).json()
    assert "{{juris:ficticio-sumula-1}}" in m["texto"]
    a = base.post(f"/api/minutas/{m['id']}/aprovar", json={"responsavel": "Dr. Teste", "ciente_alertas": True})
    assert a.status_code == 200, a.text
    r = base.patch("/api/precedentes/ficticio-sumula-1/status", json={"status": "cancelado", "nota": "teste"}).json()
    assert r["alertas_gerados"] == 1
    al = base.get("/api/alertas").json()
    crit = [x for x in al if x["tipo"] == "precedente_alterado"]
    assert crit and crit[0]["nivel"] == "critico" and crit[0]["minuta_id"] == m["id"]
    assert base.post(f"/api/alertas/{crit[0]['id']}/resolver").json()["resolvido"]


def test_tema_afetado_cruza_carteira(base):
    c1 = _caso(base, assuntos_tpu=[{"codigo": 6226, "nome": "Inclusão Indevida em Cadastro de Inadimplentes"}])
    c2 = _caso(base)
    base.post(f"/api/casos/{c2}/documentos", files={"arquivo": ("i.txt", AUTOS, "text/plain")})
    r = base.post("/api/conhecimento/temas", json=[{
        "tribunal": "STJ", "tipo": "repetitivo", "numero": "F-900", "situacao": "afetado", "suspensao_nacional": True,
        "questao": "[FICTÍCIO] Inscrição em cadastro de inadimplentes sem notificação prévia e dano moral",
        "assuntos_tpu": [6226]}]).json()
    assert r["alertas_gerados"] >= 1
    al = [a for a in base.get("/api/alertas").json() if a["tipo"] == "tema_afetado"]
    por_caso = {a["caso_id"]: a for a in al}
    assert por_caso[c1]["nivel"] == "critico" and "1.037" in por_caso[c1]["mensagem"]
    assert base.post("/api/monitor/executar").status_code == 200


# --------------------------------------------------------- regras jurídicas
def test_regras(cliente):
    r = cliente.post("/api/prescricao/intercorrente", json={"rito": "lef", "data_ciencia_tentativa_infrutifera": "2018-03-10",
                                                            "data_referencia": "2026-01-01"}).json()
    assert r["termo_final"] == "2024-03-10" and r["prescrito"]
    r = cliente.post("/api/valor-causa", json={"pedidos": [{"tipo": "alimentos", "prestacao_mensal": "800"},
                                                            {"tipo": "indenizacao", "valor": "5000"}]}).json()
    assert r["valor_da_causa"] == "14600.00"
    r = cliente.post("/api/valor-causa", json={"relacao": "alternativos", "pedidos": [{"tipo": "indenizacao", "valor": "100"},
                                                                                     {"tipo": "indenizacao", "valor": "300"}]}).json()
    assert r["valor_da_causa"] == "300.00"
    r = cliente.post("/api/vedacao-surpresa", json={"texto_decisao": "Reconheço de ofício a prescrição e a ilegitimidade.",
                                                    "texto_autos": "Petição inicial e contestação sobre dano moral."}).json()
    assert {a["materia"] for a in r["achados"]} == {"prescricao", "ilegitimidade"}
    r = cliente.post("/api/julgador", json={"texto": "Requer a tutela de urgência. Probabilidade do direito.", "tipo_peca": "Pedido de tutela de urgência"}).json()
    assert r["tipo"] == "tutela_urgencia" and any("Perigo" in p for p in r["pendencias"])
    r = cliente.post("/api/licitacoes/impugnacao", json={"data": "2026-10-15"}).json()
    assert r["limite_protocolo"] == "2026-10-09"
    r = cliente.post("/api/licitacoes/recurso", json={"data": "2026-10-09"}).json()
    assert r["vencimento"] == "2026-10-15"
    r = cliente.post("/api/licitacoes/habilitacao", json={"texto_edital": "Exige CNDT, FGTS e certidão Serasa.",
                                                          "documentos": [{"tipo": "CNDT", "validade": "2026-12-31"}],
                                                          "data_sessao": "2026-10-20"}).json()
    assert r["exigencias_sem_previsao_legal"] and any("FGTS" in p for p in r["pendencias"])


def test_distinguishing(base):
    caso = _caso(base)
    base.post(f"/api/casos/{caso}/documentos", files={"arquivo": ("i.txt", AUTOS, "text/plain")})
    r = base.post("/api/distinguishing", json={"precedente_id": "ficticio-sumula-1", "caso_id": caso}).json()
    assert r["conclusao"] in ("aplica", "distinguir", "inconclusivo") and r["comparacao"]
    r2 = base.post("/api/distinguishing", json={"precedente_id": "ficticio-acordao-2", "caso_id": caso}).json()
    assert r2["conclusao"] in ("distinguir", "inconclusivo")


def test_teses_de_massa(base):
    ids = []
    for i in range(6):
        cid = _caso(base, parte_contraria="Banco Exemplo S.A.")
        m = base.post("/api/minutas", json={"caso_id": cid, "tipo_peca": "Contestação", "pedido": "x"}).json()
        base.post(f"/api/minutas/{m['id']}/desfecho", json={"resultado": "procedente" if i < 4 else "improcedente",
                                                            "teses_acolhidas": ["ausência de notificação"] if i < 4 else [],
                                                            "teses_rejeitadas": [] if i < 4 else ["ausência de notificação"]})
        ids.append(cid)
    r = base.get("/api/teses-massa", params={"parte": "banco exemplo"}).json()
    g = r["grupos"][0]
    assert g["desfechos"] == 6 and g["amostra_suficiente"] and g["taxa_favoravel"] == 0.67
    assert g["teses"][0]["taxa_acolhimento"] == 0.67


# --------------------------------------------------------------- governança
def test_governanca(base):
    caso = _caso(base)
    base.post(f"/api/casos/{caso}/documentos", files={"arquivo": ("i.txt", AUTOS, "text/plain")})
    reg = base.get("/api/conformidade/registro-operacoes").json()
    assert any(o["operacao"] == "documento" for o in reg["operacoes"])
    ripd = base.get("/api/conformidade/ripd").text
    assert "LGPD, art. 38" in ripd and "Medidas de segurança" in ripd
    av = base.post("/api/avaliacao").json()
    assert av["total"] == 11 and av["metricas"]["prazo"]["acuracia"] == 1.0 and av["metricas"]["citacao"]["acuracia"] == 1.0
    assert av["acuracia_geral"] >= 0.8, av


def test_peticionamento(cliente, monkeypatch):
    monkeypatch.setenv("PETICIONAMENTO_LIMITE_MB", "5")
    ok = fitz.open(); ok.new_page().insert_text((72, 72), "Peticao com texto pesquisavel."); b_ok = ok.tobytes(); ok.close()
    ruim = fitz.open(); ruim.new_page(); b_ruim = ruim.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw="a", user_pw="b"); ruim.close()
    r = cliente.post("/api/peticionamento/checar", files=[("arquivos", ("peticao.pdf", b_ok, "application/pdf")),
                                                          ("arquivos", ("anexo protegido ç.pdf", b_ruim, "application/pdf"))]).json()
    assert r["arquivos"][0]["apto"] and not r["arquivos"][1]["apto"] and not r["apto"]


# ------------------------------------------------------------------ ao vivo
@pytest.mark.skipif(os.getenv("LIVE") != "1", reason="defina LIVE=1 para testar as APIs oficiais ao vivo")
def test_ao_vivo_datajud_e_tpu():
    from app.integracoes import datajud, tpu
    datajud._cache.update(chave=None, obtida_em=0.0)
    assert len(datajud.descobrir_chave()) > 20
    r = datajud.consultar_processo("5039998-29.2024.8.13.0027")
    assert r and r[0]["tribunal"] == "TJMG"
    j = datajud.jurimetria("tjmg", municipio_ibge=3106705, assunto=6226)
    assert j["total"] > 1000 and j["por_orgao"]
    assert tpu.pesquisar("assunto", "6226", "codigo")[0]["codigo"] == 6226
    assert tpu.pesquisar("movimento", "219", "codigo")[0]["nome"] == "Procedência"
