"""Importação do EJC contra um banco PostgreSQL que reproduz o esquema RAG do EJC
(knowledge_docs / knowledge_chunks com vector(1024)). Requer PG_TEST_URL e EJC_TEST_URL."""
import json
import os
import uuid

import pytest
from sqlalchemy import create_engine, text

pytestmark = pytest.mark.skipif(not (os.getenv("PG_TEST_URL") and os.getenv("EJC_TEST_URL")),
                                reason="requer PG_TEST_URL e EJC_TEST_URL")

DDL = """
DROP TABLE IF EXISTS knowledge_chunks; DROP TABLE IF EXISTS knowledge_docs; DROP TYPE IF EXISTS baserag;
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TYPE baserag AS ENUM ('publica','escritorio','caso');
CREATE TABLE knowledge_docs (
  id varchar(36) PRIMARY KEY, titulo varchar(500) NOT NULL, categoria varchar(50) NOT NULL,
  fonte varchar(255), tribunal varchar(20), extra jsonb, base_rag baserag NOT NULL DEFAULT 'publica',
  client_id varchar(36), case_id varchar(36), chave_origem varchar(255), versao int NOT NULL DEFAULT 1,
  vigente boolean NOT NULL DEFAULT true, deleted_at timestamptz);
CREATE TABLE knowledge_chunks (
  id varchar(36) PRIMARY KEY, doc_id varchar(36) REFERENCES knowledge_docs(id) ON DELETE CASCADE,
  chunk_index int NOT NULL, pagina int, conteudo text NOT NULL, embedding vector(1024));
"""


def _doc(c, titulo, categoria, extra, conteudo, **kw):
    from app.core.embeddings import vetor_hash
    did = str(uuid.uuid4())
    c.execute(text("""INSERT INTO knowledge_docs (id,titulo,categoria,fonte,tribunal,extra,base_rag,client_id,case_id,chave_origem,vigente)
                      VALUES (:id,:t,:c,:f,:tr,CAST(:e AS jsonb),CAST(:b AS baserag),:cli,:caso,:ch,:v)"""),
              {"id": did, "t": titulo, "c": categoria, "f": kw.get("fonte"), "tr": kw.get("tribunal"),
               "e": json.dumps(extra), "b": kw.get("base", "publica"), "cli": kw.get("client_id"),
               "caso": kw.get("case_id"), "ch": kw.get("chave"), "v": kw.get("vigente", True)})
    c.execute(text("INSERT INTO knowledge_chunks (id,doc_id,chunk_index,conteudo,embedding) VALUES (:i,:d,0,:t,CAST(:e AS vector))"),
              {"i": str(uuid.uuid4()), "d": did, "t": conteudo, "e": str(vetor_hash(conteudo))})
    return did


@pytest.fixture
def ejc():
    url = os.environ["EJC_TEST_URL"].replace("postgresql://", "postgresql+psycopg://", 1)
    eng = create_engine(url)
    with eng.begin() as c:
        for stmt in [s for s in DDL.split(";") if s.strip()]:
            c.execute(text(stmt))
        ok = {"rag_status": "aprovado"}
        ids = {
            "sumula_ok": _doc(c, "Súmula F-10 (fictícia)", "sumula_stj", {**ok, "conferido": True},
                              "[FICTÍCIO] Texto de súmula conferida.", chave="sumula:stj:f10", tribunal="STJ"),
            "sumula_nao_conferida": _doc(c, "Súmula F-11", "sumula_stj", ok, "[FICTÍCIO] não conferida", chave="sumula:stj:f11"),
            "lei_vigente": _doc(c, "Lei F-9, art. 1º", "legislacao", {**ok, "legal_status": "vigente",
                                "legal_status_origem": "curadoria", "legal_status_verificado_em": "2026-09-01"},
                                "Art. 1º [FICTÍCIO] Texto vigente."),
            "lei_revogada": _doc(c, "Lei F-8", "legislacao", {**ok, "legal_status": "revogada"}, "Art. 1º revogado."),
            "doutrina": _doc(c, "Doutrina F", "doutrina", ok, "[FICTÍCIO] Comentário doutrinário."),
            "cliente": _doc(c, "Peça de cliente", "precedente_interno", ok, "Sigiloso", base="escritorio", client_id="c1"),
            "ficticio": _doc(c, "Bíblia", "doutrina", {**ok, "ficticio": True}, "Material fictício."),
            "pendente": _doc(c, "Pendente", "doutrina", {"rag_status": "pendente"}, "Pendente de curadoria."),
            "juris": _doc(c, "TJMG F-1", "jurisprudencia", ok, "[FICTÍCIO] Ementa de acórdão.", tribunal="TJMG"),
        }
    yield os.environ["EJC_TEST_URL"], ids
    eng.dispose()


def test_importa_somente_base_publica_aprovada(cliente, ejc):
    if cliente.dialeto != "postgres":
        pytest.skip("vetores pgvector")
    url, ids = ejc
    seco = cliente.post("/api/conhecimento/importar-ejc", json={"ejc_database_url": url, "dry_run": True}).json()
    assert seco["documentos"] == 4  # súmula conferida, lei vigente, doutrina, jurisprudência
    rel = cliente.post("/api/conhecimento/importar-ejc", json={"ejc_database_url": url}).json()
    assert rel["normas"] == 1 and rel["precedentes"] == 2 and rel["doutrina"] == 1
    assert rel["vetores_reaproveitados"] == 4 and rel["vetores_recalculados"] == 0
    p = cliente.get(f"/api/precedentes/ejc-{ids['sumula_ok']}").json()
    assert p["tipo"] == "sumula" and p["tribunal"] == "STJ" and p["verificado"]
    for proibido in ("cliente", "ficticio", "pendente", "lei_revogada", "sumula_nao_conferida"):
        assert cliente.get(f"/api/precedentes/ejc-{ids[proibido]}").status_code == 404
    est = cliente.get("/api/conhecimento/estatisticas").json()
    assert est["trechos_importados_do_ejc"] == 4
    r = cliente.get("/api/pesquisa/doutrina", params={"q": "comentário doutrinário"}).json()
    assert r and r[0]["origem"].startswith("ejc:")
    # reimportação é idempotente
    cliente.post("/api/conhecimento/importar-ejc", json={"ejc_database_url": url})
    assert cliente.get("/api/conhecimento/estatisticas").json()["trechos_importados_do_ejc"] == 4
