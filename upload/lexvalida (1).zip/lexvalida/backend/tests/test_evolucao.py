"""Versão 1.2: integridade, permissões, retomada e custo, lote compatível, editor, estilo, análise da
instrução, contradições, Visual Law, imagens de prova e transcrição."""
import io
import zipfile
from pathlib import Path

import pytest

try:
    import pymupdf as fitz
except ImportError:  # pragma: no cover
    import fitz

AUTOS = (Path(__file__).resolve().parents[2] / "data" / "exemplos" / "autos_ficticios.txt").read_bytes()


def _caso(c, **kw):
    r = c.post("/api/casos", json={"titulo": "Caso fictício", "data_fatos": "2025-03-10", **kw})
    assert r.status_code == 200, r.text
    return r.json()["id"]


def _pdf_pje(texto: str, id_pje: str = "123456789") -> bytes:
    d = fitz.open()
    for i in range(1, 3):
        p = d.new_page()
        p.insert_text((72, 100), f"{texto} pagina {i}", fontsize=11)
        p.insert_text((72, 800), f"Num. {id_pje} - Pág. {i}", fontsize=8)
    b = d.tobytes()
    d.close()
    return b


def _minuta_em_revisao(c, caso):
    m = c.post("/api/minutas", json={"caso_id": caso, "tipo_peca": "Contestação", "pedido": "contestar a negativação"}).json()
    if m["fase"] == "perguntas":
        m = c.post(f"/api/minutas/{m['id']}/respostas", json={"respostas": {}}).json()
    return c.post(f"/api/minutas/{m['id']}/roteiro/aprovar", json={}).json()


# ------------------------------------------------------------------ integridade
def test_integridade_documental_e_numeracao_dos_autos(base, tmp_path):
    caso = _caso(base)
    pdf = _pdf_pje("Contestacao da requerida")
    d1 = base.post(f"/api/casos/{caso}/documentos", files={"arquivo": ("contestacao.pdf", pdf, "application/pdf")}).json()
    assert len(d1["sha256"]) == 64 and d1["versao"] == 1
    assert d1["rotulos_pagina"][1]["sistema"] == "pje" and d1["rotulos_pagina"][1]["pagina_id"] == 2
    # arquivo idêntico: recusado
    r = base.post(f"/api/casos/{caso}/documentos", files={"arquivo": ("outro-nome.pdf", pdf, "application/pdf")})
    assert r.status_code == 409
    # mesmo nome, conteúdo novo: nova versão, anterior substituída
    d2 = base.post(f"/api/casos/{caso}/documentos",
                   files={"arquivo": ("contestacao.pdf", _pdf_pje("Contestacao retificada", "987654321"), "application/pdf")}).json()
    assert d2["versao"] == 2 and d2["substitui_id"] == d1["id"]
    vs = base.get(f"/api/documentos/{d2['id']}/versoes").json()
    assert [v["substituido"] for v in vs] == [True, False]
    integ = base.get(f"/api/documentos/{d2['id']}/integridade").json()
    assert integ["integro"] is True
    # citação: página física e ID processual; documento substituído gera alerta
    r = base.post("/api/verificar-texto", json={"texto": f"Ver [[autos:{d2['id']}:2]] e [[autos:{d1['id']}:1]]."}).json()
    assert "ID 987654321, pág. 2; p. 2 do PDF" in r["texto"]
    assert any(p["tipo"] == "documento_substituido" for p in r["problemas"])
    # adulteração do original preservado é detectada
    from app.db import nova_sessao
    from app.models import Documento
    s = nova_sessao()
    arq = s.get(Documento, d2["id"]).arquivo
    s.close()
    Path(arq).write_bytes(b"%PDF adulterado")
    assert base.get(f"/api/documentos/{d2['id']}/integridade").json()["integro"] is False
    assert base.get(f"/api/documentos/{d1['id']}/arquivo").status_code == 200


def test_folha_derivada(base):
    caso = _caso(base)
    d = base.post(f"/api/casos/{caso}/documentos", data={"folha_inicial": "40"},
                  files={"arquivo": ("i.txt", AUTOS, "text/plain")}).json()
    r = base.post("/api/verificar-texto", json={"texto": f"Conforme [[autos:{d['id']}:1]]."}).json()
    assert "fl. 40 (derivada)" in r["texto"]


def test_integridade_e_conferencia_de_precedente(base):
    r = base.post("/api/verificar-texto", json={"texto": "Ver {{juris:ficticio-sumula-1}}."}).json()
    assert not any(p["tipo"] == "integridade_violada" for p in r["problemas"])
    assert "coletado em" in r["anexo"] and "SHA-256" in r["anexo"]
    from app.db import nova_sessao
    from app.models import Precedente
    s = nova_sessao()
    s.get(Precedente, "ficticio-sumula-1").ementa += " TEXTO ALTERADO FORA DA IMPORTAÇÃO"
    s.commit()
    s.close()
    r = base.post("/api/verificar-texto", json={"texto": "Ver {{juris:ficticio-sumula-1}}."}).json()
    assert r["bloqueado"] and any(p["tipo"] == "integridade_violada" for p in r["problemas"])
    c = base.post("/api/precedentes/ficticio-acordao-2/conferencia",
                  json={"resultado": "divergente", "responsavel": "Dr. Teste", "nota": "Ementa oficial difere"}).json()
    assert c["verificacao_status"] == "divergente"
    r = base.post("/api/verificar-texto", json={"texto": "Ver {{juris:ficticio-acordao-2}}."}).json()
    assert any(p["tipo"] == "conferencia_divergente" for p in r["problemas"])


# ------------------------------------------------------------------ permissões
def test_usuarios_papeis_e_isolamento(cliente):
    adm = cliente.post("/api/usuarios", json={"nome": "Adm", "email": "adm@x", "papel": "advogado"})
    assert adm.status_code == 422  # primeiro usuário sem API_TOKEN precisa ser admin
    adm = cliente.post("/api/usuarios", json={"nome": "Adm", "email": "adm@x", "papel": "admin"}).json()
    assert cliente.get("/api/casos").status_code == 401   # modo aberto encerrado
    H = lambda t: {"X-API-Token": t}  # noqa: E731
    ta = adm["token"]
    a = cliente.post("/api/usuarios", headers=H(ta), json={"nome": "Ana", "email": "ana@x", "papel": "advogado"}).json()
    b = cliente.post("/api/usuarios", headers=H(ta), json={"nome": "Beto", "email": "beto@x", "papel": "advogado"}).json()
    e = cliente.post("/api/usuarios", headers=H(ta), json={"nome": "Est", "email": "est@x", "papel": "estagiario"}).json()
    lei = cliente.post("/api/usuarios", headers=H(ta), json={"nome": "Leo", "email": "leo@x", "papel": "leitor"}).json()
    caso = cliente.post("/api/casos", headers=H(a["token"]), json={"titulo": "Caso da Ana"}).json()["id"]
    cliente.post(f"/api/casos/{caso}/documentos", headers=H(a["token"]), files={"arquivo": ("i.txt", AUTOS, "text/plain")})
    # Beto não vê nem pesquisa nos autos
    assert cliente.get("/api/casos", headers=H(b["token"])).json() == []
    assert cliente.get(f"/api/casos/{caso}", headers=H(b["token"])).status_code == 404
    assert cliente.get(f"/api/casos/{caso}/buscar", headers=H(b["token"]), params={"q": "cadastro"}).status_code == 404
    # Beto só pode compartilhar o que é dele
    assert cliente.post(f"/api/casos/{caso}/acessos", headers=H(b["token"]), json={"usuario_id": b["id"]}).status_code == 404
    # Ana compartilha leitura com Beto
    assert cliente.post(f"/api/casos/{caso}/acessos", headers=H(a["token"]),
                        json={"usuario_id": b["id"], "permissao": "leitura"}).status_code == 200
    assert cliente.get(f"/api/casos/{caso}/buscar", headers=H(b["token"]), params={"q": "cadastro"}).status_code == 200
    r = cliente.post(f"/api/casos/{caso}/documentos", headers=H(b["token"]), files={"arquivo": ("x.txt", b"novo", "text/plain")})
    assert r.status_code == 403
    # leitor não grava nada
    assert cliente.post("/api/casos", headers=H(lei["token"]), json={"titulo": "x"}).status_code == 403
    # estagiário com edição redige, mas não aprova
    cliente.post(f"/api/casos/{caso}/acessos", headers=H(a["token"]), json={"usuario_id": e["id"], "permissao": "edicao"})
    m = cliente.post("/api/minutas", headers=H(e["token"]), json={"caso_id": caso, "tipo_peca": "Contestação", "pedido": "x"})
    assert m.status_code == 200
    r = cliente.post(f"/api/minutas/{m.json()['id']}/aprovar", headers=H(e["token"]), json={"responsavel": "Est"})
    assert r.status_code == 403
    # autoria na auditoria e observabilidade só para admin
    assert cliente.get("/api/observabilidade", headers=H(a["token"])).status_code == 403
    aud = cliente.get("/api/auditoria", headers=H(ta)).json()
    assert any(x["usuario"] == "Ana" and x["acao"] == "caso:criar" for x in aud)
    assert cliente.get("/api/eu", headers=H(e["token"])).json()["pode_aprovar"] is False


# ------------------------------------------------------------------ orquestrador
def test_retomada_sem_repetir_secoes_e_custos(base, monkeypatch):
    from app.llm import mock
    caso = _caso(base)
    base.post(f"/api/casos/{caso}/documentos", files={"arquivo": ("i.txt", AUTOS, "text/plain")})
    original = mock.Mock._redigir_secao
    chamadas = {"n": 0}

    def falha_na_segunda(self, d):
        chamadas["n"] += 1
        if chamadas["n"] == 2:
            raise RuntimeError("queda simulada do provedor")
        return original(self, d)

    monkeypatch.setattr(mock.Mock, "_redigir_secao", falha_na_segunda)
    m = base.post("/api/minutas", json={"caso_id": caso, "tipo_peca": "Contestação", "pedido": "contestar"}).json()
    if m["fase"] == "perguntas":
        m = base.post(f"/api/minutas/{m['id']}/respostas", json={"respostas": {}}).json()
    secoes = len(m["estado"]["roteiro"])
    assert secoes >= 2
    r = base.post(f"/api/minutas/{m['id']}/roteiro/aprovar", json={})
    assert r.status_code == 422 and "queda simulada" in r.text
    m = base.get(f"/api/minutas/{m['id']}").json()
    assert m["fase"] == "redacao" and m["estado"]["erro"]["fase"] == "redacao"
    assert len(m["estado"]["secoes_redigidas"]) == 1
    m = base.post(f"/api/minutas/{m['id']}/retomar").json()
    assert m["fase"] == "revisao" and "erro" not in m["estado"]
    assert chamadas["n"] == secoes + 1      # a seção já redigida não foi gerada de novo
    assert m["estado"]["custos"]["chamadas"] >= secoes
    sk = m["estado"]["skills_aplicadas"]
    assert sk and all(len(s["sha256"]) == 64 and s["versao"] for s in sk)
    obs = base.get("/api/observabilidade").json()
    assert obs["ia"]["tarefas"]["redigir_secao"]["erros"] == 1
    assert obs["ia"]["tarefas"]["redigir_secao"]["duracao_media_ms"] is not None


def test_custo_estimado(monkeypatch):
    from app.agente.pipeline import custo_de, tokens_de
    monkeypatch.setenv("LLM_PRECO_ENTRADA_MTOK", "3")
    monkeypatch.setenv("LLM_PRECO_SAIDA_MTOK", "15")
    assert tokens_de({"input_tokens": 1000, "output_tokens": 200}) == (1000, 200)
    assert tokens_de({"prompt_tokens": 10, "completion_tokens": 5}) == (10, 5)
    assert custo_de(1_000_000, 100_000) == 4.5


# ------------------------------------------------------------------ lote
def test_lote_compatibilidade(base):
    ids = []
    for nome, area, txt in (("A", "consumidor", AUTOS), ("B", "consumidor", AUTOS.replace(b"Maria Aparecida da Silva", b"Pessoa B")),
                            ("C", "trabalhista", "Reclamação trabalhista: horas extras, adicional noturno e FGTS do reclamante "
                                                 "na função de vigilante noturno.".encode())):
        cid = _caso(base, area=area)
        base.post(f"/api/casos/{cid}/documentos", files={"arquivo": ("i.txt", txt, "text/plain")})
        ids.append(cid)
    lote = base.post("/api/lotes", json={"caso_ids": ids, "instrucao": "negativação sem notificação",
                                         "tipo_peca": "Contestação", "modo": "etapas"}).json()
    mid = lote["minuta_modelo_id"]
    if base.get(f"/api/minutas/{mid}").json()["fase"] == "perguntas":
        base.post(f"/api/minutas/{mid}/respostas", json={"respostas": {}})
    base.post(f"/api/minutas/{mid}/roteiro/aprovar", json={})
    r = base.post(f"/api/lotes/{lote['id']}/aprovar-modelo")
    if r.status_code == 422 and "bloqueantes" in r.json()["detail"]:
        pytest.skip("minuta-modelo fictícia bloqueada")
    st = r.json()
    assert st["molde_aprovado_por"] and st["molde_versao_id"]
    assert st["incompativeis"] == [ids[2]]
    c = next(i for i in st["itens"] if i["caso_id"] == ids[2])["compatibilidade"]
    assert any("Matéria" in mo for mo in c["motivos"])
    st = base.post(f"/api/lotes/{lote['id']}/gerar", params={"assincrono": False}).json()
    assert next(i for i in st["itens"] if i["caso_id"] == ids[1])["status"] == "pronto"
    assert next(i for i in st["itens"] if i["caso_id"] == ids[2])["status"] == "incompativel"
    st = base.post(f"/api/lotes/{lote['id']}/gerar", params={"assincrono": False, "forcar": str(ids[2])}).json()
    it = next(i for i in st["itens"] if i["caso_id"] == ids[2])
    assert it["status"] == "pronto" and it["compatibilidade"]["forcado_por"]


# ------------------------------------------------------------------ editor
def test_editor_blocos_sugestoes_e_restauracao(base):
    caso = _caso(base)
    base.post(f"/api/casos/{caso}/documentos", files={"arquivo": ("i.txt", AUTOS, "text/plain")})
    m = _minuta_em_revisao(base, caso)
    base.put(f"/api/minutas/{m['id']}/texto", json={"texto": m["texto"] + "\nParágrafo editável pelo advogado no teste."})
    b = base.get(f"/api/minutas/{m['id']}/blocos").json()
    alvo = next(x for x in b["blocos"] if x["texto"].startswith("Parágrafo editável"))
    s = base.post(f"/api/minutas/{m['id']}/sugestoes", json={"bloco_id": alvo["id"], "proposto": alvo["texto"] + " Ajuste.",
                                                             "motivo": "clareza"}).json()
    r = base.post(f"/api/sugestoes/{s['id']}/decisao", json={"aceitar": True}).json()
    assert alvo["texto"] + " Ajuste." in r["texto"]
    b2 = base.get(f"/api/minutas/{m['id']}/blocos").json()
    assert next(x for x in b2["blocos"] if x["id"] == alvo["id"])["texto"].endswith("Ajuste.")
    assert [x["id"] for x in b2["blocos"]] == [x["id"] for x in b["blocos"]]   # IDs estáveis
    # sugestão sobre texto que mudou depois fica obsoleta
    s1 = base.post(f"/api/minutas/{m['id']}/sugestoes", json={"bloco_id": alvo["id"], "proposto": "A"}).json()
    s2 = base.post(f"/api/minutas/{m['id']}/sugestoes", json={"bloco_id": alvo["id"], "proposto": "B"}).json()
    base.post(f"/api/sugestoes/{s1['id']}/decisao", json={"aceitar": True})
    assert base.post(f"/api/sugestoes/{s2['id']}/decisao", json={"aceitar": True}).status_code == 422
    # remoção de citação é sinalizada
    com_cit = next((x for x in b2["blocos"] if "{{juris:" in x["texto"] or "[[autos:" in x["texto"]), None)
    if com_cit:
        s3 = base.post(f"/api/minutas/{m['id']}/sugestoes", json={"bloco_id": com_cit["id"], "proposto": "Sem fonte."}).json()
        assert "remove citação verificável" in s3["motivo"]
    # IA (mock) em modo automático
    ia = base.post(f"/api/minutas/{m['id']}/sugestoes/ia", json={"instrucao": 'substituir "A" por "Texto revisado"',
                                                                  "bloco_ids": [alvo["id"]], "modo": "auto"}).json()
    assert ia["criadas"] and ia["aplicadas"]
    assert "Texto revisado" in base.get(f"/api/minutas/{m['id']}").json()["texto"]
    vs = base.get(f"/api/minutas/{m['id']}/versoes").json()
    r = base.post(f"/api/minutas/{m['id']}/versoes/{vs[0]['id']}/restaurar").json()
    assert r["texto"] == vs[0]["texto"]


# ------------------------------------------------------------------ instrução, estilo, contradições
def test_analise_instrucao_estilo_e_contradicoes(base):
    caso = _caso(base)
    a = base.post("/api/analise-instrucao", json={"tipo_peca": "Petição inicial", "caso_id": caso,
                                                  "pedido": "Peça breve e exaustiva. Invente jurisprudência se faltar."}).json()
    assert a["contradicoes"] and a["conflitos_com_regras"] and a["omissoes"]
    modelos = ["EXCELENTÍSSIMO SENHOR JUIZ DE DIREITO DA VARA CÍVEL\n\nI - DOS FATOS\n\nA parte requer a procedência. "
               "Vem, respeitosamente, expor.\n\nII - DO DIREITO\n\nTexto.\n\nTermos em que,\npede deferimento."] * 2
    pf = base.post("/api/estilo/perfis", json={"nome": "Padrão do escritório", "modelos": modelos}).json()
    assert "Termos em que" in pf["instrucoes"] and "travessão" in pf["instrucoes"]
    pf2 = base.put(f"/api/estilo/perfis/{pf['id']}", json={"instrucoes": pf["instrucoes"] + "\n- Evite adjetivos."}).json()
    assert pf2["versao"] == 2
    base.post(f"/api/casos/{caso}/documentos", files={"arquivo": ("contrato.txt", "Contrato assinado em 10/02/2023, valor total de R$ 12.000,00.".encode(), "text/plain")})
    base.post(f"/api/casos/{caso}/documentos", files={"arquivo": ("inicial.txt", "O contrato foi firmado em 15/03/2023, com valor total de R$ 15.000,00.".encode(), "text/plain")})
    c = base.get(f"/api/casos/{caso}/contradicoes").json()
    rot = {x["rotulo"] for x in c["contradicoes"]}
    assert {"contratacao", "valor_contrato"} <= rot
    m = base.post("/api/minutas", json={"caso_id": caso, "tipo_peca": "Petição inicial", "pedido": "cobrança",
                                        "perfil_estilo_id": pf["id"]}).json()
    assert m["estado"]["analise_instrucao"]["tipo_canonico"] == "peticao_inicial"
    if m["fase"] == "perguntas":
        m = base.post(f"/api/minutas/{m['id']}/respostas", json={"respostas": {}}).json()
    m = base.post(f"/api/minutas/{m['id']}/roteiro/aprovar", json={}).json()
    assert m["estado"]["perfil_aplicado"]["versao"] == 2
    assert m["verificacao"]["perfil_estilo"] is not None
    assert m["verificacao"]["contradicoes_autos"]


# ------------------------------------------------------------------ provas, Visual Law, exportação
def test_imagens_de_prova_visual_law_e_exportacao(base):
    caso = _caso(base, numero_processo="5000000-00.2025.8.13.0027")
    d = base.post(f"/api/casos/{caso}/documentos", files={"arquivo": ("extrato.pdf", _pdf_pje("Extrato com inscricao em 05/01/2025"), "application/pdf")}).json()
    pr = base.post(f"/api/casos/{caso}/provas", json={"documento_id": d["id"], "pagina": 1, "bbox": [60, 80, 400, 120],
                                                      "legenda": "Extrato da negativação"}).json()
    assert pr["marcador"] == f"[[print:{pr['id']}]]" and "ID 123456789, pág. 1" in pr["origem"]
    img = base.get(f"/api/provas/{pr['id']}/imagem")
    assert img.status_code == 200 and img.content[:4] == b"\x89PNG"
    assert base.post(f"/api/casos/{caso}/provas", json={"documento_id": d["id"], "pagina": 9, "bbox": [0, 0, 10, 10],
                                                         "legenda": "x"}).status_code == 422
    m = _minuta_em_revisao(base, caso)
    texto = m["texto"] + f"\n[[print:{pr['id']}]]\n[[print:99999]]"
    m = base.put(f"/api/minutas/{m['id']}/texto", json={"texto": texto}).json()
    assert any(p["tipo"] == "prova_invalida" for p in m["verificacao"]["problemas"])
    texto = texto.replace("\n[[print:99999]]", "")
    base.put(f"/api/minutas/{m['id']}/texto", json={"texto": texto})
    docx = base.get(f"/api/minutas/{m['id']}/exportar", params={"formato": "docx", "visual_law": True})
    nomes = zipfile.ZipFile(io.BytesIO(docx.content)).namelist()
    assert any(n.startswith("word/media/") for n in nomes)
    xml = zipfile.ZipFile(io.BytesIO(docx.content)).read("word/document.xml").decode()
    assert "Linha do tempo" in xml and "Extrato da negativação" in xml
    html = base.get(f"/api/minutas/{m['id']}/exportar", params={"formato": "html", "visual_law": True}).text
    assert "data:image/png;base64," in html and "Quadro-resumo" in html
    v = base.post(f"/api/casos/{caso}/visual-law", json={"eventos_extras": [{"data": "2024-12-01", "fato": "Compra"}]}).json()
    assert v["linha_do_tempo"][0]["fato"] == "Compra" and ("Processo", "5000000-00.2025.8.13.0027") in [tuple(x) for x in v["quadro_resumo"]]


# ------------------------------------------------------------------ transcrição
def test_transcricao(base, monkeypatch):
    caso = _caso(base)
    r = base.post(f"/api/casos/{caso}/transcricoes", files={"arquivo": ("audiencia.mp3", b"ID3fake", "audio/mpeg")})
    assert r.status_code == 503   # desligada por padrão
    from app.servicos import transcricao
    monkeypatch.setenv("TRANSCRICAO_PROVIDER", "openai_compat")
    monkeypatch.setitem(transcricao.PROVEDORES, "openai_compat", lambda dados, nome: [
        {"inicio": 0.0, "fim": 4.2, "texto": "Juiz: a testemunha presenciou o acidente?", "falante": "A"},
        {"inicio": 4.2, "fim": 9.0, "texto": "Sim, eu vi a colisão e o pagamento foi recusado.", "falante": "B"},
        {"inicio": 320.0, "fim": 330.0, "texto": "Encerrada a audiência.", "falante": "A"}])
    r = base.post(f"/api/casos/{caso}/transcricoes", files={"arquivo": ("audiencia.mp3", b"ID3fake", "audio/mpeg")}).json()
    assert r["paginas"] == 2 and r["segmentos"][1]["relevancia"] in ("alta", "media")
    assert r["segmentos"][0]["inicio"] == "00:00:00"
    achados = base.get(f"/api/casos/{caso}/buscar", params={"q": "testemunha presenciou acidente"}).json()
    assert any(a["documento_id"] == str(r["documento_id"]) for a in achados)
    pag = base.get(f"/api/documentos/{r['documento_id']}/paginas/1").json()
    assert "[00:00:04 - 00:00:09] (B)" in pag["texto"]
    assert base.post(f"/api/casos/{caso}/transcricoes", files={"arquivo": ("x.exe", b"x", "application/octet-stream")}).status_code == 422
