import json
import os
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[2]
EXEMPLOS = RAIZ / "data" / "exemplos"

os.environ.setdefault("LLM_PROVIDER", "mock")
os.environ.setdefault("EMBEDDINGS_PROVIDER", "hash")
os.environ.setdefault("SKILLS_DIR", str(RAIZ / "skills"))


def _carregar(nome):
    return json.loads((EXEMPLOS / nome).read_text(encoding="utf-8"))


@pytest.fixture(params=["sqlite"] + (["postgres"] if os.getenv("PG_TEST_URL") else []))
def cliente(request, monkeypatch, tmp_path):
    from fastapi.testclient import TestClient

    from app import db as dbmod
    from app.servicos import recuperacao

    if request.param == "sqlite":
        url = f"sqlite:///{tmp_path / 'teste.db'}"
    else:
        url = os.environ["PG_TEST_URL"]
        from sqlalchemy import create_engine, text
        eng = create_engine(url.replace("postgresql://", "postgresql+psycopg://", 1))
        with eng.begin() as c:
            c.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public;"))
        eng.dispose()
    monkeypatch.setenv("DATABASE_URL", url)
    monkeypatch.setenv("ARQUIVOS_DIR", str(tmp_path / "arquivos"))
    dbmod._engine = dbmod._Session = None
    recuperacao.resetar_memoria()
    from app.main import app
    with TestClient(app) as c:
        c.dialeto = request.param
        yield c
    recuperacao.resetar_memoria()


@pytest.fixture
def base(cliente):
    r = cliente.post("/api/conhecimento/precedentes", json=_carregar("precedentes_ficticios.json"))
    assert r.status_code == 200 and not r.json()["erros"], r.text
    r = cliente.post("/api/conhecimento/normas", json=_carregar("normas_ficticias.json"))
    assert r.status_code == 200 and not r.json()["erros"], r.text
    return cliente
