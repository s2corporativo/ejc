"""Importa a base pública aprovada do EJC para o LexValida (somente leitura no EJC).

Uso (dentro do container do backend):
    python -m scripts.importar_ejc --ejc-url postgresql://usuario:senha@host:5432/ejc --dry-run
    python -m scripts.importar_ejc --ejc-url ...            # importa
Opções:
    --sem-exigir-aprovado   inclui documentos sem rag_status=aprovado (NÃO recomendado)
    --categoria legislacao  restringe a categorias (repetível)
    --revetorizar           ignora os vetores do EJC e recalcula localmente
"""
from __future__ import annotations

import argparse
import json

from app.db import init_engine, nova_sessao
from app.servicos import importador_ejc


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ejc-url", default=None)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--sem-exigir-aprovado", action="store_true")
    ap.add_argument("--categoria", action="append")
    ap.add_argument("--limite", type=int, default=100000)
    ap.add_argument("--revetorizar", action="store_true")
    ap.add_argument("--modelo-ejc", default=None, help="Modelo de embedding usado no EJC (padrão: o mesmo deste sistema)")
    a = ap.parse_args()
    init_engine()
    db = nova_sessao()
    try:
        rel = importador_ejc.importar(db, a.ejc_url, not a.sem_exigir_aprovado, a.categoria, a.limite,
                                      not a.revetorizar, a.modelo_ejc, a.dry_run)
        print(json.dumps(rel, ensure_ascii=False, indent=2, default=str))
    finally:
        db.close()


if __name__ == "__main__":
    main()
