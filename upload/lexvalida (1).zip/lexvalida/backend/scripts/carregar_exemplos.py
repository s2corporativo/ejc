"""Carrega os registros FICTÍCIOS de demonstração (identificados com [FICTÍCIO]). Não usar em produção."""
from __future__ import annotations

import json
from pathlib import Path

from app.db import init_engine, nova_sessao
from app.servicos import conhecimento

EX = Path(__file__).resolve().parents[2] / "data" / "exemplos"


def main() -> None:
    init_engine()
    db = nova_sessao()
    try:
        for p in json.loads((EX / "precedentes_ficticios.json").read_text(encoding="utf-8")):
            conhecimento.importar_precedente(db, p)
        for n in json.loads((EX / "normas_ficticias.json").read_text(encoding="utf-8")):
            conhecimento.importar_norma(db, n)
        print("Exemplos fictícios carregados.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
