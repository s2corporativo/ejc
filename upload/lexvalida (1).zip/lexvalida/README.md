# LexValida

Sistema independente de inteligência jurídica com **camada de validade jurídica**. A IA redige; o sistema verifica se cada citação existe, se o precedente ainda vale, se a norma é a vigente na data dos fatos, se o trecho dos autos está realmente na página indicada e se o precedente sustenta a afirmação feita. Nada sai como aprovado sem o advogado.

O RAG reaproveita a arquitetura do EJC: PostgreSQL com pgvector `vector(1024)` e índice HNSW, `intfloat/multilingual-e5-large` via fastembed (mesmo pin `0.8.0`), chunker jurídico por artigo e seção, e fusão RRF (k=60) das pernas vetorial, trigram e full-text. Há também um importador da base pública aprovada do EJC que reaproveita os embeddings já calculados.

> Toda saída de IA é **rascunho**. A responsabilidade pela peça é de quem a revisa e assina (EOAB, art. 32).

---

## 1. O que o sistema faz

| Módulo | Função | Base normativa aplicada |
|---|---|---|
| Protocolo de citação | A IA só emite `{{juris:ID}}`, `{{lei:ID}}` e `[[autos:DOC:PÁG\|"trecho"]]`. O sistema substitui pelo texto da base e monta anexo com ementa e dispositivo íntegros. ID inexistente bloqueia a minuta. | CPC, art. 489, § 1º |
| Status do precedente | Vigente, modulado, afetado, em revisão, superado ou cancelado. Superado e cancelado bloqueiam a citação. | CPC, arts. 927, §§ 2º a 4º, e 1.037, II |
| Hierarquia | Ordenação por força vinculante: controle concentrado, súmula vinculante, repercussão geral e repetitivos, súmulas, órgão especial, depois acórdãos. | CPC, art. 927 |
| Vigência temporal | Norma com versões no tempo; aplica a redação vigente na data dos fatos e alerta quando difere da atual. | LINDB, art. 6º |
| Aderência da tese | Verificador independente classifica: apoia, apoia parcialmente, distinguível, contrário ou irrelevante. "Contrário" bloqueia. | CPC, art. 489, § 1º, V e VI |
| Matriz fato, prova e ônus | Cada alegação com a prova candidata nos autos e a quem cabe o ônus. | CPC, art. 373; CDC, art. 6º, VIII; CLT, art. 818 |
| Prazos | Dias úteis, suspensão de 20/12 a 20/01, DJe, portal, dobras legais, prazos penais corridos, com memória de cálculo. | CPC, arts. 219, 220, 224, 180, 183, 186, 229; Lei 11.419/2006, art. 5º; CPP, art. 798 |
| Prescrição | Catálogo restrito a prazos de previsão expressa, interrupção única, contagem em anos. | CC, arts. 132, § 3º, 202, 205, 206; CDC, art. 27; CF, art. 7º, XXIX |
| Cálculos | Correção e juros com séries fornecidas pelo usuário (nenhum índice é presumido), aritmética decimal e memória linha a linha. | CC, art. 406 (taxa legal, com piso zero do § 3º) |
| Simulação do julgador | Checklist estrutural de admissibilidade por tipo de peça. | CPC, arts. 319, 337, 341, 489, 1.003, 1.007, 1.010, 932, III |
| Crítica adversarial | A IA verificadora assume a parte contrária e aponta vulnerabilidades. | |
| Prompt injection, camada 1 | Inspeção gráfica do PDF (render mode 3, opacidade, cor quase branca, fora da página, fonte < 1 pt) e classificador que trata o trecho como dado. O documento fica bloqueado até decisão humana. | ISO 32000 |
| Prompt injection, camada 2 | Auditoria do raciocínio do redator contra as regras invariantes e o pedido do usuário (quando o provedor expõe raciocínio). | |
| Sigilo | Caso sigiloso só usa IA local (Ollama, vLLM). Pseudonimização reversível com correferência de nomes e alerta de identificadores indiretos. | LGPD, arts. 6º, III, 12 e 46; EOAB, art. 7º, II |
| Agente com supervisão | Planejar, perguntar, aprovar roteiro, pesquisar (com reformulação), redigir por seção, verificar, revisão humana. | |
| Modo Molde e lote em etapas | A IA edita o modelo aprovado por operações pontuais de ocorrência única. Citações herdadas ficam protegidas; cada minuta do lote tem diff e percentual preservado. | |
| Habilidades | `SKILL.md` auditáveis, seleção em dois estágios, fixação obrigatória, edição do usuário com versão e mescla em três vias com a oficial. | |
| Retroalimentação | Registro de desfecho por minuta (teses acolhidas e rejeitadas, precedentes decisivos). Estatística descritiva, sem previsão. | |
| Auditoria | Toda chamada de IA, decisão de segurança, alteração de status e aprovação fica registrada. | |

### Módulos de inteligência (versão 1.1)

| Módulo | Função | Base normativa aplicada |
|---|---|---|
| Monitor de precedentes | Mudança de status de precedente gera alerta em toda minuta e caso que o cita; minutas aprovadas são reverificadas de forma determinística. | CPC, arts. 927, §§ 2º a 4º |
| Temas afetados | Cadastro de repetitivos, repercussão geral e IRDR/IAC com assuntos TPU; cruzamento com os casos e alerta de suspensão. | CPC, arts. 982, I, 1.035, § 5º, e 1.037, II |
| Intimações (DJEN) | Captura por OAB na Comunica API, vínculo automático ao caso pelo número CNJ, extração do prazo do teor, cálculo com memória e alerta crítico (até 3 dias) ou de atenção (até 7 dias). Geração de minuta a partir da intimação. | CPC, arts. 219, 224 e 231; Lei 11.419/2006, art. 4º |
| DataJud | Consulta pública de processo, enriquecimento do caso (classe e assuntos TPU, órgão, movimentos) e jurimetria descritiva por tribunal, município, classe, assunto e órgão. | Res. CNJ 331/2020 |
| Tabelas Processuais Unificadas | Pesquisa de assuntos, classes e movimentos no SGT do CNJ. | Res. CNJ 46/2007 |
| STJ dados abertos | Importação de espelhos de acórdãos do portal CKAN do STJ para a base. | |
| Distinguishing | Ratio estruturada do precedente (fatos materiais, questão, tese) cruzada com os fatos do caso; indica distinção ou aderência com fundamentação. | CPC, art. 489, § 1º, VI |
| Vedação à decisão surpresa | Aponta fundamentos da decisão (prescrição, decadência, ilegitimidade e outras matérias de ofício) sem registro nos autos. | CPC, arts. 9º, 10 e 487, parágrafo único |
| Valor da causa | Cálculo por tipo de pedido, cumulados, alternativos e subsidiários, prestações vencidas e vincendas, com memória. | CPC, art. 292, I a VIII e §§ 1º a 3º |
| Prescrição intercorrente | Rito do CPC e da LEF: suspensão de 1 ano, prazo da pretensão, interrupção e advertência de oitiva prévia. | CPC, art. 921, §§ 1º, 4º, 4º-A e 5º; Lei 6.830/1980, art. 40; STJ, Súmula 314 |
| Tutela de urgência | Checklist de probabilidade do direito, perigo de dano, reversibilidade e caução. | CPC, art. 300 |
| Teses de massa | Mapa de taxa de acolhimento por tese, parte contrária e assunto, com amostra mínima de 5 desfechos. Estatística descritiva. | |
| Licitações | Prazo de impugnação (3 dias úteis antes da abertura), recurso e contrarrazões, matriz de habilitação com validade das certidões na data da sessão, e alerta de exigência sem previsão legal (ex.: Serasa ou SPC). | Lei 14.133/2021, arts. 62 a 70, 164 e 165 |
| Ambiental (TCFA) | Habilidade com o regime da taxa de controle e fiscalização ambiental. | Lei 6.938/1981, arts. 17-B a 17-D |
| Trabalhista | Liquidação delegada ao motor do EJC por API (sem duplicar o cálculo). | |
| Peticionamento | Pré-checagem do PDF: senha, camada de texto, tamanho frente ao limite do tribunal, JavaScript, anexos embutidos, texto oculto e nome de arquivo. | Res. CNJ 185/2013 (PJe) |
| Conformidade LGPD | Registro das operações derivado da auditoria e rascunho de RIPD a partir da configuração efetiva. | LGPD, arts. 37, 38 e 41 |
| Avaliação contínua | Conjunto de referência (citações, prazos, RAG, aderência) com acurácia por tipo e recall@k. | |
| Rotina automática | Monitor e captura do DJEN dos últimos 7 dias a cada `MONITOR_INTERVALO_HORAS`. | |

### Rastreabilidade, edição e governança (versão 1.2)

| Módulo | Função | Critério de aceite atendido |
|---|---|---|
| Integridade documental | SHA-256 de cada arquivo, original preservado em `ARQUIVOS_DIR`, recusa de arquivo idêntico, versões do mesmo documento (a anterior fica marcada como substituída e gera alerta se citada), conferência de integridade sob demanda. | Documento mantém origem rastreável |
| Página do PDF x numeração dos autos | Reconhece carimbos do PJe (`Num. ... - Pág. ...`), eproc (`Evento ..., PEÇA, Página ...`) e folhas (`fls. ...`), ou deriva a folha de uma folha inicial informada. A citação sai como "(nome, ID 123, pág. 2; p. 5 do PDF)". | Evita link errado em PDF composto |
| Registro de citações | Precedente e redação de norma com data de coleta e SHA-256 do texto; ementa alterada fora da importação bloqueia; conferência humana com a fonte oficial ("conferido" ou "divergente", que bloqueia). | Referência alterada não sai como verificada |
| Usuários e isolamento | Papéis admin, advogado, estagiário e leitor; token individual guardado só como hash; casos visíveis apenas ao dono, a quem recebeu acesso e ao admin (casos, autos, busca, minutas, provas, intimações, alertas, teses de massa). Estagiário não aprova (EOAB, art. 3º, § 2º). | Usuário sem acesso não recupera trechos de outro caso |
| Orquestrador com retomada | Cada seção redigida é gravada; após falha, `POST /api/minutas/{id}/retomar` continua sem repetir pesquisa nem seções concluídas. | Interrupção retoma sem nova geração indevida |
| Custo e tempo | Tokens, duração e custo estimado por chamada (preços em `LLM_PRECO_*_MTOK`) na auditoria e na minuta; painel de observabilidade com média, p95, erros, fontes e aprovações por responsável. | Resultado explicável por registros |
| Habilidades auditáveis | Cada execução registra slug, versão, origem (oficial ou do usuário) e SHA-256 do conteúdo aplicado. | Execução registra a versão usada |
| Lote com compatibilidade | Ao aprovar o molde (autor, data e versão registrados), cada processo é comparado ao modelo: matéria, polo, tribunal, classe, assuntos TPU e similaridade dos autos. Incompatível não herda o molde, salvo decisão expressa registrada. | Não mistura fatos entre processos |
| Editor por blocos | Blocos com ID estável, sugestões da IA ou de pessoas ancoradas no bloco (aceitar, rejeitar, obsoleta se o bloco mudou), modo automático que nunca remove citação verificável, restauração de qualquer versão. | Edição localizada preserva o restante |
| Mapa do caso | Contradições entre documentos (datas e valores rotulados com localização), exibidas também na verificação da minuta. | Contradições aparecem antes da aprovação |
| Análise da instrução | Antes de gerar: contradições, conflito com as regras do sistema, omissões por tipo de peça (CPC, arts. 319, 335, 337, 1.003, 1.007, 300) e excesso. | |
| Perfil de estilo | Métricas dos modelos do escritório viram instruções editáveis e versionadas; a peça gerada é conferida contra o perfil. | |
| Visual Law | Quadro-resumo e linha do tempo com fatos datados dos autos (com página) ou informados pelo advogado, no DOCX e em HTML. | |
| Imagens de prova | Recorte de área do PDF original (conferido pelo SHA-256), com legenda, origem e hash, inserido por `[[print:ID]]` e embutido no DOCX e no HTML. Não atesta autenticidade do documento. | |
| Transcrição | Áudio e vídeo por endpoint compatível ou faster-whisper local; marcação temporal, páginas de 5 minutos, relevância indicativa por trecho; vira documento pesquisável e citável. | |

**Primeiro acesso com usuários:** sem `API_TOKEN`, o sistema roda aberto em modo local até o primeiro usuário ser criado; esse primeiro usuário precisa ser admin, e o token exibido na criação deve ser guardado (não é armazenado). Com `API_TOKEN`, ele funciona como acesso de administrador técnico.

### Assistente único e núcleo de inteligência (versão 1.3)

A tela inicial é o **Assistente**: o advogado escreve o que precisa ou envia um documento; o sistema identifica o pedido, pergunta só o que falta e devolve o resultado com a base legal. As telas técnicas ficam em "Ferramentas avançadas".

| Recurso | Como funciona | Base |
|---|---|---|
| Entendimento do pedido | Classificador determinístico de intenção e de área (tabela portada do núcleo EJC) + extração de número CNJ, OAB, datas (inclusive "ontem" e por extenso), dias de prazo, valores, artigos de lei e súmulas. IA só desempata, se houver provedor real. | |
| Triagem de documento | Identifica sentença, decisão, acórdão, citação, intimação, edital, auto de infração, contrato e outros; sugere a providência com o prazo legal e oferece calcular o prazo e redigir a peça. | CPC, arts. 335, 350, 351, 1.003, § 5º, 1.009, 1.015, 1.023, 1.029; Lei 9.099/1995, arts. 12-A, 42, 49; Decreto 6.514/2008, art. 113; Lei 9.784/1999, art. 66; Lei 14.133/2021, arts. 164 e 165 (conferidos no texto oficial) |
| Ações do assistente | Resumo do dia, prazo, intimação colada, redação (planejamento, roteiro, redação, verificação), processo no DataJud (cria ou atualiza o caso), texto de lei, súmula, pesquisa, verificação de texto, prescrição, intercorrente, valor da causa, licitação, contradições, projetos de lei e jurimetria. | |
| Legislação oficial | Coleta do texto compilado do Planalto, artigo por artigo e verbatim, citável como `{{lei:cpc-art-219}}`, com SHA-256 e data de coleta. 31 diplomas no catálogo. | |
| Monitor legislativo | Proposições da Câmara (API v2) e do Senado (Dados Abertos) por tema. Projetos não são lei vigente. | |
| Pacote de migração do EJC | Importa o ZIP gerado por `export_ejc_knowledge.py`: valida manifesto e SHA-256, aplica o gate de governança, nunca importa conteúdo de caso ou cliente, regenera vetores. | LGPD, art. 6º, III |
| Salvaguardas portadas do EJC | Delimitador anti-injeção com token aleatório em todo conteúdo de terceiros; alerta de promessa de resultado; prescrição ou decadência tratadas como "sem resolução de mérito" geram correção proposta no editor; cumulação de vício e fato no CDC; orçamento de chamadas e custo por minuta. | CPC, art. 487, II; CDC, arts. 26 e 27 |

Fontes não portadas: o LexML exige verificação anti-robô (não contornada) e a busca do TJMG depende de formulário web; ficam fora.

### Fontes oficiais e chaves

| Fonte | Acesso | Situação no teste |
|---|---|---|
| DataJud (CNJ) | Chave **pública** publicada pelo CNJ na wiki oficial. O sistema a descobre sozinho (cache de 24 h) e renova em caso de 401, pois o CNJ pode trocá-la. `DATAJUD_API_KEY` fixa a chave, se preferir. | Verificado ao vivo (processo do TJMG e agregação de jurimetria) |
| SGT/TPU (CNJ) | SOAP público, sem chave. | Verificado ao vivo (assunto, classe e movimento) |
| DJEN (Comunica API) | Pública, sem chave. Bloqueia IPs fora do Brasil: o servidor precisa de IP brasileiro. | Não alcançável do ambiente de teste (bloqueio geográfico); coberto por testes com fixture no contrato usado em produção pelo EJC |
| STJ dados abertos (CKAN) | Pública, sem chave. | Não alcançável do ambiente de teste; coberto por fixture |
| EJC (liquidação) | `EJC_API_URL` e `EJC_API_TOKEN` de um usuário de equipe do EJC. | Coberto por teste com resposta simulada |
| Provedores de IA | Chave **própria** do escritório (`LLM_API_KEY`, `VERIFICADOR_API_KEY`). Não há chave pública para isso. | Sem chave, o sistema roda com o provedor `mock` |

Teste ao vivo opcional: `LIVE=1 python3 -m pytest -k ao_vivo`.

## 2. Arquitetura

```
frontend/ (HTML + JS, servido pelo backend)
backend/app/
  core/        regras determinísticas e puras (prazos, cálculos, prescrição, citações, molde, ônus,
               julgador, ingestão e anti-injeção, pseudonimização, chunker e embeddings do EJC)
  servicos/    conhecimento, recuperação híbrida (pgvector ou memória), documentos, habilidades,
               importador do EJC, auditoria
  agente/      máquina de estados do agente e geração em lote
  llm/         provedores (anthropic, openai_compat, mock) e prompts auditáveis
  servicos/    (1.2) acesso, editor, provas, transcricao, observabilidade
  integracoes/ clientes oficiais: DataJud, TPU (SGT), DJEN, STJ CKAN, API do EJC
  api/         rotas FastAPI
skills/        habilidades oficiais (SKILL.md)
data/exemplos/ registros FICTÍCIOS para demonstração e testes
```

### Recuperação (paridade com o EJC)

| Item | EJC | LexValida |
|---|---|---|
| Vetor | `knowledge_chunks.embedding vector(1024)`, HNSW cosseno | `trechos.vetor vector(1024)`, HNSW cosseno |
| Modelo | multilingual-e5-large, fastembed 0.8.0, prefixos `query:`/`passage:` | igual (código portado de `embedding_service.py`) |
| Limiar | `RAG_MIN_SIM` 0,55; `hnsw.ef_search` 100 | iguais |
| Léxico | pg_trgm `similarity` + FTS opcional (`plainto_tsquery`) | pg_trgm + FTS ligado por padrão, com consulta em OR dos lexemas (melhor recall) |
| Fusão | RRF k=60 | RRF k=60 |
| Chunking | `legal_chunker.py`, teto = janela do modelo (1.800 caracteres) | portado sem alteração de regra |
| Governança | gate fail-closed por `rag_status`, revogação, súmulas conferidas, fictício | aplicado na importação, mais status de precedente e vigência por versão |

Sem PostgreSQL (desenvolvimento), a recuperação roda em memória (BM25 + cosseno + RRF) com a mesma interface.

## 3. Instalação

### Produção (Docker)

```bash
cp .env.example .env        # edite senha, API_TOKEN e provedores de IA
docker compose up -d --build
docker compose exec backend python -m scripts.importar_ejc --dry-run   # usa EJC_DATABASE_URL
docker compose exec backend python -m scripts.importar_ejc
```

A API e a interface ficam em `http://127.0.0.1:${LEXVALIDA_PORTA}`. Publique por Nginx com TLS; não exponha a porta diretamente.

No primeiro uso o fastembed baixa o modelo (cerca de 2,3 GB), guardado no volume `lexvalida_modelos`. O `mem_limit` do compose limita a memória, em linha com o incidente de OOM registrado no EJC.

### Usuário somente leitura no banco do EJC

```sql
CREATE ROLE leitor_lexvalida LOGIN PASSWORD '...';
GRANT CONNECT ON DATABASE ejc TO leitor_lexvalida;
GRANT USAGE ON SCHEMA public TO leitor_lexvalida;
GRANT SELECT ON knowledge_docs, knowledge_chunks TO leitor_lexvalida;
```

Além disso, o importador abre a conexão com `default_transaction_read_only=on`. Os dois sistemas precisam enxergar a mesma rede Docker, ou o banco do EJC precisa ser alcançável pelo host.

### Desenvolvimento

```bash
cd backend
pip install -r requirements-dev.txt
export LLM_PROVIDER=mock EMBEDDINGS_PROVIDER=hash
python -m scripts.carregar_exemplos      # registros FICTÍCIOS
uvicorn app.main:app --reload
pytest                                    # SQLite
PG_TEST_URL=postgresql://... EJC_TEST_URL=postgresql://... pytest   # também PostgreSQL e importador
```

## 4. Provedores de IA

| Variável | Uso |
|---|---|
| `LLM_PROVIDER=anthropic` | `LLM_MODEL`, `LLM_API_KEY` |
| `LLM_PROVIDER=openai_compat` | Ollama, vLLM, LM Studio, Groq, OpenAI: `LLM_BASE_URL` (ex.: `http://ollama:11434/v1`), `LLM_MODEL`, `LLM_API_KEY` |
| `VERIFICADOR_*` | Provedor diferente do redator para aderência, auditoria e crítica adversarial (recomendado) |
| `LOCAL_LLM_*` | Obrigatório para casos sigilosos; sem ele, a nuvem fica bloqueada para esses casos |
| `LLM_PROVIDER=mock` | Offline e determinístico, sem conhecimento jurídico. Só para testes e demonstração |

## 5. Formatos de dados

**Precedente** (`POST /api/conhecimento/precedentes`, lista):
```json
{"id": "stj-sumula-385", "tribunal": "STJ", "tipo": "sumula", "numero": "385",
 "rotulo": "STJ, Súmula 385", "ementa": "<texto oficial íntegro>", "tese": "<opcional>",
 "status": "vigente", "fonte_url": "<URL oficial>", "verificado": true,
 "verificado_por": "Nome", "verificado_em": "2026-10-01",
 "relacoes": [{"destino": "norma:cdc-art-43-p2", "tipo": "interpreta"}]}
```
Tipos: `controle_concentrado`, `sumula_vinculante`, `repercussao_geral`, `repetitivo`, `irdr_iac`, `sumula`, `orgao_especial`, `sumula_tribunal`, `acordao`, `monocratica`.

**Norma** (`POST /api/conhecimento/normas`, lista), com versões sem sobreposição:
```json
{"id": "cc-art-206-p3-v", "diploma": "Código Civil (Lei 10.406/2002)", "dispositivo": "art. 206, § 3º, V",
 "rotulo": "CC, art. 206, § 3º, V", "fonte_url": "<URL oficial>", "verificado": true,
 "versoes": [{"texto": "<redação oficial>", "vigencia_inicio": "2003-01-11"}]}
```

**Habilidade**: ver `skills/`. Frontmatter `slug`, `titulo`, `tipo` (forma ou matéria), `area`, `descricao`, `gatilhos`, `revisado_em`.

## 6. Fluxo do agente

1. `POST /api/minutas`: plano e perguntas. O caso é bloqueado se houver documento com suspeita de injeção pendente de decisão.
2. `POST /api/minutas/{id}/respostas`: roteiro.
3. `POST /api/minutas/{id}/roteiro/aprovar`: pesquisa, redação por seção e verificação (`?assincrono=true` para processar em segundo plano).
4. `PUT /api/minutas/{id}/texto`: edição humana com nova verificação.
5. `POST /api/minutas/{id}/aprovar`: só sem bloqueios e com ciência expressa dos alertas.
6. `GET /api/minutas/{id}/exportar?formato=docx`.

Documentação interativa completa em `/docs`.

## 7. Limitações declaradas

- **Base vazia por padrão.** O sistema não traz jurisprudência nem legislação reais: importe do EJC (base conferida) ou de fontes oficiais. Os exemplos em `data/exemplos` são fictícios e marcados como tal.
- **OCR.** Páginas digitalizadas sem camada de texto são sinalizadas (`paginas_sem_texto_ocr_necessario`), mas não convertidas. Use o OCR do EJC ou um `ocrmypdf` prévio.
- **Pseudonimização.** A detecção de nomes é heurística (sem modelo NER treinado). Revise o cofre antes de enviar à nuvem. Para segredo de justiça, prefira IA local.
- **Camada 2 de segurança.** Depende de o provedor expor o raciocínio; caso contrário, o indicador mostra `nao_auditado`.
- **Reranker.** Não incluído. O modelo cross-encoder do fastembed avaliado no EJC (bge-reranker-base) tem licença CC-BY-NC-4.0, como registrado no próprio EJC.
- **Vigência da redação coletada do Planalto.** O texto compilado mostra só a redação atual; a citação alerta que o início de vigência não foi curado.
- **Assistente.** O entendimento é por regras e palavras-chave; pedidos fora do repertório recebem pergunta de esclarecimento, não resposta inventada.
- **Itens não implementados:** extensão de navegador para captura nos sistemas dos tribunais, edição simultânea por várias pessoas, paginação visual idêntica ao Word no editor.
- **Contradições e linha do tempo.** Extração por palavras-chave e proximidade: são indícios para conferência. Valores distintos podem ser legítimos (parcelas, aditivos).
- **Transcrição.** Depende de provedor configurado; não há identificação biométrica de falantes, e rótulos de falante do provedor não comprovam identidade. Confira com a mídia antes de citar.
- **Volume de arquivos.** Os originais em `ARQUIVOS_DIR` (volume `lexvalida_arquivos` no Docker) precisam entrar na rotina de backup junto com o banco.
- **Esquema do banco.** Não há migrações: as versões 1.1, 1.2 e 1.3 alteraram tabelas (`casos`, `documentos`, `precedentes`, `normas_versoes`, `lotes`, `auditoria`) e criaram `alertas`, `intimacoes`, `usuarios`, `acessos_caso`, `sugestoes`, `perfis_estilo`, `provas_imagem`, `fontes_coleta`, `proposicoes`, `conversas` e `mensagens_assistente`. Instale em banco novo ou recrie o esquema de um banco de testes; em produção, faça backup e migração validada antes de atualizar.
- **Jurimetria e teses de massa.** São estatística descritiva. Movimento de julgamento no DataJud não equivale ao desfecho final (há recursos e reformas), e a cobertura depende do envio dos tribunais.
- **Temas.** Cadastro manual com link oficial; não há raspagem de portais de tribunais.
- **Prazo extraído da intimação.** A extração por expressão regular é indicativa; sempre confira o teor e o prazo legal aplicável.
- **Limites de peticionamento.** Variam por tribunal e sistema; configure `PETICIONAMENTO_LIMITE_MB` conforme a norma local.
- **Aderência heurística.** Sem IA verificadora, a classificação usa sobreposição léxica e é apenas indicativa.
