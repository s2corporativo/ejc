"use strict";
const $ = (s, el = document) => el.querySelector(s);
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const tok = $("#token");
try { tok.value = sessionStorage.getItem("lv_token") || ""; } catch (_) {}
tok.addEventListener("change", () => { try { sessionStorage.setItem("lv_token", tok.value); } catch (_) {} quemSou(); });

async function api(caminho, opcoes = {}) {
  const headers = { ...(opcoes.headers || {}) };
  if (tok.value) headers["X-API-Token"] = tok.value;
  if (opcoes.json !== undefined) { headers["Content-Type"] = "application/json"; opcoes.body = JSON.stringify(opcoes.json); }
  const r = await fetch(caminho, { ...opcoes, headers });
  const tipo = r.headers.get("content-type") || "";
  const dados = tipo.includes("json") ? await r.json() : await r.text();
  if (!r.ok) {
    const d = typeof dados === "object" ? dados.detail ?? dados : dados;
    throw new Error(typeof d === "string" ? d : Array.isArray(d) ? d.map((x) => `${(x.loc || []).join(".")}: ${x.msg}`).join("; ") : JSON.stringify(d));
  }
  return dados;
}
async function baixar(caminho, nome) {
  const headers = tok.value ? { "X-API-Token": tok.value } : {};
  const r = await fetch(caminho, { headers });
  if (!r.ok) { const t = await r.text(); throw new Error(t.slice(0, 300)); }
  const url = URL.createObjectURL(await r.blob());
  const a = document.createElement("a"); a.href = url; a.download = nome; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
function abrirHtml(html) {
  const url = URL.createObjectURL(new Blob([html], { type: "text/html" }));
  window.open(url, "_blank", "noopener"); setTimeout(() => URL.revokeObjectURL(url), 60000);
}
async function quemSou() {
  try { const e = await api("/api/eu"); $("#eu").textContent = `${e.nome} (${e.papel})`; } catch (err) { $("#eu").textContent = "não autenticado"; }
}
function form(el) {
  const o = {};
  for (const [k, v] of new FormData(el).entries()) o[k] = v;
  el.querySelectorAll("input[type=checkbox]").forEach((c) => (o[c.name] = c.checked));
  return o;
}
function limpar(o) { for (const k of Object.keys(o)) if (o[k] === "") delete o[k]; return o; }
async function acao(botao, fn, saida) {
  if (botao) botao.disabled = true;
  try { await fn(); } catch (e) { if (saida) saida.innerHTML = `<div class="card erro">${esc(e.message)}</div>`; else alert(e.message); }
  finally { if (botao) botao.disabled = false; }
}
const nivel = (n) => (n === "bloqueante" ? "erro" : n === "alerta" ? "alerta" : "ok");

// ---------------------------------------------------------------- abas
document.querySelectorAll("#abas button[data-aba]").forEach((b) =>
  b.addEventListener("click", () => {
    document.querySelectorAll("#abas button[data-aba], .aba").forEach((x) => x.classList.remove("ativa"));
    b.classList.add("ativa");
    $("#" + b.dataset.aba).classList.add("ativa");
    ({ painel: painel, casos: casos, minuta: carregarMinutas, habilidades: skills, base: fontesLista, assistente: assistCasos, alertas: () => { alertasLista().catch(() => {}); intimacoesLista().catch(() => {}); quemSou(); } })[b.dataset.aba]?.();
  }));

// ---------------------------------------------------------------- painel
async function painel() {
  try {
    const s = await api("/api/saude");
    $("#saude").innerHTML = [
      ["Banco", `${s.banco}${s.pgvector ? " + pgvector " + s.pgvector : ""}`],
      ["Embeddings", `${s.embeddings.provider} / ${s.embeddings.modelo} (${s.embeddings.dimensao}d) ${s.embeddings.ok ? "" : "INDISPONÍVEL"}`],
      ["IA redatora", s.llm.redator], ["IA verificadora", s.llm.verificador],
      ["IA local para sigilo", s.llm.local_para_sigilo ? "configurada" : "não configurada"],
    ].map(([k, v]) => `<div class="card"><div class="meta">${esc(k)}</div><strong>${esc(v)}</strong></div>`).join("");
    const e = await api("/api/conhecimento/estatisticas");
    $("#estat").innerHTML = Object.entries(e).map(([k, v]) =>
      `<div class="card"><div class="meta">${esc(k.replaceAll("_", " "))}</div><strong>${esc(typeof v === "object" ? JSON.stringify(v) : v)}</strong></div>`).join("");
  } catch (err) { $("#saude").innerHTML = `<div class="card erro">${esc(err.message)}</div>`; }
}

// ---------------------------------------------------------------- casos
async function casos() {
  const lista = await api("/api/casos").catch(() => []);
  const sel = $("#sel-caso");
  sel.innerHTML = `<option value="">Sem caso vinculado</option>` + lista.map((c) => `<option value="${c.id}">#${c.id} ${esc(c.titulo)}</option>`).join("");
  $("#lista-casos").innerHTML = lista.map((c) => `
    <div class="card"><h4>#${c.id} ${esc(c.titulo)} ${c.sigiloso ? '<span class="etq alerta">sigiloso</span>' : ""}</h4>
      <div class="meta">Área: ${esc(c.area || "-")} | Data dos fatos: ${esc(c.data_fatos || "não informada")} | Processo: ${esc(c.numero_processo || "-")}</div>
      <div class="linha"><input type="file" data-caso="${c.id}" accept=".pdf,.txt"><input type="number" min="1" data-folha="${c.id}" placeholder="Folha inicial (opcional)" style="width:190px">
        <button class="sec" data-enviar="${c.id}">Enviar aos autos</button></div>
      ${c.documentos.map((d) => docHtml(d)).join("")}
      <details><summary>Mapa do caso, provas, transcrição e Visual Law</summary>
        <div class="linha"><button type="button" class="sec" data-get="/api/casos/${c.id}/contradicoes">Contradições entre documentos</button>
          <button type="button" class="sec" data-get="/api/casos/${c.id}/provas">Imagens de prova</button>
          <button type="button" class="sec" data-get="/api/casos/${c.id}/acessos">Quem tem acesso</button></div><div class="saida"></div>
        <form class="api linha" data-metodo="POST" data-rota="/api/casos/{caso_id}/visual-law?formato=html">
          <input type="hidden" name="caso_id" data-t="int" value="${c.id}"><input name="eventos_extras" data-t="json" placeholder='Fatos extras: [{"data":"2025-01-10","fato":"..."}]' class="largo">
          <button>Linha do tempo e quadro-resumo</button></form><div class="saida"></div>
        <form class="api linha" data-metodo="POST" data-rota="/api/casos/{caso_id}/provas">
          <input type="hidden" name="caso_id" data-t="int" value="${c.id}"><input name="documento_id" data-t="int" placeholder="Doc" style="width:70px" required>
          <input name="pagina" data-t="int" placeholder="Pág. do PDF" style="width:100px" required>
          <input name="bbox" data-t="listanum" placeholder="Área x0,y0,x1,y1 (pontos)" required><input name="legenda" placeholder="Legenda" required>
          <button>Recortar prova</button></form><div class="saida"></div>
        <form class="api linha" data-metodo="POST" data-rota="/api/casos/${c.id}/transcricoes" data-arquivos="arquivo" data-depois="casos">
          <input type="file" name="arquivo" accept="audio/*,video/*" required><button>Transcrever áudio ou vídeo</button></form><div class="saida"></div>
        <form class="api linha" data-metodo="POST" data-rota="/api/casos/{caso_id}/acessos">
          <input type="hidden" name="caso_id" data-t="int" value="${c.id}"><input name="usuario_id" data-t="int" placeholder="ID do usuário" required>
          <select name="permissao"><option value="leitura">Leitura</option><option value="edicao">Edição</option></select><button>Compartilhar caso</button></form><div class="saida"></div>
      </details>
    </div>`).join("") || `<p class="nota">Nenhum caso cadastrado.</p>`;
}
function docHtml(d) {
  const s = d.seguranca || {};
  const ocultos = (s.candidatos_ocultos || []).filter((c) => c.risco === "alto");
  const num = (d.rotulos_pagina || []).find((r) => r.sistema);
  return `<div class="card"><strong>Doc ${d.id}: ${esc(d.nome)}</strong> (${d.paginas} p., ${esc(d.tipo || "")}) <span class="etq">v${d.versao ?? 1}</span>
    ${d.substituido ? '<span class="etq alerta">substituído por versão mais recente</span>' : ""}
    <span class="meta">SHA-256 ${esc((d.sha256 || "").slice(0, 16))}${num ? " | numeração: " + esc(num.sistema) : ""}</span>
    <button type="button" class="sec" data-integridade="${d.id}">Conferir integridade</button>
    ${d.tipo !== "transcricao" ? `<button type="button" class="sec" data-original="${d.id}" data-nome="${esc(d.nome)}">Baixar original</button>` : ""}
    <div class="saida"></div>
    ${d.liberado_para_ia ? '<span class="etq ok">liberado para IA</span>' : '<span class="etq erro">aguarda decisão de segurança</span>'}
    ${s.paginas_sem_texto_ocr_necessario?.length ? `<div class="etq alerta">OCR necessário nas p. ${s.paginas_sem_texto_ocr_necessario.join(", ")}</div>` : ""}
    ${ocultos.length ? `<div class="nota">Texto oculto com instrução à IA:</div><ul class="lim">${ocultos.map((c) =>
      `<li>p. ${c.pagina}: <code>${esc(c.texto)}</code> <span class="etq erro">${esc(c.sinais.join(", "))}</span></li>`).join("")}</ul>
      <button data-decidir="${d.id}" data-trechos='${esc(JSON.stringify(ocultos.map((c) => c.texto)))}'>Remover trechos e liberar</button>` : ""}
    ${(s.injecoes_texto_visivel || []).map((v) => `<div class="etq alerta">p. ${v.pagina}: possível instrução visível (${esc(v.categorias.join(", "))})</div>`).join("")}
  </div>`;
}
$("#f-caso").addEventListener("submit", (ev) => { ev.preventDefault();
  acao(ev.submitter, async () => { await api("/api/casos", { method: "POST", json: limpar(form(ev.target)) }); ev.target.reset(); await casos(); }); });
$("#lista-casos").addEventListener("click", (ev) => {
  const b = ev.target.closest("button"); if (!b) return;
  if (b.dataset.enviar) acao(b, async () => {
    const arq = $(`input[data-caso="${b.dataset.enviar}"]`).files[0]; if (!arq) throw new Error("Selecione um arquivo.");
    const fd = new FormData(); fd.append("arquivo", arq);
    const folha = $(`input[data-folha="${b.dataset.enviar}"]`).value; if (folha) fd.append("folha_inicial", folha);
    await api(`/api/casos/${b.dataset.enviar}/documentos`, { method: "POST", body: fd }); await casos(); });
  if (b.dataset.integridade) { const out = b.parentElement.querySelector(".saida");
    acao(b, async () => { out.innerHTML = exibir(await api(`/api/documentos/${b.dataset.integridade}/integridade`)); }, out); }
  if (b.dataset.original) acao(b, () => baixar(`/api/documentos/${b.dataset.original}/arquivo`, b.dataset.nome));
  if (b.dataset.decidir) acao(b, async () => {
    await api(`/api/documentos/${b.dataset.decidir}/decisao-seguranca`, { method: "POST", json: { remover_trechos: JSON.parse(b.dataset.trechos), liberar: true } });
    await casos(); });
});

// ---------------------------------------------------------------- minuta
async function carregarMinutas() {
  await casos();
  const pf = await api("/api/estilo/perfis").catch(() => []);
  $("#sel-perfil").innerHTML = `<option value="">Sem perfil de estilo</option>` + pf.map((p) => `<option value="${p.id}">${esc(p.nome)} (v${p.versao})</option>`).join("");
  const l = await api("/api/minutas").catch(() => []);
  $("#sel-minuta").innerHTML = l.map((m) => `<option value="${m.id}">#${m.id} ${esc(m.tipo_peca)} (${m.fase}, ${m.status})</option>`).join("");
}
$("#f-minuta").addEventListener("submit", (ev) => { ev.preventDefault();
  acao(ev.submitter, async () => {
    const f = form(ev.target);
    const m = await api("/api/minutas", { method: "POST", json: {
      caso_id: f.caso_id ? Number(f.caso_id) : null, tipo_peca: f.tipo_peca, pedido: f.pedido,
      skills_fixadas: (f.skills_fixadas || "").split(",").map((x) => x.trim()).filter(Boolean),
      anonimizar_autos: f.anonimizar_autos, gerar_peca_contraria: f.gerar_peca_contraria,
      perfil_estilo_id: f.perfil_estilo_id ? Number(f.perfil_estilo_id) : null } });
    render(m); carregarMinutas(); }, $("#area-minuta")); });
$("#analisar-instr").addEventListener("click", (ev) => { const out = $("#res-analise");
  acao(ev.target, async () => {
    const f = form($("#f-minuta"));
    out.innerHTML = analiseHtml(await api("/api/analise-instrucao", { method: "POST", json: {
      tipo_peca: f.tipo_peca || "", pedido: f.pedido || "", caso_id: f.caso_id ? Number(f.caso_id) : null } }));
  }, out); });
function analiseHtml(a) {
  if (!a) return "";
  const l = (t, xs, cls) => xs?.length ? `<div><strong>${t}</strong><ul class="lim">${xs.map((x) => `<li class="${cls}">${esc(x)}</li>`).join("")}</ul></div>` : "";
  return `<div class="card"><h4>Análise da instrução ${a.ok ? '<span class="etq ok">sem pontos de atenção</span>' : ""}</h4>
    ${l("Contradições", a.contradicoes, "erro")}${l("Conflito com as regras do sistema", a.conflitos_com_regras, "erro")}
    ${l("Omissões", a.omissoes, "alerta")}${l("Excesso", a.excesso, "alerta")}${l("Perguntas sugeridas", a.perguntas_sugeridas, "")}</div>`;
}
$("#abrir-minuta").addEventListener("click", (ev) => acao(ev.target, async () => render(await api(`/api/minutas/${$("#sel-minuta").value}`)), $("#area-minuta")));

function render(m) {
  const e = m.estado || {}, alvo = $("#area-minuta");
  let h = `<div class="card"><h4>Minuta #${m.id}: ${esc(m.tipo_peca)}</h4><span class="etq">${esc(m.fase)}</span><span class="etq ${m.status === "APROVADA" ? "ok" : "alerta"}">${esc(m.status)}</span>
    ${e.plano ? `<div class="meta">${esc(e.plano.resumo_caso || "")}</div><div><strong>Estratégia:</strong> ${esc(e.plano.estrategia || "")}</div>` : ""}
    ${(e.plano?.alertas || []).map((a) => `<div class="etq alerta">${esc(a)}</div>`).join("")}</div>`;
  if (e.erro) h += `<div class="card erro">Falha na etapa ${esc(e.erro.fase || "")}: ${esc(e.erro.mensagem || e.erro)}
    <div class="linha"><button id="retomar">Retomar do ponto de parada</button></div></div>`;
  if (e.analise_instrucao && !e.analise_instrucao.ok && m.fase !== "revisao") h += analiseHtml(e.analise_instrucao);
  if (m.fase === "perguntas") {
    h += `<form id="f-resp" class="card coluna"><h4>Perguntas do agente</h4>${(e.perguntas || []).map((p) => `
      <label>${esc(p.pergunta)}</label>${p.opcoes?.length ? `<select name="${esc(p.id)}">${p.opcoes.map((o) => `<option>${esc(o)}</option>`).join("")}</select>` : `<input name="${esc(p.id)}">`}`).join("")}
      <button>Responder e gerar roteiro</button></form>`;
  }
  if (m.fase === "aprovar_roteiro") {
    h += `<div class="card"><h4>Roteiro proposto (edite o JSON se necessário)</h4>
      <textarea id="rot" rows="10">${esc(JSON.stringify(e.roteiro, null, 2))}</textarea>
      <div class="linha"><button id="aprovar-rot">Aprovar roteiro, pesquisar e redigir</button></div></div>`;
  }
  if ((m.fase === "pesquisa" || m.fase === "redacao") && !e.erro) h += `<div class="card">Processando. Use "Abrir minuta" para atualizar.</div>`;
  if (m.fase === "revisao") h += revisaoHtml(m);
  alvo.innerHTML = h;
  $("#f-resp")?.addEventListener("submit", (ev) => { ev.preventDefault();
    acao(ev.submitter, async () => render(await api(`/api/minutas/${m.id}/respostas`, { method: "POST", json: { respostas: form(ev.target) } })), alvo); });
  $("#aprovar-rot")?.addEventListener("click", (ev) => acao(ev.target, async () =>
    render(await api(`/api/minutas/${m.id}/roteiro/aprovar`, { method: "POST", json: { secoes: JSON.parse($("#rot").value) } })), alvo));
  $("#salvar-txt")?.addEventListener("click", (ev) => acao(ev.target, async () =>
    render(await api(`/api/minutas/${m.id}/texto`, { method: "PUT", json: { texto: $("#txt").value } })), alvo));
  $("#aprovar-min")?.addEventListener("click", (ev) => acao(ev.target, async () =>
    render(await api(`/api/minutas/${m.id}/aprovar`, { method: "POST", json: { responsavel: $("#resp").value, ciente_alertas: $("#ciente").checked } })), alvo));
  $("#retomar")?.addEventListener("click", (ev) => acao(ev.target, async () => render(await api(`/api/minutas/${m.id}/retomar`, { method: "POST" })), alvo));
  alvo.querySelectorAll("[data-exp]").forEach((b) => b.addEventListener("click", () =>
    acao(b, async () => {
      const q = b.dataset.exp;
      if (q.startsWith("html")) abrirHtml(await api(`/api/minutas/${m.id}/exportar?formato=${q}`));
      else await baixar(`/api/minutas/${m.id}/exportar?formato=${q}`, `minuta-${m.id}.${q.split("&")[0]}`);
    }, null)));
  $("#abrir-editor")?.addEventListener("click", (ev) => acao(ev.target, () => editorAbrir(m.id), $("#area-editor")));
}

// ---------------------------------------------------------------- editor por blocos
async function editorAbrir(mid) {
  const b = await api(`/api/minutas/${mid}/blocos`);
  const pend = b.sugestoes.filter((s) => s.status === "pendente");
  const vs = await api(`/api/minutas/${mid}/versoes`);
  $("#area-editor").innerHTML = `
    <form class="linha" id="f-ia"><input name="instrucao" class="largo" placeholder='Instrução à IA (ex.: substituir "X" por "Y", tornar mais conciso)' required>
      <select name="modo"><option value="minuta">Sugerir para minha decisão</option><option value="auto">Aplicar automaticamente</option></select><button>Pedir sugestões</button></form>
    ${pend.length ? `<h4>Sugestões pendentes</h4>${pend.map((s) => `<div class="card"><span class="etq">${esc(s.bloco_id)}</span><span class="meta">${esc(s.autor)}</span> ${esc(s.motivo)}
      <div class="erro"><del>${esc(s.original)}</del></div><div class="ok">${esc(s.proposto)}</div>
      <div class="linha"><button data-sug="${s.id}" data-aceitar="1">Aceitar</button><button class="sec" data-sug="${s.id}" data-aceitar="0">Rejeitar</button></div></div>`).join("")}` : ""}
    <h4>Blocos (clique para propor alteração)</h4>
    <div>${b.blocos.filter((x) => x.texto.trim()).map((x) => `<div class="bloco" data-bloco="${x.id}"><span class="meta">${x.id}</span> ${esc(x.texto)}</div>`).join("")}</div>
    <h4>Versões</h4><table><tr><th>#</th><th>Autor</th><th>Nota</th><th>Data</th><th></th></tr>${vs.map((v) =>
      `<tr><td>${v.id}</td><td>${esc(v.autor)}</td><td>${esc(v.nota)}</td><td>${esc(v.criado_em.slice(0, 16))}</td><td><button class="sec" data-restaurar="${v.id}">Restaurar</button></td></tr>`).join("")}</table>`;
  const area = $("#area-editor");
  $("#f-ia").addEventListener("submit", (ev) => { ev.preventDefault();
    acao(ev.submitter, async () => { await api(`/api/minutas/${mid}/sugestoes/ia`, { method: "POST", json: form(ev.target) }); await editorAbrir(mid); }, area); });
  area.onclick = (ev) => {
    const s = ev.target.closest("[data-sug]"), r = ev.target.closest("[data-restaurar]"), bl = ev.target.closest("[data-bloco]");
    if (s) acao(s, async () => { await api(`/api/sugestoes/${s.dataset.sug}/decisao`, { method: "POST", json: { aceitar: s.dataset.aceitar === "1" } }); render(await api(`/api/minutas/${mid}`)); await editorAbrir(mid); }, area);
    else if (r) acao(r, async () => { await api(`/api/minutas/${mid}/versoes/${r.dataset.restaurar}/restaurar`, { method: "POST" }); render(await api(`/api/minutas/${mid}`)); await editorAbrir(mid); }, area);
    else if (bl && !bl.querySelector("textarea")) {
      const atual = bl.textContent.replace(bl.dataset.bloco, "").trim();
      bl.insertAdjacentHTML("beforeend", `<textarea rows="3">${esc(atual)}</textarea><input placeholder="Motivo"><button>Propor</button>`);
      bl.querySelector("button").onclick = (e2) => { e2.stopPropagation(); acao(e2.target, async () => {
        await api(`/api/minutas/${mid}/sugestoes`, { method: "POST", json: { bloco_id: bl.dataset.bloco, proposto: bl.querySelector("textarea").value, motivo: bl.querySelector("input").value } });
        await editorAbrir(mid); }, area); };
    }
  };
}
function revisaoHtml(m) {
  const v = m.verificacao || {}, e = m.estado || {}, seg = v.seguranca || {};
  const probs = (v.problemas || []).map((p) => `<li><span class="etq ${nivel(p.nivel)}">${esc(p.nivel)}</span>${esc(p.mensagem)}</li>`).join("");
  const ader = (v.aderencia || []).map((a) => `<tr><td>${esc(a.rotulo)}</td><td>${esc(a.afirmacao)}</td><td><span class="etq ${a.classificacao === "apoia" ? "ok" : "alerta"}">${esc(a.classificacao)}</span></td><td class="meta">${esc(a.justificativa)}</td></tr>`).join("");
  const jul = (v.julgador?.checklist || []).map((c) => `<li>${c.atendido ? "✓" : "✗"} ${esc(c.item)} <span class="meta">(${esc(c.base)})</span></li>`).join("");
  const contra = (e.peca_contraria?.vulnerabilidades || []).map((x) => `<li><span class="etq ${x.gravidade === "alta" ? "erro" : "alerta"}">${esc(x.gravidade)}</span><strong>${esc(x.ponto)}</strong>: ${esc(x.argumento_adverso)} <span class="meta">Reforço: ${esc(x.como_reforcar)}</span></li>`).join("");
  const sk = (e.skills_aplicadas || []).map((s) => `<span class="etq ${s.obrigatoria ? "ok" : ""}" title="SHA-256 ${esc(s.sha256 || "")}">${esc(s.titulo)} v${s.versao ?? "?"} ${s.confianca}</span>`).join("");
  const cu = v.custos || e.custos;
  const est = v.perfil_estilo;
  const contr = (v.contradicoes_autos || []).map((c) => `<li class="alerta">${esc(c.mensagem)}</li>`).join("");
  return `
  <div class="card"><h4>Verificação ${v.bloqueado ? '<span class="etq erro">BLOQUEADA</span>' : '<span class="etq ok">sem bloqueio</span>'}
    <span class="etq ${seg.indicador === "seguro" ? "ok" : "alerta"}">segurança: ${esc(seg.indicador)}</span></h4>
    <ul class="lim">${probs || "<li>Nenhum problema.</li>"}</ul>
    ${v.pendencias?.length ? `<div class="nota">Pendências no texto:</div><ul class="lim">${v.pendencias.map((p) => `<li>${esc(p)}</li>`).join("")}</ul>` : ""}
    <div class="meta">Habilidades aplicadas: ${sk || "nenhuma"}</div>
    ${cu ? `<div class="meta">IA: ${cu.chamadas} chamadas, ${cu.tokens_entrada + cu.tokens_saida} tokens, ${(cu.duracao_ms / 1000).toFixed(1)} s${cu.custo_estimado ? `, custo estimado ${cu.custo_estimado}` : ""}</div>` : ""}
    ${est ? `<div class="meta">Perfil de estilo: ${esc(est.aplicado?.nome || "")} v${est.aplicado?.versao ?? ""} ${(est.desvios || []).map((d) => `<span class="etq alerta">${esc(d)}</span>`).join("") || '<span class="etq ok">sem desvios</span>'}</div>` : ""}</div>
  ${contr ? `<div class="card"><h4>Contradições entre documentos dos autos (conferir)</h4><ul class="lim">${contr}</ul></div>` : ""}
  ${ader ? `<div class="card"><h4>Aderência da tese (verificador independente)</h4><table><tr><th>Precedente</th><th>Afirmação</th><th>Resultado</th><th>Justificativa</th></tr>${ader}</table></div>` : ""}
  <div class="card"><h4>Simulação do julgador</h4><ul class="lim">${jul || "<li>Sem checklist para este tipo.</li>"}</ul></div>
  ${contra ? `<div class="card"><h4>Crítica da parte adversa</h4><ul class="lim">${contra}</ul></div>` : ""}
  <div class="card"><h4>Texto com marcadores (editável)</h4><textarea id="txt" rows="16">${esc(m.texto)}</textarea>
    <div class="linha"><button id="salvar-txt">Salvar e verificar novamente</button><button class="sec" id="abrir-editor">Editor por blocos e sugestões</button></div>
    <div id="area-editor"></div></div>
  <div class="card"><h4>Texto resolvido</h4><pre>${esc(m.texto_resolvido)}</pre>
    <div class="linha"><button class="sec" data-exp="docx">DOCX</button><button class="sec" data-exp="docx&visual_law=true">DOCX com Visual Law</button>
      <button class="sec" data-exp="html&visual_law=true">HTML com Visual Law</button><button class="sec" data-exp="txt">TXT</button></div></div>
  ${m.status !== "APROVADA" ? `<div class="card linha"><input id="resp" placeholder="Advogado responsável (nome e OAB)"><label class="chk"><input id="ciente" type="checkbox"> Li e assumo os alertas</label><button id="aprovar-min">Aprovar minuta</button></div>` : `<div class="card ok">Aprovada por ${esc(m.aprovada_por)}</div>`}
  <div class="card"><h4>Rastro do agente</h4><pre>${esc(JSON.stringify(e.buscas || [], null, 1))}</pre></div>`;
}

// ---------------------------------------------------------------- pesquisa
$("#f-pesq").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-pesq");
  acao(ev.submitter, async () => {
    const f = form(ev.target);
    if (f.fonte === "jurisprudencia") {
      const r = await api(`/api/pesquisa/jurisprudencia?${new URLSearchParams(limpar({ q: f.q, tribunal: f.tribunal }))}`);
      out.innerHTML = r.resultados.map((x) => `<div class="card"><h4>${esc(x.rotulo)}</h4>
        <span class="etq">${esc(x.hierarquia || x.tipo)}</span><span class="etq ${x.status === "vigente" ? "ok" : "alerta"}">${esc(x.status)}</span>
        ${x.verificado ? '<span class="etq ok">verificado</span>' : '<span class="etq alerta">não verificado</span>'}
        <span class="meta">RRF ${x.rrf} | vetor ${x.rank_vetorial ?? "-"} | lexical ${x.rank_fts ?? x.rank_lexical ?? "-"}</span>
        ${x.alerta_status ? `<div class="etq alerta">${esc(x.alerta_status)}</div>` : ""}
        ${x.tese ? `<div><strong>Tese:</strong> ${esc(x.tese)}</div>` : ""}<pre>${esc(x.ementa)}</pre>
        <div class="meta">Marcador: <code>${esc(x.marcador)}</code></div></div>`).join("") +
        (r.excluidos_por_status.length ? `<div class="card alerta">Excluídos por status: ${r.excluidos_por_status.map((x) => esc(x.rotulo + " (" + x.status + ")")).join("; ")}</div>` : "") || `<p class="nota">Sem resultados.</p>`;
    } else if (f.fonte === "legislacao") {
      const r = await api(`/api/pesquisa/legislacao?${new URLSearchParams(limpar({ q: f.q, data_fatos: f.data_fatos }))}`);
      out.innerHTML = r.resultados.map((x) => `<div class="card"><h4>${esc(x.rotulo)}</h4>
        ${x.alertas.map((a) => `<div class="etq alerta">${esc(a)}</div>`).join("")}
        <div class="meta">Redação em ${esc(x.data_referencia)}:</div><pre>${esc(x.texto_na_data_dos_fatos || "sem versão vigente")}</pre>
        <div class="meta">Marcador: <code>${esc(x.marcador)}</code></div></div>`).join("") || `<p class="nota">Sem resultados.</p>`;
    } else {
      const r = await api(`/api/pesquisa/${f.fonte}?${new URLSearchParams({ q: f.q })}`);
      out.innerHTML = r.map((x) => `<div class="card"><h4>${esc(x.titulo || x.fonte_id)}</h4><span class="meta">${esc(x.origem || "")}</span><pre>${esc(x.trecho)}</pre></div>`).join("") || `<p class="nota">Sem resultados.</p>`;
    }
  }, out); });

// ---------------------------------------------------------------- ferramentas
function memoria(r) {
  return `<div class="card">${Object.entries(r).filter(([k]) => !["memoria", "alertas"].includes(k)).map(([k, v]) => `<span class="etq">${esc(k)}: ${esc(v)}</span>`).join("")}
    <ol>${(r.memoria || []).map((l) => `<li>${esc(l)}</li>`).join("")}</ol>${(r.alertas || []).map((a) => `<div class="etq alerta">${esc(a)}</div>`).join("")}</div>`;
}
$("#f-prazo").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-prazo");
  acao(ev.submitter, async () => {
    const f = form(ev.target); const feriados = {};
    (f.feriados || "").split(",").map((x) => x.trim()).filter(Boolean).forEach((d) => (feriados[d] = "Feriado local informado"));
    out.innerHTML = memoria(await api("/api/prazos", { method: "POST", json: { data_evento: f.data_evento, dias: Number(f.dias), termo: f.termo,
      contagem: f.contagem, em_dobro: !!f.motivo_dobro, motivo_dobro: f.motivo_dobro || null, feriados_extras: feriados,
      usar_dias_forenses_usuais: f.usar_dias_forenses_usuais } }));
  }, out); });
api("/api/prescricao/catalogo").then((c) => { $("#sel-presc").innerHTML = Object.entries(c).map(([k, v]) => `<option value="${k}">${esc(v.descricao)} (${v.anos} anos, ${esc(v.base)})</option>`).join(""); }).catch(() => {});
$("#f-presc").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-presc");
  acao(ev.submitter, async () => { out.innerHTML = memoria(await api("/api/prescricao", { method: "POST", json: limpar(form(ev.target)) })); }, out); });
$("#f-verif").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-verif");
  acao(ev.submitter, async () => {
    const r = await api("/api/verificar-texto", { method: "POST", json: limpar(form(ev.target)) });
    out.innerHTML = `<div class="card">${r.bloqueado ? '<span class="etq erro">BLOQUEADO</span>' : '<span class="etq ok">sem bloqueio</span>'}
      <ul class="lim">${r.problemas.map((p) => `<li><span class="etq ${nivel(p.nivel)}">${esc(p.nivel)}</span>${esc(p.mensagem)}</li>`).join("")}</ul>
      <pre>${esc(r.texto)}\n\n${esc(r.anexo)}</pre></div>`;
  }, out); });
$("#f-anon").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-anon");
  acao(ev.submitter, async () => {
    const r = await api("/api/anonimizar", { method: "POST", json: { texto: form(ev.target).texto } });
    out.innerHTML = `<div class="card"><pre>${esc(r.texto)}</pre><h4>Cofre (guarde localmente; não é armazenado)</h4><pre>${esc(JSON.stringify(r.cofre.entradas, null, 1))}</pre>
      ${r.alertas.map((a) => `<div class="etq alerta">${esc(a)}</div>`).join("")}</div>`;
  }, out); });

// ---------------------------------------------------------------- lotes
function loteHtml(l) {
  return `<div class="card"><h4>Lote #${l.id} (${esc(l.modo)}): ${esc(l.fase)}</h4>
    ${l.minuta_modelo_id ? `<div class="meta">Minuta-modelo #${l.minuta_modelo_id}: conduza-a na aba Minuta até a revisão.</div>` : ""}
    ${l.molde_aprovado_por ? `<div class="meta">Molde aprovado por ${esc(l.molde_aprovado_por)} em ${esc((l.molde_aprovado_em || "").slice(0, 16))} (versão #${l.molde_versao_id})</div>` : ""}
    <div class="linha"><button data-l="aprovar">Aprovar minuta-modelo</button><button class="sec" data-l="gerar">Gerar demais</button><button class="sec" data-l="falhas">Repetir falhas</button>
      ${l.incompativeis?.length ? `<input id="forcar" placeholder="Forçar casos incompatíveis: ${l.incompativeis.join(",")}"><button class="sec" data-l="forcar">Gerar pelo molde mesmo assim</button>` : ""}</div>
    <table><tr><th>Caso</th><th>Status</th><th>Minuta</th><th>Preservado</th><th>Alterações frente ao molde</th></tr>
    ${l.itens.map((i) => `<tr><td>${i.caso_id}${i.modelo ? " (modelo)" : ""}</td><td>${esc(i.status)} ${i.erro ? `<span class="etq erro">${esc(i.erro)}</span>` : ""}
      ${(i.compatibilidade?.motivos || []).map((x) => `<div class="etq erro">${esc(x)}</div>`).join("")}${(i.compatibilidade?.alertas || []).map((x) => `<div class="etq alerta">${esc(x)}</div>`).join("")}</td>
      <td>${i.minuta_id ?? "-"} ${i.bloqueado ? '<span class="etq erro">bloqueada</span>' : ""}</td><td>${i.preservado_pct ?? "-"}%</td>
      <td>${i.alteracoes.slice(0, 6).map((d) => `<div class="${d.tipo === "removido" ? "erro" : "ok"}">${d.tipo === "removido" ? "-" : "+"} ${esc(d.texto)}</div>`).join("")}</td></tr>`).join("")}</table></div>`;
}
async function verLote(id) { const l = await api(`/api/lotes/${id}`); $("#res-lote").innerHTML = loteHtml(l); $("#lote-id").value = id; }
$("#f-lote").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-lote");
  acao(ev.submitter, async () => {
    const f = form(ev.target);
    const l = await api("/api/lotes", { method: "POST", json: { caso_ids: f.caso_ids.split(",").map((x) => Number(x.trim())).filter(Boolean),
      caso_modelo_id: f.caso_modelo_id ? Number(f.caso_modelo_id) : null, tipo_peca: f.tipo_peca, instrucao: f.instrucao, modo: "etapas" } });
    out.innerHTML = loteHtml(l); $("#lote-id").value = l.id;
  }, out); });
$("#ver-lote").addEventListener("click", (ev) => acao(ev.target, () => verLote($("#lote-id").value), $("#res-lote")));
$("#res-lote").addEventListener("click", (ev) => {
  const b = ev.target.closest("button[data-l]"); if (!b) return; const id = $("#lote-id").value;
  acao(b, async () => {
    if (b.dataset.l === "aprovar") await api(`/api/lotes/${id}/aprovar-modelo`, { method: "POST" });
    else if (b.dataset.l === "forcar") await api(`/api/lotes/${id}/gerar?forcar=${encodeURIComponent($("#forcar").value)}`, { method: "POST" });
    else await api(`/api/lotes/${id}/gerar?apenas_falhas=${b.dataset.l === "falhas"}`, { method: "POST" });
    await verLote(id);
  }, $("#res-lote"));
});

// ---------------------------------------------------------------- habilidades
async function skills() {
  const l = await api("/api/skills").catch(() => []);
  $("#lista-skills").innerHTML = `<table><tr><th>Habilidade</th><th>Tipo</th><th>Versão</th><th>Origem</th></tr>${l.map((s) =>
    `<tr><td><a href="#" data-s="${s.id}">${esc(s.titulo)}</a><div class="meta">${esc(s.descricao)}</div></td><td>${esc(s.tipo)}</td><td>${s.versao}</td><td>${s.oficial ? "oficial" : "sua versão"}</td></tr>`).join("")}</table>`;
}
$("#lista-skills").addEventListener("click", async (ev) => {
  const a = ev.target.closest("a[data-s]"); if (!a) return; ev.preventDefault();
  const s = await api(`/api/skills/${a.dataset.s}`);
  $("#det-skill").innerHTML = `<div class="card"><h4>${esc(s.titulo)} <span class="etq">${esc(s.slug)}</span></h4>
    <div class="meta">Gatilhos: ${esc((s.gatilhos || []).join(", "))}</div><textarea id="sk-txt" rows="16">${esc(s.conteudo)}</textarea>
    <div class="linha"><button id="sk-fork">Salvar minha versão</button></div></div>`;
  $("#sk-fork").addEventListener("click", (e2) => acao(e2.target, async () => {
    await api(`/api/skills/${encodeURIComponent(s.slug)}/fork`, { method: "POST", json: { conteudo: $("#sk-txt").value, nota: "edição pela interface" } });
    await skills(); }));
});

// ---------------------------------------------------------------- base
$("#f-ejc").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-ejc");
  acao(ev.submitter, async () => { const r = await api("/api/conhecimento/importar-ejc", { method: "POST", json: limpar(form(ev.target)) });
    out.innerHTML = `<pre>${esc(JSON.stringify(r, null, 2))}</pre>`; }, out); });
$("#f-json").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-json");
  acao(ev.submitter, async () => { const f = form(ev.target);
    const r = await api(`/api/conhecimento/${f.tipo}`, { method: "POST", json: JSON.parse(f.json) });
    out.innerHTML = `<pre>${esc(JSON.stringify(r, null, 2))}</pre>`; }, out); });
$("#ver-aud").addEventListener("click", (ev) => acao(ev.target, async () => {
  const l = await api("/api/auditoria");
  $("#res-aud").innerHTML = `<table><tr><th>Momento</th><th>Ação</th><th>Alvo</th><th>Provedor</th><th>Detalhe</th></tr>${l.map((a) =>
    `<tr><td>${esc(a.momento)}</td><td>${esc(a.acao)}</td><td>${esc(a.alvo)}</td><td>${esc(a.provedor || "")}</td><td class="meta">${esc(JSON.stringify(a.detalhe))}</td></tr>`).join("")}</table>`;
}, $("#res-aud")));

painel();

// ------------------------------------------------- formulários declarativos (módulos de inteligência)
function celula(v) {
  if (v === null || v === undefined) return "";
  if (v && typeof v === "object" && !Array.isArray(v) && "nome" in v) return esc(v.nome) + (v.codigo ? ` <span class="meta">(${esc(v.codigo)})</span>` : "");
  if (Array.isArray(v) && v.length && v.every((x) => x && typeof x === "object" && "nome" in x))
    return v.slice(0, 6).map((x) => esc(x.nome) + (x.data ? ` <span class="meta">${esc(String(x.data).slice(0, 10))}</span>` : "")).join("<br>");
  if (typeof v === "object") return `<code>${esc(JSON.stringify(v)).slice(0, 400)}</code>`;
  if (typeof v === "string" && /^https?:\/\//.test(v)) return `<a href="${esc(v)}" target="_blank" rel="noopener">link</a>`;
  return esc(v);
}
function tabela(lista) {
  const cols = [...new Set(lista.slice(0, 50).flatMap((o) => Object.keys(o)))].slice(0, 12);
  return `<div class="rolagem"><table><thead><tr>${cols.map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${
    lista.slice(0, 300).map((o) => `<tr>${cols.map((c) => `<td>${celula(o[c])}</td>`).join("")}</tr>`).join("")}</tbody></table></div>
    ${lista.length > 300 ? `<p class="nota">Exibindo 300 de ${lista.length}.</p>` : ""}`;
}
function contradicoesHtml(v) {
  const item = (c) => `<div class="card"><strong>${esc(c.rotulo.replaceAll("_", " "))}</strong> <span class="etq alerta">${esc(c.valores.join(" x "))}</span>
    ${c.mensagem ? `<div class="meta">${esc(c.mensagem)}</div>` : ""}<ul class="lim">${c.ocorrencias.map((o) =>
      `<li><strong>${esc(o.valor)}</strong> em ${esc(o.documento_nome)}, p. ${o.pagina}${o.numeracao_autos ? " (" + esc(o.numeracao_autos) + ")" : ""}: <span class="meta">"${esc(o.trecho)}"</span></li>`).join("")}</ul></div>`;
  return `<p class="nota">${esc(v.nota)}</p>${v.contradicoes.length ? v.contradicoes.map(item).join("") : '<p class="nota">Nenhuma contradição entre documentos.</p>'}
    ${v.demais_fatos_rotulados?.length ? `<details><summary>Demais fatos identificados (${v.demais_fatos_rotulados.length})</summary>${v.demais_fatos_rotulados.map(item).join("")}</details>` : ""}`;
}
function exibir(v, nivelTit = 4) {
  if (typeof v === "string") return `<pre>${esc(v)}</pre>`;
  if (v && Array.isArray(v.contradicoes) && "demais_fatos_rotulados" in v) return contradicoesHtml(v);
  if (Array.isArray(v)) {
    if (!v.length) return '<p class="nota">Nenhum resultado.</p>';
    if (v.every((x) => x && typeof x === "object" && !Array.isArray(x))) return tabela(v);
    return `<ul class="lim">${v.map((x) => `<li>${typeof x === "object" ? exibir(x, nivelTit + 1) : esc(x)}</li>`).join("")}</ul>`;
  }
  if (v && typeof v === "object") {
    const simples = [], compostos = [];
    for (const [k, x] of Object.entries(v)) (x && typeof x === "object" ? compostos : simples).push([k, x]);
    const cls = (k, x) => (k === "apto" || k === "bloqueado" || k === "prescrito") ? (x === (k === "apto") ? "ok" : "erro") : "";
    return `<div class="card">${simples.map(([k, x]) => `<span class="etq ${cls(k, x)}">${esc(k)}: ${celula(x)}</span>`).join("")}
      ${compostos.map(([k, x]) => `<h${nivelTit}>${esc(k)}</h${nivelTit}>${
        ["memoria", "alertas", "problemas", "pendencias"].includes(k) && Array.isArray(x) && x.every((y) => typeof y === "string")
          ? `<ol>${x.map((y) => `<li class="${k === "memoria" ? "" : "alerta"}">${esc(y)}</li>`).join("")}</ol>` : exibir(x, Math.min(nivelTit + 1, 6))}`).join("")}</div>`;
  }
  return `<p>${esc(v)}</p>`;
}
function converter(el) {
  const t = el.dataset.t, v = el.type === "checkbox" ? el.checked : el.value.trim();
  if (el.type === "checkbox") return v;
  if (v === "") return undefined;
  if (t === "int") { const n = Number(v); if (!Number.isFinite(n)) throw new Error(`Valor numérico inválido em ${el.name}`); return n; }
  if (t === "json") { try { return JSON.parse(v); } catch (e) { throw new Error(`JSON inválido em ${el.name}: ${e.message}`); } }
  if (t === "lista") return v.split(",").map((x) => x.trim()).filter(Boolean);
  if (t === "separados") return v.split(/\n=====+\n/).map((x) => x.trim()).filter(Boolean);
  if (t === "listanum") return v.split(",").map((x) => Number(x.trim())).filter(Number.isFinite);
  if (t === "listaint") return v.split(",").map((x) => Number(x.trim())).filter(Number.isFinite);
  if (t === "feriados") { const o = {}; v.split(",").map((x) => x.trim()).filter(Boolean).forEach((d) => (o[d] = "Feriado local informado")); return o; }
  return v;
}
function saidaDe(el) { let s = el.nextElementSibling; while (s && !s.classList.contains("saida")) s = s.nextElementSibling; return s || el.parentElement.querySelector(".saida"); }
document.addEventListener("submit", (ev) => {
  const f = ev.target.closest("form.api"); if (!f) return;
  ev.preventDefault(); const out = saidaDe(f);
  acao(ev.submitter, async () => {
    let rota = f.dataset.rota; const metodo = f.dataset.metodo; let opcoes = { method: metodo };
    if (f.dataset.arquivos) {
      const fd = new FormData(); [...f.querySelector(`input[name=${f.dataset.arquivos}]`).files].forEach((a) => fd.append(f.dataset.arquivos, a));
      opcoes.body = fd;
    } else {
      const dados = {};
      f.querySelectorAll("[name]").forEach((el) => { const v = converter(el); if (v !== undefined) dados[el.name] = v; });
      rota = rota.replace(/\{(\w+)\}/g, (_, k) => { const v = dados[k]; delete dados[k]; if (v === undefined) throw new Error(`Informe ${k}`); return encodeURIComponent(v); });
      if (metodo === "GET") { const q = new URLSearchParams(Object.entries(dados).filter(([, v]) => typeof v !== "boolean")); if ([...q].length) rota += `?${q}`; }
      else { const corpo = f.dataset.corpo ? dados[f.dataset.corpo] : dados; opcoes.json = f.dataset.lista ? [corpo] : corpo; }
    }
    const r = await api(rota, opcoes);
    out.innerHTML = typeof r === "string" && r.trimStart().startsWith("<!doctype") ? '<p class="nota">Aberto em nova janela.</p>' : exibir(r);
    if (typeof r === "string" && r.trimStart().startsWith("<!doctype")) abrirHtml(r);
    if (f.dataset.depois === "intimacoes") intimacoesLista();
    if (f.dataset.depois === "casos") casos();
  }, out);
});
document.addEventListener("click", (ev) => {
  const b = ev.target.closest("button[data-get],button[data-post]"); if (!b) return;
  const out = saidaDe(b.closest(".linha") || b);
  acao(b, async () => { out.innerHTML = exibir(await api(b.dataset.get || b.dataset.post, { method: b.dataset.get ? "GET" : "POST" })); }, out);
});

// ------------------------------------------------------------------ alertas e intimações
const NIVEL = { critico: "erro", alerta: "alerta", info: "" };
async function alertasLista() {
  const l = await api("/api/alertas");
  $("#lista-alertas").innerHTML = l.length ? `<div class="rolagem"><table><thead><tr><th>Nível</th><th>Tipo</th><th>Mensagem</th><th>Vínculos</th><th></th></tr></thead><tbody>${
    l.map((a) => `<tr><td><span class="etq ${NIVEL[a.nivel] ?? ""}">${esc(a.nivel)}</span></td><td>${esc(a.tipo)}</td><td>${esc(a.mensagem)}</td>
      <td class="meta">${["caso_id", "minuta_id", "precedente_id", "intimacao_id"].filter((k) => a[k]).map((k) => `${k}: ${esc(a[k])}`).join("<br>")}</td>
      <td><button class="sec" data-resolver="${a.id}">Resolver</button></td></tr>`).join("")}</tbody></table></div>` : '<p class="nota">Nenhum alerta aberto.</p>';
}
async function intimacoesLista() {
  const l = await api("/api/intimacoes");
  $("#lista-intim").innerHTML = exibir(l.map((i) => ({ id: i.id, processo: i.numero_processo, tribunal: i.tribunal, disponibilizacao: i.data_disponibilizacao,
    prazo_dias: i.prazo_dias, vencimento: i.vencimento, status: i.status, caso_id: i.caso_id, minuta_id: i.minuta_id, teor: (i.texto || "").slice(0, 160) })));
}
$("#lista-alertas").addEventListener("click", (ev) => { const b = ev.target.closest("[data-resolver]"); if (!b) return;
  acao(b, async () => { await api(`/api/alertas/${b.dataset.resolver}/resolver`, { method: "POST" }); await alertasLista(); }, $("#lista-alertas")); });
$("#atualizar-alertas").addEventListener("click", (ev) => acao(ev.target, alertasLista, $("#lista-alertas")));
$("#rodar-monitor").addEventListener("click", (ev) => acao(ev.target, async () => { await api("/api/monitor/executar", { method: "POST" }); await alertasLista(); }, $("#lista-alertas")));
$("#atualizar-intim").addEventListener("click", (ev) => acao(ev.target, intimacoesLista, $("#lista-intim")));
alertasLista().catch(() => {}); intimacoesLista().catch(() => {}); quemSou();


// ---------------------------------------------------------------- navegação simplificada
(function () {
  const mais = $("#mais"), av = $("#avancado");
  let aberto = false;
  try { aberto = localStorage.getItem("lv_avancado") === "1"; } catch (_) {}
  const aplicar = () => { av.hidden = !aberto; mais.setAttribute("aria-expanded", String(aberto)); mais.textContent = aberto ? "Ocultar ferramentas" : "Ferramentas avançadas"; };
  mais.addEventListener("click", () => { aberto = !aberto; try { localStorage.setItem("lv_avancado", aberto ? "1" : "0"); } catch (_) {} aplicar(); });
  aplicar();
})();
function irPara(aba) { document.querySelector(`#abas button[data-aba="${aba}"]`)?.click(); if ($("#avancado").hidden && aba !== "assistente") $("#mais").click(); }

// ---------------------------------------------------------------- assistente
let conversaId = null;
const fio = $("#as-fio");
async function assistCasos() {
  const lista = await api("/api/casos").catch(() => []);
  const atual = $("#as-caso").value;
  $("#as-caso").innerHTML = `<option value="">Nenhum caso selecionado</option>` + lista.map((c) => `<option value="${c.id}">#${c.id} ${esc(c.titulo)}</option>`).join("");
  if ([...$("#as-caso").options].some((o) => o.value === atual)) $("#as-caso").value = atual;
}
function bolha(papel, html) {
  const d = document.createElement("div"); d.className = `bolha ${papel}`; d.innerHTML = html; fio.appendChild(d);
  d.scrollIntoView({ block: "nearest" }); return d;
}
function cartaoHtml(c) {
  const lista = (xs, cls = "") => xs?.length ? `<ul class="lim ${cls}">${xs.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : "";
  if (c.tipo === "lista") return `<div class="cartao"><h4>${esc(c.titulo)}</h4>${(c.itens || []).map((i) => `<div class="item ${esc(i.nivel || "")}">
      <strong>${esc(i.titulo || "")}</strong>${i.meta ? ` <span class="meta">${esc(i.meta)}</span>` : ""}
      ${i.texto ? `<div>${esc(i.texto)}</div>` : ""}${i.marcador ? `<code>${esc(i.marcador)}</code>` : ""}
      ${i.link ? ` <a href="${esc(i.link)}" target="_blank" rel="noopener">fonte</a>` : ""}</div>`).join("")}</div>`;
  if (c.tipo === "texto_legal") return `<div class="cartao legal"><h4>${esc(c.titulo)}</h4><pre>${esc(c.texto)}</pre>
      ${lista(c.alertas, "alerta")}<div class="meta">${c.marcador ? `Para citar: <code>${esc(c.marcador)}</code>` : ""} ${c.fonte ? `<a href="${esc(c.fonte)}" target="_blank" rel="noopener">fonte oficial</a>` : ""}</div></div>`;
  return `<div class="cartao"><h4>${esc(c.titulo || "")}</h4>${c.destaque ? `<div class="destaque">${esc(c.destaque)}</div>` : ""}
    ${lista(c.linhas)}${c.memoria?.length ? `<details><summary>Memória de cálculo e fundamentos</summary>${lista(c.memoria)}</details>` : ""}
    ${lista(c.alertas, "alerta")}${c.fonte ? `<div class="meta">Fonte: ${esc(c.fonte)}</div>` : ""}</div>`;
}
function respostaHtml(r) {
  return `<p>${esc(r.texto)}</p>${(r.cartoes || []).map(cartaoHtml).join("")}
    ${(r.acoes || []).length ? `<div class="acoes">${r.acoes.map((a, i) => `<button type="button" class="${a.estilo === "principal" ? "" : "sec"}" data-acao="${i}">${esc(a.rotulo)}</button>`).join("")}</div>` : ""}
    ${(r.opcoes || []).length ? `<div class="sugestoes">${r.opcoes.map((o) => `<button type="button" class="chip" data-msg="${esc(o)}">${esc(o)}</button>`).join("")}</div>` : ""}`;
}
function mostrar(r) {
  if (r.conversa_id) conversaId = r.conversa_id;
  if (r.caso_id) assistCasos().then(() => { $("#as-caso").value = String(r.caso_id); });
  const b = bolha("assistente", respostaHtml(r));
  b.querySelectorAll("[data-acao]").forEach((btn) => btn.addEventListener("click", () => executarAcao(r.acoes[Number(btn.dataset.acao)], btn)));
}
async function enviarTexto(texto) {
  texto = (texto || "").trim(); if (!texto) return;
  bolha("usuario", esc(texto));
  const espera = bolha("assistente aguardando", "Analisando...");
  try {
    const r = await api("/api/assistente/mensagens", { method: "POST", json: { texto, conversa_id: conversaId, caso_id: $("#as-caso").value ? Number($("#as-caso").value) : null } });
    espera.remove(); mostrar(r);
  } catch (e) { espera.innerHTML = `<span class="erro">${esc(e.message)}</span>`; }
}
async function executarAcao(a, btn) {
  if (a.acao === "abrir_minuta") { irPara("minuta"); await carregarMinutas(); $("#sel-minuta").value = String(a.params.minuta_id); $("#abrir-minuta").click(); return; }
  if (a.acao === "baixar_minuta") return acao(btn, () => baixar(`/api/minutas/${a.params.minuta_id}/exportar?formato=${a.params.formato || "docx"}`, `minuta-${a.params.minuta_id}.docx`), null);
  if (a.acao === "abrir_fontes") { irPara("base"); return; }
  bolha("usuario", esc(a.rotulo));
  const espera = bolha("assistente aguardando", "Executando...");
  btn.disabled = true;
  try { const r = await api("/api/assistente/acoes", { method: "POST", json: { conversa_id: conversaId, acao: a.acao, params: a.params } }); espera.remove(); mostrar(r); }
  catch (e) { espera.innerHTML = `<span class="erro">${esc(e.message)}</span>`; }
  finally { btn.disabled = false; }
}
$("#as-form").addEventListener("submit", (ev) => { ev.preventDefault(); const t = $("#as-texto").value; $("#as-texto").value = ""; enviarTexto(t); });
$("#as-texto").addEventListener("keydown", (ev) => { if (ev.key === "Enter" && !ev.shiftKey) { ev.preventDefault(); $("#as-form").requestSubmit(); } });
document.addEventListener("click", (ev) => {
  const c = ev.target.closest(".chip[data-msg]"); if (!c) return;
  const m = c.dataset.msg;
  if (m.endsWith(" ")) { $("#as-texto").value = m; $("#as-texto").focus(); } else enviarTexto(m);
});
$("#as-arquivo").addEventListener("change", async (ev) => {
  const arq = ev.target.files[0]; if (!arq) return;
  bolha("usuario", `Documento: ${esc(arq.name)}`);
  const espera = bolha("assistente aguardando", "Lendo o documento...");
  const fd = new FormData(); fd.append("arquivo", arq);
  if (conversaId) fd.append("conversa_id", conversaId);
  if ($("#as-caso").value) fd.append("caso_id", $("#as-caso").value);
  try { const r = await api("/api/assistente/documento", { method: "POST", body: fd }); espera.remove(); mostrar(r); }
  catch (e) { espera.innerHTML = `<span class="erro">${esc(e.message)}</span>`; }
  ev.target.value = "";
});
$("#as-caso").addEventListener("change", () => { conversaId = null; });
$("#as-novo").addEventListener("click", () => { conversaId = null; fio.innerHTML = ""; inicioAssistente(); });
async function inicioAssistente() {
  await assistCasos();
  try { const r = await api("/api/assistente/hoje"); bolha("assistente", respostaHtml(r)).querySelectorAll("[data-acao]").forEach((btn) =>
    btn.addEventListener("click", () => executarAcao(r.acoes[Number(btn.dataset.acao)], btn))); }
  catch (e) { bolha("assistente", `<p>${esc(e.message)}</p><p class="nota">Se o sistema exige login, informe o token no topo.</p>`); }
}
inicioAssistente();

// ---------------------------------------------------------------- fontes oficiais
async function fontesLista() {
  const f = await api("/api/fontes").catch(() => null); if (!f) return;
  $("#lista-planalto").innerHTML = `<div class="rolagem"><table><thead><tr><th></th><th>Diploma</th><th>Área</th><th>Situação</th><th>Artigos</th><th>Última coleta</th></tr></thead><tbody>${
    f.planalto.map((d) => `<tr><td><input type="checkbox" value="${esc(d.slug)}" ${d.padrao && d.status === "nunca" ? "checked" : ""} aria-label="${esc(d.titulo)}"></td>
      <td>${esc(d.titulo)} <a href="${esc(d.url)}" target="_blank" rel="noopener">fonte</a></td><td>${esc(d.area)}</td>
      <td><span class="etq ${d.status === "ok" || d.status === "inalterado" ? "ok" : d.status === "erro" ? "erro" : ""}">${esc(d.status)}</span>${d.erro ? `<div class="meta">${esc(d.erro)}</div>` : ""}</td>
      <td>${d.artigos || "-"}</td><td>${esc((d.ultima_execucao || "").slice(0, 16).replace("T", " "))}</td></tr>`).join("")}</tbody></table></div>`;
}
$("#atualizar-fontes").addEventListener("click", (ev) => acao(ev.target, fontesLista, $("#res-planalto")));
$("#coletar-planalto").addEventListener("click", (ev) => acao(ev.target, async () => {
  const slugs = [...document.querySelectorAll("#lista-planalto input:checked")].map((x) => x.value);
  if (!slugs.length) throw new Error("Selecione ao menos um diploma.");
  const r = await api("/api/fontes/planalto", { method: "POST", json: { slugs } });
  $("#res-planalto").innerHTML = exibir(r); setTimeout(fontesLista, 4000);
}, $("#res-planalto")));
