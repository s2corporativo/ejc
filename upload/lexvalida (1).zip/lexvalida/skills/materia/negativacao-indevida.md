---
slug: negativacao-indevida
titulo: Inscrição indevida em cadastro de inadimplentes
tipo: materia
area: consumidor
descricao: Notificação prévia, inscrição preexistente e dano moral por negativação indevida.
gatilhos: [negativacao, serasa, spc, cadastro de inadimplentes, protecao ao credito, inscricao indevida]
revisado_em:
---
## Lei seca e súmulas (conferir redação e status antes de citar; buscar na base para obter o marcador)
- CDC, art. 43, § 2º: comunicação por escrito ao consumidor da abertura de cadastro não solicitada por ele.
- STJ, Súmula 359: cabe ao órgão mantenedor do cadastro a notificação do devedor antes da inscrição.
- STJ, Súmula 404: é dispensável o aviso de recebimento na carta de comunicação da negativação.
- STJ, Súmula 385: anotação irregular não gera dano moral quando preexistente legítima inscrição, ressalvado o direito ao cancelamento.

## Erros a evitar
- Pedir dano moral sem verificar inscrições preexistentes legítimas (Súmula 385).
- Imputar ao credor a falta de notificação prévia que, pela Súmula 359, cabe ao mantenedor do cadastro.
- Citar súmula sem o marcador da base: a ementa deve vir da fonte importada.
