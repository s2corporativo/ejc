---
slug: tcfa-ambiental
titulo: Taxa de Controle e Fiscalização Ambiental (TCFA)
tipo: materia
area: ambiental
descricao: TCFA do IBAMA, sujeição passiva, Cadastro Técnico Federal e defesa administrativa.
gatilhos: [tcfa, ibama, cadastro tecnico federal, ctf, potencial poluidor, taxa ambiental]
revisado_em:
---
## Lei seca (conferir redação vigente antes de citar)
- Lei 6.938/1981, art. 17-B (incluído pela Lei 10.165/2000): institui a TCFA, cujo fato gerador é o poder de polícia do IBAMA sobre atividades potencialmente poluidoras e utilizadoras de recursos naturais.
- Lei 6.938/1981, art. 17-C: sujeito passivo, quem exerce as atividades do Anexo VIII.
- Lei 6.938/1981, art. 17-D: valores por porte da empresa e potencial de poluição.
- Lei 6.938/1981, art. 17, II: Cadastro Técnico Federal de atividades potencialmente poluidoras.
- Lei 6.938/1981, Anexo VIII: atividades e grau de potencial de poluição.

## Erros a evitar
- Presumir enquadramento pela CNAE sem confrontar a atividade efetivamente exercida com o Anexo VIII.
- Calcular débito sem a série de atualização oficial do período.
