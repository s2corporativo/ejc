---
slug: prescricao-civil
titulo: Prescrição civil
tipo: materia
area: civil
descricao: Prazos prescricionais do Código Civil, termo inicial, interrupção e suspensão.
gatilhos: [prescricao, prescrita, prazo prescricional, prejudicial de merito]
revisado_em:
---
## Lei seca (conferir redação vigente antes de citar)
- CC, art. 189: violado o direito, nasce a pretensão, que se extingue pela prescrição.
- CC, arts. 197 a 201: causas impeditivas e suspensivas.
- CC, art. 202: interrupção, que somente pode ocorrer uma vez; parágrafo único: recomeça a correr da data do ato que a interrompeu ou do último ato do processo.
- CC, art. 205: prazo geral de 10 anos.
- CC, art. 206, § 3º, IV: 3 anos, ressarcimento de enriquecimento sem causa.
- CC, art. 206, § 3º, V: 3 anos, reparação civil.
- CC, art. 206, § 5º, I: 5 anos, cobrança de dívida líquida constante de instrumento público ou particular.
- CC, art. 132, § 3º: contagem de prazos em anos.
- CPC, art. 487, II: prescrição como resolução de mérito; parágrafo único: oitiva prévia das partes.
- CDC, art. 27: 5 anos para reparação por fato do produto ou do serviço.

## Erros a evitar
- Fixar termo inicial sem examinar a ciência do dano e da autoria quando o caso a exigir.
- Desconsiderar causa interruptiva (citação válida retroage à propositura: CPC, art. 240, § 1º).
