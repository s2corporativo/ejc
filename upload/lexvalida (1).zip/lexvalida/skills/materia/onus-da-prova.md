---
slug: onus-da-prova
titulo: Ônus da prova
tipo: materia
area: processo
descricao: Distribuição estática e dinâmica do ônus da prova no CPC, CDC e CLT.
gatilhos: [onus da prova, inversao do onus, prova, fato constitutivo, distribuicao dinamica]
revisado_em:
---
## Lei seca (conferir redação vigente antes de citar)
- CPC, art. 373, I: ao autor, quanto ao fato constitutivo do seu direito.
- CPC, art. 373, II: ao réu, quanto à existência de fato impeditivo, modificativo ou extintivo.
- CPC, art. 373, § 1º: distribuição diversa por decisão fundamentada, com oportunidade de a parte se desincumbir.
- CPC, art. 357, III: definição da distribuição do ônus no saneamento.
- CDC, art. 6º, VIII: inversão a critério do juiz, diante de verossimilhança ou hipossuficiência.
- CLT, art. 818, I e II, e § 1º: regra trabalhista equivalente e distribuição diversa.

## Erros a evitar
- Presumir inversão automática no CDC: ela depende de decisão judicial (salvo hipóteses legais específicas de inversão ope legis).
- Pedir inversão sem demonstrar verossimilhança ou hipossuficiência.
