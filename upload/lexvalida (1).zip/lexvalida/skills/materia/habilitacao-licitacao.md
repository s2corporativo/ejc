---
slug: habilitacao-licitacao
titulo: Habilitação em licitações (Lei 14.133/2021)
tipo: materia
area: administrativo
descricao: Documentos de habilitação, exigências sem previsão legal, impugnação e recurso.
gatilhos: [habilitacao, licitacao, pregao, edital, impugnacao do edital, inabilitacao, lei 14.133]
revisado_em:
---
## Lei seca (conferir redação vigente antes de citar)
- Lei 14.133/2021, art. 62: habilitação jurídica, técnica, fiscal, social e trabalhista e econômico-financeira.
- Art. 66: habilitação jurídica. Art. 67: qualificação técnico-profissional e técnico-operacional.
- Art. 68: regularidade fiscal, social e trabalhista (CNPJ, inscrição estadual ou municipal, Fazendas, FGTS, CNDT, art. 7º, XXXIII, da Constituição).
- Art. 69: qualificação econômico-financeira (balanço, certidão negativa de falência).
- Art. 164: impugnação e pedido de esclarecimento até 3 dias úteis antes da abertura.
- Art. 165: recursos em 3 dias úteis.

## Erros a evitar
- Tratar restrição em cadastro privado de crédito (Serasa, SPC) como impedimento: não integra o rol de regularidade fiscal do art. 68. Exigência desse tipo no edital deve ser avaliada para impugnação.
- Perder o prazo de impugnação, contado regressivamente da data de abertura.
