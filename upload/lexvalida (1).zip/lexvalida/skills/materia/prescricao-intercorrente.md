---
slug: prescricao-intercorrente
titulo: Prescrição intercorrente
tipo: materia
area: processo civil
descricao: Prescrição intercorrente na execução civil (CPC, art. 921) e na execução fiscal (LEF, art. 40).
gatilhos: [prescricao intercorrente, execucao suspensa, bens penhoraveis, arquivamento provisorio, execucao fiscal]
revisado_em:
---
## Lei seca e súmulas (conferir redação vigente antes de citar)
- CPC, art. 921, III e § 1º: suspensão da execução por 1 ano quando não localizado o executado ou bens penhoráveis.
- CPC, art. 921, § 4º (Lei 14.195/2021): termo inicial na ciência da primeira tentativa infrutífera; suspensão por uma única vez, pelo prazo máximo do § 1º.
- CPC, art. 921, § 4º-A: efetiva citação, intimação do devedor ou constrição de bens interrompem a prescrição.
- CPC, art. 921, § 5º: reconhecimento de ofício após oitiva das partes em 15 dias.
- STF, Súmula 150: prescreve a execução no mesmo prazo de prescrição da ação.
- Lei 6.830/1980, art. 40, caput e §§ 2º e 4º; STJ, Súmula 314: suspensão por 1 ano e, depois, prescrição quinquenal intercorrente.

## Erros a evitar
- Contar a prescrição da data do arquivamento quando a lei fixa a ciência da tentativa infrutífera.
- Ignorar causa interruptiva do § 4º-A.
- Pedir o reconhecimento sem requerer a oitiva prévia prevista no § 5º.
