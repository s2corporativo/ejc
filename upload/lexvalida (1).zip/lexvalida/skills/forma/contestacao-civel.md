---
slug: contestacao-civel
titulo: Contestação cível (procedimento comum)
tipo: forma
area: processo civil
descricao: Estrutura e requisitos da contestação no procedimento comum do CPC.
gatilhos: [contestacao, contestar, defesa do reu, resposta do reu]
revisado_em:
---
## Lei seca (conferir redação vigente antes de citar)
- CPC, art. 335: prazo de 15 dias (úteis, art. 219) para contestar; termo inicial conforme incisos.
- CPC, art. 336: concentração da defesa. Toda a matéria de defesa, razões de fato e de direito, e especificação de provas.
- CPC, art. 337: preliminares, a serem alegadas antes do mérito (inexistência ou nulidade da citação, incompetência, incorreção do valor da causa, inépcia, perempção, litispendência, coisa julgada, conexão, incapacidade/defeito de representação, convenção de arbitragem, ausência de legitimidade ou interesse, falta de caução, indevida concessão de gratuidade).
- CPC, art. 341: ônus da impugnação especificada; fatos não impugnados presumem-se verdadeiros, ressalvadas as exceções do artigo.
- CPC, art. 342: depois da contestação só se deduzem novas alegações nas hipóteses do artigo.
- CPC, art. 343: reconvenção na própria contestação.

## Estrutura recomendada
1. Endereçamento e qualificação. 2. Síntese da inicial. 3. Tempestividade. 4. Preliminares (art. 337). 5. Prejudiciais de mérito (prescrição e decadência). 6. Mérito, com impugnação fato a fato. 7. Provas. 8. Pedidos (acolhimento das preliminares; improcedência; sucumbência).

## Erros a evitar
- Contestar por negação geral (art. 341).
- Deixar de arguir incompetência relativa em preliminar (art. 337, II, e art. 65).
- Esquecer a especificação de provas (art. 336).
