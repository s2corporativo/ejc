---
slug: clausula-ia-honorarios
titulo: Cláusula de uso de IA no contrato de honorários
tipo: forma
area: etica profissional
descricao: Cláusula de transparência, consentimento e sigilo no uso de IA generativa pelo escritório.
gatilhos: [contrato de honorarios, clausula de inteligencia artificial, uso de ia, consentimento do cliente]
revisado_em:
---
## Fundamentos (conferir redação vigente)
- Recomendação do Conselho Federal da OAB sobre o uso de IA na prática jurídica, aprovada em novembro de 2024 (consultar a versão oficial em oab.org.br): transparência ao cliente, consentimento, proteção de dados e responsabilidade do advogado pela revisão.
- EOAB (Lei 8.906/1994), art. 7º, II (inviolabilidade e sigilo) e art. 32 (responsabilidade do advogado).
- LGPD, arts. 6º, 7º, 11, 33 e 46.

## Modelo de cláusula (adaptar ao caso)
CLÁUSULA X. O CONTRATADO poderá utilizar ferramentas de inteligência artificial como apoio à pesquisa e à redação, sob sua exclusiva supervisão e responsabilidade técnica, sendo toda peça revisada e assinada por advogado.
§ 1º. Dados pessoais e documentos do CONTRATANTE somente serão submetidos a ferramentas que adotem pseudonimização ou processamento em ambiente controlado, vedado o uso desses dados para treinamento de modelos de terceiros.
§ 2º. Em processos sob segredo de justiça, o tratamento ocorrerá exclusivamente em ambiente local, sem transferência a provedores externos.
§ 3º. O CONTRATANTE declara ciência e consente com o disposto nesta cláusula, podendo revogar o consentimento a qualquer tempo, por escrito.

## Erros a evitar
- Usar IA em nuvem com dados identificáveis sem consentimento e sem contrato de operador.
- Cláusula genérica sem tratamento específico para segredo de justiça.
