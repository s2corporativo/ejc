---
slug: peticao-inicial-civel
titulo: Petição inicial cível (procedimento comum)
tipo: forma
area: processo civil
descricao: Requisitos e estrutura da petição inicial do procedimento comum do CPC.
gatilhos: [peticao inicial, inicial, ajuizar, propor acao, acao de]
revisado_em:
---
## Lei seca (conferir redação vigente antes de citar)
- CPC, art. 319: requisitos (juízo; qualificação; fatos e fundamentos jurídicos; pedido com especificações; valor da causa; provas; opção pela audiência de conciliação ou mediação).
- CPC, art. 320: documentos indispensáveis à propositura.
- CPC, art. 292: critérios do valor da causa (inclusive soma dos pedidos cumulados e valor pretendido na indenização por dano moral, inciso V).
- CPC, arts. 322 e 324: pedido certo e determinado, com as exceções legais.
- CPC, art. 330: hipóteses de indeferimento.
- CPC, art. 334, § 5º: manifestação de desinteresse na audiência.

## Estrutura recomendada
Endereçamento; qualificação; dos fatos (cada fato com referência ao documento); do direito; tutela provisória, se houver; dos pedidos; provas; valor da causa; opção sobre a audiência.

## Erros a evitar
- Pedido genérico fora das hipóteses do art. 324, § 1º.
- Valor da causa em desacordo com o art. 292 (risco de correção de ofício, § 3º).
- Fato relevante sem documento correspondente.
