---
slug: apelacao-civel
titulo: Apelação cível
tipo: forma
area: processo civil
descricao: Requisitos de admissibilidade e estrutura da apelação no CPC.
gatilhos: [apelacao, apelar, recurso de apelacao, recorrer da sentenca]
revisado_em:
---
## Lei seca (conferir redação vigente antes de citar)
- CPC, art. 1.009: cabimento contra sentença; § 1º questões não agraváveis suscitadas em preliminar.
- CPC, art. 1.003, § 5º: prazo de 15 dias (úteis).
- CPC, art. 1.007: preparo; deserção; complementação.
- CPC, art. 1.010: requisitos da petição (nomes e qualificação, exposição do fato e do direito, razões do pedido de reforma ou de decretação de nulidade, pedido de nova decisão).
- CPC, art. 1.012: efeito suspensivo como regra e exceções do § 1º.
- CPC, art. 932, III: não conhecimento de recurso que não impugne especificamente os fundamentos da decisão.

## Erros a evitar
- Razões que repetem a inicial sem atacar os fundamentos da sentença (dialeticidade).
- Ausência de comprovação do preparo ou de pedido de gratuidade.
