---
slug: tutela-urgencia
titulo: Tutela provisória de urgência
tipo: forma
area: processo civil
descricao: Requisitos e estrutura do pedido de tutela de urgência antecipada ou cautelar.
gatilhos: [tutela de urgencia, liminar, tutela antecipada, tutela cautelar, urgencia]
revisado_em:
---
## Lei seca (conferir redação vigente antes de citar)
- CPC, art. 300, caput: probabilidade do direito e perigo de dano ou risco ao resultado útil do processo.
- CPC, art. 300, § 1º: caução, dispensável para a parte economicamente hipossuficiente.
- CPC, art. 300, § 2º: concessão liminar ou após justificação prévia.
- CPC, art. 300, § 3º: vedação quando houver perigo de irreversibilidade dos efeitos.
- CPC, arts. 303 e 305: tutela antecedente (antecipada e cautelar).
- CPC, art. 297: medidas adequadas para a efetivação.

## Estrutura recomendada
Fatos com referência a documento; probabilidade do direito (fundamento e prova); perigo concreto e atual; reversibilidade; caução ou dispensa; pedido específico com prazo e multa (art. 537).

## Erros a evitar
- Perigo genérico, sem fato concreto e atual.
- Pedido de tutela que esgota o objeto sem enfrentar o § 3º.
