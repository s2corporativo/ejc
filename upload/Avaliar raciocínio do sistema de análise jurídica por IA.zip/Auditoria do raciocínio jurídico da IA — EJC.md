# Auditoria do raciocínio jurídico da IA — EJC

**Data da auditoria:** 21 de setembro de 2026  
**Escopo:** entrada de texto colado e importação de arquivos; extração de fatos; classificação jurídica; honorários; teses; defesa; provas; pontos de atenção; lacunas; rastreabilidade e revisão humana.  
**Repositório analisado:** `s2corporativo/ejc`, branch `main`, commit `64bc6363`.

## 1. Conclusão executiva

O EJC **não está ainda apto a cumprir integralmente**, de forma consistente, a promessa de que o advogado cola um relato ou importa um arquivo e recebe uma análise jurídica completa, confiável e pronta para orientar o caso. Ele está **parcialmente apto** e possui uma fundação acima da média para chegar lá.

Hoje o sistema já consegue, em diferentes caminhos:

- preservar o arquivo original, calcular hash, executar OCR e montar um dossiê;
- fazer triagem preliminar de ramo, assunto, natureza da demanda, competência, urgência, possível ação, valor da causa, documentos faltantes, provas e próximos passos;
- extrair partes, dados pessoais, identificação processual, datas e prazo preliminar de documentos;
- gerar uma análise estratégica com pontos fortes, pontos fracos, cenários, teses, riscos, provas necessárias e próximos passos;
- consultar RAG interno e validar citações, com saída marcada como rascunho e revisão humana obrigatória;
- produzir honorários por um motor separado, com referência à tabela estruturada da OAB/MG;
- gerar, para **casos já existentes**, um dossiê que combina análise estratégica, teses do banco, honorários, crítica adversarial opcional e snapshot HITL.

O principal problema não é falta de prompt ou falta de modelo. É que o raciocínio está **fragmentado em pipelines com contratos diferentes**, e a Entrada Única faz apenas uma fusão mínima. No fluxo de novo relato/arquivo, ela não consolida toda a análise jurídica profunda, não retorna honorários sugeridos e não entrega, no mesmo resultado, a matriz completa de fatos, evidências, teses, fundamentos, contra-argumentos e pontos de esclarecimento.

Minha recomendação é **não trocar imediatamente de IA**. Primeiro, deve-se corrigir o raciocínio do produto: um pipeline em etapas, com evidências e estados epistemológicos explícitos, seguido por pesquisa jurídica ancorada em fontes oficiais vigentes. Depois disso, o modelo pode ser comparado por testes objetivos. Trocar de provedor agora provavelmente apenas produziria respostas mais eloquentes, não necessariamente mais seguras.

## 2. O que já está bem construído

### 2.1 Entrada e preservação documental

A importação persiste o original antes de OCR e IA, mantém hash e possui fluxo de documentos múltiplos. Isso é adequado para cadeia probatória e para falhas do provedor. A implementação também prevê degradação graciosa: quando a IA falha, o sistema preserva o determinístico e sinaliza a revisão.

### 2.2 Governança, LGPD e HITL

O código aplica sanitização de PII antes do envio ao gateway, valida PII residual, registra AILog em vários caminhos, impede promoção automática para documento formal e marca as saídas como rascunho. O dossiê de caso existente também mantém snapshot, auditoria e endpoint de aprovação.

Essa é uma decisão correta: a IA deve atuar como **copiloto interno do advogado**, não como autoridade jurídica autônoma.

### 2.3 Contratos de incerteza

O `legal_brain/contracts.py` tem um desenho conceitualmente forte: `EvidenceState` distingue fato confirmado, alegação do cliente, alegação da parte contrária, fato controvertido e inferência da IA. Também existem contratos para referência jurídica, vigência, cobertura de pesquisa e planos de pesquisa.

O problema é que esses contratos ainda não governam toda a saída operacional da Entrada Única. O sistema possui a ideia correta, mas ainda não a aplica como formato universal obrigatório em cada afirmação.

### 2.4 RAG e validação

A análise estratégica consulta a base interna e chama um validador de resposta para citações, promessas de resultado e ausência de base verificável. A política de não inventar lei, precedente, número de processo ou resultado é adequada.

Há, contudo, uma distinção importante: **RAG interno não é automaticamente fonte oficial vigente**. A base precisa ter proveniência, data de verificação, status de vigência, tribunal/órgão e relação entre a fonte e a proposição gerada.

### 2.5 Honorários estruturados

O EJC já possui tabela versionada e motor determinístico de proposta. O código evita inventar item de tabela e mantém a regra de que o advogado define o valor final. Isso é melhor do que deixar o LLM calcular livremente.

A limitação é de integração e abrangência: o fluxo da Entrada Única para novo caso não chama esse motor; o dossiê de um caso já criado chama. Além disso, a implementação está explicitamente ancorada na **OAB/MG**, não em uma tabela OAB parametrizada por UF e vigência.

## 3. Fluxo real encontrado

### 3.1 Texto colado

O texto colado na Entrada Única é enviado para `triagem_entrevista_service.analisar_relato`. O contrato pede ao modelo:

- ramo;
- assunto;
- natureza da demanda;
- competência;
- possível ação;
- urgência e tutela;
- prescrição preliminar;
- valor da causa;
- documentos e provas faltantes;
- próximos passos;
- pedidos possíveis;
- riscos;
- chance de êxito.

A resposta é normalizada e alimenta o rascunho da Entrada Única. Esse fluxo é bom para **triagem**, mas não é ainda uma análise jurídica completa. Ele não produz, de forma estruturada, por exemplo:

- tese com fundamento normativo individualizado e fonte;
- tese principal, subsidiária e defensiva separadas;
- fatos favoráveis e desfavoráveis vinculados a evidências;
- contra-argumentos prováveis e respectivas respostas;
- análise de admissibilidade, ônus da prova e autenticidade;
- cronologia probatória completa;
- matriz fato → prova → tese → risco;
- explicação do que é fato alegado, fato extraído e inferência.

Além disso, o campo de chance de êxito aparece no prompt de triagem. Mesmo sendo rotulado como estimativa interna, esse tipo de percentual é de alto risco quando não há base estatística concreta e validada. No dossiê posterior há uma trava melhor, que elimina a porcentagem quando não existe base verificável. Essa regra deveria ser uniforme desde a entrada.

### 3.2 Arquivo importado

O arquivo segue OCR, classificação, comparação/prontidão e análise do pacote documental. O schema da análise de documento já contempla tipo, área, órgão, processo, partes, dados pessoais, fatos, datas, prazo, vícios/teses, cláusulas, dados bancários, documentos faltantes, estratégia e alertas.

Isso é uma boa cobertura de campos, porém o contrato tem três limitações centrais:

1. **Os campos não são suficientemente evidenciados.** Há `documento`, `página`, `trecho_literal` e confiança para datas, mas não existe o mesmo vínculo obrigatório para cada parte, fato, valor, endereço, cláusula, tese, risco e recomendação.
2. **A validação estrutural é permissiva.** A análise considera a estrutura válida quando existe qualquer uma das chaves `area`, `partes`, `datas`, `prazo` ou `teses`; isso não garante que os dados essenciais estejam presentes nem corretos.
3. **A saída não é fundida em um relatório jurídico universal.** A Entrada Única aproveita principalmente nome, partes, área, resumo, prazo, documentos faltantes, provas e próximos passos. A estratégia e a matriz de teses do pacote não são incorporadas de modo completo à proposta de novo caso.

### 3.3 Dossiê de caso existente

O caminho mais completo é `gerar_dossie_juridico`, usado quando já existe `case_id`. Ele:

1. lê o caso, partes, documentos visíveis e cronologia;
2. chama `analisar_caso` com análise estratégica e RAG;
3. busca teses canônicas no banco;
4. chama o motor de honorários;
5. chama novamente a triagem para pedidos possíveis;
6. correlaciona prova e tese por similaridade lexical;
7. gera perguntas de lacuna;
8. opcionalmente chama crítica adversarial;
9. cria snapshot e exige aprovação humana.

Esse é o caminho que mais se aproxima do objetivo do usuário. Mesmo assim, ainda há problemas: a correlação entre prova e tese é lexical, a pesquisa não é necessariamente executada até comprovar vigência e precedente contrário, e o dossiê só nasce depois que o caso já foi criado.

## 4. Lacunas prioritárias

### P0 — O resultado pode parecer completo sem estar epistemicamente completo

A saída do LLM mistura fatos, inferências, hipóteses, recomendações e conclusões em estruturas textuais simples. O sistema possui `EvidenceState`, mas a Entrada Única não exige que cada item seja rotulado com:

- origem;
- trecho e página;
- documento;
- confiança;
- estado epistemológico;
- fundamento;
- vigência;
- revisão humana;
- motivo de ausência quando o campo é nulo.

**Risco:** o advogado pode interpretar uma inferência bem redigida como fato extraído do documento.

**Correção:** adotar um `Evidence Ledger` como fonte única. Nenhuma tese, prazo, valor, endereço, parte ou risco deve existir no relatório sem referência a um ou mais itens desse ledger, ou sem rótulo explícito de hipótese/recomendação.

### P0 — Fundamentos jurídicos e vigência não estão garantidos na entrada

O prompt de análise estratégica proíbe inventar leis e precedentes, mas aceita texto livre como `fundamento_legal`. A própria documentação `REGRAS_JURIDICAS.md` está sem regras preenchidas, fontes, datas de verificação e testes. A governança determina fonte oficial e vigência, mas o catálogo operacional não está completo.

**Risco:** o sistema pode devolver “verificar tema” ou um fundamento plausível, mas não comprovado, em um relatório que o usuário considera técnico.

**Correção:** separar o processo em duas etapas: (a) hipótese jurídica gerada pelo modelo; (b) verificação em base normativa/jurisprudencial versionada, com fonte oficial, vigência, data da consulta e status. Sem etapa (b), a saída deve ser “hipótese não verificada”, não tese pronta.

### P0 — Honorários não integram o fluxo de entrada de novo caso

No fluxo `analisar_entrada`, a proposta retorna área, assunto, fatos, partes, documentos, provas, prazo e próximos passos, mas não chama `fee_proposal_service.sugerir_proposta`. Honorários só aparecem no dossiê de caso existente.

**Risco:** a principal expectativa descrita pelo usuário — importar e já receber a referência de honorários — não é atendida na primeira tela.

**Correção:** após a área/tipo de demanda serem confirmados ou classificados com confiança mínima, chamar um motor determinístico de honorários como **estimativa pendente de confirmação**, usando UF, tabela, vigência, tipo de serviço, instância, complexidade, atos e valor econômico. Se a UF ou tabela não estiverem disponíveis, retornar explicitamente “não calculado — fonte/tabela ausente”. Nunca preencher com percentual genérico sem deixar isso claramente separado da tabela OAB.

### P0 — Prazo é detectado, mas não necessariamente calculado com segurança

A entrada identifica `data_expressa` e `termo_inicial`, mas o campo `regra` do schema é “verificar”. O código normaliza a data para ISO, porém não há, nesse fluxo, uma comprovação de rito, tribunal, feriados locais, suspensão, exclusão/inclusão de dias e marco jurídico suficiente para transformar a detecção em prazo processual confiável.

**Correção:** separar “data literal encontrada” de “prazo calculado”. Só criar prazo acionável após motor determinístico de prazo, com rito, tribunal, UF/comarca, calendário versionado, fonte normativa e confirmação humana.

### P1 — A Entrada Única é uma triagem enriquecida, não um analista jurídico completo

A fusão em `entrada_service.py` é deliberadamente mínima. Ela não transporta integralmente a saída de `matriz_vicios_teses`, estratégia, fundamentos, cláusulas, valores, endereços e contradições documentais para a proposta. O resultado é adequado para criar um caso, mas não para representar o entendimento completo do arquivo.

**Correção:** separar dois produtos dentro do mesmo fluxo:

- **Proposta de caso:** dados mínimos para criação segura do caso;
- **Relatório de inteligência jurídica:** análise completa, versionada e revisável.

A tela pode continuar simples, mas o backend não deve descartar informação jurídica relevante ao fazer a fusão.

### P1 — Correlação prova–tese é apenas lexical

`_correlacionar_fato_prova_tese` usa sobreposição de tokens e um limiar baixo. O próprio retorno informa que a relação não foi confirmada.

**Risco:** uma prova pode ser lexicalmente semelhante e juridicamente irrelevante, inadmissível, insuficiente ou ligada ao fato errado.

**Correção:** a correlação deve ser uma hipótese explicada, com: fato controvertido, elemento da tese, admissibilidade, suficiência, ônus, parte que produz, status e revisão. O modelo pode propor a relação, mas um validador deve checar se existe evidência correspondente.

### P1 — Classificação de ramo não tem uma etapa explícita de desambiguação

O sistema classifica área a partir de texto e catálogo, mas o `legal_brain` identifica questões por regras lexicais. O motor é bom como mecanismo de cobertura e saneamento, porém não deve ser confundido com raciocínio jurídico. Casos multidisciplinares precisam de ramo principal, ramos secundários, conflito entre classificadores e pergunta de desambiguação.

**Correção:** retornar `ramo_principal`, `ramos_secundarios`, `hipoteses_de_classificacao`, evidências de cada hipótese e perguntas que alterariam a classificação. Não selecionar silenciosamente uma área quando a diferença muda prazo, competência, tese ou honorários.

### P1 — Endereço, valores e entidades ainda não têm contrato universal

O pedido inclui endereço e valor. O fluxo tem `valor_causa` na triagem e diversos valores específicos em análises bancárias, mas a Entrada Única não possui um objeto universal para endereços, valores monetários, moedas, datas, percentuais e identificadores. Também não há garantia de que endereço extraído de uma assinatura, contrato ou cadastro seja distinguido de endereço de citação, domicílio do fato ou endereço da parte.

**Correção:** criar objetos estruturados:

```json
{
  "valor": 12500.0,
  "moeda": "BRL",
  "tipo": "valor_da_causa",
  "origem": {"documento_id": "...", "pagina": 2, "trecho": "..."},
  "estado": "extraido",
  "confianca": 0.91,
  "requer_confirmacao_humana": true
}
```

O mesmo padrão deve existir para endereço, parte, data, cláusula e evento.

### P1 — Pesquisa adversarial e pesquisa jurídica não são padrão

A crítica por segunda IA é opcional (`DUAS_IAS_ENABLED`). O plano do `legal_brain` prevê cobertura de fonte primária, vigência, precedente favorável, precedente adverso e aderência fática, mas o caminho principal da Entrada Única não demonstra que todas essas dimensões sejam executadas antes da resposta.

**Correção:** para cada questão relevante, o relatório deve mostrar uma matriz de cobertura: fonte primária, vigência, interpretação favorável, interpretação adversa, aderência aos fatos e lacunas. Quando uma dimensão não for pesquisada, isso deve aparecer como pendência, não como silêncio.

### P2 — Falta de avaliação baseada em casos dourados

A suíte tem muitos testes de contrato, parse, governança e fail-safe, mas a execução local desta auditoria não conseguiu iniciar os testes focados porque o ambiente não possui `pytest` instalado. Mais importante, a estrutura observada não demonstra uma bateria de casos jurídicos dourados por ramo que meça precisão de entidades, classificação, fatos, prazos, teses, provas e honorários.

**Correção:** criar conjunto sintético versionado por ramo, com gabarito produzido por advogado, e medir:

- precisão/recall de partes, datas, valores, endereços e processo;
- acerto do ramo principal e dos ramos secundários;
- taxa de teses sem fonte;
- taxa de fatos sem evidência;
- falsos positivos de prazo e de urgência;
- cobertura de documentos faltantes;
- diferença entre honorário sugerido e item OAB aplicável;
- consistência entre modelos e entre reexecuções.

## 5. Arquitetura de raciocínio recomendada

Não recomendo um único prompt “aja como advogado sênior”. Recomendo este pipeline:

```text
Entrada texto/arquivo
        ↓
Preservação + OCR + páginas + hash + classificação documental
        ↓
Extração determinística e estruturada de entidades
        ↓
Evidence Ledger: cada fato/entidade com trecho, página, origem e estado
        ↓
Reconciliação: conflitos entre documentos, duplicidades e lacunas
        ↓
Classificação: ramo principal + secundários + confiança + desambiguação
        ↓
Saneamento jurídico determinístico: partes, competência, fase, prazos, valores
        ↓
Issue spotting por ramo + questões transversais
        ↓
Pesquisa jurídica grounded: fonte oficial, vigência, precedente favorável/adverso
        ↓
Análise de mérito: teses, defesa, riscos, provas, contra-argumentos
        ↓
Motor determinístico de honorários e cálculos
        ↓
Crítica adversarial e verificadores
        ↓
Relatório com evidências, incertezas, pendências e HITL
```

O LLM deve ser usado em três papéis diferentes, com prompts e permissões diferentes:

1. **Extrator:** não opina; somente localiza e estrutura o que está no material.
2. **Analista:** formula hipóteses, teses e recomendações exclusivamente a partir do ledger e das fontes recuperadas.
3. **Crítico:** tenta derrubar a análise, procurando fatos ausentes, contradições, fundamento vencido, tese adversa, prazo não demonstrado e prova insuficiente.

O cálculo de honorários, prazos, percentuais, datas e regras de vigência deve permanecer fora do LLM sempre que houver regra determinística disponível.

## 6. Contrato universal de saída recomendado

A resposta universal deveria ter, no mínimo, estes blocos:

- `classificacao`: ramo principal, secundários, tipo documental, fase e confiança;
- `partes`: nome, papel, tipo, qualificação, endereço por finalidade e evidência;
- `fatos`: fato, fonte, página, estado epistemológico, controvérsia e confiança;
- `cronologia`: evento, data literal, data interpretada, origem e incerteza;
- `valores`: tipo, valor, moeda, data-base, origem e fórmula;
- `questoes_juridicas`: pergunta, regra acionada, fatos necessários e lacunas;
- `fontes`: norma/precedente, fonte oficial, vigência, data de consulta e status;
- `teses`: principal, subsidiárias, defensivas e adversas, cada uma com fundamentos e evidências;
- `provas`: fato probando, prova existente, prova faltante, ônus, admissibilidade e urgência;
- `riscos`: probabilidade qualitativa, impacto, base e mitigação;
- `pontos_de_esclarecimento`: pergunta, por que muda o resultado e prioridade;
- `honorarios`: UF, tabela, item, vigência, referência e memória determinística;
- `prazos`: apenas detecções até que o motor de prazo confirme o cálculo;
- `acoes`: criar caso, tarefa, alerta, pedido de documento ou revisão;
- `metadados`: modelo, provedor, fontes, versão do prompt, versão do catálogo e logs;
- `hitl`: o que o advogado precisa confirmar antes de cada promoção.

## 7. Prioridade de implementação

### Fase 0 — Bloqueios de confiabilidade

1. Preencher e governar `REGRAS_JURIDICAS.md` com fontes oficiais, vigência, responsável e testes.
2. Proibir qualquer tese, prazo, valor ou recomendação sem estado epistemológico e evidência.
3. Remover ou desabilitar percentuais de chance de êxito sem base estatística validada.
4. Diferenciar claramente “data encontrada” de “prazo calculado”.
5. Fazer a análise estrutural falhar fechado quando campos essenciais não forem entregues.

### Fase 1 — Relatório universal

1. Criar schema universal versionado.
2. Criar Evidence Ledger e reconciliação entre documentos.
3. Integrar a saída completa de documentos e do relato sem descartar campos.
4. Retornar relatório de inteligência separado da proposta mínima de criação do caso.
5. Implementar ramo principal/secundário e desambiguação.

### Fase 2 — Jurídico verificável

1. Executar plano de pesquisa do legal brain por questão.
2. Exigir fonte primária, vigência e cobertura favorável/adversa.
3. Criar analisadores por ramo somente após o contrato comum estar estável.
4. Integrar conflito, competência, prescrição, decadência, prova e admissibilidade como módulos verificáveis.

### Fase 3 — Honorários e operações

1. Integrar o motor de honorários ao fluxo de novo caso.
2. Parametrizar UF, seccional, tabela, vigência e tipo de serviço.
3. Exibir item, fonte, data-base, memória e limitações.
4. Criar ações revisáveis para tarefas, documentos faltantes, prazos e alertas.

### Fase 4 — Avaliação e escolha de IA

1. Construir casos dourados sintéticos e avaliações por ramo.
2. Medir qualidade factual, jurídica, de evidência, custo e latência.
3. Comparar o provedor atual com alternativas apenas nesses testes.
4. Usar modelo rápido para extração simples e modelo mais forte para síntese/crítica, sem permitir que nenhum dos dois bypass os validadores.

## 8. Decisão sobre usar outra IA

**Recomendação atual: não trocar ainda.** O problema predominante é de orquestração, contrato de dados, proveniência e validação. Um modelo superior pode melhorar redação e cobertura, mas não resolverá:

- ausência de honorários no primeiro fluxo;
- falta de evidência por campo;
- regras jurídicas sem catálogo preenchido;
- prazos sem motor de cálculo completo;
- classificação ambígua sem desambiguação;
- correlação lexical entre prova e tese;
- descarte de partes da análise na fusão da Entrada Única.

A escolha de outro modelo deve ser considerada depois da Fase 1, caso os testes mostrem falha persistente em extração, raciocínio adversarial ou aderência jurídica. A arquitetura deve permanecer independente do provedor, sempre através do gateway atual.

## 9. Veredito final

| Capacidade | Situação atual | Veredito |
|---|---|---|
| Texto colado → triagem inicial | Implementada | Apta com revisão |
| Arquivo → OCR/classificação/dossiê | Implementada | Apta com revisão |
| Identificar ramo | Implementada, mas com ambiguidade limitada | Parcial |
| Identificar partes | Implementada | Apta como sugestão, exigir evidência |
| Identificar endereço | Sem contrato universal consistente | Não apta |
| Identificar problema/questão | Implementada em triagem e issue spotting | Parcial |
| Sugerir teses | Implementada | Parcial; exige fontes e ledger |
| Sugerir defesa/contra-argumentos | Parcial, principalmente no dossiê existente | Parcial |
| Apontar provas | Implementada | Apta como hipótese revisável |
| Pontos de atenção | Implementada em alertas/riscos | Apta com validação |
| Pontos de esclarecimento | Implementada no dossiê | Parcial; deve existir desde a entrada |
| Prazo | Detectado, não plenamente calculado | Não apta para automatização |
| Honorário OAB | Motor existente, integrado tardiamente e OAB/MG | Parcial |
| Relatório completo em uma entrada | Não consolidado | Não apta |
| Revisão humana e auditoria | Forte | Apta |

**Síntese:** o EJC já é um bom **sistema de intake jurídico assistido** e possui peças para se tornar um bom **sistema de inteligência jurídica grounded**. Ainda não deve ser apresentado como uma IA que, sozinha, reconhece tudo e entrega uma análise jurídica completa e confiável a partir de qualquer texto ou arquivo. O próximo investimento deve ser no **raciocínio verificável e na integração dos pipelines**, não na simples troca de modelo.

## 10. Arquivos centrais examinados

- `backend/app/services/entrada_service.py`
- `backend/app/services/entrada_juridica_service.py`
- `backend/app/routers/entrada_universal.py`
- `backend/app/services/triagem_entrevista_service.py`
- `backend/app/services/analise_estrategica.py`
- `backend/app/services/legal_brain/brain.py`
- `backend/app/services/legal_brain/contracts.py`
- `backend/app/services/legal_brain/issue_engine.py`
- `backend/app/services/document_classifier.py`
- `backend/app/routers/honorarios_oab.py`
- `docs/GOVERNANCA_IA.md`
- `docs/REGRAS_JURIDICAS.md`
- `docs/importacao-juridica-ramos-plano.md`
- `docs/DESENHO_ENTRADA_UNICA_E_CASO_WORKSPACE.md`

**Nota de validação:** tentei executar a suíte focada de testes, mas o ambiente local do clone não possui o módulo `pytest` instalado; portanto, o presente documento combina inspeção estática detalhada do código, contratos e documentação com a execução falha explicitamente registrada, sem presumir que os testes passaram.


## 11. Complemento após o documento de requisitos anexado

O documento anexado confirma que o objetivo correto não é criar um chat jurídico, mas transformar a Entrada Única em um **motor de estruturação e inteligência jurídica**. Ele também exige uma classificação individual das capacidades. A matriz abaixo complementa o diagnóstico anterior.

### 11.1 Classificação individual das capacidades

| Capacidade | Classificação | Evidência/observação |
|---|---|---|
| Entrada de texto colado | **Existente mas incompleta** | `triagem_entrevista_service.py` gera painel preliminar, mas não o dossiê jurídico completo. |
| Upload de PDF/DOCX/imagem e preservação | **Existente e funcional** | Pipeline de upload, hash, OCR, persistência antecipada e fail-soft. |
| Conjunto de documentos | **Existente mas incompleta** | Monta dossiê e compara documentos, mas a síntese universal não conserva todos os resultados. |
| Extração de partes | **Existente mas incompleta** | Extrai autor/réu e dados pessoais; falta contrato universal completo para profissão, estado civil, endereço, CEP, contato, representação e relação entre partes. |
| Extração de endereço | **Ausente como capacidade universal** | Há campos em domínios específicos, mas não um objeto universal com finalidade, origem, página e confiança. |
| Extração de datas e linha do tempo | **Existente mas incompleta** | Datas possuem metadados no intake; falta estado confirmado/aproximado/inferido aplicado de forma universal e reconciliação robusta. |
| Extração de valores | **Existente mas incompleta** | `valor_causa` e campos bancários existem; falta normalização universal de moeda, tipo, data-base, origem e fórmula. |
| Classificação de ramo/subramo | **Existente mas incompleta** | Triagem e taxonomia existem; faltam ramos secundários, conflito entre hipóteses e desambiguação guiada. |
| Identificação do problema central | **Existente mas incompleta** | Issue engine e triagem existem; a Entrada Única não entrega sempre problema central e questões secundárias em contrato completo. |
| Fatos documentados/declarados/inferidos | **Implementada de forma inadequada** | `EvidenceState` existe nos contratos, mas não é obrigatório em cada fato da saída da Entrada Única. |
| Contradições entre documentos | **Existente mas incompleta** | Existem comparação e alertas em módulos; falta uma saída universal de contradição com documentos, páginas e impacto. |
| Perguntas de esclarecimento | **Existente mas incompleta** | O dossiê gera perguntas; o novo fluxo deveria fazê-lo antes da criação do caso e priorizar perguntas que mudam decisão. |
| Issue spotting | **Existente mas incompleta** | `issue_engine.py` possui regras determinísticas úteis, mas cobertura ainda é limitada e não equivale a análise de mérito. |
| Teses principais/subsidiárias/alternativas | **Existente mas incompleta** | Análise estratégica e matriz de teses existem; integração universal e vínculo obrigatório com evidência/fonte ainda faltam. |
| Argumentos da parte contrária | **Existente mas incompleta** | Há campos de falhas adversas e crítica opcional; a segunda visão não é obrigatória em todos os fluxos. |
| Plano de provas | **Existente mas incompleta** | Há `provas_necessarias` e `EvidenceLink`, mas ainda falta separar integralmente prova existente, cliente, terceiro, parte contrária, ordem judicial, preservação e risco de perda. |
| Pesquisa normativa/jurisprudencial | **Existente mas incompleta** | RAG, LexML/DataJud/tribunais e registros de autoridade existem; o caminho da Entrada Única não garante cobertura completa e atualizada por questão. |
| Proteção contra prompt injection | **Existente e funcional como guardrail de orquestração** | Há delimitadores e instruções explícitas no orquestrador e testes específicos. Deve ser validada também no novo pipeline universal e em cada ferramenta. |
| Rastreabilidade conclusão → fonte | **Existente mas incompleta** | AILog, fontes RAG e autoridades existem; falta a navegação granular conclusão → fato → página/trecho → fonte jurídica. |
| Honorários OAB | **Existente mas incompleta** | Motor estruturado OAB/MG e versionamento existem; falta integração na entrada nova e parametrização geral por seccional. |
| Eventos críticos e tarefas | **Existente mas incompleta** | Prazos e ações são detectados; falta a materialização universal de evento candidato → tarefa/prazo após confirmação. |
| Memória incremental | **Existente mas incompleta** | Snapshots append-only e versões documentais existem; falta relatório explícito “o que mudou após este documento?” com impacto em fatos, provas, teses e riscos. |
| Persistência após validação | **Existente e funcional em parte** | Criação de caso, partes, documentos e snapshot têm gates; tese/prova/tarefa/honorário ainda não são todos promovidos por um fluxo único de aprovação. |
| Schemas de inteligência | **Existente mas incompleta** | Existem `CaseIntelligenceSnapshot`, `LegalIssue`, `ThesisCandidate`, `AuthorityRecord` e `EvidenceLink`; o snapshot ainda é JSONB de estrutura livre e não funciona como contrato universal obrigatório de todos os fluxos. |
| Roteamento por complexidade | **Existente mas incompleta** | Gateway, tiers, modelos locais/externos e tarefas existem; a política precisa ser medida por qualidade/custo/latência em casos dourados. |
| Modelo rápido versus modelo de raciocínio | **Existente mas incompleta** | Há `chat_rapido`, `triagem`, `document_extraction`, `estrategia` e níveis de inteligência; falta uma política de decisão baseada em complexidade e fallback testado. |
| Modelo premium sob demanda | **Existente mas incompleta** | Há Anthropic/nível alto e crítica adversarial opcional; não há ainda um modo de segunda opinião premium explicitamente controlado pelo advogado. |
| Sistema operacional jurídico integrado | **Somente parcialmente implementado** | O domínio possui as peças, mas a Entrada Única ainda não é o orquestrador único de todas elas. |

### 11.2 Componentes que devem ser reaproveitados

O anexo reforça que não se deve criar uma terceira arquitetura. Os componentes a preservar e consolidar são:

- `backend/app/routers/entrada.py` e `backend/app/services/entrada_service.py` como porta/orquestrador da Entrada Única;
- `backend/app/routers/entrada_universal.py` como pipeline de preservação, OCR, classificação e análise documental;
- `backend/app/services/triagem_entrevista_service.py` para triagem inicial do relato;
- `backend/app/services/analise_estrategica.py` como componente de síntese estratégica, após receber um contexto estruturado;
- `backend/app/services/legal_brain/` para issue spotting, planos de pesquisa e contratos;
- `backend/app/models/case_intelligence.py` para snapshots versionados e HITL;
- `backend/app/models/matriz_teses.py` para questões, teses candidatas, autoridades e vínculos de evidência;
- `backend/app/services/ai/core/orchestrator.py` e `backend/app/services/ai/delimitador.py` para roteamento, delimitação de dados e proteção contra prompt injection;
- `backend/app/services/ai_gateway.py` para independência de provedor;
- `fee_proposal_service.py` e `honorarios_oab.py` para honorários determinísticos e versionados;
- serviços de RAG, verificador de jurisprudência, fontes oficiais, DataJud e LexML;
- fluxos existentes de documentos, provas, prazos, conflitos, snapshots e auditoria.

### 11.3 Duplicação arquitetural observada

A duplicação principal não é necessariamente de código morto, mas de **caminhos de raciocínio**:

1. triagem por relato;
2. análise documental da Entrada Universal;
3. análise estratégica de caso;
4. dossiê jurídico da Entrada Única;
5. legal brain determinístico;
6. matriz de teses;
7. Raio-X e outros módulos de inteligência.

Todos possuem conceitos sobrepostos de área, fatos, teses, riscos, provas e próximos passos. O risco é o mesmo caso receber classificações diferentes, perder campos durante a fusão ou ter uma tese armazenada em texto em um fluxo e como entidade estruturada em outro.

A correção recomendada é um **adaptador canônico**, não uma nova IA: todos os fluxos devem produzir o mesmo `CaseIntelligence` versionado, ainda que cada fluxo preencha somente seu subconjunto. O JSONB do snapshot pode continuar como envelope de compatibilidade, mas os objetos críticos devem ser validados por schema e referenciar entidades de fato, prova, autoridade e tese.

### 11.4 Avaliação de modelos e roteamento

A arquitetura atual já possui camada própria de gateway e contempla Ollama, Anthropic, Groq e Maritaca sob políticas de configuração e sanitização. Isso atende ao requisito de não ficar estruturalmente dependente de um fornecedor.

No entanto, não é possível afirmar, apenas pela inspeção do repositório e sem executar uma bateria comparativa com configuração real, que a escolha atual de cada modelo seja a melhor em qualidade, custo, latência ou privacidade. A decisão correta é estabelecer uma matriz de avaliação:

| Classe de tarefa | Roteamento recomendado | Critério de promoção |
|---|---|---|
| OCR, parsing e normalização | determinístico/local primeiro | taxa de extração correta e custo |
| Classificação documental e ramo | modelo rápido + regras | precisão, confiança calibrada e abstensão |
| Entidades, datas e valores | extrator estruturado/local quando possível | precisão e evidência por campo |
| Issue spotting | regras do legal brain + modelo rápido | recall de questões sem excesso de falsos positivos |
| Pesquisa jurídica | ferramentas/fontes oficiais + modelo de síntese | citação verificável e vigência |
| Teses e estratégia | modelo de raciocínio | aderência aos fatos, fontes e contra-argumentos |
| Crítica adversarial | segundo modelo independente | descoberta de fragilidades novas |
| Caso excepcionalmente complexo | premium sob demanda, com comando do advogado | ganho mensurável sobre o modelo padrão |

**Conclusão sobre troca de modelo:** o anexo não traz evidência suficiente para justificar uma troca imediata. A primeira etapa deve ser medir o roteamento existente. Só recomendar mudança de modelo se um benchmark sintético demonstrar diferença objetiva em qualidade, custo, privacidade, estabilidade, latência, contexto ou precisão.

### 11.5 Requisitos adicionais que passam a ser P0/P1

Com o anexo, três itens sobem de prioridade:

- **P0 — prompt injection em documentos:** já há guardrails relevantes no orquestrador, mas o teste deve cobrir o pipeline inteiro, inclusive OCR, RAG, ferramentas e importação de processo. Texto documental deve sempre ser tratado como dado não confiável, nunca como instrução.
- **P0 — rastreabilidade navegável:** não basta guardar `fontes_rag` no resultado; cada conclusão exibida deve poder retornar ao fato, documento, página/trecho e autoridade jurídica usada.
- **P1 — análise incremental:** snapshots e versões já são uma fundação adequada, mas deve ser criada uma operação explícita de comparação que mostre ao advogado o impacto do documento novo sem reprocessar silenciosamente o caso inteiro.

### 11.6 Critério de homologação recomendado

A funcionalidade só deve ser considerada pronta quando um conjunto sintético cobrir, no mínimo:

1. narrativa simples com duas partes, contrato, datas, valor, inadimplemento, endereço, tentativa de solução e documento faltante;
2. o mesmo caso em PDF digital;
3. PDF digitalizado com OCR;
4. DOCX;
5. vários documentos;
6. documentos contraditórios;
7. processo extenso;
8. documento contendo prompt injection;
9. caso multidisciplinar;
10. documento novo em caso já existente.

Para cada cenário, o sistema deve demonstrar: partes, problema, área, fatos, datas, valores, endereço, teses, argumentos contrários, riscos, provas, lacunas, estratégia, honorários, fontes, confidence metadata e rastreabilidade. O gabarito deve ser produzido/revisado por advogado e a taxa de informação inventada deve ser medida separadamente, com meta tendendo a zero.

O anexo, portanto, **não contradiz o relatório anterior**; ele confirma o diagnóstico e fornece os requisitos para a próxima fase: consolidar os componentes existentes em um núcleo cognitivo estruturado, sem transformar o sistema em um chatbot e sem declarar a função pronta apenas porque existem prompts ou endpoints.
