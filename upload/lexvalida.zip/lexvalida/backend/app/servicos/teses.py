"""Teses de defesa de massa: o que funcionou contra cada parte contrária recorrente.

Estatística DESCRITIVA da base do próprio escritório (desfechos registrados), sem previsão de
resultado. Percentuais só são exibidos a partir de AMOSTRA_MINIMA ocorrências.
"""
from __future__ import annotations

import re
from collections import defaultdict

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core.texto import normalizar
from ..models import Caso, Desfecho, Minuta

AMOSTRA_MINIMA = 5
FAVORAVEIS = {"procedente", "parcial", "acordo"}


def _chave_parte(nome: str | None) -> str:
    n = normalizar(nome or "")
    n = re.sub(r"\b(s\.?a\.?|ltda|me|epp|eireli|cia|companhia)\b", " ", n)
    return " ".join(n.split())


def mapa(db: Session, parte_contraria: str | None = None, assunto_tpu: int | None = None) -> dict:
    alvo = _chave_parte(parte_contraria) if parte_contraria else None
    grupos: dict[str, dict] = defaultdict(lambda: {"total": 0, "favoraveis": 0, "teses": defaultdict(lambda: [0, 0]),
                                                   "precedentes": defaultdict(int), "nome": ""})
    for d in db.scalars(select(Desfecho)):
        m = db.get(Minuta, d.minuta_id)
        c = db.get(Caso, m.caso_id) if m and m.caso_id else None
        if not c or not c.parte_contraria:
            continue
        k = _chave_parte(c.parte_contraria)
        if alvo and alvo not in k:
            continue
        if assunto_tpu and assunto_tpu not in {int(a.get("codigo")) for a in (c.assuntos_tpu or []) if isinstance(a, dict) and a.get("codigo")}:
            continue
        g = grupos[k]
        g["nome"] = g["nome"] or c.parte_contraria
        g["total"] += 1
        fav = d.resultado in FAVORAVEIS
        g["favoraveis"] += fav
        for t in d.teses_acolhidas or []:
            g["teses"][t][0] += 1
        for t in d.teses_rejeitadas or []:
            g["teses"][t][1] += 1
        for p in d.precedentes_decisivos or []:
            g["precedentes"][p] += 1
    saida = []
    for g in grupos.values():
        suficiente = g["total"] >= AMOSTRA_MINIMA
        teses = sorted(({"tese": t, "acolhida": a, "rejeitada": r,
                         "taxa_acolhimento": round(a / (a + r), 2) if suficiente and (a + r) else None}
                        for t, (a, r) in g["teses"].items()), key=lambda x: -(x["acolhida"] - x["rejeitada"]))
        saida.append({"parte_contraria": g["nome"], "desfechos": g["total"],
                      "taxa_favoravel": round(g["favoraveis"] / g["total"], 2) if suficiente else None,
                      "amostra_suficiente": suficiente, "teses": teses,
                      "precedentes_decisivos": sorted(g["precedentes"].items(), key=lambda x: -x[1])[:10]})
    return {"grupos": sorted(saida, key=lambda x: -x["desfechos"]), "amostra_minima": AMOSTRA_MINIMA,
            "nota": "Estatística descritiva da base do escritório; não é previsão de resultado."}
