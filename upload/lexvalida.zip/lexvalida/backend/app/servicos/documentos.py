"""Casos, documentos dos autos e verificação de citações contra a base."""
from __future__ import annotations

from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core import citacoes
from ..core.hierarquia import avaliar_status
from ..core.ingestao import DocumentoProcessado, processar_pdf, processar_texto, remover_trechos
from ..models import Caso, Documento, Norma, Precedente, Trecho
from . import conhecimento


def ingerir_documento(db: Session, caso_id: int, nome: str, dados: bytes) -> tuple[Documento, DocumentoProcessado]:
    caso = db.get(Caso, caso_id)
    if not caso:
        raise ValueError("Caso inexistente.")
    if nome.lower().endswith(".pdf"):
        proc = processar_pdf(dados, nome)
    else:
        proc = processar_texto(dados.decode("utf-8", errors="replace"), nome)
    doc = Documento(caso_id=caso_id, nome=nome, paginas=proc.paginas, seguranca=proc.relatorio_seguranca(),
                    liberado_para_ia=not proc.risco_alto)
    db.add(doc)
    db.commit()
    _indexar_paginas(db, doc, proc)
    return doc, proc


def _indexar_paginas(db: Session, doc: Documento, proc: DocumentoProcessado) -> None:
    conhecimento.remover_fonte(db, "autos", str(doc.id))
    for i, texto in enumerate(proc.texto_por_pagina, start=1):
        if texto.strip():
            blocos = [list(b.bbox) for b in proc.blocos if b.pagina == i]
            conhecimento.indexar(db, "autos", str(doc.id), texto, caso_id=doc.caso_id, pagina=i,
                                 bbox=blocos[:50] or None)


def decidir_trechos_suspeitos(db: Session, documento_id: int, remover: list[str], liberar: bool = True) -> Documento:
    """Decisão humana sobre trechos sinalizados: os removidos não seguem para a IA."""
    doc = db.get(Documento, documento_id)
    if not doc:
        raise ValueError("Documento inexistente.")
    trechos = db.scalars(select(Trecho).where(Trecho.fonte_tipo == "autos", Trecho.fonte_id == str(doc.id))).all()
    paginas: dict[int, list[str]] = {}
    for t in sorted(trechos, key=lambda x: (x.pagina or 0, x.ordem)):
        paginas.setdefault(t.pagina or 1, []).append(t.texto)
    proc = DocumentoProcessado(doc.nome, doc.paginas, [], ["\n".join(paginas.get(i, [])) for i in range(1, doc.paginas + 1)],
                               [], [], [])
    proc = remover_trechos(proc, remover)
    _indexar_paginas(db, doc, proc)
    seg = dict(doc.seguranca or {})
    seg["decisao_usuario"] = {"removidos": remover, "liberado": liberar}
    doc.seguranca, doc.liberado_para_ia = seg, liberar
    db.commit()
    return doc


def texto_da_pagina(db: Session, documento_id: str, pagina: int) -> dict | None:
    doc = db.get(Documento, int(documento_id)) if str(documento_id).isdigit() else None
    if not doc:
        return None
    ts = db.scalars(select(Trecho).where(Trecho.fonte_tipo == "autos", Trecho.fonte_id == str(doc.id),
                                         Trecho.pagina == pagina).order_by(Trecho.ordem)).all()
    if not ts:
        return None
    return {"documento_nome": doc.nome, "texto": "\n".join(t.texto for t in ts), "pagina": pagina}


def texto_dos_autos(db: Session, caso_id: int, limite_chars: int = 60000) -> str:
    """Texto dos autos liberados para IA, com cabeçalhos [doc:ID p.N] para referência rastreável."""
    docs = db.scalars(select(Documento).where(Documento.caso_id == caso_id, Documento.liberado_para_ia.is_(True))).all()
    partes, total = [], 0
    for d in docs:
        ts = db.scalars(select(Trecho).where(Trecho.fonte_tipo == "autos", Trecho.fonte_id == str(d.id))
                        .order_by(Trecho.pagina, Trecho.ordem)).all()
        pag_atual = None
        for t in ts:
            if t.pagina != pag_atual:
                partes.append(f"\n<<doc:{d.id} \"{d.nome}\" p.{t.pagina}>>")
                pag_atual = t.pagina
            partes.append(t.texto)
            total += len(t.texto)
            if total > limite_chars:
                partes.append("\n[... autos truncados por limite de contexto; use a busca nos autos ...]")
                return "\n".join(partes)
    return "\n".join(partes)


def resolver_citacoes(db: Session, texto: str, data_fatos: date | None) -> citacoes.Resolucao:
    ref = data_fatos or date.today()

    def prec(pid: str):
        p = db.get(Precedente, pid)
        if not p:
            return None
        st = avaliar_status(p.status)
        return {"rotulo": p.rotulo, "ementa": p.ementa, "tese": p.tese, "status": p.status,
                "alerta_status": st["alerta"], "bloqueia": st["bloqueia"], "verificado": p.verificado,
                "fonte_url": p.fonte_url}

    def norma(nid: str):
        n = db.get(Norma, nid)
        if not n:
            return None
        v, atual = conhecimento.versao_vigente(n, ref), conhecimento.versao_vigente(n, date.today())
        return {"rotulo": n.rotulo, "texto": v.texto if v else "", "vigente_na_data": v is not None,
                "difere_da_atual": bool(v and atual and v.id != atual.id), "verificado": n.verificado,
                "inicio_desconhecido": bool(v and v.vigencia_inicio is None),
                "data_referencia": ref.strftime("%d/%m/%Y")}

    return citacoes.resolver(texto, prec, norma, lambda d, p: texto_da_pagina(db, d, p))
