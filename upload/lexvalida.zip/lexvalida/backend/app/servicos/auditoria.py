from __future__ import annotations

from sqlalchemy.orm import Session

from ..models import Auditoria


def registrar(db: Session, acao: str, alvo: str = "", detalhe: dict | None = None,
              provedor: str | None = None, usuario: str = "local") -> None:
    db.add(Auditoria(acao=acao, alvo=alvo, detalhe=detalhe or {}, provedor=provedor, usuario=usuario))
    db.commit()
