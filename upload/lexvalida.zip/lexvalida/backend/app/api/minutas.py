"""Minutas (agente com supervisão humana), lotes, habilidades, estilo e auditoria."""
from __future__ import annotations

import io
from datetime import date

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from fastapi.responses import PlainTextResponse, StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..agente import lote as lote_srv
from ..agente import pipeline
from ..db import get_session, nova_sessao
from ..llm import prompts
from ..llm.provedores import ErroProvedor, construir, extrair_json
from ..models import Auditoria, Desfecho, Minuta, Skill
from ..servicos import skills as skills_srv

r = APIRouter(prefix="/api", tags=["minutas"])


def _erro(e: Exception) -> HTTPException:
    if isinstance(e, ErroProvedor):
        return HTTPException(503, str(e))
    return HTTPException(422, str(e))


def _minuta(m: Minuta, completo: bool = True) -> dict:
    d = {"id": m.id, "caso_id": m.caso_id, "tipo_peca": m.tipo_peca, "pedido": m.pedido, "fase": m.fase,
         "status": m.status, "aprovada_por": m.aprovada_por, "criado_em": m.criado_em.isoformat(),
         "bloqueado": (m.verificacao or {}).get("bloqueado")}
    if completo:
        est = dict(m.estado or {})
        est.pop("cofre", None)  # o cofre de anonimização não trafega pela API
        d.update({"estado": est, "texto": m.texto, "texto_resolvido": m.texto_resolvido, "verificacao": m.verificacao})
    return d


class IniciarIn(BaseModel):
    caso_id: int | None = None
    tipo_peca: str
    pedido: str
    skills_fixadas: list[str] = []
    anonimizar_autos: bool = False
    gerar_peca_contraria: bool = True


@r.post("/minutas")
def iniciar(p: IniciarIn, db: Session = Depends(get_session)):
    try:
        return _minuta(pipeline.iniciar(db, p.caso_id, p.tipo_peca, p.pedido, p.skills_fixadas,
                                        p.anonimizar_autos, p.gerar_peca_contraria))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.get("/minutas")
def listar(db: Session = Depends(get_session)):
    return [_minuta(m, False) for m in db.scalars(select(Minuta).order_by(Minuta.id.desc()).limit(200))]


@r.get("/minutas/{mid}")
def obter(mid: int, db: Session = Depends(get_session)):
    m = db.get(Minuta, mid)
    if not m:
        raise HTTPException(404, "Minuta inexistente.")
    return _minuta(m)


class RespostasIn(BaseModel):
    respostas: dict


@r.post("/minutas/{mid}/respostas")
def responder(mid: int, p: RespostasIn, db: Session = Depends(get_session)):
    try:
        return _minuta(pipeline.responder(db, mid, p.respostas))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


class RoteiroIn(BaseModel):
    secoes: list[dict] | None = None


def _executar_roteiro(mid: int, secoes):
    db = nova_sessao()
    try:
        pipeline.aprovar_roteiro(db, mid, secoes)
    except Exception as e:  # noqa: BLE001
        m = db.get(Minuta, mid)
        if m:
            m.estado = {**(m.estado or {}), "erro": str(e)}
            m.fase = "falha"
            db.commit()
    finally:
        db.close()


@r.post("/minutas/{mid}/roteiro/aprovar")
def aprovar_roteiro(mid: int, p: RoteiroIn, bg: BackgroundTasks, assincrono: bool = False,
                    db: Session = Depends(get_session)):
    if assincrono:
        m = db.get(Minuta, mid)
        if not m or m.fase != "aprovar_roteiro":
            raise HTTPException(422, "Minuta fora da fase de aprovação do roteiro.")
        bg.add_task(_executar_roteiro, mid, p.secoes)
        return {"id": mid, "fase": "pesquisa", "assincrono": True}
    try:
        return _minuta(pipeline.aprovar_roteiro(db, mid, p.secoes))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


class TextoIn(BaseModel):
    texto: str
    nota: str = "Edição do advogado"


@r.put("/minutas/{mid}/texto")
def editar(mid: int, p: TextoIn, db: Session = Depends(get_session)):
    try:
        return _minuta(pipeline.editar(db, mid, p.texto, p.nota))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.post("/minutas/{mid}/verificar")
def verificar(mid: int, db: Session = Depends(get_session)):
    try:
        return _minuta(pipeline.verificar(db, mid))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


class AprovarIn(BaseModel):
    responsavel: str
    ciente_alertas: bool = False


@r.post("/minutas/{mid}/aprovar")
def aprovar(mid: int, p: AprovarIn, db: Session = Depends(get_session)):
    try:
        return _minuta(pipeline.aprovar(db, mid, p.responsavel, p.ciente_alertas))
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.get("/minutas/{mid}/versoes")
def versoes(mid: int, db: Session = Depends(get_session)):
    return pipeline.versoes(db, mid)


class DesfechoIn(BaseModel):
    resultado: str
    teses_acolhidas: list[str] = []
    teses_rejeitadas: list[str] = []
    precedentes_decisivos: list[str] = []
    observacoes: str = ""
    data: date | None = None


@r.post("/minutas/{mid}/desfecho")
def desfecho(mid: int, p: DesfechoIn, db: Session = Depends(get_session)):
    if not db.get(Minuta, mid):
        raise HTTPException(404, "Minuta inexistente.")
    d = Desfecho(minuta_id=mid, **p.model_dump())
    db.add(d)
    db.commit()
    return {"id": d.id}


@r.get("/desfechos/estatisticas")
def estat_desfechos(db: Session = Depends(get_session)):
    cont: dict[str, dict] = {}
    for d in db.scalars(select(Desfecho)):
        for p in d.precedentes_decisivos or []:
            c = cont.setdefault(p, {"acolhido": 0, "total": 0})
            c["total"] += 1
            c["acolhido"] += d.resultado in ("procedente", "parcial", "acordo")
    return {"precedentes": cont, "nota": "Estatística descritiva da base própria; não é previsão de resultado."}


@r.get("/minutas/{mid}/exportar")
def exportar(mid: int, formato: str = "docx", db: Session = Depends(get_session)):
    m = db.get(Minuta, mid)
    if not m:
        raise HTTPException(404, "Minuta inexistente.")
    texto = m.texto_resolvido or m.texto
    rotulo = "MINUTA APROVADA" if m.status == "APROVADA" else "RASCUNHO, SUJEITO A REVISÃO DO ADVOGADO"
    if formato == "txt":
        return PlainTextResponse(f"{rotulo}\n\n{texto}")
    from docx import Document
    from docx.shared import Pt
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name, st.font.size = "Times New Roman", Pt(12)
    doc.add_paragraph(rotulo).runs[0].bold = True
    for par in texto.split("\n"):
        if par.strip() and par.strip().isupper() and len(par.strip()) < 120:
            doc.add_heading(par.strip(), level=2)
        else:
            doc.add_paragraph(par)
    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                             headers={"Content-Disposition": f'attachment; filename="minuta-{mid}.docx"'})


# ------------------------------------------------------------------------- lotes
class LoteIn(BaseModel):
    caso_ids: list[int]
    instrucao: str
    tipo_peca: str
    modo: str = "etapas"
    caso_modelo_id: int | None = None
    roteiro: list[dict] | None = None


@r.post("/lotes")
def criar_lote(p: LoteIn, db: Session = Depends(get_session)):
    try:
        l = lote_srv.criar(db, p.caso_ids, p.instrucao, p.tipo_peca, p.modo, p.caso_modelo_id, p.roteiro)
        return lote_srv.status(db, l.id)
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.post("/lotes/{lid}/aprovar-modelo")
def aprovar_modelo(lid: int, db: Session = Depends(get_session)):
    try:
        lote_srv.aprovar_modelo(db, lid)
        return lote_srv.status(db, lid)
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


def _gerar_lote(lid: int, apenas_falhas: bool):
    db = nova_sessao()
    try:
        lote_srv.gerar_demais(db, lid, apenas_falhas)
    finally:
        db.close()


@r.post("/lotes/{lid}/gerar")
def gerar_lote(lid: int, bg: BackgroundTasks, apenas_falhas: bool = False, assincrono: bool = True,
               db: Session = Depends(get_session)):
    if assincrono:
        bg.add_task(_gerar_lote, lid, apenas_falhas)
        return {"id": lid, "fase": "gerando", "assincrono": True}
    try:
        lote_srv.gerar_demais(db, lid, apenas_falhas)
        return lote_srv.status(db, lid)
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.get("/lotes/{lid}")
def status_lote(lid: int, db: Session = Depends(get_session)):
    try:
        return lote_srv.status(db, lid)
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


# --------------------------------------------------------------------- habilidades
def _skill(s: Skill, completo: bool = False) -> dict:
    d = {"id": s.id, "slug": s.slug, "titulo": s.titulo, "tipo": s.tipo, "area": s.area, "descricao": s.descricao,
         "gatilhos": s.gatilhos, "oficial": s.oficial, "versao": s.versao, "dono": s.dono, "ativa": s.ativa,
         "origem_id": s.origem_id, "origem_versao": s.origem_versao}
    if completo:
        d.update({"conteudo": s.conteudo, "historico": s.historico})
    return d


@r.post("/skills/sincronizar")
def sincronizar(db: Session = Depends(get_session)):
    return skills_srv.sincronizar_oficiais(db)


@r.get("/skills")
def listar_skills(db: Session = Depends(get_session)):
    return [_skill(s) for s in db.scalars(select(Skill).order_by(Skill.tipo, Skill.slug))]


@r.get("/skills/{sid}")
def obter_skill(sid: int, db: Session = Depends(get_session)):
    s = db.get(Skill, sid)
    if not s:
        raise HTTPException(404, "Habilidade inexistente.")
    return _skill(s, True)


class ForkIn(BaseModel):
    conteudo: str
    nota: str = ""
    dono: str = "local"


@r.post("/skills/{slug}/fork")
def fork(slug: str, p: ForkIn, db: Session = Depends(get_session)):
    return _skill(skills_srv.criar_fork(db, slug, p.conteudo, p.dono, p.nota), True)


class SkillMdIn(BaseModel):
    skill_md: str
    dono: str = "local"


@r.post("/skills")
def criar_skill(p: SkillMdIn, db: Session = Depends(get_session)):
    try:
        return _skill(skills_srv.criar_propria(db, p.skill_md, p.dono), True)
    except ValueError as e:
        raise HTTPException(422, str(e)) from e


@r.get("/skills-atualizacoes")
def atualizacoes(dono: str = "local", db: Session = Depends(get_session)):
    return skills_srv.atualizacoes_pendentes(db, dono)


@r.get("/skills/fork/{fid}/mescla")
def propor_mescla(fid: int, db: Session = Depends(get_session)):
    try:
        return skills_srv.propor_mescla(db, fid)
    except ValueError as e:
        raise HTTPException(422, str(e)) from e


class MesclaIn(BaseModel):
    texto: str


@r.put("/skills/fork/{fid}/mescla")
def aplicar_mescla(fid: int, p: MesclaIn, db: Session = Depends(get_session)):
    return _skill(skills_srv.aplicar_mescla(db, fid, p.texto), True)


class SelecaoIn(BaseModel):
    contexto: str
    tipo_peca: str = ""
    fixadas: list[str] = []


@r.post("/skills/selecionar")
def selecionar(p: SelecaoIn, db: Session = Depends(get_session)):
    sel, _ = skills_srv.selecionar_para(db, p.contexto, p.tipo_peca, p.fixadas)
    return sel


# ------------------------------------------------------------------- estilo e auditoria
class EstiloIn(BaseModel):
    modelos: list[str]


@r.post("/estilo/perfil")
def perfil_estilo(p: EstiloIn):
    try:
        prov = construir()
        resp = prov.gerar("estilo", prompts.SISTEMA_BASE + "\n\n" + prompts.ESTILO,
                          "\n\n=====\n\n".join(f"<modelo>\n{m[:15000]}\n</modelo>" for m in p.modelos[:8]),
                          {"modelos": p.modelos})
        return extrair_json(resp.texto)
    except Exception as e:  # noqa: BLE001
        raise _erro(e) from e


@r.get("/auditoria")
def listar_auditoria(limite: int = 200, db: Session = Depends(get_session)):
    return [{"id": a.id, "momento": a.momento.isoformat(), "usuario": a.usuario, "acao": a.acao, "alvo": a.alvo,
             "provedor": a.provedor, "detalhe": a.detalhe}
            for a in db.scalars(select(Auditoria).order_by(Auditoria.id.desc()).limit(min(limite, 1000)))]
