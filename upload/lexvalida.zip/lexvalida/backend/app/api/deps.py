from __future__ import annotations

import hmac

from fastapi import Header, HTTPException

from ..config import get_config
from ..db import get_session  # noqa: F401  (reexport)


def exigir_token(x_api_token: str | None = Header(default=None)) -> None:
    esperado = get_config().api_token
    if esperado and not (x_api_token and hmac.compare_digest(x_api_token, esperado)):
        raise HTTPException(status_code=401, detail="Token de API ausente ou inválido.")
