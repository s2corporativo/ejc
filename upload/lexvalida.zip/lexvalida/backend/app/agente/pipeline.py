"""Agente de redação com supervisão humana obrigatória (máquina de estados).

Fases:
  planejamento -> perguntas (aguarda advogado) -> aprovar_roteiro (aguarda advogado)
  -> pesquisa -> redacao -> verificacao -> revisao (RASCUNHO, aguarda aprovação humana)

Nenhuma minuta sai como APROVADA sem ato explícito do usuário, e a aprovação é bloqueada
enquanto houver problema bloqueante na verificação (citação inexistente, precedente
superado, norma não vigente na data dos fatos, trecho dos autos não encontrado).
"""
from __future__ import annotations

import json
from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core import citacoes
from ..core.aderencia import extrair_afirmacoes, heuristica
from ..core.anonimizador import Cofre, anonimizar, desanonimizar
from ..core.julgador import simular
from ..llm import prompts
from ..llm.provedores import Provedor, construir, extrair_json
from ..models import Caso, Minuta, Precedente, VersaoMinuta
from ..servicos import auditoria, conhecimento, documentos
from ..servicos import skills as skills_srv

MAX_REFORMULACOES = 2


class ErroFluxo(RuntimeError):
    pass


def _evento(m: Minuta, tipo: str, **dados) -> None:
    est = dict(m.estado or {})
    est.setdefault("eventos", []).append({"tipo": tipo, **dados})
    m.estado = est


def _set(m: Minuta, **kv) -> None:
    est = dict(m.estado or {})
    est.update(kv)
    m.estado = est


def _provedores(db: Session, m: Minuta) -> tuple[Provedor, Provedor]:
    caso = db.get(Caso, m.caso_id) if m.caso_id else None
    sig = bool(caso and caso.sigiloso and not (m.estado or {}).get("anonimizado"))
    return construir(papel="redator", sigiloso=sig), construir(papel="verificador", sigiloso=sig)


def _chamar(db: Session, prov: Provedor, m: Minuta, tarefa: str, sistema: str, usuario: str,
            dados: dict, json_esperado: bool = True, max_tokens: int = 4000):
    r = prov.gerar(tarefa, sistema, usuario, dados, max_tokens=max_tokens)
    est = dict(m.estado or {})
    est.setdefault("raciocinios", []).append({"tarefa": tarefa, "raciocinio": r.raciocinio[:4000]})
    m.estado = est
    auditoria.registrar(db, f"llm:{tarefa}", f"minuta:{m.id}", {"uso": r.uso}, f"{r.provedor}:{r.modelo}")
    return extrair_json(r.texto) if json_esperado else r.texto


def _autos(db: Session, m: Minuta) -> str:
    if not m.caso_id:
        return ""
    texto = documentos.texto_dos_autos(db, m.caso_id)
    est = m.estado or {}
    if est.get("anonimizado") and texto:
        cofre = Cofre.from_dict(est.get("cofre", {}))
        r = anonimizar(texto, cofre)
        _set(m, cofre=r["cofre"], identificadores_indiretos=r["identificadores_indiretos"][:20])
        return r["texto"]
    return texto


# ------------------------------------------------------------------ fases
def iniciar(db: Session, caso_id: int | None, tipo_peca: str, pedido: str,
            skills_fixadas: list[str] | None = None, anonimizar_autos: bool = False,
            gerar_peca_contraria: bool = True) -> Minuta:
    caso = db.get(Caso, caso_id) if caso_id else None
    if caso_id and not caso:
        raise ErroFluxo("Caso inexistente.")
    if caso:
        bloqueados = [d.nome for d in caso.documentos if not d.liberado_para_ia]
        if bloqueados:
            raise ErroFluxo("Documentos com suspeita de prompt injection aguardam sua decisão: " + ", ".join(bloqueados))
    m = Minuta(caso_id=caso_id, tipo_peca=tipo_peca, pedido=pedido, fase="planejamento",
               estado={"skills_fixadas": skills_fixadas or [], "anonimizado": anonimizar_autos,
                       "gerar_peca_contraria": gerar_peca_contraria})
    db.add(m)
    db.commit()
    redator, _ = _provedores(db, m)
    autos = _autos(db, m)
    usuario = (f"Tipo de peça: {tipo_peca}\nPedido do advogado: {pedido}\n"
               f"Data dos fatos: {caso.data_fatos if caso and caso.data_fatos else 'não informada'}\n"
               f"<autos>\n{autos[:40000]}\n</autos>")
    plano = _chamar(db, redator, m, "planejar", prompts.SISTEMA_BASE + "\n\n" + prompts.PLANEJAR, usuario,
                    {"tipo_peca": tipo_peca, "pedido": pedido, "autos_texto": autos})
    _set(m, plano=plano, perguntas=plano.get("perguntas", []))
    _evento(m, "plano", perguntas=len(plano.get("perguntas", [])))
    if plano.get("perguntas"):
        m.fase = "perguntas"
        db.commit()
        return m
    db.commit()
    return _gerar_roteiro(db, m, {})


def responder(db: Session, minuta_id: int, respostas: dict) -> Minuta:
    m = _obter(db, minuta_id, "perguntas")
    _set(m, respostas=respostas)
    _evento(m, "respostas", total=len(respostas))
    return _gerar_roteiro(db, m, respostas)


def _gerar_roteiro(db: Session, m: Minuta, respostas: dict) -> Minuta:
    redator, _ = _provedores(db, m)
    est = m.estado or {}
    usuario = (f"Tipo de peça: {m.tipo_peca}\nPedido: {m.pedido}\nPlano: {json.dumps(est.get('plano', {}), ensure_ascii=False)}\n"
               f"Respostas do advogado: {json.dumps(respostas, ensure_ascii=False)}")
    rot = _chamar(db, redator, m, "roteiro", prompts.SISTEMA_BASE + "\n\n" + prompts.ROTEIRO, usuario,
                  {"tipo_peca": m.tipo_peca})
    _set(m, roteiro=rot.get("secoes", []))
    m.fase = "aprovar_roteiro"
    db.commit()
    return m


def aprovar_roteiro(db: Session, minuta_id: int, secoes: list[dict] | None = None) -> Minuta:
    m = _obter(db, minuta_id, "aprovar_roteiro")
    if secoes:
        _set(m, roteiro=secoes)
    _set(m, roteiro_aprovado=True)
    _evento(m, "roteiro_aprovado", secoes=len((m.estado or {}).get("roteiro", [])))
    m.fase = "pesquisa"
    db.commit()
    _pesquisar(db, m)
    _redigir(db, m)
    verificar(db, m.id)
    return db.get(Minuta, m.id)


def _pesquisar(db: Session, m: Minuta) -> None:
    redator, _ = _provedores(db, m)
    est = m.estado or {}
    caso = db.get(Caso, m.caso_id) if m.caso_id else None
    consultas = (est.get("plano") or {}).get("consultas", {})
    juris, leis, autos, buscas = {}, {}, {}, []

    for q in [c for c in consultas.get("jurisprudencia", []) if c][:6]:
        tentativas, atual = 0, q
        while True:
            r = conhecimento.pesquisar_jurisprudencia(db, atual, limite=5)
            buscas.append({"fonte": "jurisprudencia", "consulta": atual, "resultados": len(r["resultados"]),
                           "excluidos_por_status": [e["id"] for e in r["excluidos_por_status"]]})
            for it in r["resultados"]:
                juris.setdefault(it["id"], it)
            if r["resultados"] or tentativas >= MAX_REFORMULACOES:
                break
            nova = _chamar(db, redator, m, "reformular", prompts.SISTEMA_BASE + "\n\n" + prompts.REFORMULAR,
                           f"Consulta: {atual}", {"consulta": atual}).get("consultas", [])
            tentativas += 1
            if not nova:
                break
            atual = nova[0]

    for q in [c for c in consultas.get("legislacao", []) if c][:6]:
        r = conhecimento.pesquisar_legislacao(db, q, caso.data_fatos if caso else None, limite=5)
        buscas.append({"fonte": "legislacao", "consulta": q, "resultados": len(r["resultados"])})
        for it in r["resultados"]:
            if it["texto_na_data_dos_fatos"]:
                leis.setdefault(it["id"], it)

    if m.caso_id:
        pontos = [c for c in consultas.get("autos", []) if c]
        for s in est.get("roteiro", []):
            pontos += [s.get("titulo", "")] + list(s.get("pontos", []))
        for q in [p for p in pontos if p][:10]:
            res = conhecimento.pesquisar_autos(db, m.caso_id, q, limite=4)
            buscas.append({"fonte": "autos", "consulta": q, "resultados": len(res)})
            for it in res:
                autos.setdefault(it["trecho_id"], it)

    modelos = conhecimento.pesquisar_modelos(db, f"{m.tipo_peca} {m.pedido}")
    doutrina = conhecimento.pesquisar_fonte(db, "doutrina", f"{m.tipo_peca} {m.pedido}", limite=4)
    _set(m, pesquisa={"jurisprudencia": list(juris.values()), "legislacao": list(leis.values()),
                      "autos": list(autos.values()), "modelos": modelos, "doutrina": doutrina}, buscas=buscas)
    _evento(m, "pesquisa", jurisprudencia=len(juris), legislacao=len(leis), autos=len(autos),
            modelos=len(modelos), doutrina=len(doutrina))
    m.fase = "redacao"
    db.commit()


def _bloco_pesquisa(pq: dict) -> str:
    linhas = ["PRECEDENTES DISPONÍVEIS (cite apenas por {{juris:ID}}):"]
    for j in pq.get("jurisprudencia", []):
        alerta = f" [ALERTA: {j['alerta_status']}]" if j.get("alerta_status") else ""
        linhas.append(f"- ID {j['id']} | {j['rotulo']} | {j.get('hierarquia') or ''}{alerta}\n  Tese/ementa: {(j.get('tese') or j['ementa'])[:700]}")
    linhas.append("\nDISPOSITIVOS DISPONÍVEIS (cite apenas por {{lei:ID}}), redação vigente na data dos fatos:")
    for n in pq.get("legislacao", []):
        linhas.append(f"- ID {n['id']} | {n['rotulo']}: {(n['texto_na_data_dos_fatos'] or '')[:600]}")
    if pq.get("doutrina"):
        linhas.append("\nMATERIAL DE APOIO (doutrina/base do EJC; use para raciocínio, não cite como precedente nem como lei):")
        for x in pq["doutrina"]:
            linhas.append(f"- {x.get('titulo') or x['fonte_id']}: {x['trecho'][:500]}")
    linhas.append("\nTRECHOS DOS AUTOS RELEVANTES (cite por [[autos:DOC:PAGINA]]):")
    for a in pq.get("autos", [])[:20]:
        linhas.append(f"- doc {a['documento_id']} p.{a['pagina']}: {a['texto'][:500]}")
    return "\n".join(linhas)


def _redigir(db: Session, m: Minuta) -> None:
    redator, _ = _provedores(db, m)
    est = m.estado or {}
    pq = est.get("pesquisa", {})
    contexto_skills = f"{m.tipo_peca} {m.pedido} {(est.get('plano') or {}).get('resumo_caso', '')}"
    selecionadas, bloco_skills = skills_srv.selecionar_para(db, contexto_skills, m.tipo_peca, est.get("skills_fixadas", []))
    _set(m, skills_aplicadas=[{"slug": s["slug"], "titulo": s["titulo"], "confianca": s["confianca"],
                               "obrigatoria": s["obrigatoria"]} for s in selecionadas])
    sistema = prompts.SISTEMA_BASE + "\n\n" + prompts.REDIGIR_SECAO + ("\n\n" + bloco_skills if bloco_skills else "")
    autos = _autos(db, m)
    bloco_pq = _bloco_pesquisa(pq)
    modelos = "\n---\n".join(x["trecho"] for x in pq.get("modelos", []))
    secoes_txt = []
    for s in est.get("roteiro", []):
        usuario = (f"Peça: {m.tipo_peca}\nPedido: {m.pedido}\nRespostas do advogado: {json.dumps(est.get('respostas', {}), ensure_ascii=False)}\n"
                   f"Roteiro aprovado: {json.dumps(est.get('roteiro'), ensure_ascii=False)}\n"
                   f"SEÇÃO A REDIGIR: {json.dumps(s, ensure_ascii=False)}\n"
                   f"<pesquisa>\n{bloco_pq}\n</pesquisa>\n<modelo>\n{modelos[:6000]}\n</modelo>\n<autos>\n{autos[:30000]}\n</autos>")
        txt = _chamar(db, redator, m, "redigir_secao", sistema, usuario,
                      {"secao": s, "pesquisa": pq}, json_esperado=False, max_tokens=3000)
        secoes_txt.append(txt.strip())
        _evento(m, "secao_redigida", secao=s.get("titulo"))
    m.texto = "\n\n".join(secoes_txt)
    db.add(VersaoMinuta(minuta_id=m.id, texto=m.texto, nota="Redação inicial do agente", autor="ia"))
    m.fase = "verificacao"
    db.commit()


def verificar(db: Session, minuta_id: int) -> Minuta:
    """Verificação completa. Pode ser chamada novamente após edição humana."""
    m = db.get(Minuta, minuta_id)
    if not m:
        raise ErroFluxo("Minuta inexistente.")
    _, verificador = _provedores(db, m)
    caso = db.get(Caso, m.caso_id) if m.caso_id else None
    est = m.estado or {}

    texto = m.texto
    if est.get("anonimizado") and est.get("cofre"):
        d = desanonimizar(texto, est["cofre"])
        texto = d["texto"]
        alertas_cofre = d["alertas"]
    else:
        alertas_cofre = []

    res = documentos.resolver_citacoes(db, texto, caso.data_fatos if caso else None)

    # Aderência da tese: verificador distinto do redator
    aderencias = []
    for af in extrair_afirmacoes(m.texto, citacoes.RX_JURIS)[:15]:
        p = db.get(Precedente, af["id"])
        if not p:
            continue
        tese = p.tese or p.ementa
        try:
            r = _chamar(db, verificador, m, "aderencia", prompts.ADERENCIA,
                        f"AFIRMAÇÃO DA PEÇA: {af['afirmacao']}\nPRECEDENTE {p.rotulo}\nTESE/EMENTA: {tese}",
                        {"afirmacao": af["afirmacao"], "tese": tese})
            origem = "verificador"
        except Exception as e:  # noqa: BLE001
            r, origem = heuristica(af["afirmacao"], tese), f"heuristica ({e.__class__.__name__})"
        aderencias.append({"precedente": p.id, "rotulo": p.rotulo, "afirmacao": af["afirmacao"][:300],
                           "classificacao": r.get("classificacao"), "justificativa": r.get("justificativa"),
                           "origem": origem, "heuristica": heuristica(af["afirmacao"], tese)})

    # Camada 2: auditoria do raciocínio
    rac = "\n".join(x["raciocinio"] for x in est.get("raciocinios", []) if x.get("raciocinio"))
    if rac:
        try:
            aud = _chamar(db, verificador, m, "auditoria", prompts.AUDITORIA,
                          f"INSTRUÇÕES DO SISTEMA:\n{prompts.REGRAS_INVARIANTES}\n\nPEDIDO DO USUÁRIO:\n{m.pedido}\n\nRACIOCÍNIO DO REDATOR:\n{rac[:12000]}",
                          {"raciocinio": rac})
        except Exception as e:  # noqa: BLE001
            aud = {"injecao": None, "fabricacao": None, "justificativa": f"Auditoria indisponível: {e}"}
    else:
        aud = {"injecao": None, "fabricacao": None,
               "justificativa": "Provedor não expôs raciocínio; auditoria da Camada 2 não aplicável a esta geração."}
    indicador = "seguro"
    if aud.get("injecao"):
        indicador = "possivel_injecao"
    elif aud.get("fabricacao"):
        indicador = "possivel_fabricacao"
    elif aud.get("injecao") is None:
        indicador = "nao_auditado"

    julg = simular(res.texto, m.tipo_peca)
    if julg.get("tipo") == "sentenca" and m.caso_id:
        from ..core.julgador import vedacao_surpresa
        julg["vedacao_surpresa"] = vedacao_surpresa(res.texto, documentos.texto_dos_autos(db, m.caso_id, limite_chars=400000))
        for a in julg["vedacao_surpresa"]["achados"]:
            julg["pendencias"].append(a["mensagem"])
    contraria = est.get("peca_contraria")
    if est.get("gerar_peca_contraria", True) and contraria is None:
        try:
            contraria = _chamar(db, verificador, m, "contraria", prompts.SISTEMA_BASE + "\n\n" + prompts.CONTRARIA,
                                f"<peca>\n{m.texto[:30000]}\n</peca>", {"texto": m.texto})
        except Exception as e:  # noqa: BLE001
            contraria = {"erro": str(e)}
        _set(m, peca_contraria=contraria)

    pendencias = [l for l in m.texto.splitlines() if "[PESQUISA PENDENTE" in l or "[DADO PENDENTE" in l]
    problemas = [p.as_dict() for p in res.problemas] + [{"nivel": "alerta", "tipo": "cofre", "mensagem": a, "marcador": ""} for a in alertas_cofre]
    for a in aderencias:
        if a["classificacao"] in ("contrario", "distinguivel", "irrelevante"):
            problemas.append({"nivel": "bloqueante" if a["classificacao"] == "contrario" else "alerta",
                              "tipo": "aderencia", "mensagem": f"{a['rotulo']}: {a['classificacao']}. {a['justificativa']}",
                              "marcador": a["precedente"]})
    bloqueado = any(p["nivel"] == "bloqueante" for p in problemas) or indicador == "possivel_injecao"
    m.texto_resolvido = res.texto + ("\n\n" + res.anexo if res.anexo else "")
    m.verificacao = {
        "bloqueado": bloqueado, "problemas": problemas, "citados": res.citados, "aderencia": aderencias,
        "seguranca": {"indicador": indicador, **aud}, "julgador": julg, "pendencias": pendencias,
        "skills_aplicadas": est.get("skills_aplicadas", []), "verificado_em": date.today().isoformat(),
    }
    m.fase = "revisao"
    m.status = "RASCUNHO"
    db.commit()
    auditoria.registrar(db, "verificacao", f"minuta:{m.id}", {"bloqueado": bloqueado, "problemas": len(problemas)})
    return m


def editar(db: Session, minuta_id: int, texto: str, nota: str = "Edição do advogado") -> Minuta:
    m = db.get(Minuta, minuta_id)
    if not m:
        raise ErroFluxo("Minuta inexistente.")
    if m.status == "APROVADA":
        raise ErroFluxo("Minuta aprovada é imutável; crie nova versão.")
    m.texto = texto
    db.add(VersaoMinuta(minuta_id=m.id, texto=texto, nota=nota, autor="usuario"))
    db.commit()
    return verificar(db, m.id)


def aprovar(db: Session, minuta_id: int, responsavel: str, ciente_alertas: bool = False) -> Minuta:
    m = db.get(Minuta, minuta_id)
    if not m or m.fase != "revisao":
        raise ErroFluxo("A minuta precisa estar em revisão para ser aprovada.")
    v = m.verificacao or {}
    if v.get("bloqueado"):
        raise ErroFluxo("Há problemas bloqueantes na verificação. Corrija e verifique novamente.")
    if any(p["nivel"] == "alerta" for p in v.get("problemas", [])) and not ciente_alertas:
        raise ErroFluxo("Existem alertas. Confirme ciência (ciente_alertas=true) para aprovar.")
    if not responsavel.strip():
        raise ErroFluxo("Informe o advogado responsável pela aprovação.")
    m.status, m.aprovada_por = "APROVADA", responsavel
    db.commit()
    auditoria.registrar(db, "aprovacao", f"minuta:{m.id}", {"responsavel": responsavel}, usuario=responsavel)
    return m


def _obter(db: Session, minuta_id: int, fase: str) -> Minuta:
    m = db.get(Minuta, minuta_id)
    if not m:
        raise ErroFluxo("Minuta inexistente.")
    if m.fase != fase:
        raise ErroFluxo(f"Fase atual é '{m.fase}', esperado '{fase}'.")
    return m


def versoes(db: Session, minuta_id: int) -> list[dict]:
    return [{"id": v.id, "nota": v.nota, "autor": v.autor, "criado_em": v.criado_em.isoformat(), "texto": v.texto}
            for v in db.scalars(select(VersaoMinuta).where(VersaoMinuta.minuta_id == minuta_id).order_by(VersaoMinuta.id))]
