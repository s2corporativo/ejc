"""Geração em lote.

Modo "etapas" (recomendado para demandas repetitivas):
 1. a minuta do processo-modelo segue o fluxo normal do agente (perguntas, roteiro, revisão);
 2. o advogado aprova a minuta-modelo: a última versão é CONGELADA como molde;
 3. as demais minutas são geradas pelo Modo Molde: a IA só emite operações pontuais sobre o
    molde (partes, datas, valores, fatos, referências aos autos). Marcadores de precedente e
    de lei do molde são protegidos: a pesquisa revisada na minuta-modelo é herdada;
 4. cada minuta passa pela verificação completa e é comparada com o molde (diff).

Modo "instantaneo": cada processo percorre o agente completo, com o roteiro informado na
criação do lote valendo como roteiro pré-aprovado pelo advogado.
"""
from __future__ import annotations

import json

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core.citacoes import RX_JURIS, RX_LEI
from ..core.molde import aplicar_operacoes
from ..llm import prompts
from ..llm.provedores import construir
from ..models import Caso, Lote, LoteItem, Minuta, VersaoMinuta
from ..servicos import auditoria, documentos
from . import pipeline


def criar(db: Session, caso_ids: list[int], instrucao: str, tipo_peca: str, modo: str = "etapas",
          caso_modelo_id: int | None = None, roteiro: list[dict] | None = None) -> Lote:
    if len(caso_ids) < 2:
        raise pipeline.ErroFluxo("O lote precisa de pelo menos dois processos.")
    if modo == "instantaneo" and not roteiro:
        raise pipeline.ErroFluxo("No modo instantâneo informe o roteiro: ele vale como aprovação prévia do advogado.")
    modelo = caso_modelo_id or caso_ids[0]
    if modelo not in caso_ids:
        raise pipeline.ErroFluxo("O processo-modelo precisa integrar o lote.")
    lote = Lote(instrucao=instrucao, tipo_peca=tipo_peca, modo=modo, caso_modelo_id=modelo,
                fase="aguardando_modelo" if modo == "etapas" else "pronto_para_gerar")
    db.add(lote)
    db.commit()
    for cid in caso_ids:
        db.add(LoteItem(lote_id=lote.id, caso_id=cid))
    db.commit()
    est = {"roteiro": roteiro} if roteiro else {}
    if modo == "etapas":
        m = pipeline.iniciar(db, modelo, tipo_peca, instrucao)
        lote.minuta_modelo_id = m.id
        item = db.scalar(select(LoteItem).where(LoteItem.lote_id == lote.id, LoteItem.caso_id == modelo))
        item.minuta_id, item.status = m.id, "gerando"
    else:
        lote.molde_congelado = json.dumps(est, ensure_ascii=False)
    db.commit()
    return lote


def aprovar_modelo(db: Session, lote_id: int) -> Lote:
    lote = db.get(Lote, lote_id)
    if not lote or lote.modo != "etapas" or lote.fase != "aguardando_modelo":
        raise pipeline.ErroFluxo("Lote inexistente ou fora da fase de aprovação do modelo.")
    m = db.get(Minuta, lote.minuta_modelo_id)
    if not m or m.fase != "revisao":
        raise pipeline.ErroFluxo("A minuta-modelo ainda não está pronta para revisão.")
    if (m.verificacao or {}).get("bloqueado"):
        raise pipeline.ErroFluxo("A minuta-modelo tem problemas bloqueantes; corrija antes de aprovar o molde.")
    lote.molde_congelado = m.texto
    lote.fase = "molde_aprovado"
    item = db.scalar(select(LoteItem).where(LoteItem.lote_id == lote.id, LoteItem.caso_id == lote.caso_modelo_id))
    item.status = "pronto"
    db.commit()
    auditoria.registrar(db, "lote:molde_aprovado", f"lote:{lote.id}", {"minuta_modelo": m.id})
    return lote


def gerar_demais(db: Session, lote_id: int, apenas_falhas: bool = False) -> Lote:
    lote = db.get(Lote, lote_id)
    if not lote:
        raise pipeline.ErroFluxo("Lote inexistente.")
    if lote.modo == "etapas" and lote.fase not in ("molde_aprovado", "gerando", "concluido"):
        raise pipeline.ErroFluxo("Aprove a minuta-modelo antes de gerar as demais.")
    lote.fase = "gerando"
    db.commit()
    itens = db.scalars(select(LoteItem).where(LoteItem.lote_id == lote.id)).all()
    for it in itens:
        if lote.modo == "etapas" and it.caso_id == lote.caso_modelo_id:
            continue
        if apenas_falhas and it.status != "falha":
            continue
        if not apenas_falhas and it.status == "pronto":
            continue
        it.status, it.erro = "gerando", None
        db.commit()
        try:
            if lote.modo == "etapas":
                _gerar_por_molde(db, lote, it)
            else:
                _gerar_instantaneo(db, lote, it)
            it.status = "pronto"
        except Exception as e:  # noqa: BLE001 — falha recuperável por item
            db.rollback()
            it = db.get(LoteItem, it.id)
            it.status, it.erro = "falha", str(e)[:1000]
        db.commit()
    lote.fase = "concluido"
    db.commit()
    return lote


def _gerar_por_molde(db: Session, lote: Lote, it: LoteItem) -> None:
    caso = db.get(Caso, it.caso_id)
    if not caso:
        raise pipeline.ErroFluxo(f"Caso {it.caso_id} inexistente.")
    bloqueados = [d.nome for d in caso.documentos if not d.liberado_para_ia]
    if bloqueados:
        raise pipeline.ErroFluxo("Documentos aguardando decisão de segurança: " + ", ".join(bloqueados))
    molde = lote.molde_congelado or ""
    autos = documentos.texto_dos_autos(db, caso.id)
    m = Minuta(caso_id=caso.id, tipo_peca=lote.tipo_peca, pedido=lote.instrucao, fase="redacao",
               estado={"lote_id": lote.id, "modo": "molde", "gerar_peca_contraria": False})
    db.add(m)
    db.commit()
    prov = construir(papel="redator", sigiloso=caso.sigiloso)
    r = prov.gerar("molde", prompts.SISTEMA_BASE + "\n\n" + prompts.MOLDE,
                   f"Instrução do lote: {lote.instrucao}\n<modelo>\n{molde}\n</modelo>\n<autos>\n{autos[:40000]}\n</autos>",
                   {"modelo": molde, "pares": (lote_pares_teste.get(caso.id) or [])})
    from ..llm.provedores import extrair_json
    ops = extrair_json(r.texto).get("operacoes", [])
    protegidos = [x.group(0) for x in RX_JURIS.finditer(molde)] + [x.group(0) for x in RX_LEI.finditer(molde)]
    res = aplicar_operacoes(molde, ops, protegidos=protegidos)
    m.texto = res.texto
    m.estado = {**m.estado, "operacoes_aplicadas": res.aplicadas, "operacoes_rejeitadas": res.rejeitadas,
                "preservado_pct": res.preservado_pct,
                "raciocinios": [{"tarefa": "molde", "raciocinio": r.raciocinio[:4000]}]}
    db.add(VersaoMinuta(minuta_id=m.id, texto=m.texto, nota=f"Gerada pelo molde do lote {lote.id}", autor="ia"))
    db.commit()
    pipeline.verificar(db, m.id)
    it.minuta_id, it.diff = m.id, res.diff


def _gerar_instantaneo(db: Session, lote: Lote, it: LoteItem) -> None:
    roteiro = json.loads(lote.molde_congelado or "{}").get("roteiro", [])
    m = pipeline.iniciar(db, it.caso_id, lote.tipo_peca, lote.instrucao, gerar_peca_contraria=False)
    if m.fase == "perguntas":
        m = pipeline.responder(db, m.id, {"observacao": "Lote instantâneo: sem respostas individuais."})
    m = pipeline.aprovar_roteiro(db, m.id, roteiro)
    it.minuta_id = m.id


def status(db: Session, lote_id: int) -> dict:
    lote = db.get(Lote, lote_id)
    if not lote:
        raise pipeline.ErroFluxo("Lote inexistente.")
    itens = db.scalars(select(LoteItem).where(LoteItem.lote_id == lote.id)).all()
    out = []
    for it in itens:
        m = db.get(Minuta, it.minuta_id) if it.minuta_id else None
        out.append({"item_id": it.id, "caso_id": it.caso_id, "modelo": it.caso_id == lote.caso_modelo_id,
                    "status": it.status, "erro": it.erro, "minuta_id": it.minuta_id,
                    "minuta_fase": m.fase if m else None,
                    "bloqueado": (m.verificacao or {}).get("bloqueado") if m else None,
                    "preservado_pct": (m.estado or {}).get("preservado_pct") if m else None,
                    "alteracoes": [d for d in (it.diff or []) if d["tipo"] != "igual"]})
    return {"id": lote.id, "modo": lote.modo, "fase": lote.fase, "tipo_peca": lote.tipo_peca,
            "minuta_modelo_id": lote.minuta_modelo_id, "itens": out}


# Somente para testes com o provedor mock: pares (antigo, novo) por caso.
lote_pares_teste: dict[int, list[tuple[str, str]]] = {}
