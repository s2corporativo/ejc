"""LexValida: inteligência jurídica com validação (aplicação FastAPI)."""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from datetime import date, timedelta
from pathlib import Path

from fastapi import Depends, FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text

from .api import conhecimento, ferramentas, inteligencia, minutas
from .api.deps import exigir_token
from .config import RAIZ, get_config
from .core import embeddings
from .db import init_engine, nova_sessao

logging.basicConfig(level=logging.INFO)
FRONT = Path(__file__).resolve().parents[2] / "frontend"


@asynccontextmanager
async def ciclo(app: FastAPI):
    init_engine()
    from .servicos.skills import sincronizar_oficiais
    db = nova_sessao()
    try:
        sincronizar_oficiais(db)
    finally:
        db.close()
    tarefa = None
    horas = get_config().monitor_intervalo_horas
    if horas > 0:
        tarefa = asyncio.create_task(_rotina(horas))
    yield
    if tarefa:
        tarefa.cancel()


def _ciclo_rotina() -> dict:
    """Monitor de precedentes e temas + captura do DJEN dos últimos 7 dias (se DJEN_OABS)."""
    from .servicos import intimacoes, monitor
    db = nova_sessao()
    try:
        res = {"monitor": monitor.executar(db)}
        oabs = intimacoes.parse_oabs(get_config().djen_oabs)
        if oabs:
            r = intimacoes.sincronizar_djen(db, oabs, date.today() - timedelta(days=7), date.today())
            res["djen"] = {"novas": len(r["novas"]), "erros": r["erros"]}
        return res
    finally:
        db.close()


async def _rotina(horas: float) -> None:
    log = logging.getLogger("lexvalida.rotina")
    while True:
        try:
            log.info("Rotina automática: %s", await asyncio.to_thread(_ciclo_rotina))
        except Exception as e:  # noqa: BLE001 — a rotina nunca derruba o servidor
            log.exception("Falha na rotina automática: %s", e)
        await asyncio.sleep(horas * 3600)


app = FastAPI(title="LexValida", version="1.1.0", lifespan=ciclo,
              description="Inteligência jurídica com validação de citações, vigência, prova e prazos. "
                          "Toda saída de IA é rascunho sujeito à revisão do advogado.")

for router in (ferramentas.r, conhecimento.r, minutas.r, inteligencia.r):
    app.include_router(router, dependencies=[Depends(exigir_token)])


@app.get("/api/saude")
def saude():
    cfg = get_config()
    db = nova_sessao()
    try:
        db.execute(text("SELECT 1"))
        banco = db.get_bind().dialect.name
        pgvector = None
        if banco == "postgresql":
            pgvector = db.execute(text("SELECT extversion FROM pg_extension WHERE extname='vector'")).scalar()
    finally:
        db.close()
    ok_emb, det_emb = embeddings.validar_modelo_local()
    return {"status": "ok", "banco": banco, "pgvector": pgvector,
            "embeddings": {"provider": cfg.embeddings_provider, "modelo": cfg.embeddings_model,
                           "dimensao": cfg.embeddings_dim, "ok": ok_emb, "detalhe": det_emb},
            "llm": {"redator": cfg.llm_provider, "verificador": cfg.verificador_provider or cfg.llm_provider,
                    "local_para_sigilo": bool(cfg.local_provider_base_url)},
            "autenticacao": bool(cfg.api_token), "raiz": str(RAIZ)}


if FRONT.exists():
    app.mount("/static", StaticFiles(directory=FRONT), name="static")

    @app.get("/")
    def index():
        return FileResponse(FRONT / "index.html")
