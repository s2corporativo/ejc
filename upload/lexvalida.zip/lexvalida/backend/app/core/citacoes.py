"""Protocolo de citação verificável.

A IA NUNCA escreve ementa, texto de lei ou trecho dos autos. Ela emite marcadores:
  {{juris:ID}}                          precedente da base
  {{lei:ID}}                            dispositivo legal (versão vigente na data dos fatos)
  [[autos:DOC_ID:PAGINA]]               referência rastreável aos autos
  [[autos:DOC_ID:PAGINA|"trecho"]]      idem, com trecho literal que será conferido

O resolvedor substitui cada marcador pelo rótulo oficial, monta o anexo com o texto íntegro
da base e produz um relatório de verificação. Marcador inexistente vira erro bloqueante.
Citações em texto livre (fora do protocolo) são detectadas e sinalizadas como não verificadas.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable

from .texto import normalizar

RX_JURIS = re.compile(r"\{\{juris:([a-z0-9][a-z0-9._-]*)\}\}", re.IGNORECASE)
RX_LEI = re.compile(r"\{\{lei:([a-z0-9][a-z0-9._-]*)\}\}", re.IGNORECASE)
RX_AUTOS = re.compile(r"\[\[autos:([A-Za-z0-9_-]+):(\d+)(?:\|\"([^\"]{3,400})\")?\]\]")

RX_LIVRE = [
    ("precedente", re.compile(r"\b(?:REsp|RE|AREsp|AgInt|AgRg|EREsp|HC|RHC|MS|RMS|ADI|ADC|ADPF|Rcl|AI|ARE|RR|AIRR)\s*(?:n[º°o]\.?\s*)?\d[\d.]{2,}(?:/[A-Z]{2})?", re.IGNORECASE)),
    ("sumula", re.compile(r"\bS[úu]mula(?:\s+Vinculante)?\s*(?:n[º°o]\.?\s*)?\d+", re.IGNORECASE)),
    ("tema", re.compile(r"\bTema\s*(?:n[º°o]\.?\s*)?\d+", re.IGNORECASE)),
]


@dataclass
class Problema:
    nivel: str      # bloqueante | alerta | info
    tipo: str
    mensagem: str
    marcador: str = ""

    def as_dict(self) -> dict:
        return {"nivel": self.nivel, "tipo": self.tipo, "mensagem": self.mensagem, "marcador": self.marcador}


@dataclass
class Resolucao:
    texto: str
    anexo: str
    problemas: list[Problema] = field(default_factory=list)
    citados: dict = field(default_factory=lambda: {"juris": [], "lei": [], "autos": []})

    @property
    def bloqueado(self) -> bool:
        return any(p.nivel == "bloqueante" for p in self.problemas)

    def as_dict(self) -> dict:
        return {"texto": self.texto, "anexo": self.anexo, "bloqueado": self.bloqueado,
                "problemas": [p.as_dict() for p in self.problemas], "citados": self.citados}


def resolver(
    texto: str,
    buscar_precedente: Callable[[str], dict | None],
    buscar_norma: Callable[[str], dict | None],
    buscar_pagina_autos: Callable[[str, int], dict | None],
    manter_referencias_autos: bool = True,
) -> Resolucao:
    """As funções de busca devolvem dicts:
    precedente: {rotulo, ementa, tese, status, alerta_status, bloqueia, verificado, fonte_url}
    norma: {rotulo, texto, vigente_na_data: bool, difere_da_atual: bool, verificado, data_referencia}
    autos: {documento_nome, texto}
    """
    res = Resolucao(texto="", anexo="")
    juris_ok: dict[str, dict] = {}
    normas_ok: dict[str, dict] = {}

    def _juris(m: re.Match) -> str:
        pid = m.group(1).lower()
        p = juris_ok.get(pid) or buscar_precedente(pid)
        if not p:
            res.problemas.append(Problema("bloqueante", "precedente_inexistente",
                                          f"Precedente '{pid}' não existe na base: possível alucinação.", m.group(0)))
            return f"[CITAÇÃO INVÁLIDA: {pid}]"
        juris_ok[pid] = p
        if p.get("bloqueia"):
            res.problemas.append(Problema("bloqueante", "precedente_superado", f"{p['rotulo']}: {p['alerta_status']}", m.group(0)))
        elif p.get("alerta_status"):
            res.problemas.append(Problema("alerta", "status_precedente", f"{p['rotulo']}: {p['alerta_status']}", m.group(0)))
        if not p.get("verificado"):
            res.problemas.append(Problema("alerta", "nao_verificado",
                                          f"{p['rotulo']}: registro ainda não conferido com a fonte oficial.", m.group(0)))
        if pid not in res.citados["juris"]:
            res.citados["juris"].append(pid)
        return p["rotulo"]

    def _lei(m: re.Match) -> str:
        nid = m.group(1).lower()
        n = normas_ok.get(nid) or buscar_norma(nid)
        if not n:
            res.problemas.append(Problema("bloqueante", "norma_inexistente",
                                          f"Dispositivo '{nid}' não existe na base.", m.group(0)))
            return f"[NORMA INVÁLIDA: {nid}]"
        normas_ok[nid] = n
        if not n.get("vigente_na_data"):
            res.problemas.append(Problema("bloqueante", "norma_nao_vigente",
                                          f"{n['rotulo']}: sem redação vigente em {n.get('data_referencia')}.", m.group(0)))
        elif n.get("difere_da_atual"):
            res.problemas.append(Problema("alerta", "norma_alterada",
                                          f"{n['rotulo']}: redação aplicada é a da data dos fatos ({n.get('data_referencia')}), diversa da atual (LINDB, art. 6º).",
                                          m.group(0)))
        if n.get("inicio_desconhecido"):
            res.problemas.append(Problema("alerta", "vigencia_nao_curada",
                                          f"{n['rotulo']}: início de vigência não curado; confirme a redação aplicável à data dos fatos.",
                                          m.group(0)))
        if not n.get("verificado"):
            res.problemas.append(Problema("alerta", "nao_verificado", f"{n['rotulo']}: texto ainda não conferido.", m.group(0)))
        if nid not in res.citados["lei"]:
            res.citados["lei"].append(nid)
        return n["rotulo"]

    def _autos(m: re.Match) -> str:
        doc, pag, trecho = m.group(1), int(m.group(2)), m.group(3)
        p = buscar_pagina_autos(doc, pag)
        if not p:
            res.problemas.append(Problema("bloqueante", "referencia_autos_invalida",
                                          f"Documento {doc}, página {pag}: inexistente nos autos.", m.group(0)))
            return f"[REFERÊNCIA INVÁLIDA: doc {doc}, p. {pag}]"
        if trecho and normalizar(" ".join(trecho.split())) not in normalizar(" ".join(p["texto"].split())):
            res.problemas.append(Problema("bloqueante", "trecho_nao_encontrado",
                                          f"Trecho citado não consta do doc. {p['documento_nome']}, p. {pag}: \"{trecho[:80]}\"",
                                          m.group(0)))
        res.citados["autos"].append({"documento": doc, "pagina": pag, "trecho_conferido": bool(trecho)})
        return f"({p['documento_nome']}, p. {pag})" if manter_referencias_autos else ""

    texto = RX_JURIS.sub(_juris, texto)
    texto = RX_LEI.sub(_lei, texto)
    texto = RX_AUTOS.sub(_autos, texto)

    rotulos = [p["rotulo"] for p in juris_ok.values()] + [n["rotulo"] for n in normas_ok.values()]
    for tipo, rx in RX_LIVRE:
        for m in rx.finditer(texto):
            if not any(m.group(0).lower() in r.lower() for r in rotulos):
                res.problemas.append(Problema("alerta", "citacao_fora_do_protocolo",
                                              f"'{m.group(0)}' citado em texto livre, sem verificação na base.", m.group(0)))

    partes = []
    if juris_ok:
        partes.append("PRECEDENTES CITADOS (texto íntegro da base)\n")
        for p in juris_ok.values():
            partes.append(f"{p['rotulo']}\n{p.get('tese') or ''}\n{p['ementa']}\nFonte: {p.get('fonte_url') or 'não informada'}\n")
    if normas_ok:
        partes.append("DISPOSITIVOS CITADOS (redação vigente na data dos fatos)\n")
        for n in normas_ok.values():
            partes.append(f"{n['rotulo']}: {n['texto']}\n")
    unicos, vistos = [], set()
    for p in res.problemas:
        chave = (p.tipo, p.mensagem)
        if chave not in vistos:
            vistos.add(chave)
            unicos.append(p)
    res.problemas = unicos
    res.texto, res.anexo = texto, "\n".join(partes)
    return res
