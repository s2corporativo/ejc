"""Provedor offline determinístico. Sem conhecimento jurídico próprio: apenas organiza o
material recebido e emite marcadores, para que todo o fluxo (incluindo verificações) possa ser
testado sem chave de API. Saídas identificadas como [MOCK]."""
from __future__ import annotations

import json
import statistics

from ..core.aderencia import heuristica
from ..core.ingestao import classificar_trecho
from ..core.julgador import tipo_canonico
from .provedores import Provedor, Resposta

ROTEIROS = {
    "peticao_inicial": ["Dos fatos", "Do direito", "Dos pedidos"],
    "contestacao": ["Síntese da inicial", "Preliminares", "Do mérito", "Dos pedidos"],
    "sentenca": ["Relatório", "Fundamentação", "Dispositivo"],
    "recurso": ["Tempestividade e preparo", "Razões recursais", "Do pedido de reforma"],
}


class Mock(Provedor):
    nome = "mock"

    def gerar(self, tarefa, sistema, usuario, dados=None, max_tokens=4000, temperatura=0.2):
        d = dados or {}
        fn = getattr(self, f"_{tarefa}", None)
        saida, raciocinio = fn(d) if fn else ("[MOCK] tarefa sem simulação", "")
        if not isinstance(saida, str):
            saida = json.dumps(saida, ensure_ascii=False)
        return Resposta(saida, raciocinio, "mock", "mock-1")

    def _planejar(self, d):
        pedido = d.get("pedido", "")
        canon = tipo_canonico(d.get("tipo_peca", ""))
        perguntas = []
        if canon == "peticao_inicial":
            perguntas.append({"id": "q1", "pergunta": "Incluir pedido de tutela de urgência?", "opcoes": ["Sim", "Não"]})
        return {
            "resumo_caso": "[MOCK] " + (d.get("autos_texto", "")[:300].replace("\n", " ") or "Sem autos carregados."),
            "pontos_chave": [pedido[:200]] if pedido else [],
            "estrategia": "[MOCK] Estratégia a ser definida pelo advogado com base nos pontos-chave.",
            "perguntas": perguntas,
            "consultas": {"jurisprudencia": [pedido], "legislacao": [pedido], "autos": [pedido]},
            "alertas": ["Provedor MOCK: conteúdo sem análise jurídica real."],
        }, "Analisei o pedido e os autos recebidos; nenhuma instrução externa identificada."

    def _roteiro(self, d):
        canon = tipo_canonico(d.get("tipo_peca", "")) or ""
        titulos = ROTEIROS.get(canon, ["Introdução", "Fundamentação", "Conclusão"])
        return {"secoes": [{"id": f"s{i}", "titulo": t, "objetivo": f"[MOCK] Desenvolver: {t}", "pontos": []}
                           for i, t in enumerate(titulos, start=1)]}, "Roteiro padrão do tipo de peça."

    def _reformular(self, d):
        palavras = [p for p in d.get("consulta", "").split() if len(p) > 4]
        return {"consultas": [" ".join(palavras[:3])] if palavras else []}, ""

    def _redigir_secao(self, d):
        sec, pq = d.get("secao", {}), d.get("pesquisa", {})
        linhas = [sec.get("titulo", "Seção").upper(), ""]
        autos = pq.get("autos", [])
        if autos:
            a = autos[0]
            trecho = " ".join(a["texto"].split())[:60].strip()
            linhas.append(f"[MOCK] Conforme consta dos autos, \"{trecho}\" [[autos:{a['documento_id']}:{a['pagina']}|\"{trecho}\"]].")
        for j in pq.get("jurisprudencia", [])[:1]:
            base = (j.get("tese") or j.get("rotulo") or "")[:160]
            linhas.append(f"[MOCK] Nesse sentido: {base} {{{{juris:{j['id']}}}}}.")
        for n in pq.get("legislacao", [])[:1]:
            linhas.append(f"[MOCK] Incide o disposto em {{{{lei:{n['id']}}}}}.")
        if len(linhas) == 2:
            linhas.append("[MOCK] [PESQUISA PENDENTE: fundamentos para esta seção]")
        return "\n".join(linhas), f"Redigi a seção {sec.get('titulo')} usando apenas a pesquisa fornecida."

    def _aderencia(self, d):
        h = heuristica(d.get("afirmacao", ""), d.get("tese", ""))
        mapa = {"provavel_apoio": "apoia", "apoio_incerto": "apoia_parcialmente",
                "possivel_contradicao": "contrario", "possivel_irrelevancia": "irrelevante"}
        return {"classificacao": mapa.get(h["classificacao"], "irrelevante"), "justificativa": "[MOCK] " + h["justificativa"]}, ""

    def _auditoria(self, d):
        rac = d.get("raciocinio", "")
        cls = classificar_trecho(rac)
        fabric = any(k in rac.lower() for k in ("inventar", "inventei", "vou supor uma data", "fabricar"))
        return {"injecao": cls["risco"] == "alto", "fabricacao": fabric, "confianca": 0.6,
                "justificativa": "[MOCK] Varredura por padrões no raciocínio."}, ""

    def _contraria(self, d):
        return {"vulnerabilidades": [{"ponto": "[MOCK] Prova dos fatos constitutivos", "argumento_adverso":
                "A parte adversa alegará insuficiência probatória.", "gravidade": "media",
                "como_reforcar": "Vincular cada fato a documento dos autos."}]}, ""

    def _molde(self, d):
        ops = [{"op": "substituir", "localizar": a, "por": n, "motivo": "[MOCK] par informado"}
               for a, n in d.get("pares", []) if a in d.get("modelo", "")]
        return {"operacoes": ops}, ""

    def _ratio(self, d):
        import re as _re
        tese = d.get("tese", "")
        partes = [x.strip() for x in _re.split(r"[.;]", tese) if len(x.strip()) > 15]
        return {"ratio": tese[:400], "fatos_materiais": partes[:5] or [tese[:200]],
                "ressalvas": ["[MOCK] extração por segmentação de frases"]}, ""

    def _distinguir(self, d):
        comp = []
        for f in d.get("fatos_materiais", []):
            melhor = max(d.get("trechos", {}).get(f, []), key=lambda x: x["sobreposicao"], default=None)
            sob = melhor["sobreposicao"] if melhor else 0
            corr = "analogo" if sob >= 0.15 else "divergente" if sob >= 0.07 else "ausente"
            comp.append({"fato_precedente": f, "fato_caso": (melhor or {}).get("texto", "")[:200],
                         "correspondencia": corr, "referencia": (melhor or {}).get("marcador", "")})
        if comp and all(c["correspondencia"] in ("identico", "analogo") for c in comp):
            concl = "aplica"
        elif any(c["correspondencia"] == "ausente" for c in comp):
            concl = "distinguir"
        else:
            concl = "inconclusivo"
        return {"comparacao": comp, "conclusao": concl, "fundamentacao": "[MOCK] comparação por sobreposição textual"}, ""

    def _estilo(self, d):
        textos = d.get("modelos", [])
        pars = [len(p.split()) for t in textos for p in t.split("\n\n") if p.strip()]
        media = statistics.mean(pars) if pars else 0
        return {"tom": "formal", "paragrafos": f"média de {media:.0f} palavras por parágrafo",
                "formalidade": "alta", "restricoes_linguagem": [], "formato_assinatura": "",
                "observacoes": ["[MOCK] perfil estatístico simples"]}, ""
