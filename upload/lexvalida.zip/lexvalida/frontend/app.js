"use strict";
const $ = (s, el = document) => el.querySelector(s);
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const tok = $("#token");
try { tok.value = sessionStorage.getItem("lv_token") || ""; } catch (_) {}
tok.addEventListener("change", () => { try { sessionStorage.setItem("lv_token", tok.value); } catch (_) {} });

async function api(caminho, opcoes = {}) {
  const headers = { ...(opcoes.headers || {}) };
  if (tok.value) headers["X-API-Token"] = tok.value;
  if (opcoes.json !== undefined) { headers["Content-Type"] = "application/json"; opcoes.body = JSON.stringify(opcoes.json); }
  const r = await fetch(caminho, { ...opcoes, headers });
  const tipo = r.headers.get("content-type") || "";
  const dados = tipo.includes("json") ? await r.json() : await r.text();
  if (!r.ok) {
    const d = typeof dados === "object" ? dados.detail ?? dados : dados;
    throw new Error(typeof d === "string" ? d : Array.isArray(d) ? d.map((x) => `${(x.loc || []).join(".")}: ${x.msg}`).join("; ") : JSON.stringify(d));
  }
  return dados;
}
function form(el) {
  const o = {};
  for (const [k, v] of new FormData(el).entries()) o[k] = v;
  el.querySelectorAll("input[type=checkbox]").forEach((c) => (o[c.name] = c.checked));
  return o;
}
function limpar(o) { for (const k of Object.keys(o)) if (o[k] === "") delete o[k]; return o; }
async function acao(botao, fn, saida) {
  if (botao) botao.disabled = true;
  try { await fn(); } catch (e) { if (saida) saida.innerHTML = `<div class="card erro">${esc(e.message)}</div>`; else alert(e.message); }
  finally { if (botao) botao.disabled = false; }
}
const nivel = (n) => (n === "bloqueante" ? "erro" : n === "alerta" ? "alerta" : "ok");

// ---------------------------------------------------------------- abas
document.querySelectorAll("#abas button").forEach((b) =>
  b.addEventListener("click", () => {
    document.querySelectorAll("#abas button, .aba").forEach((x) => x.classList.remove("ativa"));
    b.classList.add("ativa");
    $("#" + b.dataset.aba).classList.add("ativa");
    ({ painel: painel, casos: casos, minuta: carregarMinutas, habilidades: skills, alertas: () => { alertasLista().catch(() => {}); intimacoesLista().catch(() => {}); } })[b.dataset.aba]?.();
  }));

// ---------------------------------------------------------------- painel
async function painel() {
  try {
    const s = await api("/api/saude");
    $("#saude").innerHTML = [
      ["Banco", `${s.banco}${s.pgvector ? " + pgvector " + s.pgvector : ""}`],
      ["Embeddings", `${s.embeddings.provider} / ${s.embeddings.modelo} (${s.embeddings.dimensao}d) ${s.embeddings.ok ? "" : "INDISPONÍVEL"}`],
      ["IA redatora", s.llm.redator], ["IA verificadora", s.llm.verificador],
      ["IA local para sigilo", s.llm.local_para_sigilo ? "configurada" : "não configurada"],
    ].map(([k, v]) => `<div class="card"><div class="meta">${esc(k)}</div><strong>${esc(v)}</strong></div>`).join("");
    const e = await api("/api/conhecimento/estatisticas");
    $("#estat").innerHTML = Object.entries(e).map(([k, v]) =>
      `<div class="card"><div class="meta">${esc(k.replaceAll("_", " "))}</div><strong>${esc(typeof v === "object" ? JSON.stringify(v) : v)}</strong></div>`).join("");
  } catch (err) { $("#saude").innerHTML = `<div class="card erro">${esc(err.message)}</div>`; }
}

// ---------------------------------------------------------------- casos
async function casos() {
  const lista = await api("/api/casos").catch(() => []);
  const sel = $("#sel-caso");
  sel.innerHTML = `<option value="">Sem caso vinculado</option>` + lista.map((c) => `<option value="${c.id}">#${c.id} ${esc(c.titulo)}</option>`).join("");
  $("#lista-casos").innerHTML = lista.map((c) => `
    <div class="card"><h4>#${c.id} ${esc(c.titulo)} ${c.sigiloso ? '<span class="etq alerta">sigiloso</span>' : ""}</h4>
      <div class="meta">Área: ${esc(c.area || "-")} | Data dos fatos: ${esc(c.data_fatos || "não informada")}</div>
      <div class="linha"><input type="file" data-caso="${c.id}" accept=".pdf,.txt"><button class="sec" data-enviar="${c.id}">Enviar aos autos</button></div>
      ${c.documentos.map((d) => docHtml(d)).join("")}
    </div>`).join("") || `<p class="nota">Nenhum caso cadastrado.</p>`;
}
function docHtml(d) {
  const s = d.seguranca || {};
  const ocultos = (s.candidatos_ocultos || []).filter((c) => c.risco === "alto");
  return `<div class="card"><strong>Doc ${d.id}: ${esc(d.nome)}</strong> (${d.paginas} p.)
    ${d.liberado_para_ia ? '<span class="etq ok">liberado para IA</span>' : '<span class="etq erro">aguarda decisão de segurança</span>'}
    ${s.paginas_sem_texto_ocr_necessario?.length ? `<div class="etq alerta">OCR necessário nas p. ${s.paginas_sem_texto_ocr_necessario.join(", ")}</div>` : ""}
    ${ocultos.length ? `<div class="nota">Texto oculto com instrução à IA:</div><ul class="lim">${ocultos.map((c) =>
      `<li>p. ${c.pagina}: <code>${esc(c.texto)}</code> <span class="etq erro">${esc(c.sinais.join(", "))}</span></li>`).join("")}</ul>
      <button data-decidir="${d.id}" data-trechos='${esc(JSON.stringify(ocultos.map((c) => c.texto)))}'>Remover trechos e liberar</button>` : ""}
    ${(s.injecoes_texto_visivel || []).map((v) => `<div class="etq alerta">p. ${v.pagina}: possível instrução visível (${esc(v.categorias.join(", "))})</div>`).join("")}
  </div>`;
}
$("#f-caso").addEventListener("submit", (ev) => { ev.preventDefault();
  acao(ev.submitter, async () => { await api("/api/casos", { method: "POST", json: limpar(form(ev.target)) }); ev.target.reset(); await casos(); }); });
$("#lista-casos").addEventListener("click", (ev) => {
  const b = ev.target.closest("button"); if (!b) return;
  if (b.dataset.enviar) acao(b, async () => {
    const arq = $(`input[data-caso="${b.dataset.enviar}"]`).files[0]; if (!arq) throw new Error("Selecione um arquivo.");
    const fd = new FormData(); fd.append("arquivo", arq);
    await api(`/api/casos/${b.dataset.enviar}/documentos`, { method: "POST", body: fd }); await casos(); });
  if (b.dataset.decidir) acao(b, async () => {
    await api(`/api/documentos/${b.dataset.decidir}/decisao-seguranca`, { method: "POST", json: { remover_trechos: JSON.parse(b.dataset.trechos), liberar: true } });
    await casos(); });
});

// ---------------------------------------------------------------- minuta
async function carregarMinutas() {
  await casos();
  const l = await api("/api/minutas").catch(() => []);
  $("#sel-minuta").innerHTML = l.map((m) => `<option value="${m.id}">#${m.id} ${esc(m.tipo_peca)} (${m.fase}, ${m.status})</option>`).join("");
}
$("#f-minuta").addEventListener("submit", (ev) => { ev.preventDefault();
  acao(ev.submitter, async () => {
    const f = form(ev.target);
    const m = await api("/api/minutas", { method: "POST", json: {
      caso_id: f.caso_id ? Number(f.caso_id) : null, tipo_peca: f.tipo_peca, pedido: f.pedido,
      skills_fixadas: (f.skills_fixadas || "").split(",").map((x) => x.trim()).filter(Boolean),
      anonimizar_autos: f.anonimizar_autos, gerar_peca_contraria: f.gerar_peca_contraria } });
    render(m); carregarMinutas(); }, $("#area-minuta")); });
$("#abrir-minuta").addEventListener("click", (ev) => acao(ev.target, async () => render(await api(`/api/minutas/${$("#sel-minuta").value}`)), $("#area-minuta")));

function render(m) {
  const e = m.estado || {}, alvo = $("#area-minuta");
  let h = `<div class="card"><h4>Minuta #${m.id}: ${esc(m.tipo_peca)}</h4><span class="etq">${esc(m.fase)}</span><span class="etq ${m.status === "APROVADA" ? "ok" : "alerta"}">${esc(m.status)}</span>
    ${e.plano ? `<div class="meta">${esc(e.plano.resumo_caso || "")}</div><div><strong>Estratégia:</strong> ${esc(e.plano.estrategia || "")}</div>` : ""}
    ${(e.plano?.alertas || []).map((a) => `<div class="etq alerta">${esc(a)}</div>`).join("")}</div>`;
  if (m.fase === "falha") h += `<div class="card erro">${esc(e.erro)}</div>`;
  if (m.fase === "perguntas") {
    h += `<form id="f-resp" class="card coluna"><h4>Perguntas do agente</h4>${(e.perguntas || []).map((p) => `
      <label>${esc(p.pergunta)}</label>${p.opcoes?.length ? `<select name="${esc(p.id)}">${p.opcoes.map((o) => `<option>${esc(o)}</option>`).join("")}</select>` : `<input name="${esc(p.id)}">`}`).join("")}
      <button>Responder e gerar roteiro</button></form>`;
  }
  if (m.fase === "aprovar_roteiro") {
    h += `<div class="card"><h4>Roteiro proposto (edite o JSON se necessário)</h4>
      <textarea id="rot" rows="10">${esc(JSON.stringify(e.roteiro, null, 2))}</textarea>
      <div class="linha"><button id="aprovar-rot">Aprovar roteiro, pesquisar e redigir</button></div></div>`;
  }
  if (m.fase === "pesquisa" || m.fase === "redacao") h += `<div class="card">Processando. Use "Abrir minuta" para atualizar.</div>`;
  if (m.fase === "revisao") h += revisaoHtml(m);
  alvo.innerHTML = h;
  $("#f-resp")?.addEventListener("submit", (ev) => { ev.preventDefault();
    acao(ev.submitter, async () => render(await api(`/api/minutas/${m.id}/respostas`, { method: "POST", json: { respostas: form(ev.target) } })), alvo); });
  $("#aprovar-rot")?.addEventListener("click", (ev) => acao(ev.target, async () =>
    render(await api(`/api/minutas/${m.id}/roteiro/aprovar`, { method: "POST", json: { secoes: JSON.parse($("#rot").value) } })), alvo));
  $("#salvar-txt")?.addEventListener("click", (ev) => acao(ev.target, async () =>
    render(await api(`/api/minutas/${m.id}/texto`, { method: "PUT", json: { texto: $("#txt").value } })), alvo));
  $("#aprovar-min")?.addEventListener("click", (ev) => acao(ev.target, async () =>
    render(await api(`/api/minutas/${m.id}/aprovar`, { method: "POST", json: { responsavel: $("#resp").value, ciente_alertas: $("#ciente").checked } })), alvo));
}
function revisaoHtml(m) {
  const v = m.verificacao || {}, e = m.estado || {}, seg = v.seguranca || {};
  const probs = (v.problemas || []).map((p) => `<li><span class="etq ${nivel(p.nivel)}">${esc(p.nivel)}</span>${esc(p.mensagem)}</li>`).join("");
  const ader = (v.aderencia || []).map((a) => `<tr><td>${esc(a.rotulo)}</td><td>${esc(a.afirmacao)}</td><td><span class="etq ${a.classificacao === "apoia" ? "ok" : "alerta"}">${esc(a.classificacao)}</span></td><td class="meta">${esc(a.justificativa)}</td></tr>`).join("");
  const jul = (v.julgador?.checklist || []).map((c) => `<li>${c.atendido ? "✓" : "✗"} ${esc(c.item)} <span class="meta">(${esc(c.base)})</span></li>`).join("");
  const contra = (e.peca_contraria?.vulnerabilidades || []).map((x) => `<li><span class="etq ${x.gravidade === "alta" ? "erro" : "alerta"}">${esc(x.gravidade)}</span><strong>${esc(x.ponto)}</strong>: ${esc(x.argumento_adverso)} <span class="meta">Reforço: ${esc(x.como_reforcar)}</span></li>`).join("");
  const sk = (e.skills_aplicadas || []).map((s) => `<span class="etq ${s.obrigatoria ? "ok" : ""}">${esc(s.titulo)} ${s.confianca}</span>`).join("");
  return `
  <div class="card"><h4>Verificação ${v.bloqueado ? '<span class="etq erro">BLOQUEADA</span>' : '<span class="etq ok">sem bloqueio</span>'}
    <span class="etq ${seg.indicador === "seguro" ? "ok" : "alerta"}">segurança: ${esc(seg.indicador)}</span></h4>
    <ul class="lim">${probs || "<li>Nenhum problema.</li>"}</ul>
    ${v.pendencias?.length ? `<div class="nota">Pendências no texto:</div><ul class="lim">${v.pendencias.map((p) => `<li>${esc(p)}</li>`).join("")}</ul>` : ""}
    <div class="meta">Habilidades aplicadas: ${sk || "nenhuma"}</div></div>
  ${ader ? `<div class="card"><h4>Aderência da tese (verificador independente)</h4><table><tr><th>Precedente</th><th>Afirmação</th><th>Resultado</th><th>Justificativa</th></tr>${ader}</table></div>` : ""}
  <div class="card"><h4>Simulação do julgador</h4><ul class="lim">${jul || "<li>Sem checklist para este tipo.</li>"}</ul></div>
  ${contra ? `<div class="card"><h4>Crítica da parte adversa</h4><ul class="lim">${contra}</ul></div>` : ""}
  <div class="card"><h4>Texto com marcadores (editável)</h4><textarea id="txt" rows="16">${esc(m.texto)}</textarea>
    <div class="linha"><button id="salvar-txt">Salvar e verificar novamente</button></div></div>
  <div class="card"><h4>Texto resolvido</h4><pre>${esc(m.texto_resolvido)}</pre>
    <div class="linha"><a href="/api/minutas/${m.id}/exportar?formato=docx">Exportar DOCX</a> | <a href="/api/minutas/${m.id}/exportar?formato=txt">TXT</a></div></div>
  ${m.status !== "APROVADA" ? `<div class="card linha"><input id="resp" placeholder="Advogado responsável (nome e OAB)"><label class="chk"><input id="ciente" type="checkbox"> Li e assumo os alertas</label><button id="aprovar-min">Aprovar minuta</button></div>` : `<div class="card ok">Aprovada por ${esc(m.aprovada_por)}</div>`}
  <div class="card"><h4>Rastro do agente</h4><pre>${esc(JSON.stringify(e.buscas || [], null, 1))}</pre></div>`;
}

// ---------------------------------------------------------------- pesquisa
$("#f-pesq").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-pesq");
  acao(ev.submitter, async () => {
    const f = form(ev.target);
    if (f.fonte === "jurisprudencia") {
      const r = await api(`/api/pesquisa/jurisprudencia?${new URLSearchParams(limpar({ q: f.q, tribunal: f.tribunal }))}`);
      out.innerHTML = r.resultados.map((x) => `<div class="card"><h4>${esc(x.rotulo)}</h4>
        <span class="etq">${esc(x.hierarquia || x.tipo)}</span><span class="etq ${x.status === "vigente" ? "ok" : "alerta"}">${esc(x.status)}</span>
        ${x.verificado ? '<span class="etq ok">verificado</span>' : '<span class="etq alerta">não verificado</span>'}
        <span class="meta">RRF ${x.rrf} | vetor ${x.rank_vetorial ?? "-"} | lexical ${x.rank_fts ?? x.rank_lexical ?? "-"}</span>
        ${x.alerta_status ? `<div class="etq alerta">${esc(x.alerta_status)}</div>` : ""}
        ${x.tese ? `<div><strong>Tese:</strong> ${esc(x.tese)}</div>` : ""}<pre>${esc(x.ementa)}</pre>
        <div class="meta">Marcador: <code>${esc(x.marcador)}</code></div></div>`).join("") +
        (r.excluidos_por_status.length ? `<div class="card alerta">Excluídos por status: ${r.excluidos_por_status.map((x) => esc(x.rotulo + " (" + x.status + ")")).join("; ")}</div>` : "") || `<p class="nota">Sem resultados.</p>`;
    } else if (f.fonte === "legislacao") {
      const r = await api(`/api/pesquisa/legislacao?${new URLSearchParams(limpar({ q: f.q, data_fatos: f.data_fatos }))}`);
      out.innerHTML = r.resultados.map((x) => `<div class="card"><h4>${esc(x.rotulo)}</h4>
        ${x.alertas.map((a) => `<div class="etq alerta">${esc(a)}</div>`).join("")}
        <div class="meta">Redação em ${esc(x.data_referencia)}:</div><pre>${esc(x.texto_na_data_dos_fatos || "sem versão vigente")}</pre>
        <div class="meta">Marcador: <code>${esc(x.marcador)}</code></div></div>`).join("") || `<p class="nota">Sem resultados.</p>`;
    } else {
      const r = await api(`/api/pesquisa/${f.fonte}?${new URLSearchParams({ q: f.q })}`);
      out.innerHTML = r.map((x) => `<div class="card"><h4>${esc(x.titulo || x.fonte_id)}</h4><span class="meta">${esc(x.origem || "")}</span><pre>${esc(x.trecho)}</pre></div>`).join("") || `<p class="nota">Sem resultados.</p>`;
    }
  }, out); });

// ---------------------------------------------------------------- ferramentas
function memoria(r) {
  return `<div class="card">${Object.entries(r).filter(([k]) => !["memoria", "alertas"].includes(k)).map(([k, v]) => `<span class="etq">${esc(k)}: ${esc(v)}</span>`).join("")}
    <ol>${(r.memoria || []).map((l) => `<li>${esc(l)}</li>`).join("")}</ol>${(r.alertas || []).map((a) => `<div class="etq alerta">${esc(a)}</div>`).join("")}</div>`;
}
$("#f-prazo").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-prazo");
  acao(ev.submitter, async () => {
    const f = form(ev.target); const feriados = {};
    (f.feriados || "").split(",").map((x) => x.trim()).filter(Boolean).forEach((d) => (feriados[d] = "Feriado local informado"));
    out.innerHTML = memoria(await api("/api/prazos", { method: "POST", json: { data_evento: f.data_evento, dias: Number(f.dias), termo: f.termo,
      contagem: f.contagem, em_dobro: !!f.motivo_dobro, motivo_dobro: f.motivo_dobro || null, feriados_extras: feriados,
      usar_dias_forenses_usuais: f.usar_dias_forenses_usuais } }));
  }, out); });
api("/api/prescricao/catalogo").then((c) => { $("#sel-presc").innerHTML = Object.entries(c).map(([k, v]) => `<option value="${k}">${esc(v.descricao)} (${v.anos} anos, ${esc(v.base)})</option>`).join(""); }).catch(() => {});
$("#f-presc").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-presc");
  acao(ev.submitter, async () => { out.innerHTML = memoria(await api("/api/prescricao", { method: "POST", json: limpar(form(ev.target)) })); }, out); });
$("#f-verif").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-verif");
  acao(ev.submitter, async () => {
    const r = await api("/api/verificar-texto", { method: "POST", json: limpar(form(ev.target)) });
    out.innerHTML = `<div class="card">${r.bloqueado ? '<span class="etq erro">BLOQUEADO</span>' : '<span class="etq ok">sem bloqueio</span>'}
      <ul class="lim">${r.problemas.map((p) => `<li><span class="etq ${nivel(p.nivel)}">${esc(p.nivel)}</span>${esc(p.mensagem)}</li>`).join("")}</ul>
      <pre>${esc(r.texto)}\n\n${esc(r.anexo)}</pre></div>`;
  }, out); });
$("#f-anon").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-anon");
  acao(ev.submitter, async () => {
    const r = await api("/api/anonimizar", { method: "POST", json: { texto: form(ev.target).texto } });
    out.innerHTML = `<div class="card"><pre>${esc(r.texto)}</pre><h4>Cofre (guarde localmente; não é armazenado)</h4><pre>${esc(JSON.stringify(r.cofre.entradas, null, 1))}</pre>
      ${r.alertas.map((a) => `<div class="etq alerta">${esc(a)}</div>`).join("")}</div>`;
  }, out); });

// ---------------------------------------------------------------- lotes
function loteHtml(l) {
  return `<div class="card"><h4>Lote #${l.id} (${esc(l.modo)}): ${esc(l.fase)}</h4>
    ${l.minuta_modelo_id ? `<div class="meta">Minuta-modelo #${l.minuta_modelo_id}: conduza-a na aba Minuta até a revisão.</div>` : ""}
    <div class="linha"><button data-l="aprovar">Aprovar minuta-modelo</button><button class="sec" data-l="gerar">Gerar demais</button><button class="sec" data-l="falhas">Repetir falhas</button></div>
    <table><tr><th>Caso</th><th>Status</th><th>Minuta</th><th>Preservado</th><th>Alterações frente ao molde</th></tr>
    ${l.itens.map((i) => `<tr><td>${i.caso_id}${i.modelo ? " (modelo)" : ""}</td><td>${esc(i.status)} ${i.erro ? `<span class="etq erro">${esc(i.erro)}</span>` : ""}</td>
      <td>${i.minuta_id ?? "-"} ${i.bloqueado ? '<span class="etq erro">bloqueada</span>' : ""}</td><td>${i.preservado_pct ?? "-"}%</td>
      <td>${i.alteracoes.slice(0, 6).map((d) => `<div class="${d.tipo === "removido" ? "erro" : "ok"}">${d.tipo === "removido" ? "-" : "+"} ${esc(d.texto)}</div>`).join("")}</td></tr>`).join("")}</table></div>`;
}
async function verLote(id) { const l = await api(`/api/lotes/${id}`); $("#res-lote").innerHTML = loteHtml(l); $("#lote-id").value = id; }
$("#f-lote").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-lote");
  acao(ev.submitter, async () => {
    const f = form(ev.target);
    const l = await api("/api/lotes", { method: "POST", json: { caso_ids: f.caso_ids.split(",").map((x) => Number(x.trim())).filter(Boolean),
      caso_modelo_id: f.caso_modelo_id ? Number(f.caso_modelo_id) : null, tipo_peca: f.tipo_peca, instrucao: f.instrucao, modo: "etapas" } });
    out.innerHTML = loteHtml(l); $("#lote-id").value = l.id;
  }, out); });
$("#ver-lote").addEventListener("click", (ev) => acao(ev.target, () => verLote($("#lote-id").value), $("#res-lote")));
$("#res-lote").addEventListener("click", (ev) => {
  const b = ev.target.closest("button[data-l]"); if (!b) return; const id = $("#lote-id").value;
  acao(b, async () => {
    if (b.dataset.l === "aprovar") await api(`/api/lotes/${id}/aprovar-modelo`, { method: "POST" });
    else await api(`/api/lotes/${id}/gerar?apenas_falhas=${b.dataset.l === "falhas"}`, { method: "POST" });
    await verLote(id);
  }, $("#res-lote"));
});

// ---------------------------------------------------------------- habilidades
async function skills() {
  const l = await api("/api/skills").catch(() => []);
  $("#lista-skills").innerHTML = `<table><tr><th>Habilidade</th><th>Tipo</th><th>Versão</th><th>Origem</th></tr>${l.map((s) =>
    `<tr><td><a href="#" data-s="${s.id}">${esc(s.titulo)}</a><div class="meta">${esc(s.descricao)}</div></td><td>${esc(s.tipo)}</td><td>${s.versao}</td><td>${s.oficial ? "oficial" : "sua versão"}</td></tr>`).join("")}</table>`;
}
$("#lista-skills").addEventListener("click", async (ev) => {
  const a = ev.target.closest("a[data-s]"); if (!a) return; ev.preventDefault();
  const s = await api(`/api/skills/${a.dataset.s}`);
  $("#det-skill").innerHTML = `<div class="card"><h4>${esc(s.titulo)} <span class="etq">${esc(s.slug)}</span></h4>
    <div class="meta">Gatilhos: ${esc((s.gatilhos || []).join(", "))}</div><textarea id="sk-txt" rows="16">${esc(s.conteudo)}</textarea>
    <div class="linha"><button id="sk-fork">Salvar minha versão</button></div></div>`;
  $("#sk-fork").addEventListener("click", (e2) => acao(e2.target, async () => {
    await api(`/api/skills/${encodeURIComponent(s.slug)}/fork`, { method: "POST", json: { conteudo: $("#sk-txt").value, nota: "edição pela interface" } });
    await skills(); }));
});

// ---------------------------------------------------------------- base
$("#f-ejc").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-ejc");
  acao(ev.submitter, async () => { const r = await api("/api/conhecimento/importar-ejc", { method: "POST", json: limpar(form(ev.target)) });
    out.innerHTML = `<pre>${esc(JSON.stringify(r, null, 2))}</pre>`; }, out); });
$("#f-json").addEventListener("submit", (ev) => { ev.preventDefault(); const out = $("#res-json");
  acao(ev.submitter, async () => { const f = form(ev.target);
    const r = await api(`/api/conhecimento/${f.tipo}`, { method: "POST", json: JSON.parse(f.json) });
    out.innerHTML = `<pre>${esc(JSON.stringify(r, null, 2))}</pre>`; }, out); });
$("#ver-aud").addEventListener("click", (ev) => acao(ev.target, async () => {
  const l = await api("/api/auditoria");
  $("#res-aud").innerHTML = `<table><tr><th>Momento</th><th>Ação</th><th>Alvo</th><th>Provedor</th><th>Detalhe</th></tr>${l.map((a) =>
    `<tr><td>${esc(a.momento)}</td><td>${esc(a.acao)}</td><td>${esc(a.alvo)}</td><td>${esc(a.provedor || "")}</td><td class="meta">${esc(JSON.stringify(a.detalhe))}</td></tr>`).join("")}</table>`;
}, $("#res-aud")));

painel();

// ------------------------------------------------- formulários declarativos (módulos de inteligência)
function celula(v) {
  if (v === null || v === undefined) return "";
  if (typeof v === "object") return `<code>${esc(JSON.stringify(v)).slice(0, 400)}</code>`;
  if (typeof v === "string" && /^https?:\/\//.test(v)) return `<a href="${esc(v)}" target="_blank" rel="noopener">link</a>`;
  return esc(v);
}
function tabela(lista) {
  const cols = [...new Set(lista.slice(0, 50).flatMap((o) => Object.keys(o)))].slice(0, 12);
  return `<div class="rolagem"><table><thead><tr>${cols.map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${
    lista.slice(0, 300).map((o) => `<tr>${cols.map((c) => `<td>${celula(o[c])}</td>`).join("")}</tr>`).join("")}</tbody></table></div>
    ${lista.length > 300 ? `<p class="nota">Exibindo 300 de ${lista.length}.</p>` : ""}`;
}
function exibir(v, nivelTit = 4) {
  if (typeof v === "string") return `<pre>${esc(v)}</pre>`;
  if (Array.isArray(v)) {
    if (!v.length) return '<p class="nota">Nenhum resultado.</p>';
    if (v.every((x) => x && typeof x === "object" && !Array.isArray(x))) return tabela(v);
    return `<ul class="lim">${v.map((x) => `<li>${typeof x === "object" ? exibir(x, nivelTit + 1) : esc(x)}</li>`).join("")}</ul>`;
  }
  if (v && typeof v === "object") {
    const simples = [], compostos = [];
    for (const [k, x] of Object.entries(v)) (x && typeof x === "object" ? compostos : simples).push([k, x]);
    const cls = (k, x) => (k === "apto" || k === "bloqueado" || k === "prescrito") ? (x === (k === "apto") ? "ok" : "erro") : "";
    return `<div class="card">${simples.map(([k, x]) => `<span class="etq ${cls(k, x)}">${esc(k)}: ${celula(x)}</span>`).join("")}
      ${compostos.map(([k, x]) => `<h${nivelTit}>${esc(k)}</h${nivelTit}>${
        ["memoria", "alertas", "problemas", "pendencias"].includes(k) && Array.isArray(x) && x.every((y) => typeof y === "string")
          ? `<ol>${x.map((y) => `<li class="${k === "memoria" ? "" : "alerta"}">${esc(y)}</li>`).join("")}</ol>` : exibir(x, Math.min(nivelTit + 1, 6))}`).join("")}</div>`;
  }
  return `<p>${esc(v)}</p>`;
}
function converter(el) {
  const t = el.dataset.t, v = el.type === "checkbox" ? el.checked : el.value.trim();
  if (el.type === "checkbox") return v;
  if (v === "") return undefined;
  if (t === "int") { const n = Number(v); if (!Number.isFinite(n)) throw new Error(`Valor numérico inválido em ${el.name}`); return n; }
  if (t === "json") { try { return JSON.parse(v); } catch (e) { throw new Error(`JSON inválido em ${el.name}: ${e.message}`); } }
  if (t === "lista") return v.split(",").map((x) => x.trim()).filter(Boolean);
  if (t === "listaint") return v.split(",").map((x) => Number(x.trim())).filter(Number.isFinite);
  if (t === "feriados") { const o = {}; v.split(",").map((x) => x.trim()).filter(Boolean).forEach((d) => (o[d] = "Feriado local informado")); return o; }
  return v;
}
function saidaDe(el) { let s = el.nextElementSibling; while (s && !s.classList.contains("saida")) s = s.nextElementSibling; return s || el.parentElement.querySelector(".saida"); }
document.querySelectorAll("form.api").forEach((f) => f.addEventListener("submit", (ev) => {
  ev.preventDefault(); const out = saidaDe(f);
  acao(ev.submitter, async () => {
    let rota = f.dataset.rota; const metodo = f.dataset.metodo; let opcoes = { method: metodo };
    if (f.dataset.arquivos) {
      const fd = new FormData(); [...f.querySelector(`input[name=${f.dataset.arquivos}]`).files].forEach((a) => fd.append(f.dataset.arquivos, a));
      opcoes.body = fd;
    } else {
      const dados = {};
      f.querySelectorAll("[name]").forEach((el) => { const v = converter(el); if (v !== undefined) dados[el.name] = v; });
      rota = rota.replace(/\{(\w+)\}/g, (_, k) => { const v = dados[k]; delete dados[k]; if (v === undefined) throw new Error(`Informe ${k}`); return encodeURIComponent(v); });
      if (metodo === "GET") { const q = new URLSearchParams(Object.entries(dados).filter(([, v]) => typeof v !== "boolean")); if ([...q].length) rota += `?${q}`; }
      else { const corpo = f.dataset.corpo ? dados[f.dataset.corpo] : dados; opcoes.json = f.dataset.lista ? [corpo] : corpo; }
    }
    out.innerHTML = exibir(await api(rota, opcoes));
    if (f.dataset.depois === "intimacoes") intimacoesLista();
  }, out);
}));
document.addEventListener("click", (ev) => {
  const b = ev.target.closest("button[data-get],button[data-post]"); if (!b) return;
  const out = saidaDe(b.closest(".linha") || b);
  acao(b, async () => { out.innerHTML = exibir(await api(b.dataset.get || b.dataset.post, { method: b.dataset.get ? "GET" : "POST" })); }, out);
});

// ------------------------------------------------------------------ alertas e intimações
const NIVEL = { critico: "erro", alerta: "alerta", info: "" };
async function alertasLista() {
  const l = await api("/api/alertas");
  $("#lista-alertas").innerHTML = l.length ? `<div class="rolagem"><table><thead><tr><th>Nível</th><th>Tipo</th><th>Mensagem</th><th>Vínculos</th><th></th></tr></thead><tbody>${
    l.map((a) => `<tr><td><span class="etq ${NIVEL[a.nivel] ?? ""}">${esc(a.nivel)}</span></td><td>${esc(a.tipo)}</td><td>${esc(a.mensagem)}</td>
      <td class="meta">${["caso_id", "minuta_id", "precedente_id", "intimacao_id"].filter((k) => a[k]).map((k) => `${k}: ${esc(a[k])}`).join("<br>")}</td>
      <td><button class="sec" data-resolver="${a.id}">Resolver</button></td></tr>`).join("")}</tbody></table></div>` : '<p class="nota">Nenhum alerta aberto.</p>';
}
async function intimacoesLista() {
  const l = await api("/api/intimacoes");
  $("#lista-intim").innerHTML = exibir(l.map((i) => ({ id: i.id, processo: i.numero_processo, tribunal: i.tribunal, disponibilizacao: i.data_disponibilizacao,
    prazo_dias: i.prazo_dias, vencimento: i.vencimento, status: i.status, caso_id: i.caso_id, minuta_id: i.minuta_id, teor: (i.texto || "").slice(0, 160) })));
}
$("#lista-alertas").addEventListener("click", (ev) => { const b = ev.target.closest("[data-resolver]"); if (!b) return;
  acao(b, async () => { await api(`/api/alertas/${b.dataset.resolver}/resolver`, { method: "POST" }); await alertasLista(); }, $("#lista-alertas")); });
$("#atualizar-alertas").addEventListener("click", (ev) => acao(ev.target, alertasLista, $("#lista-alertas")));
$("#rodar-monitor").addEventListener("click", (ev) => acao(ev.target, async () => { await api("/api/monitor/executar", { method: "POST" }); await alertasLista(); }, $("#lista-alertas")));
$("#atualizar-intim").addEventListener("click", (ev) => acao(ev.target, intimacoesLista, $("#lista-intim")));
alertasLista().catch(() => {}); intimacoesLista().catch(() => {});
