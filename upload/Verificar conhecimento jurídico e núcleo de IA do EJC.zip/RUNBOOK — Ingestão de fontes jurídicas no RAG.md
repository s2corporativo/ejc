# RUNBOOK — Ingestão de fontes jurídicas no RAG

Como o EJC popula a base de conhecimento (RAG) puxando as fontes jurídicas
oficiais, e como disparar/monitorar a ingestão completa.

## Princípio: a ingestão roda em PRODUÇÃO (VPS), não em sessões de dev

Os ingestores baixam conteúdo de `planalto.gov.br`, `*.jus.br`, `*.leg.br`,
`lexml.gov.br` etc. **A busca real só funciona onde há internet aberta e o
banco de produção** — ou seja, no VPS (`ejc.depaulateixeira.adv.br`). Sessões de
desenvolvimento Claude Code têm o egress restrito por política de rede (o proxy
responde `403` a `.gov.br`/`.jus.br`), então a ingestão **não** roda a partir
delas — e não se deve contornar esse bloqueio. Os testes dos ingestores são
offline (mocks/fixtures); a coleta viva é sempre no VPS.

## Semente pública para escritório sem casos próprios

O catálogo versionado `backend/app/eval/fontes_publicas_iniciais.json` define a
primeira base pública do EJC. Ele separa normas vigentes, precedentes
vinculantes, jurisprudência persuasiva e material informativo. Não contém casos
do escritório, experiência própria, pareceres ou gold set humano.

O seed inicial de jurisprudência usa 15 consultas focadas em consumidor,
trabalhista, cível/processual, penal e tributário. Para executar em produção,
com autenticação de `admin`, `socio` ou `superadmin`:

```bash
curl -sS -X POST "$BASE/api/rag/seed?incluir_jurisprudencia=true" \
  -H "Authorization: Bearer $TOKEN"
```

Esse endpoint é idempotente e agenda o importador oficial configurado
(LexML/STJ). Se uma fonte estiver desabilitada ou indisponível, o sistema deve
registrar o job como parcial/erro; não preencher a lacuna com texto de IA.
Depois, conferir a tabela `fontes_ingestao`, a proveniência e uma busca por
Tema/lei no painel do RAG. O operador deve preservar URL, órgão, identificador,
data de consulta, versão/hash e nível de confiança.

## Estado dos gates (produção)

Todos ligados por default (`backend/app/core/config.py`). Para desligar uma
fonte, defina a flag `=false` no `.env` do VPS e reinicie o backend
(`get_settings()` é cacheado — editar o `.env` sem reiniciar não tem efeito).

| Flag | Default | Fonte |
|------|---------|-------|
| `ENABLE_SCHEDULER` | `true` | liga o APScheduler (todos os jobs abaixo) |
| `DJEN_INGEST_ENABLED` | `true` | DJEN → RAG (OABs em `DJEN_OABS_MONITORADAS`: `252599/MG,251174/MG`). **Não confundir com o alerta de prazo**: o job das 06h30 (`capturar_para_advogado`) ignora esta variável e lê `users.djen_oab_numero` |
| `TJMG_INGEST_ENABLED` | `true` | crawler de jurisprudência do TJMG |
| `LEXML_INGEST_ENABLED` | `true` | **federação LexML** (ver cobertura abaixo) |
| `CONHECIMENTO_INGEST_ENABLED` | `true` | ANPD + Normas RFB |
| `RAG_SUMULAS_SEED_ENABLED` | `true` | seed de súmulas (STJ/TST/STF) no boot |

> Premissa de worker único: com vários workers `uvicorn`, deixe
> `ENABLE_SCHEDULER=false` nos workers extras (só um agenda os jobs).

### Egress brasileiro do DJEN / Comunica CNJ

O endpoint oficial permanece fixo em `https://comunicaapi.pje.jus.br/api/v1`.
Se o host de produção tiver saída fora do Brasil e o CloudFront responder
`403`/bloqueio geográfico, configure **somente** `DJEN_HTTP_PROXY_URL` com
proxy HTTP(S) CONNECT privado/controlado cuja saída pública seja brasileira.

Requisitos operacionais:

- não usar proxy público/gratuito;
- permitir destino apenas `comunicaapi.pje.jus.br:443`;
- não realizar inspeção/interceptação TLS;
- manter autenticação/credencial somente no segredo/.env da VPS;
- o processo DJEN usa `trust_env=False`, portanto proxies globais do host não são herdados;
- após alterar o .env, reiniciar o backend.

Homologação mínima após configurar o egress:

1. validar de dentro do container backend que a consulta oficial deixa de ser classificada como `geo_bloqueado`;
2. executar uma captura real de OAB e conferir paginação/total;
3. repetir a captura para provar deduplicação/idempotência;
4. confirmar `/api/intimacoes/status-captura` em sucesso ou `sucesso_sem_resultados` válido;
5. conferir que nenhuma credencial de proxy ou teor integral desnecessário foi parar em logs;
6. validar `/api/health` e `/api/health/ready` no SHA implantado.

Rollback operacional: remover `DJEN_HTTP_PROXY_URL` e reiniciar o backend restaura a conexão direta. O rollback de código é o revert do PR; não há migration nem transformação de dados.

## 1) Ingestão automática (scheduler)

Com `ENABLE_SCHEDULER=true`, os jobs rodam sozinhos (horários UTC):

| Job | Cadência | Puxa |
|-----|----------|------|
| `ing_planalto` | domingo 03h | Códigos/leis federais (Planalto, catálogo de 36 diplomas) |
| `ing_stj` | sábado 03h | Acórdãos/jurisprudência STJ |
| `ing_camara` | diário 04h00 | Proposições da Câmara |
| `ing_senado` | diário 04h20 | Matérias do Senado |
| `ing_tjmg` | sábado 04h30 | Jurisprudência TJMG |
| `ing_djen` | diário 05h00 | Intimações DJEN (OABs monitoradas) |
| `ing_lexml` | sábado 05h00 | Federação LexML (jurisdições + temas) |
| `ing_conhecimento` | domingo 03h | ANPD + Normas RFB |

Súmulas (STJ/TST/STF) e a legislação federal inicial também são semeadas no
**boot** (`seeds/seed_all.py` + `base_juridica_seed`, idempotentes).

## 2) Ingestão manual sob demanda (endpoints)

Ambos exigem papel **superadmin/admin/socio** e são rate-limited. Rodam em
background (idempotentes — reexecutar não duplica; dedup por `chave_origem`).

> **Atalho:** `scripts/ingestao_rag.sh` faz os passos 1-2 abaixo (login +
> disparo). Ex.: `EJC_EMAIL=admin@dominio ./scripts/ingestao_rag.sh`
> (com `EJC_SEED=1` inclui o passo 3). A senha é solicitada sem eco; nada é
> hardcoded.

### Passo 1 — autenticar (obter access token)

```bash
BASE=https://ejc.depaulateixeira.adv.br
TOKEN=$(curl -sS -X POST "$BASE/api/auth/login" \
  -H 'Content-Type: application/json' \
  -d '{"email":"SEU_EMAIL_ADMIN","password":"SUA_SENHA"}' \
  | python3 -c 'import sys,json; print(json.load(sys.stdin)["access_token"])')
```
> Se a conta tiver 2FA ativo, inclua `"totp_code":"123456"` no corpo.

### Passo 2 — disparar as fontes oficiais (ANPD + RFB + federação LexML)

```bash
curl -sS -X POST "$BASE/api/rag/ingest-fontes-oficiais" \
  -H "Authorization: Bearer $TOKEN"
# 202 Accepted → { "fontes": ["anpd","normas_rfb","lexml"], ... }
```

### Passo 3 — semear/atualizar a base do escritório (opcional)

```bash
# base institucional (README, checklists, padrão-ouro de peças) +
# ?incluir_jurisprudencia agenda uma importação inicial LexML/STJ
curl -sS -X POST "$BASE/api/rag/seed?incluir_jurisprudencia=true" \
  -H "Authorization: Bearer $TOKEN"
```

## 3) Acompanhamento

O resultado durável fica na tabela **`fontes_ingestao`** (última execução,
status `ok`/`parcial`/`erro`, contagem por slug — `planalto`, `stj`, `lexml`,
`anpd`, `normas_rfb`, ...). Consulte pelo painel de fontes da aplicação ou via
SQL no banco de produção.

## 4) Verificar que o RAG está recuperando

Após a ingestão, uma consulta jurídica deve trazer contexto. O retrieval tem
**fallback textual** (pg_trgm/FTS) quando os embeddings ainda não foram
preenchidos, então a busca já funciona; os vetores (`intfloat/multilingual-e5-large`,
1024d) melhoram o ranqueamento e são preenchidos pelo job/serviço de
reindexação de embeddings.

## Cobertura de fontes

| Pedido | Como é coberto |
|--------|----------------|
| Leis federais (Planalto) | job `ing_planalto` + seed de boot |
| Súmulas STJ/TST/STF | seed de súmulas + job `ing_stj` |
| STJ / Câmara / Senado | jobs dedicados |
| TJMG | job `ing_tjmg` + federação LexML |
| DJEN (intimações) | job `ing_djen` (OABs `252599/MG` e `251174/MG`) |
| **TRT-3 / TRF-6** | **federação LexML** (jurisdição nominal) |
| **Juizados especiais** | **federação LexML** (turmas recursais) |
| **Assembleia MG (ALMG) / legislação estadual** | **federação LexML** (esfera estadual) |
| **Município de Betim (leis municipais)** | **federação LexML** (localidade `minas.gerais;betim`) |
| ANPD + Normas RFB | job `ing_conhecimento` |

A **federação LexML** (`services/ingestors/lexml.py`) usa o federador oficial
`lexml.gov.br` (mantido pelo Senado) como fonte única — legislação
estadual/municipal grava em `referencia_legislativa` e jurisprudência em
`jurisprudencia` (nunca `legislacao%`, para não afrouxar o gate anti-alucinação
de citações). Toda URL gravada passa pela allowlist de domínios oficiais.

> Limitação conhecida: a API pública do LexML (`buscar_lexml`) é por
> palavra-chave — as jurisdições nominais (ALMG, Betim, TRT-3, TRF-6, juizados)
> são miradas por consulta explícita e o URN é gravado como metadado de
> proveniência. Portais dedicados (ALMG, Câmara de Betim, TRT-3/TRF-6 diretos)
> exigiriam ingestor próprio validado com `.gov`/`.jus` liberado.
