from __future__ import annotations

from app.services.document_template_validator import (
    validate_admission_template,
    validate_rendered_admission_document,
)
from app.models.document_generation import DocumentGenerationAttempt, DocumentGenerationStatus
from app.models.legal_doc import LegalDoc
from app.models.procuracao import Procuracao


def _template(tipo: str) -> str:
    if tipo == "contrato":
        return (
            "CONTRATO DE PRESTAÇÃO DE SERVIÇOS\n"
            "CONTRATANTE: {{cliente_qualificacao}}\n"
            "CLÁUSULA 1 - OBJETO\n"
            "HONORÁRIOS\n"
            "____________________________"
        )
    return (
        "PROCURAÇÃO AD JUDICIA\n"
        "OUTORGANTE: {{cliente_qualificacao}}\n"
        "OUTORGADO: {{escritorio_socio_titular}}\n"
        "PODERES: {{tipo_poderes}}\n"
        "____________________________"
    )


def test_template_admissao_valido_e_variavel_desconhecida_bloqueada():
    assert validate_admission_template("contrato", _template("contrato")).valid
    rejeitado = validate_admission_template(
        "contrato", _template("contrato") + " {{variavel_inexistente}}"
    )
    assert not rejeitado.valid
    assert any("variáveis desconhecidas" in item for item in rejeitado.errors)


def test_documento_renderizado_nao_pode_conter_placeholder():
    resultado = validate_rendered_admission_document(
        "procuracao",
        _template("procuracao").replace("{{tipo_poderes}}", "[tipo_poderes?]"),
        {"tipo_poderes": "ad_judicia"},
    )
    assert not resultado.valid


def test_modelos_expoem_controles_de_versionamento_e_formalizacao():
    assert {"kit_id", "kit_version", "is_current", "superseded_by_id"} <= set(LegalDoc.__table__.columns.keys())
    assert {"source_legal_doc_id", "signed_document_id", "formalizada_em", "formalizada_por"} <= set(Procuracao.__table__.columns.keys())
    assert {"status", "attempt_count", "last_error_code", "next_retry_at"} <= set(DocumentGenerationAttempt.__table__.columns.keys())
    assert DocumentGenerationStatus.falhou.value == "falhou"
