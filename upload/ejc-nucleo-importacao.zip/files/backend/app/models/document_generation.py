from __future__ import annotations

import enum
from sqlalchemy import Column, DateTime, Enum as SAEnum, ForeignKey, Integer, String, Text, func
from app.core.database import Base


class DocumentGenerationStatus(str, enum.Enum):
    pendente = "pendente"
    processando = "processando"
    concluida = "concluida"
    falhou = "falhou"


class DocumentGenerationAttempt(Base):
    __tablename__ = "document_generation_attempts"

    id = Column(String(36), primary_key=True)
    client_id = Column(String(36), ForeignKey("clients.id", ondelete="CASCADE"), nullable=False, index=True)
    requested_by = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    status = Column(SAEnum(DocumentGenerationStatus), nullable=False, default=DocumentGenerationStatus.pendente, index=True)
    attempt_count = Column(Integer, nullable=False, default=0)
    max_attempts = Column(Integer, nullable=False, default=3)
    last_error_code = Column(String(80), nullable=True)
    last_error_message = Column(String(500), nullable=True)
    kit_id = Column(String(36), nullable=True, index=True)
    kit_version = Column(Integer, nullable=True)
    legal_doc_ids = Column(Text, nullable=True)  # JSON string; IDs only, never content.
    next_retry_at = Column(DateTime(timezone=True), nullable=True, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    completed_at = Column(DateTime(timezone=True), nullable=True)
