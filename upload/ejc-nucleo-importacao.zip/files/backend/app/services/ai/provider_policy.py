# ── app/services/ai/provider_policy.py ───────────────────────────────────────
# POLICY CENTRAL de provedores de IA (Núcleo Único).
#
# Decide, ANTES de qualquer chamada de modelo:
#   • quais provedores são elegíveis (habilitação + chave + soberania de dados);
#   • em que ordem tentar (AI_PROVIDER_PRIORITY + perfil da tarefa);
#   • se o conteúdo precisa/pode ser sanitizado para destino externo (LGPD);
#   • se a chamada é permitida ou bloqueada (PII residual sem provider local).
#
# A policy NÃO chama modelo nenhum — é decisão pura. O despacho continua no
# ai_gateway (que aplica a barreira final de sanitização por conta própria).
from __future__ import annotations
from dataclasses import dataclass, field

from app.core.config import get_settings
from app.services.sanitizer import sanitizar_pii, validar_sem_pii

# Provedores que processam dados FORA do VPS (LGPD: exigem sanitização).
PROVIDERS_EXTERNOS = {"anthropic", "groq", "maritaca"}

# Tarefas complexas (raciocínio jurídico profundo) → priorizam Maritaca no
# roteamento automático. Claude fica reservado à solicitação explícita.
TAREFAS_COMPLEXAS = {
    "analise_caso", "minutas", "dossie", "pesquisa_juridica",
    "estrategia", "analise_juridica", "elaboracao_peca", "auditoria_peca",
    "analise_contrato", "jurimetria", "critica_adversarial", "rag_query",
    "prazos", "audiencia", "ambiental", "trabalhista", "criminal", "familia",
    "administrativo", "sucessoes", "imobiliario", "constitucional", "juizados",
    "civel",
}

# Tarefas simples/econômicas → preferem Ollama/Groq (custo ~zero).
TAREFAS_ECONOMICAS = {"resumo", "triagem", "chat_rapido", "honorarios"}


@dataclass
class PolicyDecision:
    permitido: bool
    provider_chain: list[tuple[str, str | None]] = field(default_factory=list)
    sanitizar_antes: bool = False
    motivo: str = ""
    requer_hitl: bool = True
    requer_fonte: bool = False
    bloqueio_motivo: str | None = None


class AIProviderPolicy:
    """Avaliador central de elegibilidade/ordem de provedores de IA."""

    @staticmethod
    def _elegivel(provider: str) -> bool:
        """Delega ao registry — fonte única de habilitação/chave/kill-switch.

        A cópia local desta regra não checava GROQ_ENABLED: o kill-switch do
        Groq só valia depois que `provider_registry_runtime.instalar()` trocava
        este método. Fora do runtime (testes, scripts, worker sem o patch), a
        policy dizia "elegível" para um provedor desligado (auditoria 18/08).
        """
        from app.services.ai.provider_registry import provider_elegivel

        return provider_elegivel(provider)

    @staticmethod
    def _ordem_prioridade() -> list[str]:
        s = get_settings()
        vistos: list[str] = []
        for p in (s.AI_PROVIDER_PRIORITY or "").split(","):
            p = p.strip().lower()
            if p and p not in vistos:
                vistos.append(p)
        # Default sem AI_PROVIDER_PRIORITY: Groq no cotidiano, Maritaca em
        # leitura/análise/pesquisa, Ollama para fallback local e Claude somente
        # sob solicitação explícita (salvo flag de rollback).
        return vistos or ["groq", "maritaca", "ollama", "anthropic"]

    def avaliar(
        self,
        texto_completo: str,
        task_type: str,
        *,
        ja_sanitizado: bool = False,
        exige_fonte: bool = False,
        provider_solicitado: str | None = None,
    ) -> PolicyDecision:
        """
        Decide a cadeia de provedores para `task_type` dado o conteúdo.

        Regras:
          1. Cadeia base = AI_PROVIDER_PRIORITY filtrada por elegibilidade.
          2. Destino externo + AI_REQUIRE_SANITIZATION_FOR_EXTERNAL:
             sanitiza e checa residual; PII residual → remove externos.
          3. Cadeia vazia → permitido=False com motivo SEGURO (tipos de PII,
             nunca os valores — o conteúdo jamais é ecoado).
          4. Tarefas complexas priorizam Maritaca; econômicas priorizam Groq.
             Claude só entra automaticamente se ANTHROPIC_AUTO_ROUTING_ENABLED=true.
        """
        s = get_settings()
        task = (task_type or "").strip().lower()
        motivos: list[str] = []
        auto_anthropic = bool(getattr(s, "ANTHROPIC_AUTO_ROUTING_ENABLED", False))
        solicitado_inelegivel: str | None = None

        solicitado = (provider_solicitado or "").strip().lower()
        if solicitado and solicitado not in {"groq", "maritaca", "anthropic", "ollama"}:
            solicitado = ""

        if solicitado:
            if self._elegivel(solicitado):
                elegiveis = [solicitado]
            else:
                elegiveis = []
                from app.services.ai.provider_registry import motivo_inelegivel
                solicitado_inelegivel = motivo_inelegivel(solicitado) or "indisponível"
            motivos.append(f"provedor solicitado explicitamente: {solicitado}")
        else:
            elegiveis = [p for p in self._ordem_prioridade() if self._elegivel(p)]
            if not auto_anthropic:
                elegiveis = [p for p in elegiveis if p != "anthropic"]
                motivos.append("Claude reservado para solicitação explícita")

        # ── Barreira LGPD: destino externo exige conteúdo sem PII ────────────
        sanitizar_antes = False
        tem_externo = any(p in PROVIDERS_EXTERNOS for p in elegiveis)
        if tem_externo and s.AI_REQUIRE_SANITIZATION_FOR_EXTERNAL:
            sanitizar_antes = True
            texto_chk = texto_completo or ""
            if not ja_sanitizado:
                texto_chk, _ = sanitizar_pii(texto_chk)
            residual = validar_sem_pii(texto_chk)
            if residual:
                elegiveis = [p for p in elegiveis if p not in PROVIDERS_EXTERNOS]
                motivos.append(
                    "PII residual detectada ("
                    + ", ".join(residual)
                    + ") — provedores externos removidos da cadeia (LGPD)"
                )

        # ── Priorização por perfil da tarefa ─────────────────────────────────
        if not solicitado and task in TAREFAS_COMPLEXAS:
            # Afinidade ESTRITA: mérito jurídico automático usa Maritaca; Ollama
            # pode permanecer como fallback local/sigilo. Groq não assume mérito
            # silenciosamente. A flag de rollback reabilita Anthropic no automático.
            permitidos = {"maritaca", "ollama"}
            if auto_anthropic:
                permitidos.add("anthropic")
            elegiveis = [p for p in elegiveis if p in permitidos]
            if auto_anthropic and "anthropic" in elegiveis:
                elegiveis = ["anthropic"] + [p for p in elegiveis if p != "anthropic"]
                motivos.append("tarefa complexa — rollback Anthropic automático ativo")
            elif "maritaca" in elegiveis:
                elegiveis = ["maritaca"] + [p for p in elegiveis if p != "maritaca"]
                motivos.append("tarefa complexa — afinidade Maritaca/Ollama")
            else:
                motivos.append("tarefa complexa — afinidade Maritaca/Ollama")
        elif not solicitado and task in TAREFAS_ECONOMICAS:
            # Afinidade ESTRITA: rotina usa Groq; Ollama pode servir de fallback
            # local. Maritaca não é consumida por rotina automaticamente.
            # A flag de rollback recoloca Anthropic no fallback automático.
            permitidos = {"groq", "ollama"}
            if auto_anthropic:
                permitidos.add("anthropic")
            elegiveis = [p for p in elegiveis if p in permitidos]
            if "groq" in elegiveis:
                elegiveis = ["groq"] + [p for p in elegiveis if p != "groq"]
            motivos.append(
                "tarefa econômica — afinidade Groq/Ollama"
                + ("/Anthropic rollback" if auto_anthropic else "")
            )

        requer_hitl = bool(s.AI_REQUIRE_HITL)

        if not elegiveis:
            # Mensagem HONESTA conforme a causa da cadeia vazia:
            #  • se externos foram removidos por PII residual, só uma IA LOCAL
            #    resolveria (ou limpar o texto);
            #  • caso contrário, o deploy simplesmente não tem provedor externo
            #    elegível (falta ANTHROPIC_API_KEY / AI_EXTERNAL_PROVIDERS_ALLOWED)
            #    nem Ollama local. Não direcionar só para "habilite o Ollama":
            #    o desenho de produção é IA externa com mascaramento de PII.
            #  • e, desde AUD27-P0-1, a cadeia também fica vazia quando o
            #    kill-switch GLOBAL está desligado — aí nenhuma chave de
            #    provedor resolve, e mandar o operador atrás de
            #    ANTHROPIC_API_KEY o faria perseguir a causa errada.
            removido_por_pii = any("PII residual" in m for m in motivos)
            if not s.AI_ENABLED:
                bloqueio = (
                    "A IA está desligada no sistema (kill-switch AI_ENABLED). "
                    "Nenhum provedor — nem local — responde enquanto ela estiver "
                    "desligada; religue em AI_ENABLED=true para voltar a usar."
                )
            elif solicitado and solicitado_inelegivel:
                bloqueio = (
                    f"O provedor solicitado ({solicitado}) não está disponível: "
                    f"{solicitado_inelegivel}. Selecione outro motor disponível "
                    "ou corrija a configuração desse provedor."
                )
            elif removido_por_pii:
                bloqueio = (
                    "Este conteúdo tem dados pessoais que não podem ir a uma IA "
                    "externa. Habilite uma IA local (OLLAMA_ENABLED=true) ou "
                    "remova os dados pessoais do texto e tente novamente."
                )
            else:
                bloqueio = (
                    "Nenhum provedor elegível para esta tarefa. Verifique a "
                    "configuração do motor previsto para a função (Groq para "
                    "rotina; Maritaca para mérito jurídico) ou selecione "
                    "explicitamente outro motor disponível no sistema. Para "
                    "conteúdo que exige execução local, habilite o Ollama."
                )
            return PolicyDecision(
                permitido=False,
                provider_chain=[],
                sanitizar_antes=sanitizar_antes,
                motivo="; ".join(motivos) or "nenhum provedor de IA elegível",
                requer_hitl=requer_hitl,
                requer_fonte=exige_fonte,
                bloqueio_motivo=bloqueio,
            )

        # Modelo fica None: o gateway resolve o modelo por tarefa/provedor.
        return PolicyDecision(
            permitido=True,
            provider_chain=[(p, None) for p in elegiveis],
            sanitizar_antes=sanitizar_antes,
            motivo="; ".join(motivos) or "cadeia padrão por prioridade",
            requer_hitl=requer_hitl,
            requer_fonte=exige_fonte,
            bloqueio_motivo=None,
        )
