"""Validação determinística de templates de contrato e procuração.

Nenhum template de admissão deve substituir o modelo institucional sem passar
por este módulo. A validação é estrutural e deliberadamente conservadora: ela
não declara validade jurídica; apenas impede omissões técnicas conhecidas.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import re


_ALLOWED_VARIABLES = {
    "cliente_nome", "cliente_cpf_cnpj", "cliente_endereco", "cliente_qualificacao",
    "numero_processo", "parte_contraria", "comarca", "vara", "valor_causa", "area",
    "data_hoje", "advogado_nome", "advogado_oab", "valor_honorarios",
    "percentual_exito", "forma_pagamento", "entrada", "numero_parcelas",
    "primeiro_vencimento", "data_documento", "escritorio_nome", "escritorio_cnpj",
    "escritorio_oab", "escritorio_endereco", "escritorio_cidade", "escritorio_estado",
    "escritorio_email", "escritorio_site", "escritorio_socio_titular", "tipo_poderes",
    "poderes_especiais", "referencia_oab",
}

_REQUIRED_ANCHORS = {
    "contrato": (
        ("CONTRATO", "título do instrumento"),
        ("CONTRATANTE", "qualificação do contratante"),
        ("HONORÁRIOS", "cláusula de honorários"),
        ("CLÁUSULA 1", "objeto"),
        ("________________", "bloco de assinatura"),
    ),
    "procuracao": (
        ("PROCURAÇÃO", "título do instrumento"),
        ("OUTORGANTE", "qualificação do outorgante"),
        ("OUTORGADO", "identificação do outorgado"),
        ("PODERES", "cláusula de poderes"),
        ("________________", "bloco de assinatura"),
    ),
}

_VAR_RE = re.compile(r"\{\{\s*([a-z_]+)\s*\}\}")
_UNRESOLVED_RE = re.compile(r"\[[a-z_][a-z0-9_]*\?\]", re.IGNORECASE)


@dataclass(frozen=True)
class TemplateValidationResult:
    valid: bool
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    variables: tuple[str, ...] = ()


def _tipo(tipo_peca: str) -> str:
    return (tipo_peca or "").strip().lower()


def validate_admission_template(
    tipo_peca: str, conteudo: str, *, strict: bool = True
) -> TemplateValidationResult:
    """Valida conteúdo bruto antes de ativar/cadastrar template de admissão."""
    tipo = _tipo(tipo_peca)
    texto = conteudo or ""
    errors: list[str] = []
    warnings: list[str] = []
    variables = tuple(sorted(set(_VAR_RE.findall(texto))))

    if tipo not in _REQUIRED_ANCHORS:
        return TemplateValidationResult(False, ("tipo de template não é de admissão",))
    if not texto.strip():
        return TemplateValidationResult(False, ("conteúdo do template não pode ser vazio",))

    desconhecidas = sorted(set(variables) - _ALLOWED_VARIABLES)
    if desconhecidas:
        errors.append("variáveis desconhecidas: " + ", ".join(desconhecidas))

    for anchor, descricao in _REQUIRED_ANCHORS[tipo]:
        if anchor not in texto.upper():
            errors.append(f"âncora obrigatória ausente: {descricao}")

    if "[?]" in texto or _UNRESOLVED_RE.search(texto):
        errors.append("template contém marcador de variável não resolvida")
    if "R$ [____]" in texto or "[__]%" in texto:
        warnings.append("template contém placeholder financeiro; exige preenchimento antes da assinatura")

    if not strict and errors:
        warnings.extend(errors)
        errors = []
    return TemplateValidationResult(not errors, tuple(errors), tuple(warnings), variables)


def validate_rendered_admission_document(
    tipo_peca: str, conteudo: str, context: dict
) -> TemplateValidationResult:
    """Valida o resultado renderizado e rejeita variáveis desconhecidas/ausentes."""
    base = validate_admission_template(tipo_peca, conteudo)
    errors = list(base.errors)
    texto = conteudo or ""
    if _VAR_RE.search(texto) or "[?]" in texto or _UNRESOLVED_RE.search(texto):
        errors.append("documento renderizado contém variável não resolvida")
    if not context:
        errors.append("contexto de renderização ausente")
    return TemplateValidationResult(
        not errors, tuple(dict.fromkeys(errors)), base.warnings, base.variables
    )
