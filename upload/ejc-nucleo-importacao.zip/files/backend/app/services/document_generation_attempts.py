from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.client import Client
from app.models.document_generation import DocumentGenerationAttempt, DocumentGenerationStatus
from app.models.user import User


def _safe_error(exc: Exception) -> tuple[str, str]:
    code = type(exc).__name__[:80]
    message = str(exc).replace("\n", " ").strip()[:480] or "falha não especificada"
    # Nunca persistir SQL completo, conteúdo documental ou traceback.
    for marker in ("SELECT ", "INSERT ", "UPDATE ", "CPF", "CNPJ"):
        if marker in message.upper():
            message = "falha interna na geração documental"
            break
    return code, message


async def criar_tentativa(
    db: AsyncSession, *, client_id: str, requested_by: str | None, max_attempts: int = 3
) -> DocumentGenerationAttempt:
    tentativa = DocumentGenerationAttempt(
        id=str(uuid4()), client_id=client_id, requested_by=requested_by,
        status=DocumentGenerationStatus.pendente, max_attempts=max_attempts,
    )
    db.add(tentativa)
    await db.commit()
    await db.refresh(tentativa)
    return tentativa


async def marcar_concluida(
    db: AsyncSession, tentativa_id: str, resultado: dict
) -> DocumentGenerationAttempt:
    tentativa = await db.get(DocumentGenerationAttempt, tentativa_id)
    if tentativa is None:
        raise HTTPException(status_code=404, detail="Tentativa de geração não encontrada")
    tentativa.status = DocumentGenerationStatus.concluida
    tentativa.attempt_count = (tentativa.attempt_count or 0) + 1
    tentativa.kit_id = resultado.get("kit_id")
    tentativa.kit_version = resultado.get("kit_version")
    ids = [resultado.get("procuracao", {}).get("legal_doc_id"), resultado.get("contrato", {}).get("legal_doc_id")]
    tentativa.legal_doc_ids = json.dumps([item for item in ids if item])
    tentativa.completed_at = datetime.now(timezone.utc)
    tentativa.next_retry_at = None
    await db.commit()
    await db.refresh(tentativa)
    return tentativa


async def marcar_falha(
    db: AsyncSession, tentativa_id: str, exc: Exception
) -> DocumentGenerationAttempt:
    tentativa = await db.get(DocumentGenerationAttempt, tentativa_id)
    if tentativa is None:
        raise HTTPException(status_code=404, detail="Tentativa de geração não encontrada")
    code, message = _safe_error(exc)
    tentativa.status = DocumentGenerationStatus.falhou
    tentativa.attempt_count = (tentativa.attempt_count or 0) + 1
    tentativa.last_error_code = code
    tentativa.last_error_message = message
    tentativa.next_retry_at = (
        datetime.now(timezone.utc) + timedelta(minutes=5 * tentativa.attempt_count)
        if tentativa.attempt_count < tentativa.max_attempts else None
    )
    await db.commit()
    await db.refresh(tentativa)
    return tentativa


async def retry_generation_attempt(
    db: AsyncSession, *, attempt_id: str, cu: User
) -> dict:
    tentativa = (await db.execute(select(DocumentGenerationAttempt).where(
        DocumentGenerationAttempt.id == attempt_id,
    ))).scalar_one_or_none()
    if tentativa is None:
        raise HTTPException(status_code=404, detail="Tentativa de geração não encontrada")
    if tentativa.status == DocumentGenerationStatus.concluida:
        return {"status": tentativa.status.value, "attempt_id": tentativa.id, "kit_id": tentativa.kit_id, "kit_version": tentativa.kit_version}
    if tentativa.attempt_count >= tentativa.max_attempts:
        raise HTTPException(status_code=409, detail="Limite de tentativas de geração atingido")

    client = await db.get(Client, tentativa.client_id)
    if client is None or client.deleted_at is not None:
        raise HTTPException(status_code=404, detail="Cliente não encontrado")
    from app.routers.clients import _pode_ver_cliente
    if not await _pode_ver_cliente(cu, client, db):
        raise HTTPException(status_code=404, detail="Cliente não encontrado")
    from app.services.geracao_documental_cliente import gerar_documentos_cliente

    tentativa.status = DocumentGenerationStatus.processando
    await db.commit()
    try:
        resultado = await gerar_documentos_cliente(db, client, cu)
    except Exception as exc:
        await db.rollback()
        await marcar_falha(db, tentativa.id, exc)
        raise HTTPException(status_code=409, detail="Geração documental falhou; tentativa registrada para novo processamento") from exc
    await marcar_concluida(db, tentativa.id, resultado)
    return {"status": "concluida", "attempt_id": tentativa.id, **resultado}
