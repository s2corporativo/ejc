# ── app/services/ingestors/stj.py ────────────────────────────────────────────
# Ingestor de jurisprudência do STJ via Portal de Dados Abertos (CKAN).
# Fonte oficial e gratuita de TEXTO de jurisprudência superior (a lacuna que o
# DataJud não cobre). Usa os "espelhos de acórdãos" — arquivos JSON mensais por
# órgão julgador, com EMENTA, tese jurídica, relator e referências legislativas.
#
# Estratégia: por execução, ingere o arquivo MENSAL MAIS RECENTE de cada órgão.
# Dedup por numeroRegistro evita reingestão. Conteúdo embebido = ementa + tese
# + dispositivos citados (partes juridicamente citáveis), NÃO o inteiro teor da
# decisão (volumoso e de baixo ganho semântico).
from __future__ import annotations

import logging

from sqlalchemy.ext.asyncio import AsyncSession

from app.services.ingestion_service import fetch, upsert_documento
# Mesmo inferidor de área usado pelo TJMG (ingestors/tjmg.py): um
# vocabulário de áreas só, para a matriz de cobertura não ver duas
# taxonomias diferentes conforme o tribunal de origem.
from app.services.jurisprudencia_externa import _inferir_area

logger = logging.getLogger("ejc.ingestao.stj")

CKAN = "https://dadosabertos.web.stj.jus.br/api/3/action"

# Órgãos julgadores (datasets CKAN). Corte Especial + 3 Seções + 6 Turmas.
ORGAOS = [
    "espelhos-de-acordaos-corte-especial",
    "espelhos-de-acordaos-primeira-secao",
    "espelhos-de-acordaos-segunda-secao",
    "espelhos-de-acordaos-terceira-secao",
    "espelhos-de-acordaos-primeira-turma",
    "espelhos-de-acordaos-segunda-turma",
    "espelhos-de-acordaos-terceira-turma",
    "espelhos-de-acordaos-quarta-turma",
    "espelhos-de-acordaos-quinta-turma",
    "espelhos-de-acordaos-sexta-turma",
]

MAX_POR_ORGAO = 800   # teto de acórdãos por órgão/execução (controle de volume)


def _txt(rec: dict, *chaves: str) -> str:
    """Primeiro valor não vazio entre `chaves` (degrada para "" se nenhum existir).

    O espelho do CKAN não garante campo algum: o ingestor nunca pode quebrar
    por chave ausente nem gravar a string "None" no corpo do documento.
    """
    for c in chaves:
        v = rec.get(c)
        if v is None:
            continue
        s = str(v).strip()
        if s and s.lower() not in ("none", "null"):
            return s
    return ""


def _monta_conteudo(rec: dict) -> str:
    """Concatena as partes juridicamente citáveis de um acórdão.

    A IDENTIFICAÇÃO do julgado (nº do processo, nº de registro e data de
    julgamento) abre o conteúdo — e isso não é cosmético:

    1. Sem ela, acórdãos julgados em bloco (mesma classe, relator, órgão e data,
       com a ementa idêntica que o STJ publica em repetitivos) geram texto byte
       a byte igual → mesmo SHA-1 em `hash_conteudo` → falso duplicado no painel
       de governança.
    2. Pior: o trecho recuperado pelo RAG chegava à IA sem o próprio número do
       processo — a ementa e a tese sem identificação verificável são a condição
       clássica da citação inventada, exatamente o que o gate antialucinação
       existe para barrar.

    Campo ausente é omitido; nenhum campo é obrigatório.
    """
    partes = []
    sigla = _txt(rec, "siglaClasse")
    processo = _txt(rec, "numeroProcesso", "numeroUnicoProcesso")
    if processo:
        partes.append(f"Processo: {(sigla + ' ' + processo).strip()}")
    registro = _txt(rec, "numeroRegistro")
    if registro:
        partes.append(f"Registro: {registro}")
    julgamento = _txt(rec, "dataJulgamento", "dataDecisao")
    if julgamento:
        partes.append(f"Julgamento: {julgamento}")
    classe = _txt(rec, "descricaoClasse", "siglaClasse")
    if classe:
        partes.append(f"Classe: {classe}")
    if rec.get("ministroRelator"):
        partes.append(f"Relator: Min. {rec['ministroRelator']}")
    if rec.get("nomeOrgaoJulgador"):
        partes.append(f"Órgão: {rec['nomeOrgaoJulgador']}")
    if rec.get("dataPublicacao"):
        partes.append(f"Publicação: {rec['dataPublicacao']}")
    if rec.get("ementa"):
        partes.append(f"\nEMENTA:\n{rec['ementa']}")
    if rec.get("teseJuridica"):
        partes.append(f"\nTESE JURÍDICA:\n{rec['teseJuridica']}")
    if rec.get("tema"):
        partes.append(f"\nTema: {rec['tema']}")
    refs = rec.get("referenciasLegislativas")
    if refs and isinstance(refs, list):
        txt = "; ".join(str(x) for x in refs if x)
        if txt:
            partes.append(f"\nReferências legislativas: {txt}")
    return "\n".join(partes)


async def _ultimo_json(orgao: str) -> dict | None:
    """Localiza o recurso JSON mais recente (por nome AAAAMMDD.json) do órgão."""
    r = await fetch(f"{CKAN}/package_show", params={"id": orgao}, timeout=30)
    recursos = r.json().get("result", {}).get("resources", [])
    jsons = [x for x in recursos if (x.get("format") or "").upper() == "JSON"]
    if not jsons:
        return None
    # nomes no padrão AAAAMMDD.json → ordena lexicograficamente = cronológico
    jsons.sort(key=lambda x: x.get("name", ""))
    return jsons[-1]


async def ingerir(db: AsyncSession) -> tuple[int, int]:
    """Ingere o lote mensal mais recente de cada órgão. Retorna (novos, total)."""
    novos = total = 0
    # Falhas por órgão, contadas para que "todos falharam" não se disfarce de
    # "não havia acórdão novo". Sem isto, uma mudança de contrato ou uma queda
    # do portal devolvia (0, 0) — indistinguível de execução sadia e vazia.
    falhas: list[str] = []
    contratos_invalidos = 0
    for orgao in ORGAOS:
        try:
            rec_json = await _ultimo_json(orgao)
            if not rec_json:
                continue
            r = await fetch(rec_json["url"], timeout=60)
            dados = r.json()
            if not isinstance(dados, list):
                # Contrato quebrado (a fonte deixou de devolver lista) é FALHA,
                # não "órgão sem acórdãos": pular em silêncio foi como o LexML
                # e o DOU passaram meses entregando zero.
                contratos_invalidos += 1
                logger.warning("STJ %s: resposta não é lista (contrato mudou)", orgao)
                continue
            sigla = orgao.replace("espelhos-de-acordaos-", "")
            n_orgao = 0
            for rec in dados[:MAX_POR_ORGAO]:
                if not rec.get("ementa"):
                    continue   # sem ementa não há valor semântico
                chave = f"stj:{rec.get('numeroRegistro') or rec.get('id')}"
                titulo = (
                    f"STJ {rec.get('siglaClasse','')} "
                    f"{rec.get('numeroProcesso','')} — {sigla}"
                ).strip()
                conteudo = _monta_conteudo(rec)
                total += 1
                res = await upsert_documento(
                    db, titulo=titulo[:500], categoria="jurisprudencia",
                    conteudo=conteudo, chave_origem=chave,
                    fonte="STJ — Dados Abertos (espelhos de acórdãos)",
                    tribunal="STJ",
                    extra={
                        "orgao": rec.get("nomeOrgaoJulgador"),
                        "relator": rec.get("ministroRelator"),
                        "classe": rec.get("siglaClasse"),
                        "data_decisao": rec.get("dataDecisao"),
                        # Sem esta chave, `detectar_area` cai no match textual
                        # sobre título/categoria e todo acórdão do STJ termina
                        # em "Geral" na matriz de cobertura — a "lacuna de área"
                        # da auditoria era rótulo faltando, não conteúdo. Mesmo
                        # inferidor do TJMG: um vocabulário de áreas só.
                        "area_juridica": _inferir_area(f"{titulo}\n{conteudo}") or None,
                        "rag_status": "aprovado",
                        "tipo_fonte": "jurisprudencia_oficial",
                    },
                    confianca="alta",   # fonte oficial (STJ Dados Abertos)
                )
                if res in ("novo", "atualizado"):
                    novos += 1
                    n_orgao += 1
                # commit em lotes de 50 (não segura tudo em memória)
                if total % 50 == 0:
                    await db.commit()
            await db.commit()
            logger.info(f"STJ {sigla}: {n_orgao} novos")
        except Exception as e:
            await db.rollback()
            falhas.append(f"{orgao}:{type(e).__name__}")
            logger.warning(f"STJ {orgao}: {type(e).__name__}: {e}")

    if ORGAOS and (len(falhas) + contratos_invalidos) == len(ORGAOS):
        raise RuntimeError(
            f"STJ: todos os {len(ORGAOS)} órgãos falharam "
            f"({len(falhas)} por erro, {contratos_invalidos} por contrato "
            "inválido). Nenhuma ingestão foi executada."
        )
    return novos, total
