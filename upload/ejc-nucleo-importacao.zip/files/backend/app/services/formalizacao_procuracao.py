from __future__ import annotations

from datetime import date, datetime, timezone
from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.audit_log import criar_audit_log
from app.models.client import Client
from app.models.document import Document
from app.models.legal_doc import LegalDoc, PecaStatus, PecaTipo
from app.models.procuracao import Procuracao
from app.models.signature import SignatureRequest, SignatureStatus
from app.models.user import User


_STATUS_APTO = {PecaStatus.aprovada, PecaStatus.final}


async def formalizar_procuracao(
    db: AsyncSession,
    *,
    legal_doc_id: str,
    signed_document_id: str,
    cu: User,
) -> Procuracao:
    """Converte uma minuta revisada e assinada em mandato formal idempotente."""
    doc = (await db.execute(select(LegalDoc).where(
        LegalDoc.id == legal_doc_id,
        LegalDoc.deleted_at.is_(None),
        LegalDoc.tipo_peca == PecaTipo.procuracao,
        LegalDoc.client_id.is_not(None),
        LegalDoc.client_admission_kind == "procuracao_ad_judicia",
        LegalDoc.is_current.is_(True),
    ))).scalar_one_or_none()
    if doc is None:
        raise HTTPException(status_code=404, detail="Procuração revisada não encontrada")
    if not doc.human_reviewed or doc.status not in _STATUS_APTO:
        raise HTTPException(status_code=409, detail="A procuração precisa estar revisada e aprovada antes da formalização")

    cli = await db.get(Client, doc.client_id)
    signed = (await db.execute(select(Document).where(
        Document.id == signed_document_id,
        Document.deleted_at.is_(None),
        Document.client_id == doc.client_id,
    ))).scalar_one_or_none()
    if cli is None or signed is None:
        raise HTTPException(status_code=404, detail="Documento assinado ou cliente não encontrado")

    assinatura = (await db.execute(select(SignatureRequest).where(
        SignatureRequest.document_id == signed.id,
        SignatureRequest.client_id == doc.client_id,
        SignatureRequest.status == SignatureStatus.assinado,
        SignatureRequest.deleted_at.is_(None),
    ).order_by(SignatureRequest.assinado_em.desc().nullslast()))).scalars().first()
    if assinatura is None:
        raise HTTPException(status_code=409, detail="Não há assinatura registrada para o documento informado")
    if signed.sha256 and assinatura.hash_sha256 != signed.sha256:
        raise HTTPException(status_code=409, detail="A assinatura não corresponde ao hash do documento assinado")

    existente = (await db.execute(select(Procuracao).where(
        Procuracao.source_legal_doc_id == doc.id,
        Procuracao.deleted_at.is_(None),
    ))).scalar_one_or_none()
    if existente is not None:
        return existente

    # Os poderes são inferidos apenas de metadados controlados do documento.
    # A formalização não aceita poderes livres no payload de rota.
    tipo_poderes = "ad_judicia_et_extra" if "ET EXTRA" in (doc.conteudo or "").upper() else "ad_judicia"
    permite_substabelecimento = "SUBSTABELECER" in (doc.conteudo or "").upper()
    procuracao = Procuracao(
        id=str(uuid4()),
        client_id=doc.client_id,
        tipo_poderes=tipo_poderes,
        poderes_especiais=None,
        permite_substabelecimento=permite_substabelecimento,
        data_outorga=assinatura.assinado_em.date() if assinatura.assinado_em else date.today(),
        document_id=signed.id,
        signed_document_id=signed.id,
        source_legal_doc_id=doc.id,
        formalizada_em=datetime.now(timezone.utc),
        formalizada_por=cu.id,
        observacoes="Formalizada a partir de LegalDoc revisado e documento assinado; revisão humana registrada.",
    )
    db.add(procuracao)
    await criar_audit_log(
        db, cu.id, getattr(cu.role, "value", str(cu.role)),
        "FORMALIZAR_PROCURACAO", "procuracoes", procuracao.id,
        detalhes=f"source_legal_doc_id={doc.id}; signed_document_id={signed.id}",
    )
    await db.commit()
    await db.refresh(procuracao)
    return procuracao
