"""Hardening do ciclo documental de contratos e procurações.

Revision ID: 171_documental_hardening
Revises: 170_djen_remove_unicidade_global
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "171_documental_hardening"
down_revision = "170_djen_remove_unicidade_global"
branch_labels = None
depends_on = None

deployment_policy = "human_reviewed_additive"


def upgrade() -> None:
    op.add_column("legal_docs", sa.Column("kit_id", sa.String(36), nullable=True))
    op.add_column("legal_docs", sa.Column("kit_version", sa.Integer(), nullable=True))
    op.add_column("legal_docs", sa.Column("is_current", sa.Boolean(), nullable=True))
    op.add_column("legal_docs", sa.Column("superseded_by_id", sa.String(36), nullable=True))
    op.create_index("ix_legal_docs_kit_id", "legal_docs", ["kit_id"])
    op.create_index("ix_legal_docs_is_current", "legal_docs", ["is_current"])
    op.create_foreign_key(
        "fk_legal_docs_superseded_by_id", "legal_docs", "legal_docs",
        ["superseded_by_id"], ["id"], ondelete="SET NULL",
    )
    op.create_index(
        "uq_legal_docs_current_admission_kind",
        "legal_docs",
        ["client_id", "client_admission_kind"],
        unique=True,
        postgresql_where=sa.text(
            "deleted_at IS NULL AND is_current = true AND client_id IS NOT NULL "
            "AND client_admission_kind IS NOT NULL"
        ),
    )

    op.add_column("procuracoes", sa.Column("source_legal_doc_id", sa.String(36), nullable=True))
    op.add_column("procuracoes", sa.Column("signed_document_id", sa.String(36), nullable=True))
    op.add_column("procuracoes", sa.Column("formalizada_em", sa.DateTime(timezone=True), nullable=True))
    op.add_column("procuracoes", sa.Column("formalizada_por", sa.String(36), nullable=True))
    op.create_index("ix_procuracoes_source_legal_doc_id", "procuracoes", ["source_legal_doc_id"])
    op.create_index("ix_procuracoes_signed_document_id", "procuracoes", ["signed_document_id"])
    op.create_foreign_key("fk_procuracoes_source_legal_doc", "procuracoes", "legal_docs", ["source_legal_doc_id"], ["id"], ondelete="SET NULL")
    op.create_foreign_key("fk_procuracoes_signed_document", "procuracoes", "documents", ["signed_document_id"], ["id"], ondelete="SET NULL")
    op.create_foreign_key("fk_procuracoes_formalizada_por", "procuracoes", "users", ["formalizada_por"], ["id"], ondelete="SET NULL")

    status_enum = postgresql.ENUM("pendente", "processando", "concluida", "falhou", name="documentgenerationstatus")
    status_enum.create(op.get_bind(), checkfirst=True)
    op.create_table(
        "document_generation_attempts",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("client_id", sa.String(36), sa.ForeignKey("clients.id", ondelete="CASCADE"), nullable=False),
        sa.Column("requested_by", sa.String(36), sa.ForeignKey("users.id", ondelete="SET NULL"), nullable=True),
        sa.Column("status", status_enum, nullable=False),
        sa.Column("attempt_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("max_attempts", sa.Integer(), nullable=False, server_default="3"),
        sa.Column("last_error_code", sa.String(80), nullable=True),
        sa.Column("last_error_message", sa.String(500), nullable=True),
        sa.Column("kit_id", sa.String(36), nullable=True),
        sa.Column("kit_version", sa.Integer(), nullable=True),
        sa.Column("legal_doc_ids", sa.Text(), nullable=True),
        sa.Column("next_retry_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_document_generation_attempts_client_id", "document_generation_attempts", ["client_id"])
    op.create_index("ix_document_generation_attempts_status", "document_generation_attempts", ["status"])
    op.create_index("ix_document_generation_attempts_kit_id", "document_generation_attempts", ["kit_id"])
    op.create_index("ix_document_generation_attempts_next_retry_at", "document_generation_attempts", ["next_retry_at"])


def downgrade() -> None:
    op.drop_index("ix_document_generation_attempts_next_retry_at", table_name="document_generation_attempts")
    op.drop_index("ix_document_generation_attempts_kit_id", table_name="document_generation_attempts")
    op.drop_index("ix_document_generation_attempts_status", table_name="document_generation_attempts")
    op.drop_index("ix_document_generation_attempts_client_id", table_name="document_generation_attempts")
    op.drop_table("document_generation_attempts")
    postgresql.ENUM(name="documentgenerationstatus").drop(op.get_bind(), checkfirst=True)

    op.drop_constraint("fk_procuracoes_formalizada_por", "procuracoes", type_="foreignkey")
    op.drop_constraint("fk_procuracoes_signed_document", "procuracoes", type_="foreignkey")
    op.drop_constraint("fk_procuracoes_source_legal_doc", "procuracoes", type_="foreignkey")
    op.drop_index("ix_procuracoes_signed_document_id", table_name="procuracoes")
    op.drop_index("ix_procuracoes_source_legal_doc_id", table_name="procuracoes")
    op.drop_column("procuracoes", "formalizada_por")
    op.drop_column("procuracoes", "formalizada_em")
    op.drop_column("procuracoes", "signed_document_id")
    op.drop_column("procuracoes", "source_legal_doc_id")

    op.drop_index("uq_legal_docs_current_admission_kind", table_name="legal_docs")
    op.drop_constraint("fk_legal_docs_superseded_by_id", "legal_docs", type_="foreignkey")
    op.drop_index("ix_legal_docs_is_current", table_name="legal_docs")
    op.drop_index("ix_legal_docs_kit_id", table_name="legal_docs")
    op.drop_column("legal_docs", "superseded_by_id")
    op.drop_column("legal_docs", "is_current")
    op.drop_column("legal_docs", "kit_version")
    op.drop_column("legal_docs", "kit_id")
