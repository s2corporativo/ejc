#!/usr/bin/env bash
set -euo pipefail

TARGET=""
DRY_RUN=0
while [ "$#" -gt 0 ]; do
  case "$1" in
    --target) TARGET="${2:?Informe o diretório do EJC após --target}"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help)
      echo "Uso: $0 --target /caminho/ejc [--dry-run]"; exit 0 ;;
    *) echo "Argumento desconhecido: $1" >&2; exit 2 ;;
  esac
done

[ -n "$TARGET" ] || { echo "Informe --target /caminho/para/ejc" >&2; exit 2; }
[ -d "$TARGET/backend/app" ] || { echo "Target não parece ser a raiz do EJC: $TARGET" >&2; exit 3; }

PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
MANIFEST="$PKG_DIR/MANIFEST.txt"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$TARGET/.ejc-nucleo-backup-$STAMP"

while IFS= read -r rel || [ -n "$rel" ]; do
  [ -z "$rel" ] && continue
  case "$rel" in \#*) continue ;; esac
  src="$PKG_DIR/files/$rel"
  dst="$TARGET/$rel"
  [ -f "$src" ] || { echo "Arquivo ausente no pacote: $rel" >&2; exit 4; }
  if [ "$DRY_RUN" -eq 1 ]; then
    if [ -e "$dst" ]; then echo "BACKUP+COPY $rel"; else echo "COPY $rel"; fi
  else
    if [ -e "$dst" ]; then
      mkdir -p "$BACKUP/$(dirname "$rel")"
      cp -a "$dst" "$BACKUP/$rel"
    fi
    mkdir -p "$(dirname "$dst")"
    cp -a "$src" "$dst"
  fi
done < "$MANIFEST"

if [ "$DRY_RUN" -eq 1 ]; then
  echo "DRY-RUN concluído; nenhum arquivo foi alterado."
else
  printf '%s\n' "$STAMP" > "$TARGET/.ejc-nucleo-last-install"
  echo "Instalação concluída. Backup: $BACKUP"
  echo "Próximo passo: revisar .env e executar a migration apenas no PostgreSQL de staging isolado."
fi
