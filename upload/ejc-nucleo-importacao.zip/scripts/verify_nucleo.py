#!/usr/bin/env python3
from __future__ import annotations

import ast
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
manifest = ROOT / "MANIFEST.txt"
errors: list[str] = []

for raw in manifest.read_text(encoding="utf-8").splitlines():
    rel = raw.strip()
    if not rel or rel.startswith("#"):
        continue
    path = ROOT / "files" / rel
    if not path.is_file():
        errors.append(f"arquivo ausente: {rel}")
        continue
    if path.suffix == ".py":
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except SyntaxError as exc:
            errors.append(f"sintaxe inválida em {rel}: {exc}")

for path in (ROOT / "files").rglob("*"):
    if path.is_file() and path.suffix in {".py", ".md", ".txt", ".sh"}:
        text = path.read_text(encoding="utf-8", errors="ignore").lower()
        if "mongodb+srv" in text or "mongodb atlas" in text:
            errors.append(f"referência proibida a Atlas/MongoDB em pacote: {path.relative_to(ROOT)}")

if errors:
    print("VERIFICAÇÃO REPROVADA")
    print("\n".join(f"- {e}" for e in errors))
    sys.exit(1)

count = sum(1 for line in manifest.read_text(encoding="utf-8").splitlines() if line.strip() and not line.lstrip().startswith("#"))
print(f"VERIFICAÇÃO OK: {count} arquivos no manifesto; Python parseado; isolamento Atlas preservado")
