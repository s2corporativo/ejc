# Núcleo de Inteligência, RAG e Hardening Documental do EJC

Pacote de importação para o repositório EJC (`s2corporativo/ejc`).

## O que este pacote contém

- Orquestração de IA, catálogo de agentes, classificação de intenção e política HITL;
- sanitização e pseudonimização de PII;
- proteção contra prompt injection em documentos, OCR e contexto RAG;
- reranking, grounding, citações e validação de respostas;
- governança e ingestors de fontes oficiais: Planalto, STJ, TJMG, LexML, Senado, Câmara e DJEN;
- modelos e rotas de IA/RAG;
- hardening documental de contratos e procurações;
- validação obrigatória de templates;
- versionamento único de kit documental;
- formalização da procuração somente a partir de documento revisado/assinado;
- pendências persistidas e reprocessáveis para falhas de geração;
- migration `171_documental_hardening`;
- testes focados e scripts de ingestão/avaliação.

## Isolamento em relação ao Atlas

Este pacote **não usa MongoDB Atlas**, não contém credencial de Atlas e não altera variáveis de ambiente. O EJC continua usando exclusivamente a infraestrutura PostgreSQL/pgvector já definida pelo próprio EJC.

Não configurar `DATABASE_URL` com uma URI MongoDB/Atlas. O pacote não deve ser instalado apontando para produção sem backup e homologação prévia.

## Instalação segura

1. Extraia o ZIP.
2. Entre na raiz do repositório EJC.
3. Execute primeiro em modo simulação:

```bash
bash /caminho/ejc-nucleo-importacao/install.sh --target /caminho/para/ejc --dry-run
```

4. Faça uma cópia/commit do repositório e instale:

```bash
bash /caminho/ejc-nucleo-importacao/install.sh --target /caminho/para/ejc
```

O instalador cria backup dos arquivos substituídos em `.ejc-nucleo-backup-<timestamp>`.

## Dependências

Os pins mínimos estão em `backend/requirements-nucleo.txt`. O projeto deve instalar também o `backend/requirements.txt` original; este arquivo é apenas um complemento verificável.

```bash
python -m pip install -r backend/requirements.txt
python -m pip install -r backend/requirements-nucleo.txt
```

## Migration

A migration deve ser executada somente no PostgreSQL de homologação primeiro:

```bash
cd backend
alembic upgrade head
```

Antes de executar, confirme que `DATABASE_URL` aponta para PostgreSQL de staging isolado. Não usar banco do Atlas nem produção.

## Verificação local

```bash
bash install.sh --target /caminho/para/ejc --dry-run
python scripts/verify_nucleo.py
cd backend
python -m compileall -q app scripts
pytest -q tests/test_documental_hardening.py
```

## Limites

Este pacote não fornece automaticamente:

- credenciais de provedor de IA;
- banco PostgreSQL de staging;
- dados pessoais de clientes;
- corpus jurídico já carregado no banco;
- aprovação jurídica de qualquer minuta;
- garantia de acurácia processual.

A saída jurídica permanece rascunho e exige revisão humana antes de protocolo ou uso oficial.
