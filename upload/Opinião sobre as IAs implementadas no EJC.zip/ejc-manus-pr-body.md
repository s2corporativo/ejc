## Issue vinculada
Closes #1797

## Solução
Integração Manus API v2 para análises jurídicas assíncronas no EJC, com:

- Cliente HTTP para `task.create` e `task.listMessages`.
- Rotas autenticadas `POST /api/manus/analises` e `GET /api/manus/analises/{task_id}`.
- Webhook `POST /api/manus/webhook` com assinatura RSA-SHA256 e janela anti-replay.
- Sanitização e pseudonimização local antes do envio externo.
- Structured output obrigatório e revisão humana.
- Persistência auditável em `manus_tasks` via migration `162_manus_tasks`.
- Feature flag `MANUS_API_ENABLED=false` por padrão.

## Testes executados
- `4 passed` em `backend/tests/test_manus_integration.py`.
- `33 passed` nos gates de Alembic e governança de migrations.
- `alembic heads` confirmou `162_manus_tasks` como único head.
- `compileall` e `git diff --check` aprovados.

## Riscos residuais
- A aplicação da migration em PostgreSQL real ainda depende do ambiente de homologação.
- A chave Manus e o webhook HTTPS ainda precisam ser configurados pela operação.
- Transferência internacional, retenção e DPA devem ser homologados antes de dados reais.
- A integração não deve ser habilitada para casos com sigilo reforçado.
- O gate completo do security-auditor ainda exige evidência autenticada do ambiente CI.

## Rollback
- Manter ou restaurar `MANUS_API_ENABLED=false` interrompe novas chamadas externas.
- Remover `MANUS_API_KEY` impede novas criações.
- Reverter a migration `162_manus_tasks` somente após decisão de preservação do histórico.
- O caminho síncrono atual de IA não é alterado.
