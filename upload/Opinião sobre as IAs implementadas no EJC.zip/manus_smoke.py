import base64
import hashlib
import time
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from app.core.config import Settings
from app.services.manus_client import verify_manus_webhook

s = Settings()
assert s.MANUS_API_ENABLED is False
key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
public = key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode()
body = b'{"event_type":"task_created"}'
url = 'https://ejc.example/api/manus/webhook'
ts = int(time.time())
signed = f'{ts}.{url}.{hashlib.sha256(body).hexdigest()}'.encode()
sig = base64.b64encode(key.sign(signed, padding.PKCS1v15(), hashes.SHA256())).decode()
assert verify_manus_webhook(public_key_pem=public, url=url, body=body, signature_b64=sig, timestamp=str(ts), now=ts)
assert not verify_manus_webhook(public_key_pem=public, url=url, body=b'{}', signature_b64=sig, timestamp=str(ts), now=ts)
print('manus_smoke=ok')
