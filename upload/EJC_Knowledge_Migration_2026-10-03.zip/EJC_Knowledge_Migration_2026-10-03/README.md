# EJC Knowledge Migration Bundle

Pacote de migração segura da base de conhecimento do EJC atual para o novo EJC.

## Estado deste pacote

Fonte de código auditada: `s2corporativo/ejc`, branch `main`
Commit de referência: `4c03f861d08e4175af888ea710983c672846459c`

Este ZIP contém:

1. contrato de dados para o novo Knowledge Core;
2. exportador para extrair a base **viva** do PostgreSQL do EJC atual;
3. validador de integridade;
4. importador para o schema novo;
5. schema SQL de referência;
6. manifesto de fontes/versionamento;
7. inventário dos ativos de conhecimento confirmados no repositório;
8. materiais estratégicos do projeto marcados como **não autoritativos** e
   **não ingeridos automaticamente**.

### Limitação objetiva desta geração

Nesta sessão não havia acesso ao PostgreSQL/VPS de produção. Portanto,
`data/raw/*.jsonl` não contém os registros vivos de `knowledge_docs`,
`knowledge_chunks`, `fontes_ingestao` e `teses`.

Para completar o pacote no ambiente autorizado, copie `scripts/export_ejc_knowledge.py`
para o backend atual (ou monte este diretório no container) e execute:

```bash
umask 077
python scripts/export_ejc_knowledge.py \
  --output /tmp/ejc-knowledge-export \
  --scope all

python scripts/validate_bundle.py /tmp/ejc-knowledge-export
```

O exportador **não inclui embeddings por padrão**. Isso é intencional:
vetores são derivados e devem ser regenerados no EJC novo usando o modelo
de embeddings escolhido. O conteúdo textual, a proveniência, a curadoria,
o escopo e o histórico são preservados.

## Política de segurança/LGPD

- O modo `--scope all` pode conter dados de cliente/caso.
- Execute somente na VPS/ambiente autorizado.
- O exportador cria arquivos com permissão restritiva e não imprime conteúdo.
- Não envie o pacote bruto por e-mail ou canal público.
- O importador preserva `client_id` e `case_id`; não transforma material
  restrito em base global.
- Materiais fictícios/didáticos mantêm o marcador `ficticio=true`.
- Material sem aprovação/curadoria não é promovido silenciosamente.

## Fluxo recomendado

EJC atual -> export JSONL -> validação/hash -> cópia segura -> EJC novo
-> importação transacional -> reindexação -> embeddings novos
-> teste de isolamento -> homologação -> antigo fica somente leitura.
