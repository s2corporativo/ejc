#!/usr/bin/env python3
"""Exporta o patrimônio de conhecimento do EJC atual sem expor segredos.

Executar DENTRO do ambiente autorizado do backend atual.

Exemplos:
  python export_ejc_knowledge.py --output /tmp/ejc-knowledge-export --scope all
  python export_ejc_knowledge.py --output /tmp/ejc-knowledge-public --scope public

Por padrão, embeddings NÃO são exportados. Eles são derivados e devem ser
regenerados no EJC novo.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path
from datetime import datetime, timezone

from sqlalchemy import text
from app.core.database import AsyncSessionLocal

TABLES = {
    "knowledge_docs": {"required": True},
    "knowledge_chunks": {"required": True},
    "fontes_ingestao": {"required": True},
    "teses": {"required": False},
    "tese_caso_links": {"required": False},
}

def _json_default(value):
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)

def _dump_line(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=_json_default)

async def _table_exists(db, table_name: str) -> bool:
    q = text("""
      SELECT EXISTS (
        SELECT 1 FROM information_schema.tables
        WHERE table_schema='public' AND table_name=:name
      )
    """)
    return bool((await db.execute(q, {"name": table_name})).scalar())

async def _export_query(db, query: str, path: Path) -> int:
    count = 0
    result = await db.stream(text(query))
    with path.open("w", encoding="utf-8") as f:
        async for row in result:
            payload = row[0]
            f.write(_dump_line(payload) + "\n")
            count += 1
    return count

def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

async def run(output: Path, scope: str):
    os.umask(0o077)
    output.mkdir(parents=True, exist_ok=True)
    raw = output / "data" / "raw"
    raw.mkdir(parents=True, exist_ok=True)

    manifest = {
        "bundle_schema_version": 1,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": scope,
        "embeddings_included": False,
        "tables": {},
        "warnings": [
            "Pode conter sigilo profissional/dados pessoais quando scope=all.",
            "Transferir somente por canal seguro.",
            "Embeddings omitidos; regenerar no destino."
        ],
    }

    async with AsyncSessionLocal() as db:
        # Documentos: preserva todas as versões e soft-deletes.
        where_docs = ""
        if scope == "public":
            where_docs = " WHERE client_id IS NULL AND case_id IS NULL AND base_rag::text='publica' "
        docs_q = f"SELECT to_jsonb(t) FROM knowledge_docs t {where_docs} ORDER BY created_at NULLS FIRST, id"
        p = raw / "knowledge_docs.jsonl"
        manifest["tables"]["knowledge_docs"] = {
            "rows": await _export_query(db, docs_q, p),
            "sha256": _sha256(p),
        }

        # Chunks: NÃO exporta embedding. Mantém texto + página + id/doc_id.
        if scope == "public":
            chunks_q = """
              SELECT to_jsonb(k) - 'embedding'
              FROM knowledge_chunks k
              JOIN knowledge_docs d ON d.id=k.doc_id
              WHERE d.client_id IS NULL AND d.case_id IS NULL AND d.base_rag::text='publica'
              ORDER BY k.doc_id, k.chunk_index
            """
        else:
            chunks_q = """
              SELECT to_jsonb(k) - 'embedding'
              FROM knowledge_chunks k
              ORDER BY k.doc_id, k.chunk_index
            """
        p = raw / "knowledge_chunks.jsonl"
        manifest["tables"]["knowledge_chunks"] = {
            "rows": await _export_query(db, chunks_q, p),
            "sha256": _sha256(p),
        }

        # Fontes/telemetria de ingestão.
        p = raw / "fontes_ingestao.jsonl"
        manifest["tables"]["fontes_ingestao"] = {
            "rows": await _export_query(db, "SELECT to_jsonb(t) FROM fontes_ingestao t ORDER BY slug", p),
            "sha256": _sha256(p),
        }

        # Teses são patrimônio institucional; no modo public não são exportadas.
        for table_name in ("teses", "tese_caso_links"):
            if not await _table_exists(db, table_name):
                manifest["tables"][table_name] = {"present": False, "rows": 0}
                continue
            if scope == "public":
                manifest["tables"][table_name] = {"present": True, "rows": 0, "omitted_by_scope": True}
                continue
            p = raw / f"{table_name}.jsonl"
            q = f"SELECT to_jsonb(t) FROM {table_name} t ORDER BY id"
            manifest["tables"][table_name] = {
                "present": True,
                "rows": await _export_query(db, q, p),
                "sha256": _sha256(p),
            }

    (output / "manifests").mkdir(exist_ok=True)
    (output / "manifests" / "live_export_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({
        "ok": True,
        "output": str(output),
        "tables": {k: v.get("rows", 0) for k, v in manifest["tables"].items()}
    }, ensure_ascii=False))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", required=True)
    ap.add_argument("--scope", choices=("public", "all"), default="all")
    args = ap.parse_args()
    asyncio.run(run(Path(args.output), args.scope))
