#!/usr/bin/env python3
from __future__ import annotations
import sys, json, hashlib
from pathlib import Path

def sha256(p: Path):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def count_jsonl(p: Path):
    n=0
    with p.open(encoding="utf-8") as f:
        for i,line in enumerate(f,1):
            if not line.strip():
                continue
            try: json.loads(line)
            except Exception as e:
                raise SystemExit(f"{p}:{i}: JSON inválido: {e}")
            n+=1
    return n

def main(base: Path):
    mf=base/"manifests"/"live_export_manifest.json"
    if not mf.exists():
        raise SystemExit("manifesto live_export_manifest.json ausente")
    m=json.loads(mf.read_text(encoding="utf-8"))
    errors=[]
    for name,meta in m.get("tables",{}).items():
        if meta.get("omitted_by_scope") or not meta.get("present", True):
            continue
        p=base/"data"/"raw"/f"{name}.jsonl"
        if not p.exists():
            errors.append(f"{name}: arquivo ausente")
            continue
        rows=count_jsonl(p)
        if rows != meta.get("rows"):
            errors.append(f"{name}: rows {rows} != manifesto {meta.get('rows')}")
        if meta.get("sha256") and sha256(p) != meta["sha256"]:
            errors.append(f"{name}: SHA256 divergente")
    # integridade FK básica doc -> chunks
    docs=set()
    dp=base/"data"/"raw"/"knowledge_docs.jsonl"
    cp=base/"data"/"raw"/"knowledge_chunks.jsonl"
    if dp.exists():
        for l in dp.open(encoding="utf-8"):
            if l.strip(): docs.add(str(json.loads(l)["id"]))
    if cp.exists():
        for i,l in enumerate(cp.open(encoding="utf-8"),1):
            if not l.strip(): continue
            r=json.loads(l)
            if str(r.get("doc_id")) not in docs:
                errors.append(f"knowledge_chunks:{i}: doc_id órfão {r.get('doc_id')}")
                if len(errors)>50: break
    if errors:
        print(json.dumps({"ok":False,"errors":errors},ensure_ascii=False,indent=2))
        raise SystemExit(2)
    print(json.dumps({"ok":True,"documents":len(docs)},ensure_ascii=False,indent=2))

if __name__=="__main__":
    if len(sys.argv)!=2:
        raise SystemExit("uso: validate_bundle.py <diretorio-exportado>")
    main(Path(sys.argv[1]))
