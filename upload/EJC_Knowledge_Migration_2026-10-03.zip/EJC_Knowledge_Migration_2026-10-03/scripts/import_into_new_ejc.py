#!/usr/bin/env python3
"""Importador de referência para o Knowledge Core V2.

Requer:
  - PostgreSQL do NOVO EJC;
  - schema/schema knowledge_core_v2.sql aplicado;
  - DATABASE_URL_SYNC no ambiente (psycopg/SQLAlchemy URL síncrona).

É idempotente por PK. Não sobrescreve conteúdo existente silenciosamente:
ON CONFLICT atualiza somente campos equivalentes do mesmo ID.
Embeddings permanecem NULL e devem ser regenerados no novo EJC.
"""
from __future__ import annotations
import argparse, json, os
from pathlib import Path
from sqlalchemy import create_engine, text

def rows(path: Path):
    if not path.exists():
        return
    with path.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)

def scope_of(d):
    b=d.get("base_rag")
    if b in ("publica","escritorio","caso"):
        return b
    if d.get("case_id"): return "caso"
    if d.get("client_id"): return "escritorio"
    return "publica"

def main(bundle: Path, db_url: str):
    eng=create_engine(db_url, future=True)
    raw=bundle/"data"/"raw"
    with eng.begin() as c:
        for d in rows(raw/"knowledge_docs.jsonl") or []:
            c.execute(text("""
              INSERT INTO knowledge_documents
              (id,title,category,source_ref,tribunal,metadata,scope,client_id,case_id,
               origin_key,content_hash,source_updated_at,version,current,
               previous_version_id,reviewed,reviewed_by,reviewed_at,created_at,deleted_at)
              VALUES
              (:id,:title,:category,:source_ref,:tribunal,CAST(:metadata AS jsonb),:scope,
               :client_id,:case_id,:origin_key,:content_hash,:source_updated_at,:version,
               :current,:previous_version_id,:reviewed,:reviewed_by,:reviewed_at,:created_at,:deleted_at)
              ON CONFLICT (id) DO UPDATE SET
                title=EXCLUDED.title, category=EXCLUDED.category,
                source_ref=EXCLUDED.source_ref, tribunal=EXCLUDED.tribunal,
                metadata=EXCLUDED.metadata, scope=EXCLUDED.scope,
                client_id=EXCLUDED.client_id, case_id=EXCLUDED.case_id,
                origin_key=EXCLUDED.origin_key, content_hash=EXCLUDED.content_hash,
                source_updated_at=EXCLUDED.source_updated_at,
                version=EXCLUDED.version, current=EXCLUDED.current,
                previous_version_id=EXCLUDED.previous_version_id,
                reviewed=EXCLUDED.reviewed, reviewed_by=EXCLUDED.reviewed_by,
                reviewed_at=EXCLUDED.reviewed_at, deleted_at=EXCLUDED.deleted_at
            """), {
                "id": d["id"], "title": d["titulo"], "category": d["categoria"],
                "source_ref": d.get("fonte"), "tribunal": d.get("tribunal"),
                "metadata": json.dumps(d.get("extra") or {}, ensure_ascii=False),
                "scope": scope_of(d), "client_id": d.get("client_id"), "case_id": d.get("case_id"),
                "origin_key": d.get("chave_origem"), "content_hash": d.get("hash_conteudo"),
                "source_updated_at": d.get("atualizado_em"), "version": d.get("versao") or 1,
                "current": bool(d.get("vigente", True)),
                "previous_version_id": d.get("versao_anterior_id"),
                "reviewed": bool(d.get("revisado", False)),
                "reviewed_by": d.get("revisado_por"), "reviewed_at": d.get("revisado_em"),
                "created_at": d.get("created_at"), "deleted_at": d.get("deleted_at"),
            })

        for k in rows(raw/"knowledge_chunks.jsonl") or []:
            c.execute(text("""
              INSERT INTO knowledge_chunks
              (id,document_id,chunk_index,page,content,embedding,created_at)
              VALUES (:id,:doc,:idx,:page,:content,NULL,:created)
              ON CONFLICT (id) DO UPDATE SET
                document_id=EXCLUDED.document_id, chunk_index=EXCLUDED.chunk_index,
                page=EXCLUDED.page, content=EXCLUDED.content, embedding=NULL
            """), {"id":k["id"],"doc":k["doc_id"],"idx":k["chunk_index"],
                    "page":k.get("pagina"),"content":k["conteudo"],"created":k.get("created_at")})

        for t in rows(raw/"teses.jsonl") or []:
            c.execute(text("""
              INSERT INTO knowledge_theses
              (id,title,description,legal_basis,jurisprudence,counterargument,legal_area,
               tribunal,magistrate,tags,notes,thesis_type,status,times_used,times_won,
               times_lost,success_rate,created_by,created_at,updated_at,deleted_at)
              VALUES (:id,:title,:description,:legal_basis,:jurisprudence,:counterargument,
               :legal_area,:tribunal,:magistrate,:tags,:notes,:thesis_type,:status,
               :times_used,:times_won,:times_lost,:success_rate,:created_by,:created_at,
               :updated_at,:deleted_at)
              ON CONFLICT (id) DO UPDATE SET
               title=EXCLUDED.title,description=EXCLUDED.description,
               legal_basis=EXCLUDED.legal_basis,jurisprudence=EXCLUDED.jurisprudence,
               counterargument=EXCLUDED.counterargument,legal_area=EXCLUDED.legal_area,
               tribunal=EXCLUDED.tribunal,magistrate=EXCLUDED.magistrate,
               tags=EXCLUDED.tags,notes=EXCLUDED.notes,thesis_type=EXCLUDED.thesis_type,
               status=EXCLUDED.status,times_used=EXCLUDED.times_used,
               times_won=EXCLUDED.times_won,times_lost=EXCLUDED.times_lost,
               success_rate=EXCLUDED.success_rate,updated_at=EXCLUDED.updated_at,
               deleted_at=EXCLUDED.deleted_at
            """), {
              "id":t["id"],"title":t["titulo"],"description":t["descricao"],
              "legal_basis":t.get("fundamentacao"),"jurisprudence":t.get("jurisprudencia"),
              "counterargument":t.get("contra_argumento"),"legal_area":t.get("area_juridica"),
              "tribunal":t.get("tribunal"),"magistrate":t.get("magistrado"),
              "tags":t.get("tags"),"notes":t.get("observacoes"),
              "thesis_type":t.get("tipo"),"status":t.get("status"),
              "times_used":t.get("vezes_usada") or 0,"times_won":t.get("vezes_venceu") or 0,
              "times_lost":t.get("vezes_perdeu") or 0,"success_rate":t.get("taxa_sucesso"),
              "created_by":t.get("created_by"),"created_at":t.get("created_at"),
              "updated_at":t.get("updated_at"),"deleted_at":t.get("deleted_at"),
            })
    print(json.dumps({"ok":True,"embeddings":"pending_regeneration"},ensure_ascii=False))

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("bundle")
    ap.add_argument("--database-url", default=os.getenv("DATABASE_URL_SYNC"))
    a=ap.parse_args()
    if not a.database_url:
        raise SystemExit("DATABASE_URL_SYNC ausente")
    main(Path(a.bundle), a.database_url)
