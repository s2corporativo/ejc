Corpus versionado confirmado em backend/seeds/biblia_ejc/*.jsonl no repositório EJC. Os corpos dos JSONL não foram materializados nesta sessão. O export da base viva os inclui se já ingeridos.
