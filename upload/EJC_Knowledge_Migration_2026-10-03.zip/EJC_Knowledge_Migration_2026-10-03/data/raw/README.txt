Os JSONL da base viva serão gerados pelo scripts/export_ejc_knowledge.py no ambiente autorizado.
