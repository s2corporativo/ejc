-- EJC Knowledge Core V2 - schema de referência
-- Ajustar nomes/FKs às tabelas reais do novo EJC antes do go-live.
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS knowledge_sources (
    id text PRIMARY KEY,
    description text NOT NULL,
    category text,
    active boolean NOT NULL DEFAULT true,
    last_run timestamptz,
    last_status text,
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS knowledge_documents (
    id text PRIMARY KEY,
    title text NOT NULL,
    category text NOT NULL,
    source_ref text,
    tribunal text,
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    scope text NOT NULL CHECK (scope IN ('publica','escritorio','caso')),
    client_id text,
    case_id text,
    origin_key text,
    content_hash text,
    source_updated_at timestamptz,
    version integer NOT NULL DEFAULT 1,
    current boolean NOT NULL DEFAULT true,
    previous_version_id text,
    reviewed boolean NOT NULL DEFAULT false,
    reviewed_by text,
    reviewed_at timestamptz,
    created_at timestamptz,
    deleted_at timestamptz
);

CREATE INDEX IF NOT EXISTS ix_knowledge_documents_origin_key
  ON knowledge_documents(origin_key);
CREATE INDEX IF NOT EXISTS ix_knowledge_documents_scope
  ON knowledge_documents(scope, client_id, case_id);
CREATE INDEX IF NOT EXISTS ix_knowledge_documents_current
  ON knowledge_documents(current) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS knowledge_chunks (
    id text PRIMARY KEY,
    document_id text NOT NULL REFERENCES knowledge_documents(id) ON DELETE CASCADE,
    chunk_index integer NOT NULL,
    page integer,
    content text NOT NULL,
    embedding vector(1024),
    created_at timestamptz,
    UNIQUE(document_id, chunk_index)
);

CREATE TABLE IF NOT EXISTS knowledge_theses (
    id text PRIMARY KEY,
    title text NOT NULL,
    description text NOT NULL,
    legal_basis text,
    jurisprudence text,
    counterargument text,
    legal_area text,
    tribunal text,
    magistrate text,
    tags text,
    notes text,
    thesis_type text,
    status text,
    times_used integer NOT NULL DEFAULT 0,
    times_won integer NOT NULL DEFAULT 0,
    times_lost integer NOT NULL DEFAULT 0,
    success_rate double precision,
    created_by text,
    created_at timestamptz,
    updated_at timestamptz,
    deleted_at timestamptz
);

CREATE TABLE IF NOT EXISTS knowledge_thesis_case_links (
    id text PRIMARY KEY,
    thesis_id text NOT NULL REFERENCES knowledge_theses(id) ON DELETE CASCADE,
    case_id text NOT NULL,
    result text,
    note text,
    created_at timestamptz,
    created_by text
);
