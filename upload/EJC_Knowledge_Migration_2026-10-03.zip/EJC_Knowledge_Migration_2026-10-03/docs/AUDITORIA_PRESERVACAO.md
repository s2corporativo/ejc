# Auditoria de preservação

## Confirmado no EJC atual

O modelo `KnowledgeDoc` preserva:
- título, categoria, fonte, tribunal e JSON `extra`;
- base RAG explícita (`publica`, `escritorio`, `caso`);
- isolamento por `client_id` e `case_id`;
- `chave_origem` e `hash_conteudo`;
- estado de indexação;
- versão, vigência e vínculo com versão anterior;
- revisão humana (`revisado`, `revisado_por`, `revisado_em`);
- timestamps e soft-delete.

`KnowledgeChunk` preserva:
- documento pai;
- índice do chunk;
- página original;
- conteúdo textual;
- embedding derivado;
- timestamp.

`FonteIngestao` mantém telemetria/rastreabilidade dos ingestores.

O Banco de Teses usa `teses` e `tese_caso_links`.

## Base versionada confirmada

A "Bíblia de Conhecimento EJC" é corpus didático/fictício versionado em
`backend/seeds/biblia_ejc/*.jsonl`. O próprio seed grava
`extra.ficticio=true`, `rag_status=aprovado`, `uso_autorizado=estrutura`,
confiança `media`, e usa chaves `biblia_ejc:*`.

Arquivos confirmados pelo README do repositório:
- situacoes.jsonl — 84 situações;
- instrucoes.jsonl;
- governanca.jsonl;
- modelos.jsonl — 221 modelos;
- modelos_vol3.jsonl — 48 modelos.

Esse material **não deve ser confundido com jurisprudência real**.

## Não transferir como fonte de verdade

- embeddings/vetores;
- caches;
- respostas soltas de IA;
- chats não revisados;
- logs que contenham prompts/PII sem necessidade;
- monkey patches e compatibilidade de runtime;
- código legado do RAG apenas por existir.

## Gate de homologação

A migração só é aprovada se:
1. 100% dos documentos esperados estiverem presentes pelo manifesto/hash;
2. nenhum chunk apontar para documento inexistente;
3. todos os escopos restritos continuarem restritos;
4. documentos fictícios preservarem o marcador;
5. documentos não revisados não forem promovidos indevidamente;
6. embeddings forem regenerados no destino;
7. busca pública não retornar conteúdo de cliente/caso;
8. testes de citação/proveniência passarem.
