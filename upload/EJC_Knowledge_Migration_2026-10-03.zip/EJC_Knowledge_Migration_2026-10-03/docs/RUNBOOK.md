# Runbook operacional

## 1. No EJC atual (VPS autorizada)

```bash
cd /opt/ejc-deploy-src/backend   # ajuste ao caminho real confirmado na VPS
umask 077
python /caminho/export_ejc_knowledge.py --output /tmp/ejc-knowledge-export --scope all
python /caminho/validate_bundle.py /tmp/ejc-knowledge-export
```

Faça backup normal do EJC antes de qualquer migração. O exportador é somente leitura.

## 2. Confira

- `manifests/live_export_manifest.json`
- contagens
- SHA-256
- presença de `knowledge_docs.jsonl`
- presença de `knowledge_chunks.jsonl`
- presença de `fontes_ingestao.jsonl`
- `teses.jsonl`, se a tabela existir

## 3. Transferência

Mover por canal seguro. O pacote pode conter sigilo profissional e dados pessoais.

## 4. No novo EJC

1. Aplicar `schema/knowledge_core_v2.sql` em ambiente de homologação.
2. Rodar `validate_bundle.py`.
3. Rodar `import_into_new_ejc.py`.
4. Regenerar embeddings.
5. Executar testes de isolamento e retrieval.
6. Só depois promover para produção.

## 5. Rollback

A importação deve ocorrer em banco novo/snapshot. Em caso de falha:
- descartar o banco/snapshot de homologação;
- manter o EJC atual intocado;
- corrigir mapeamento;
- repetir a importação.
